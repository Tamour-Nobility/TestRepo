using System.Collections.Generic;
using System.Web.Mvc;
using MvcDigitalSignatureDemo.Models;

namespace MvcDigitalSignatureDemo.Controllers
{
    public class SignatureController : Controller
    {
        private static List<SignatureModel> InMemoryDb = new List<SignatureModel>();

        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Submit(SignatureModel model)
        {
            if (ModelState.IsValid)
            {
                InMemoryDb.Add(model);
                ViewBag.Message = "Signature saved successfully.";
            }
            return View("Index");
        }

        public ActionResult List()
        {
            return View(InMemoryDb);
        }
    }
}