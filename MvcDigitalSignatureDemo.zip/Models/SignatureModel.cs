namespace MvcDigitalSignatureDemo.Models
{
    public class SignatureModel
    {
        public int Id { get; set; }
        public string SignerName { get; set; }
        public string SignatureImageBase64 { get; set; }
    }
}