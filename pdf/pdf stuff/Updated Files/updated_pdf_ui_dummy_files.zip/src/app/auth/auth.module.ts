import { ErrorHandler, NgModule } from '@angular/core';
import { LoginComponent } from './Login/login.component';
import { SharedModule } from '../shared/shared.module';
import { NgOtpInputModule } from 'ng-otp-input';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { OtpComponent } from './otp/otp.component';


@NgModule({
  declarations: [
    LoginComponent,
    ForgotPasswordComponent,
    OtpComponent,

  ],
  imports: [
    SharedModule,
    NgOtpInputModule
  ]
  ,
  providers: [

   
  ],
})
export class AuthModule { }
