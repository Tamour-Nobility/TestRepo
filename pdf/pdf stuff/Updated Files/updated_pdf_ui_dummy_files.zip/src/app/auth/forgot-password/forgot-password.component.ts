import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AuthService } from '../../services/auth/auth.service';
import { AlertService } from '../../services/data/Alert.service';
import { TokenRequestModel } from '../../models/token/token.model';
import { ResetPasswordViewModel } from '../../user-management/classes/requestResponse';
import { APIService } from '../../components/services/api.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { AbstractControl, ValidationErrors } from '@angular/forms';
import { AccessViewModel } from '../../models/auth/auth';
import { NgOtpInputComponent } from 'ng-otp-input';
 
 
 
@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {
    Year = (new Date()).getFullYear();
  currentView: 'forgotEmail' | 'forgotOtp' | 'resetPassword' = 'forgotEmail';
  clicked = false; // for button loader
  email: string = '';
  step: 'email' | 'otp' = 'email'; // control screen
  forgotEmailForm: FormGroup;
  resetPasswordForm: FormGroup;
  otpForm!: FormGroup;
  submitted = false;
  otpValue = '';
  passwordMismatch = false;
showPasswordCriteriaError = false;
updatePaswordLoader:boolean = true;
resendOTPMessage:boolean=false;
 otpError: boolean = false;
otpErrorMessage: string = '';
 
  showPassword = false;
  showConfirmPassword = false;
passwordError = false;
  @ViewChild(NgOtpInputComponent,) ngOtpInputRef!: NgOtpInputComponent;
passwordErrorTitle = "Entered password doesn't match the criteria.";
  // otpConfig = {
  //   length: 6,
  //   allowNumbersOnly: true
  // };
  forgotUserId: any; // from backend after email check
  tokenRequestModel: TokenRequestModel;
    objResetPasswordViewModel: ResetPasswordViewModel;
      accessViewModel:AccessViewModel;
   
 
 
  constructor(
    private fb: FormBuilder,
    private router: Router,
    private toastr: ToastrService,
     private authService: AuthService,
        private alertService: AlertService,
        private apiService: APIService,
          private spinner: NgxSpinnerService,
  ) {
   
 
    this.resetPasswordForm = this.fb.group({
      password: ['', [Validators.required]],
      confirmPassword: ['', [Validators.required]]
    });
        this.tokenRequestModel = new TokenRequestModel();
            this.accessViewModel=new AccessViewModel();
                this.objResetPasswordViewModel = new ResetPasswordViewModel();
 
 
 
  }
 
  ngOnInit(): void {
    this.forgotEmailForm = this.fb.group({
    email: ['', [Validators.required, Validators.email]]
   //  email: ['', [Validators.required, Validators.email, this.emailDomainValidator]]
  });
 
  this.otpForm = this.fb.group({
    otp: ['', [Validators.required, Validators.minLength(6)]]
  });
    // Show toaster when component first loads
    // if (this.currentView === 'forgotEmail') {
    //   this.toastr.info(
    //     "Enter the email address and we'll send you an OTP to reset your password.",
    //     'Forgot Password',
    //     { timeOut: 5000, closeButton: true }
    //   );
    // }
  }
 config = {
    allowNumbersOnly: true,
    length: 6,
    isPasswordInput: false,
    disableAutoFocus: true,
    placeholder: 0,
 
    inputStyles: {
      'width': '35px',
      'height': '40px',
      'border': '3px groove',
      'background': 'rgba(255, 255, 255, 0.25)'
     
 
    },
 
    inputClass:'each_input',
    containerClass:'all_inputs'
  };
  // Custom email domain validator
emailDomainValidator(control: AbstractControl): ValidationErrors | null {
  const email = control.value;
  if (email && email.indexOf('@') !== -1) {
    const [, domain] = email.split('@');
    if (domain.toLowerCase() !== 'nobilityrcm.com') {
      return { domainInvalid: true };
    }
  }
  return null;
}
maskEmail(email: string): string {
  if (!email) return '';
  const [user, domain] = email.split('@');
  if (!domain) return email;
  const visibleUser = user.substring(0, 2);
  const maskedUser = visibleUser + '*'.repeat(Math.max(0, user.length - 2));
  const domainName = domain.split('.')[0];
  const domainExt = domain.substring(domainName.length);
 
  const visibleDomain = domainName.substring(0, 3);
  const maskedDomain = visibleDomain + '*'.repeat(Math.max(0, domainName.length - 3));
 
  return `${maskedUser}@${maskedDomain}${domainExt}`;
}
 
sendForgotOtp() {
  this.submitted = true;
 debugger;
  if (this.forgotEmailForm.invalid) {
    if (this.forgotEmailForm.controls['email'].errors['domainInvalid']) {
      this.toastr.error('Email must end with @nobilityrcm.com', 'Invalid Email');
    } else {
      debugger;
      this.toastr.error('Please enter a valid email address', 'Invalid Email');
    }
    return;
  }
 
  this.clicked = true;  
 
  this.tokenRequestModel.Grant_Type = "resetPassword";
  this.tokenRequestModel.Username = this.forgotEmailForm.value.email;
 
  this.authService.Token(this.tokenRequestModel).subscribe({
    next: (res) => {
      // this.spinner.hide();
      this.clicked = false;
      //  this.resendOTPMessage = false;
 
      if (res) {
        debugger;
        this.forgotUserId = res.UserId / 23443;
        this.currentView = 'forgotOtp'; // go to OTP screen
      }
    },
    error: (err) => {
      debugger
      console.log('error in auth email ',err)
      // this.spinner.hide();
      this.clicked = false; // reset button state
      this.toastr.error('Please enter a valid email address', "Error");
      console.error(err);
    }
  });
}
 
 
onForgotOtpChange(otp: string) {
  if (!otp || otp.trim() === '') {
    return;
  }

  this.otpValue = otp;
  this.otpErrorMessage = "";
  this.otpError = false;
  this.accessViewModel.code = otp;

  if (this.accessViewModel.code.length === 6) {
    // remove focus from the OTP fields
    if (document.activeElement instanceof HTMLElement) {
      document.activeElement.blur();
    }

    this.verifyForgotOtp();
  }
}
 
  // verifyForgotOtp() {
  //   debugger;
   
verifyForgotOtp() {
  if (this.otpValue.length === 6) {
    this.clicked = true;
    this.accessViewModel.userid = this.forgotUserId;
    this.accessViewModel.code = this.otpValue;
 
    this.authService.Code(this.accessViewModel).subscribe({
      next: (res) => {
        this.clicked = false;
        this.otpError = false; // clear old error
 debugger;
        if (res != null) {
          this.toastr.success('OTP verified successfully');
          this.currentView = 'resetPassword';
          this.updatePaswordLoader = false;
             this.otpErrorMessage = ""
               this.otpError = false;
        }
      },
      error: (err) => {
        debugger
        this.clicked = false;
        this.setOtpError(err); // call helper method
      }
    });
  } else {
    debugger
    this.setOtpError(null, 'Please enter a valid 6-digit OTP');
  }
}
 
 
  resendForgotOtp() {
      this.resendOTPMessage=true
     // clear old error

this.sendForgotOtp();
    console.log('Resending OTP to', this.forgotEmailForm.value.email);
    // this.toastr.info(`OTP re-sent to ${this.forgotEmailForm.value.email}`);
  }

  updatePassword() {
  this.clicked = true;
 
  if (this.resetPasswordForm.invalid) return;
 
  const { password, confirmPassword } = this.resetPasswordForm.value;
 
  // Password criteria regex
  const passwordCriteria = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!^%$*&@#_\-]).{8,}$/;
 
  // Validate criteria
  this.showPasswordCriteriaError = !passwordCriteria.test(password);
  if (this.showPasswordCriteriaError) return;
 
  // Validate match
  this.passwordMismatch = password !== confirmPassword;
  if (this.passwordMismatch) return;
 
  if (this.forgotUserId == null) {
    this.toastr.warning('User not identified. Please try again.', 'Validation');
    return;
  }
 
  // Prepare API model
  this.objResetPasswordViewModel = {
    UserId: this.forgotUserId,
    Password: password,
    ConfirmPassword: confirmPassword
  };
 
  this.updatePaswordLoader = true;
 
  this.apiService.PostDataWithoutSpinner('/Token/ResetPasswordForOTP', this.objResetPasswordViewModel, (response) => {
    this.updatePaswordLoader = false;
 
    if (response.Status === 'Success') {
      this.toastr.success('Password has been reset successfully.', 'Reset Password');
      this.router.navigate(['/login']);
    } else {
      this.toastr.error(response.Response || 'An error occurred.', 'Error');
    }
  });
}
 
/** Allow only valid characters in password input */
allowOnlyValidChars(event: KeyboardEvent) {
  const allowedPattern = /^[a-zA-Z0-9!^%$*&#@_\-]$/;
  const inputChar = event.key;
  // allow Enter key (do not block it)
  if (inputChar === 'Enter') {
    return;
  }
 
  if (!allowedPattern.test(inputChar)) {
    event.preventDefault(); // block invalid character
  }
}

  backToLogin() {
    this.router.navigate(['/login']);
  }

setOtpError(status?: any, customMessage?: string) {
  debugger
  this.otpError = true;
 
  if (customMessage) {
    this.otpErrorMessage = customMessage;
    return;
  }
 
  if (status === 401) {
    this.otpErrorMessage = 'Invalid OTP Code';
  } else if (status === 400) {
    this.otpErrorMessage = 'Bad Request';
  } else if (status === 500) {
    this.otpErrorMessage = 'Internal Server Error';
  } else {
        debugger;
    this.otpErrorMessage = status;
  }
    // 🔑 Clear OTP input field
  this.otpValue = '';
  if (this.ngOtpInputRef) {
    this.ngOtpInputRef.setValue('');
  }
    // Prevent blinking cursor (remove focus from otp fields)
    setTimeout(() => {
      const activeElement = document.activeElement as HTMLElement;
      if (activeElement) {
        activeElement.blur();
      }
    }, 0);

      setTimeout(() => {
    this.otpError = false;
    this.otpErrorMessage = '';
  }, 4000);
}
onEnter(event: Event, inputEl: HTMLInputElement) {
  debugger;
  event.preventDefault();
  inputEl.blur(); // 👈 force cursor to leave input
  this.sendForgotOtp();
}

onBlur(event: Event) {
  this.sendForgotOtp();
}

 
}