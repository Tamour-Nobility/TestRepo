import {
    Component, OnInit, ChangeDetectorRef, ViewChild, ViewContainerRef,
    ComponentFactoryResolver, ComponentRef, Input
} from '@angular/core';
import { DatePipe } from '@angular/common';
import { APIService } from '../../components/services/api.service';
import { GvarService } from '../../components/services/GVar/gvar.service';
import { Router, ActivatedRoute } from '@angular/router';
import { zipdata } from '../../patient/Classes/patientInsClass';
import { ProviderModel, SaveProviderModel, Specilization, WCBRating, SpecialtyGroups, SpecialtyCategory, DocumentModel } from '../providers/Classes/providersClass';
import { IMyDate, IMyDpOptions } from 'mydatepicker';
declare var $: any
import 'datatables.net';
import { trim } from 'jquery';
import { ToastrService } from 'ngx-toastr';
import { CurrentUserViewModel } from '../../models/auth/auth';
import { GvarsService } from '../../services/G_vars/gvars.service';
import * as moment from 'moment';
import { FileHandlerService } from '../../components/services/file-handler/filehandler.service';
import { Common } from '../../../app/services/common/common';

@Component({
    selector: 'app-providers',
    templateUrl: './providers.component.html',
    styleUrls: ['./providers.component.css']
})
export class ProvidersComponent implements OnInit {
    @Input() listSpecilization: Specilization[];
    @Input() listWCBRating: WCBRating[];
    @Input() listSpecialtyGroups: SpecialtyGroups[];
    @Input() listSpecializations: Specilization[];
    specialtyCategoryOne: SpecialtyCategory[];
    specialtyCategoryTwo: SpecialtyCategory[];
    SelectedSpecialityCategoryOne: SpecialtyCategory;
    SelectedSpecialityGroup: SpecialtyGroups;
    public isEdit = false;
    public isList = true;
    public myDatePickerOptions: IMyDpOptions = {
        dateFormat: 'mm/dd/yyyy', height: '20px', width: '100%',
         editableDateField: false,
          openSelectorOnInputClick: true
    };
    public placeholder: string = 'MM/DD/YYYY';
    providersModel: ProviderModel[];
    saveProviderModel: SaveProviderModel;
    docModel:DocumentModel;
    
    provtable: any;
    dataTable: any;
    zipData: zipdata;
    cmpRef: ComponentRef<any>;
    strProv_DOB: string = "";
    strProv_DEA_EXP: string = "";
    bISview: boolean = false;
    SelectedPracticeCode: number;
    isNew: boolean;
    zipProviderData: zipdata[];
    TaxonomyCode: any;
    NPICODE :any;
     currentUser: CurrentUserViewModel;
       moduleExists = false;
      subModuleExists = false;
      addProviderPropertyExist=false;
      editProviderPropertyExist=false;
      viewProviderPropertyExist=false;
      activeProviderPropertyExist=false;
      proDocSubModule=false
      addProviderDocExist=false
      editProviderDocExist=false
      deleteProviderDocExist
      charCount: number = 0
      providerDocId:number=0
        providerCode:number=0
        selectedDocumentType:any= null;
        selectedDocumentShow:any= null;
        selectedMessage: any = "";
        docTable:any;
        selectedFiles: File[] = [];
      docTypeList: any[] = [];
       issuedate: IMyDate =null;
    expirydate:IMyDate = null;
       showIssueDatePicker: boolean = true;
    showExpiryDatePicker: boolean = true;
         public placeholdertxt: string = 'MM/DD/YYYY';
      searchableDocTypeList: { Type_Value: number, Type_Dec: string }[] = [];
      proStateList :any[]=[];
      docList:any[]=[];
      attachLink:boolean=false;
           backupFile: any = null;
     deletedFile: any = null;
     fileValidationUpdate:boolean=false
  

    constructor(private chRef: ChangeDetectorRef,
        public datepipe: DatePipe,
        public router: Router,
        public route: ActivatedRoute,
        public API: APIService,
        private cdr: ChangeDetectorRef,
        private toaster: ToastrService,
        private componentFactoryResolver: ComponentFactoryResolver,
        public Gv: GvarService,
        private gvService: GvarsService,
       private _fileHandlerService: FileHandlerService) {
        this.providersModel = [];
        this.saveProviderModel = new SaveProviderModel;
        this.docModel= new DocumentModel;
        this.listSpecilization = [];
        this.specialtyCategoryOne = [];
        this.specialtyCategoryTwo = [];
        this.SelectedSpecialityGroup = new SpecialtyGroups();
        this.SelectedSpecialityCategoryOne = new SpecialtyCategory();
        this.zipProviderData=[];
      
    
    }

    ngOnInit() {
        this.route.params.subscribe(params => {
            if (params['id'] !== 0 && params['id'] !== '0') {
                this.SelectedPracticeCode = params['id'];
                this.GetPracticeProvidersList();
                this.checkProviderAccess(this.gvService.currentUser.RolesAndRights);
                this.checkProviderDocAccess(this.gvService.currentUser.RolesAndRights);
            }
        });
        if(this.SelectedPracticeCode)
            {
                this.TaxonomyCodes();
            }
                
    }

    GetPracticeProvidersList(type: string = "") {
        if (this.SelectedPracticeCode == null || this.SelectedPracticeCode == 0 || this.SelectedPracticeCode == undefined)
            return;
        this.API.getData('/PracticeSetup/GetProviders?PracticeId=' + this.SelectedPracticeCode).subscribe(
            data => {
                if (data.Status === 'Sucess') {
                    if (this.provtable) {
                        this.provtable.destroy();
                    }
                    this.providersModel = data.Response;
                    this.chRef.detectChanges();
                    this.provtable = $('.provtable').DataTable({
                        language: {
                            emptyTable: "No data available"
                        }
                    });
                } else {
                    swal('Failed', data.Status, 'error');
                }
            }
        );
    }


    GetSpecilization() {
        this.API.getData('/PracticeSetup/GetSpecilization').subscribe(
            data => {
                if (data.Status === 'Sucess') {
                    this.listSpecilization = data.Response;
                } else {
                    swal('Failed', data.Status, 'error');
                }
            }
        );
    }
    //   GetWCBRating() {
    //     this.API.getData('/PracticeSetup/GetWCBRating').subscribe(
    //         data => {
    //             if (data.Status === 'Sucess') {
    //                 this.listWCBRating = data.Response;
    //             } else {
    //                 swal('Failed', data.Status, 'error');
    //             }
    //         }
    //     );
    //   }
    showList() {
        this.isList = true;
        this.isEdit = false;
        this.GetPracticeProvidersList("List");
    }
    showAdd() {
        this.isList = false;
        this.isEdit = true;
    }

    ViewProvider(Provider_Code) {
        this.bISview = true;
        this.providerCode=Provider_Code
        this.showAdd();
         this.GetDocTypeList();
        this.GetPracticeProviderDetails(Provider_Code);
       
    }
    onDateChangedExp(event, id) {
        if (id === 0) {
            this.saveProviderModel.Date_Of_Birth = event.formatted;
            this.strProv_DOB = event.formatted;
        } else {
            this.saveProviderModel.DEA_Expiry_Date = event.formatted;
            this.strProv_DEA_EXP = event.formatted;
        }
    }
    AddProvider() {
        if (this.saveProviderModel.Provider_Code === undefined || this.saveProviderModel.Provider_Code === 0 || this.saveProviderModel.Provider_Code === null) {
            this.saveProviderModel.Provider_Code = 0;
            this.saveProviderModel.Practice_Code = this.SelectedPracticeCode;
            this.saveProviderModel.Is_Active = true;
            this.saveProviderModel.Deleted = false;
        }
        if (!this.canSave())
            return;

        this.saveProviderModel.Date_Of_Birth = this.datepipe.transform(this.strProv_DOB, 'MM/dd/yyyy');
        this.saveProviderModel.DEA_Expiry_Date = this.datepipe.transform(this.strProv_DEA_EXP, 'MM/dd/yyyy');
        this.saveProviderModel.Gender = trim(this.saveProviderModel.Gender);
        this.saveProviderModel.Provid_MName = trim(this.saveProviderModel.Provid_MName);
        this.saveProviderModel.grp_taxonomy_id=this.TaxonomyCode;
        this.API.PostData('/PracticeSetup/SaveProvider/', this.saveProviderModel, (d) => {
            if (d.Status === 'Sucess') {
                if (this.saveProviderModel.Provider_Code == 0) {
                    swal('Provider', 'Provider has been saved successfully.', 'success');
                    this.saveProviderModel.Provider_Code = d.Response;
                }
                else
                    swal('Provider', 'Provider has been updated successfully.', 'success');
                this.resetProviderDetails(d.Response);
            }
        });
    }
    onBlurMethod() {
        this.API.getData('/Demographic/GetCitiesByZipCode?ZipCode=' + this.saveProviderModel.ZIP).subscribe(
            data => {
                if (data.Status === 'Sucess') {
                    this.zipProviderData = data.Response;
                    this.saveProviderModel.CITY = this.zipProviderData[0].CityName;
                    this.saveProviderModel.STATE = this.zipProviderData[0].State;
                } else {
                    this.saveProviderModel.CITY = '';
                    this.saveProviderModel.CITY = '';
                }
            }
        );
    }
    EditProvider(Provider_Code) {
        this.providerCode=Provider_Code
        this.GetDocTypeList();
        this.showAdd();
        this.bISview = false;
        this.GetPracticeProviderDetails(Provider_Code);
        this.isNew = false;
    }

    resetProviderDetails(Provider_Code) {
        this.bISview = !this.bISview;
        this.GetPracticeProviderDetails(Provider_Code);
    }

    resetFields() {
        this.showList();
        this.saveProviderModel = new SaveProviderModel;
        if (this.isNew) {
            this.isNew = !this.isNew;
        }
    }
    ActiveInactiveProvider(Provider_Code) {
        let selectedProvider = this.providersModel.find(t => t.Provider_Code == Provider_Code);
        this.API.confirmFun('Confirmation', `Are you sure you want to ${!selectedProvider.Is_Active ? 'active' : 'inactive'} this provider?`, () => {
            this.API.getData('/PracticeSetup/ActivateInActiveProvider?providerId=' + Provider_Code + '&PracticeId=' + this.SelectedPracticeCode + '&isActive=' + !selectedProvider.Is_Active).subscribe(
                data => {
                    swal('Provider', 'Provider status has been changed successfully.', 'success');
                    this.GetPracticeProvidersList();
                });
        });
    }
     //added by pir ubaid - get taxonomy code for payer mapping
     TaxonomyCodes() {
        this.API.getData('/PracticeSetup/TaxonomyCode?PracticeId=' + this.SelectedPracticeCode).subscribe( data => {
                    if (data.Status === "Success") {
                        this.TaxonomyCode = data.Response; 
                        } else {
                    }
                },
                (error) => {
                    console.error("Error fetching taxonomy code:", error);
                }
            );
    }
    
    NPICode() {
        this.API.getData('/PracticeSetup/NPICode?PracticeId=' + this.SelectedPracticeCode).subscribe(
            (data) => {
                if (data.Status === "Success") {
                    // Assign the API response directly to group_npi
                    this.saveProviderModel.group_npi = data.Response;
                } else {
                   
                }
            },
            (error) => {
                console.error("Error fetching NPI code:", error);
            }
        );
    }

    ProviderEmptyModel() {
        this.showAdd();
        this.saveProviderModel = new SaveProviderModel;
        this.strProv_DOB = "";
        this.strProv_DEA_EXP = "";
        this.bISview = false;
        this.isNew = true;
        this.saveProviderModel.SPECIALIZATION_CODE="";
        this.saveProviderModel.GroupNo=null;
        this.saveProviderModel.Taxonomy_Code=""
        this.NPICode();    }
    GetPracticeProviderDetails(Provider_Code) {
        if (Provider_Code == undefined || Provider_Code == null || Provider_Code == '')
            return;

        this.API.getData('/PracticeSetup/GetProvider?providerId=' + Provider_Code + '&PracticeId=' + this.SelectedPracticeCode).subscribe(
            data => {
                if (data.Status === 'Sucess') {
                    this.saveProviderModel = data.Response;
                    this.saveProviderModel.Provid_FName = data.Response.Provid_FName.toUpperCase()
                    this.saveProviderModel.Provid_LName = data.Response.Provid_LName.toUpperCase()
                    this.saveProviderModel.Provid_MName = data.Response.Provid_MName ? data.Response.Provid_MName.toUpperCase() : '';
                    this.saveProviderModel.Provider_Title = data.Response.Provider_Title ? data.Response.Provider_Title.toUpperCase() : '';
                    this.saveProviderModel.ADDRESS = data.Response.ADDRESS.toUpperCase();
                    this.saveProviderModel.Address_Line2 = data.Response.Address_Line2 ? data.Response.Address_Line2.toUpperCase() : '';
                    if(this.saveProviderModel.ZIP!=""|| this.saveProviderModel.ZIP!=null){
                        
                        this.onBlurMethod();
                    }
                    this.saveProviderModel.Date_Of_Birth = this.datepipe.transform(this.saveProviderModel.Date_Of_Birth, 'MM/dd/yyyy');
                    this.saveProviderModel.DEA_Expiry_Date = this.datepipe.transform(this.saveProviderModel.DEA_Expiry_Date, 'MM/dd/yyyy');

                    this.strProv_DOB = this.saveProviderModel.Date_Of_Birth;
                    this.strProv_DEA_EXP = this.saveProviderModel.DEA_Expiry_Date;
                    if (this.saveProviderModel && this.saveProviderModel.GroupNo) {
                        this.onChangeSpecialityGroup(this.saveProviderModel.GroupNo, "edit");
                    }

                }
            });
    }


    canSave(): boolean {
         if (this.isNullOrEmptyString(this.saveProviderModel.Provid_FName)) {
            this.toaster.warning('Enter Provider First Name','Validaion');
            return false;
        }
        if (this.isNullOrEmptyString(this.saveProviderModel.Provid_LName)) {
            this.toaster.warning('Enter Provider Last Name','Validaion');
            return false;
        }
         if (this.isNullOrEmptyString(this.saveProviderModel.ADDRESS)) {
            this.toaster.warning('Enter Address.','Validaion');
            return false;
        }
        if (this.isNullOrEmptyString(this.saveProviderModel.ZIP)) {
            this.toaster.warning('Enter Zip Code','Validaion');
            return false;
        }
         if (this.isNullOrEmptyString(this.saveProviderModel.CITY)||this.saveProviderModel.CITY=="Select City" ) {
             this.toaster.warning('Enter City ','Validaion');
            return false;
        }
        else if (this.saveProviderModel.ZIP.length < 4 || this.isNullOrEmptyString(this.saveProviderModel.CITY)) {
            this.toaster.warning('Enter valid Zip Code','Validaion');
            return false;
        }
        if (this.isNullOrEmptyString(this.saveProviderModel.Phone_One)) {
             this.toaster.warning('Enter Home Ph.','Validaion');
            return false;
        }
        if ((this.saveProviderModel.Phone_One.length)!=10) {
             this.toaster.warning('Enter Valid Home Ph.','Validaion');
            return false;
        }
         if (this.isNullOrEmptyString(this.saveProviderModel.Email_Address)) {
            this.toaster.warning('Enter Email Address.','Validaion');
            return false;
        } else if (!(this.saveProviderModel.Email_Address.indexOf("@") > -1)) {
            this.toaster.warning('Enter valid Email Address.', 'Validaion');
            return false;
        }
        if (this.isNullOrEmptyString(this.saveProviderModel.Phone_One)) {
            swal('Validation Error', 'Enter Home Ph.', 'error');
            return false;
        }
         if (this.isNullOrEmptyString(this.saveProviderModel.NPI)) {
            //swal('Validation Error', 'Enter NPI Number.', 'error');
             this.toaster.warning('Enter NPI Number.','Validaion');
            return false;
        }
 
        else if (this.saveProviderModel.NPI.length != 10) {

             this.toaster.warning('Enter Valid NPI Number.','Validaion');
            return false;
        }
        if (this.isNullOrEmptyString(this.saveProviderModel.federal_taxid)) {
            this.toaster.warning('Enter Tax ID','Validaion');
            return false;
        }
          else if ((this.saveProviderModel.federal_taxid.length) != 9) {
            this.toaster.warning('Enter Valid Tax ID','Validaion');
            return false;
        }
        if (this.isNullOrEmptyString(this.saveProviderModel.SPECIALIZATION_CODE)) {
             this.toaster.warning('Select Specialization.', 'Validaion');
            return false;
        }
        if (this.isNullOrEmptyString(this.saveProviderModel.group_npi)) {
             this.toaster.warning('Enter Group NPI.','Validaion');
            return false;
        }
         else if ((this.saveProviderModel.group_npi.length)!=10) {
             this.toaster.warning('Enter Valid Group NPI.','Validaion');
            return false;
        }
        if (this.isNullOrEmptyString(this.saveProviderModel.federal_taxidnumbertype)) {
            this.toaster.warning('Select Tax ID Type.', 'Validaion');
            return false;
        }
         if (this.saveProviderModel.GroupNo == 0 || this.saveProviderModel.GroupNo == undefined) {
            this.toaster.warning('Select Taxonomy Type.', 'Validaion');
            return false;
        }
        if (this.isNullOrEmptyString(this.saveProviderModel.Taxonomy_Code)) {
            this.toaster.warning('Select Taxonomy Code from Category One.', 'Validaion');
            return false;
        }
       
        if (this.isNullOrUndefinedNumber(this.TaxonomyCode)) {
             this.toaster.warning('Select Group Taxonomy.', 'Validaion');
            return false;
        }
        if(this.saveProviderModel.Phone_Two != undefined &&  this.saveProviderModel.Phone_Two != "" && this.saveProviderModel.Phone_Two != null ){
        if (this.saveProviderModel.Phone_Two.length != 10) {
             this.toaster.warning('Enter Valid Office Ph.','Validaion');
            return false;
        }
        }
        if(this.saveProviderModel.Phone_Three != undefined &&  this.saveProviderModel.Phone_Three != "" && this.saveProviderModel.Phone_Three != null ){
        if (this.saveProviderModel.Phone_Three.length != 10) {
             this.toaster.warning('Enter Valid Cell Ph.','Validaion');
            return false;
        }
        }
       
        
        return true;
    }                     //End canSave
    //--Validation functions
    isNullOrEmptyString(str: string): boolean {
        if (str == undefined || str == null || $.trim(str) == '')
            return true;
        else
            return false;
    }


    isNullOrUndefinedNumber(num: number): boolean {
        if (num == undefined || num == null)
            return true;
        else
            return false;
    }

    isVerifyDate(date: string): boolean {
        var match = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec(date);
        if (!match)
            return false;
        else
            return true;
    }

    getProviderCode(Type: string = "") {
        this.API.Gv.ProviderCode = this.saveProviderModel.Provider_Code;
        if (Type == 'ProviderPayers') {
                setTimeout(function () {
                $("#btnProviderPayer").trigger("click");
            }, 100);
        }
        else if (Type == "ProviderNotes") {

        }
        else if (Type == "ProviderResources") {
                setTimeout(function () {
                $("#btnProviderResources").trigger("click");
            }, 100);

        }
        else {
            setTimeout(function () {
                $("#btnLoadLocation").trigger("click");
            }, 100);
        }
    }

    onChangeSpecialityGroup(data: any, type: string = 'add') {
        this.SelectedSpecialityGroup = this.listSpecialtyGroups.find(t => t.GROUP_NO == data);
        this.specialtyCategoryOne = [];
        if (type !== 'edit') {
            this.saveProviderModel.Taxonomy_Code = '';
        }
        this.SelectedSpecialityCategoryOne = new SpecialtyCategory();
        this.API.getData(`/PracticeSetup/GetPracticeSpecialityCategoryOne?GroupNo=${data}`).subscribe(
            data => {
                if (data.Status === 'Sucess') {
                    this.specialtyCategoryOne = data.Response;
                } else {
                    swal('Failed', data.Status, 'error');
                }
            }
        );
    }

    onChangePracticeSpecialityCategoryOne(data: any): any {
        this.SelectedSpecialityCategoryOne = this.specialtyCategoryOne.find(t => t.CAT_NO == data);
        this.specialtyCategoryTwo = [];
        this.API.getData(`/PracticeSetup/GetPracticeSpecialityCategoryTwo?GroupNo=${this.SelectedSpecialityGroup.GROUP_NO}&CatLevel=${this.SelectedSpecialityCategoryOne.CAT_LEVEL}`).subscribe(
            data => {
                if (data.Status === 'Sucess') {
                    this.specialtyCategoryTwo = data.Response;
                } else {
                    swal('Failed', data.Status, 'error');
                }
            }
        );
    }

    transformText(text: string) {
        return text.toLowerCase();
    }

    // Only AlphaNumeric
    keyPressAlphaNumeric(event) {
        var inp = String.fromCharCode(event.keyCode);
        if (/[a-zA-Z0-9]/.test(inp)) {
            return true;
        } else {
            event.preventDefault();
            return false;
        }
    }
    checkProviderAccess(rolesAndRights: any[]): void {
  // Step 1: Check for Module
  this.moduleExists = rolesAndRights.some(
    r => r.ModuleName === 'PracticeProfile'
  );
  // Step 2: Check for SubModule (only if module exists)
  this.subModuleExists = rolesAndRights.some(
    r => r.ModuleName === 'PracticeProfile' && r.SubModuleName === 'ProviderDetails'
  );
  // Step 3: Check for Property (only if module + submodule exist)
this.addProviderPropertyExist = rolesAndRights.some(
    r =>
     r.ModuleName === 'PracticeProfile' &&
      r.SubModuleName === 'ProviderDetails' &&
      r.PropertyName === 'AddProvider'
  );
  this.editProviderPropertyExist = rolesAndRights.some(
    r =>
     r.ModuleName === 'PracticeProfile' &&
      r.SubModuleName === 'ProviderDetails' &&
      r.PropertyName === 'EditProvider'
  );
    this.viewProviderPropertyExist = rolesAndRights.some(
    r =>
     r.ModuleName === 'PracticeProfile' &&
      r.SubModuleName === 'ProviderDetails' &&
      r.PropertyName === 'ViewProvider'
  );
      this.activeProviderPropertyExist = rolesAndRights.some(
    r =>
     r.ModuleName === 'PracticeProfile' &&
      r.SubModuleName === 'ProviderDetails' &&
      r.PropertyName === 'ActiveProvider'
  );

}
 checkProviderDocAccess(rolesAndRights: any[]) : void{
   // Step 1: Check for Module
  this.moduleExists = rolesAndRights.some(
    r => r.ModuleName === 'PracticeProfile'
  );
  // Step 2: Check for SubModule (only if module exists)
  this.subModuleExists = rolesAndRights.some(
    r => r.ModuleName === 'PracticeProfile' && r.SubModuleName === 'ProviderDoc'
  );
  this.proDocSubModule = rolesAndRights.some(
    r =>
     r.ModuleName === 'PracticeProfile' &&
      r.SubModuleName === 'ProviderDoc' 
  );
  // Step 3: Check for Property (only if module + submodule exist)
  this.addProviderDocExist = rolesAndRights.some(
    r =>
     r.ModuleName === 'PracticeProfile' &&
      r.SubModuleName === 'ProviderDoc' &&
      r.PropertyName === 'AddDoc'
  );
  this.editProviderDocExist = rolesAndRights.some(
    r =>
     r.ModuleName === 'PracticeProfile' &&
      r.SubModuleName === 'ProviderDoc' &&
      r.PropertyName === 'EditDoc'
  );
    this.deleteProviderDocExist = rolesAndRights.some(
    r =>
     r.ModuleName === 'PracticeProfile' &&
      r.SubModuleName === 'ProviderDoc' &&
      r.PropertyName === 'DeleteDoc'
  );
 }
closeDOCModal(): void {

  ($('#uploadDocumentModal') as any).one('hidden.bs.modal', () => {
    $('body').removeClass('modal-open');
    $('.modal-backdrop').remove();
          this.GetAllDoc();
    // Show previous modal
    ($('#providerdoc') as any).modal('show');
  });

  // Hide upload modal
  ($('#uploadDocumentModal') as any).modal('hide');

  // Reset data
  this.docModel = new DocumentModel();
  this.selectedFiles = [];
  this.fileValidationUpdate = true;
}
closeGetDOCModal() {
    setTimeout(() => {
      this.selectedDocumentType = "All";  
      this.cdr.detectChanges();  
    }, 0);   

  ($('#providerdoc') as any).modal('hide');

 
}
    GetDocTypeList() {
        this.API.getData('/PracticeSetup/GetProviderDocTypeList').subscribe(
            data => {
                if (data.Status === 'Success') {
                    this.docTypeList = data.Response;
                    let docs = data.Response.map(doc => ({
    Type_Value: doc.Type_Value,
    Type_Dec: doc.Type_Dec
   
  }));
 
                   this.searchableDocTypeList = [
  { Type_Value: null, Type_Dec: 'All' },
  ...this.docTypeList.map(d => ({
      Type_Value: d.Type_Value,
      Type_Dec: d.Type_Dec
  }))
];
        this.selectedDocumentType = null;
                } else {
                    swal('Failed', data.Status, 'error');
                }
            }
        );
    }
        GetStateList() {
        this.API.getData('/PracticeSetup/GetProviderStateList').subscribe(
            data => {
                if (data.Status === 'Success') {
                    this.proStateList = data.Response;
                } else {
                    swal('Failed', data.Status, 'error');
                }
            }
        );
    }
    showdocTypeList(){
        ($('#providerdoc') as any).modal('hide');
         this.fileValidationUpdate=false
         this.attachLink=false;
        this.docModel = new DocumentModel();
        this. GetStateList();


    }
// checkCharLimit() {
//   if (!this.docModel.Comments) {
//     this.charCount = 0;
//     return;
//   }

//   // Current length of input
//   this.charCount = this.docModel.Comments.length;

//   // Enforce 400-character limit
//   if (this.charCount > 400) {
//     this.docModel.Comments = this.docModel.Comments.slice(0, 400);
//     this.charCount = 400;
//   }
// }
onDateChangedIssue(event) {
  this.docModel.Issue_Date = event.formatted;
  //this.docModel.Issue_Date = event ? event.formatted : null;
}

onDateChangedExpiry(event) {
  this.docModel.Expiry_Date  = event.formatted;
  //this.docModel.Expiry_Date = event ? event.formatted : null;
}
    clearDatePickers() {
  // Remove pickers from DOM
  this.showIssueDatePicker = false;
  this.showExpiryDatePicker = false;

  // After Angular removes them, set null dates and bring them back
  setTimeout(() => {
    this.issuedate = null;
    this.expirydate = null;

    this.docModel.Issue_Date = null;
    this.docModel.Expiry_Date = null;

    this.showIssueDatePicker = true;
    this.showExpiryDatePicker = true;
  }, 0);
}
saveDoc(){
    debugger
      if(this.docModel.Document_Type=="")
        {
          this.toaster.error("Please Select a Document Type","Error");
          return;
        }
      if(this.docModel.Status=="")
        {
          this.toaster.error("Please Select a Status","Error");
          return;
        }

      if(this.docModel.Status == "Completed" || this.docModel.Status == "Expired" )
        {
            if(this.docModel.Issue_Date =="")
                 {
                   this.toaster.error("Please enter Issue Date.","Error");
                   return;
                 }
            if(this.docModel.Expiry_Date =="")
                 {
                   this.toaster.error("Please enter Expiry Date.","Error");
                   return;
                 }
        }
  
const issue = moment(this.docModel.Issue_Date).startOf('day');
const expiry = moment(this.docModel.Expiry_Date).startOf('day');

if (expiry.isBefore(issue)) {
  this.toaster.error("Expiry Date cannot be earlier than Issue Date.", "Error");
  return;
}
if(this.selectedFiles.length == 0 && this.fileValidationUpdate == false){
this.toaster.error("Please attach at least one document file.", "Error");
  return;
}
         this.docModel.Practice_Code=this.SelectedPracticeCode;
        this.docModel.Provider_Code=this.providerCode;
    this.API.PostData('/PracticeSetup/SaveProviderDocs', this.docModel, (d) => {
  if (d.Status === 'Success') {
this.providerDocId=d.Response.Provider_Doc_Id;
  this.clearDatePickers();
         this.issuedate = null;
  this.docModel.Issue_Date = null;
  this.expirydate = null;
  this.docModel.Expiry_Date=null;
   ($('#uploadDocumentModal') as any).one('hidden.bs.modal', () => {
        $('body').removeClass('modal-open');
        $('.modal-backdrop').remove();
        this.uploadFileAfterSave();
        this.GetAllDoc();
        ($('#providerdoc') as any).modal('show');
      });

      ($('#uploadDocumentModal') as any).modal('hide');
       this.chRef.detectChanges();
    }
  });

}
removeFile(index: number) {
  this.selectedFiles.splice(index, 1);
}
 onFileSelected(event: any): void {
  debugger;
  const files: FileList = event.target.files;
  const allowedExtensions = ['pdf', 'jpg', 'jpeg', 'png', 'docx', 'xls', 'xlsx'];
  // If no message selected, do nothing
  //if (this.selectedMessage == null) return;
  // Check if it's a new message (plain string) or an existing message (object)
  const isNewMessage = typeof this.selectedMessage === 'string';

  if (isNewMessage) {
    // Validate that the message is not empty or just whitespace
    
    // Loop through selected files
    for (let i = 0; i < files.length; i++) {
      const file = files.item(i);
      if (!file) continue;
      
      const fileName = file.name;
      const fileSize = file.size;
      const fileExt = fileName.split('.').pop().toLowerCase();
      if (!fileExt || !allowedExtensions.includes(fileExt)) {
        this.toaster.error(
        'Only supported file formats are allowed (PDF, JPG, JPEG, PNG, DOCX, XLS, XLSX).',
        'Error'
      );
        continue;
      }
        
      // Limit to 4 attachments
      if (this.selectedFiles.length >= 4) {
        this.toaster.error('You cannot upload more than 4 attachments.','Error');
        break;
      }
      this.selectedFiles.push(file);
    }
     event.target.value = '';
    return;
  }


  if (!this.selectedMessage.selectedFile) {
    this.selectedMessage.selectedFile = [];
  }

  if (!this.selectedFiles) {
    this.selectedFiles = [];
  }

  for (let i = 0; i < files.length; i++) {
    const file = files.item(i);
    if (!file) continue;

    const fileName = file.name;
    const fileSize = file.size;
    const fileExt = fileName.split('.').pop().toLowerCase();
      if (!fileExt || !allowedExtensions.includes(fileExt)) {
      this.toaster.error(
        'Only supported file formats are allowed (PDF, JPG, JPEG, PNG, DOCX, XLS, XLSX).',
        'Error'
      );
      continue;
    }

    const totalForMessage =
      (this.selectedMessage.selectedFile.length || 0) +
      (this.selectedMessage.attachments.length || 0);

    if (totalForMessage >= 4) {
      this.toaster.error('You cannot upload more than 4 attachments for this message.','Error');
      break;
    }
    this.selectedMessage.selectedFile.push(file);
    this.selectedFiles.push(file);
      event.target.value = '';
  }
}
uploadFileAfterSave() {

  if (!this.selectedFiles || this.selectedFiles.length === 0) {
    return;
  }

  const formData = new FormData();
  formData.append("fileName", this.selectedFiles[0].name);
  formData.append("id", this.providerDocId.toString());
  formData.append("file", this.selectedFiles[0]);

  this._fileHandlerService.UploadFile(formData, '/PracticeSetup/ProviderDocFileUpload')
      .subscribe(res => {
        if (res.Status === "success") {
          this.GetAllDoc()
          this.selectedFiles=[]
          this.fileValidationUpdate=false
        } else {
          
        }
      }, (error) => {
         
      });
}

GetAllDoc() {
  if(this.selectedDocumentType=="All"){
      this.selectedDocumentType= null
      this.selectedDocumentShow="All"
  }
  this.API.getData(`/PracticeSetup/GetProviderDocList?PracticeCode=${this.SelectedPracticeCode}&ProviderCode=${this.providerCode}&Doc_Type=${this.selectedDocumentType}`)
    .subscribe(
      data => {
        if (data.Status === 'Success') {
          this.selectedDocumentType =this.selectedDocumentShow
         if ($.fn.DataTable.isDataTable('#docTable')) {
        $('#docTable').DataTable().clear().destroy();
      }
        this.docList = data.Response;
        this.cdr.detectChanges(); 
          
         setTimeout(() => {
        this.docTable = $('#docTable').DataTable({
            scrollX:true,
          columnDefs: [
            { orderable: false, targets: -1 }
          ],
          language: {
            emptyTable: 'No data available'
          },
          pageLength: 10
        });
      }, 0);
         ($('#providerdoc') as any).modal('show');
        
        } else {
          swal('Failed', data.Status, 'error');
        }
      }
    );
}

    SearchDoc(){
   const selectedValue = this.selectedDocumentType;  
   this.selectedDocumentShow =  this.selectedDocumentType
  const selectedItem = this.searchableDocTypeList.find(item => item.Type_Dec === selectedValue);
  const description = selectedItem ? selectedItem.Type_Value : null;
  this.selectedDocumentType = description;
  if(this.selectedDocumentType=="All"){
      this.selectedDocumentType= null
  }
     this.GetAllDoc();
    } 
 GetProviderDocBYid(Id :number){
      ($('#providerdoc') as any).modal('hide');
    this.API.getData(`/PracticeSetup/GetProviderDocBYId?id=${Id}`).subscribe(
            data => {
   if (data.Status =='Suceess'){
          this.docModel=data.Response;
          this.setIssueDate(this.docModel.Issue_Date);
         this.setExpiryDate(this.docModel.Expiry_Date);
          this.attachLink=true;
              this.fileValidationUpdate=true;
          ($('#uploadDocumentModal') as any).modal('show')

        } else {
                    swal('Failed', data.Status, 'error');
                }
            }
        );
 }
 DeleteProviderDocBYid(Id :number){
    this.API.confirm(
        'Confirmation',  
        'Are you sure you want to delete?',  
        () => {  
            this.onDelYesClick(Id);
        },
        () => {  // If user clicks "No"
            this.onDelNoClick();
        }
    );
 }

openDocument(id: number): void {
  this.API.getFile(`/PracticeSetup/Download/${id}`)
    .subscribe((file: Blob) => {
       const blobUrl = window.URL.createObjectURL(file);
      const newWindow = window.open(blobUrl, '_blank');

      if (!newWindow) {
        alert('Please allow popups for this website to open the document.');
      }
      setTimeout(() => {
        window.URL.revokeObjectURL(blobUrl);
      }, 10000); 
    }, error => {
      console.error('Error opening file', error);
    });
}
deleteFile(file: any) {
  this.backupFile = {
    File_Name: this.docModel.File_Name,
    File_Path: this.docModel.File_Path
  };

  this.API.confirm(
    'Confirmation',
    'Are you sure you want to delete?',
    () => {
      this.onYesClick();   // YES
    },
    () => {
      this.onNoClick();    // NO
    }
  );
}

onNoClick(): any {
     if (this.backupFile) {
    this.docModel.File_Name = this.backupFile.File_Name;
    this.docModel.File_Path = this.backupFile.File_Path;
    this.attachLink=true;
  }
  // this.resetFields();
}

onYesClick(): any {
this.docModel.File_Name = '';
  this.docModel.File_Path = '';
   this.attachLink=false;
   this.fileValidationUpdate=false;
}
restoreOldFile() {
  if (this.backupFile) {
    this.docModel.File_Name = this.backupFile.File_Name;
    this.docModel.File_Path = this.backupFile.File_Path;
  }
}
onDelYesClick(Id: number) {
    // Proceed with the deletion if the user clicked "Yes"
    this.API.getData(`/PracticeSetup/DeleteProviderDocBYid?id=${Id}`).subscribe(
        data => {
            if (data.Status === 'Success') {
                this.GetAllDoc();
                ($('#providerdoc') as any).modal('show');  
            } else {
                swal('Failed', data.Status, 'error');
            }
        },
        error => {
            swal('Error', 'An error occurred while deleting the document', 'error');
        }
    );
}
onDelNoClick() {
   
}
    setIssueDate(date: string) {
        if (!Common.isNullOrEmpty(date)) {
            let dDate = new Date(date);
            this.issuedate = {
                year: dDate.getFullYear(),
                month: dDate.getMonth() + 1,
                day: dDate.getDate()
            };
        }
    }

    setExpiryDate(date: string) {
        if (!Common.isNullOrEmpty(date)) {
            let dDate = new Date(date);
            this.expirydate = {
                year: dDate.getFullYear(),
                month: dDate.getMonth() + 1,
                day: dDate.getDate()
            };
        }
    }

}


