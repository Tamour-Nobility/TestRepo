import { Component, OnInit, ChangeDetectorRef, AfterViewInit, OnDestroy, ViewChild } from '@angular/core';
import { GvarService } from '../../components/services/GVar/gvar.service';
import { GvarsService } from '../../services/G_vars/gvars.service';
import { Router, ActivatedRoute, Scroll } from '@angular/router';
import {
  ComboFillingList, PracticeNotesList,
  PracticeNotesModel, Practice_Notes, PracticeNotes, PracticeModel, Provider_Working_Days_Time
  , ProviderPayer, ProviderNotes, ProviderNotesModel, SpecialInstructionModel
  , ProviderResources, ReportingModel,
  DocumentModel
} from '../practiceList/Classes/practiceClass';
import { APIService } from '../../components/services/api.service';
import { DatePipe } from '@angular/common';
import { Subject } from 'rxjs';
import { WCBRating, SpecialtyGroups, Specilization } from '../providers/Classes/providersClass';
import 'datatables.net'
import { Common } from '../../../app/services/common/common';
import { AddEditPracticeComponent } from '../addeditpractice/add-edit-practice.component';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { NgxSpinnerService } from 'ngx-spinner';
import { ModalWindow } from '../../shared/modal-window/modal-window.component';
import { InsuranceSearchComponent } from '../../shared/insurance-search/insurance-search.component';
import { PracTabInsuranceSearchComponent } from '../../shared/prac-tab-insurance-search copy/prac-tab-insurance-search.component';
import { DatatableService } from '../../../app/services/data/datatable.service';
import { User } from '../../user-management/classes/requestResponse';
import { CurrentUserViewModel } from '../../models/auth/auth';
import {WebPortalsComponent} from '../web-portals/web-portals.component';
import * as moment from 'moment';
import { FileHandlerService } from '../../components/services/file-handler/filehandler.service';
import { IMyDate, IMyDateModel, IMyDpOptions } from 'mydatepicker';




declare var $: any;


@Component({
  selector: 'app-practice-tab',
  templateUrl: './practice-tab.component.html',
  styleUrls: ['./practice-tab.component.css']
})

export class PracticeTABComponent implements OnDestroy, OnInit, AfterViewInit {
  [x: string]: any;
  ProviderCode = 50010176;
  dtPracInstruction: any;
  dtOptionsSI: DataTables.Settings = {};
  dtTriggerSI: Subject<any> = new Subject();
  listSI: any;
  checkhistorySI: boolean = false;
  objSpecialInstructionModel: SpecialInstructionModel;
  dtOptions: DataTables.Settings = {};
  dtTrigger: Subject<any> = new Subject();
  dataTable: any;
  public temp_var: Object = false;
  listProviderResources: ProviderResources[];
  objProviderNotes: ProviderNotes;
  objProviderNotesModel: ProviderNotesModel;
  listProviderPayer: ProviderPayer[];
  listProvider_Working_Days_Time: Provider_Working_Days_Time[];
  ObjPractice_Notes: PracticeNotes;
  listPractice_Notes: Practice_Notes[];
  comboFillingList: ComboFillingList[];
  practiceNotes: PracticeNotesList;
  PracticeNotesSIList: PracticeNotesList[];
  practoceNotesListNew: PracticeNotesModel;
  objPracticeModel: PracticeModel;
  docModel:DocumentModel;
  selectedValue: string;
  userContent: string;
  numActive: number = 1;
  numActiveProv: number = 1;
  numActiveSI: number = 1;
  table: any
  numProviderCode: number = 0;
  strUpdatedLocationCode: string;
  numProviderLocation: number;
  listWCBRating: WCBRating[];
  listSpecialtyGroups: SpecialtyGroups[];
  listSpecializations: Specilization[];
  SelectedPracticeCode: number = 0;
  practiceNotestable: any;
  practiceNotesSIQuestion: any;
  syncDisable: boolean = true;
  showInsuranceNamePopup: boolean = false;
  currentInsuranceNumber: number;
  objReportingModel: ReportingModel;
  ReportingModelForm: FormGroup;
  managerData: String;
  PHDData: String;
  managerDropdownData: any;
  teamLeadData: string = '';
  teamLeadDropdownData: any;
  billingAssociateData: any;
  billingAssociateDropdownData: any;
  divisionData: any;
  divisionDropdownData: any;
  usersSelectList: any;
  selectedOption: string = ''; // Set default value
  selectedShift: string = 'M';
  isAdd:boolean=false;
  addEditPracticeComp:any;
  listUser: User[];
  assignedUser: any;
  moduleExists = false;
  subModuleExists = false;
  delPracPayerPropertyExist=false;
  mapPayerPropertyExist=false;
  saveRepoPropertyExist=false;
  addInstructionPropertyExist=false;
  editInstructionPropetyExist=false;
  addNotesPropetyExist=false;
  editNotesPropetyExist=false;
  deleteNotesPropertyExist=false;
  addProviderNotesPropertyExist=false;
    editProviderNotesPropertyExist=false;
      DeleteProviderNotesPropertyExist=false;
      syncPracticePropertyExist=false;
      pracDocSubModule=false
  addPracticeDocExist=false;
  editPracticeDocExist=false;
  deletePracticeDocExist=false;
WebPortalsExists=false;
    docList:any[]=[];
    docTypeList: any[] = [];
    selectedFile: File[] = [];
      selectedMessage: any = "";
      backupFile: any = null;
     deletedFile: any = null;
    attachLink:boolean=false;
    fileValidationUpdate:boolean=false
    docPTable: any;
     selectedDocumentType:any= null;
     selectedDocumentShow:any= null;
  currentUser: CurrentUserViewModel;
  //  issuedate: IMyDate = {
  //       day: 0,
  //       month: 0,
  //       year: 0
  //   }; ;
  //  expirydate:IMyDate = {
  //       day: 0,
  //       month: 0,
  //       year: 0
  //   };
    issuedate: IMyDate =null;
    expirydate:IMyDate = null;
    public placeholdertxt: string = 'MM/DD/YYYY';
    showIssueDatePicker: boolean = true;
    showExpiryDatePicker: boolean = true;

  @ViewChild(AddEditPracticeComponent) addEditPrac: AddEditPracticeComponent;
  @ViewChild('insuranceSearch') insuranceModal: ModalWindow;
  @ViewChild(InsuranceSearchComponent) ins: InsuranceSearchComponent;
  @ViewChild(PracTabInsuranceSearchComponent) prcIns: PracTabInsuranceSearchComponent;
     public myDatePickerOptions: IMyDpOptions = {
          dateFormat: 'mm/dd/yyyy', height: '25px', width: '93%',
          editableDateField: false,
          openSelectorOnInputClick: true
      };
  constructor(private chRef: ChangeDetectorRef, public formBuilder: FormBuilder, public Gv: GvarService, public router: Router,
    public route: ActivatedRoute, private toaster: ToastrService, private gvService: GvarsService,
    public API: APIService, public datepipe: DatePipe, private spinner: NgxSpinnerService, private datatableService: DatatableService,
   private _fileHandlerService: FileHandlerService, private cdr: ChangeDetectorRef) {
    this.ObjPractice_Notes = new PracticeNotes;
    this.listPractice_Notes = [];
    this.comboFillingList = []
    this.practiceNotes = new PracticeNotesList;
    this.practoceNotesListNew = new PracticeNotesModel;
    this.PracticeNotesSIList = [];
    this.objPracticeModel = new PracticeModel;
    this.listProvider_Working_Days_Time = [];
    this.listProviderPayer = [];
    this.objProviderNotes = new ProviderNotes;
    this.objProviderNotesModel = new ProviderNotesModel;
    this.listProviderResources = [];
    this.objSpecialInstructionModel = new SpecialInstructionModel();
    this.listWCBRating = [];
    this.listSpecialtyGroups = [];
    this.listSpecializations = [];
    this.objReportingModel = new ReportingModel();
    this.listUser = [];
    this.docModel= new DocumentModel;
  }
  Practice: string;
  ngOnInit() {
    this.objReportingModel.Assigned_Client="NPM";
this.checkAccess(this.gvService.currentUser.RolesAndRights);
    if (localStorage.getItem('showSuccessSwal') === 'true') {
      swal('Success', 'Practice Payer has been Deleted.', 'success');
      localStorage.removeItem('showSuccessSwal');
    }

    this.route.params.subscribe(params => {
      if (params['id'] !== 0 && params['id'] !== '0') {
        this.SelectedPracticeCode = params['id'];
      }
    });
    this.numProviderCode = this.API.Gv.ProviderCode;
    this.Practice = '';
    this.Practice = this.API.Gv.practiceName + ' (' + this.SelectedPracticeCode + ')';
  if (!this.API.Gv.practiceName && this.SelectedPracticeCode != 0) {
  const selectedPractice = this.API.Gv.currentUser.Practices.find(
    (p: any) => p.PracticeCode == this.SelectedPracticeCode
  );

          if (selectedPractice) {
            this.API.Gv.practiceName= selectedPractice.PracticeName;
             this.Practice = this.API.Gv.practiceName + ' (' + this.SelectedPracticeCode + ')';
          } 
    }
    if (this.SelectedPracticeCode == undefined || this.SelectedPracticeCode == null || this.SelectedPracticeCode == 0) {
      this.Practice = "(New Practice)";
      this.isAdd=true
    }
    this.initForm();
    this.GetPracticeDropDownValues();
    this.GetProviderDropDown();
    this.getUsersList();
    this.checkPracticePayerAccess(this.gvService.currentUser.RolesAndRights);
    this.checkPracticeReportingAccess(this.gvService.currentUser.RolesAndRights);
    this.checkPracticeInstructionAccess(this.gvService.currentUser.RolesAndRights);
    this.checkPracticeNotesAccess(this.gvService.currentUser.RolesAndRights);
    this.checkProviderNotesAccess(this.gvService.currentUser.RolesAndRights);
    this.checkPracticeSyncAccess(this.gvService.currentUser.RolesAndRights);
    this.checkPracticeDocAccess(this.gvService.currentUser.RolesAndRights);
     this.GetDocTypeList();

  }

  ngAfterViewInit() {

    this.chRef.detectChanges();
    this.dataTable = $('#providerPayerTable').DataTable({
      paging: true,
      searching: true,
      info: true,
      lengthMenu: [5, 10, 25, 50],
    });
  }

  ngOnDestroy(): void {
    // Do not forget to unsubscribe the event
    this.dtTrigger.unsubscribe();
  }

  GetPracticeNoteList() {
    this.API.getData('/PracticeSetup/GetPracticeNotesList?PracticeId=' + this.SelectedPracticeCode + '&PracticeLocationId=' + this.SelectedPracticeCode).subscribe(
      data => {
        if (data.Status === 'Sucess') {
          this.practiceNotes = data.Response;
        }
      });
  }
  GetProviderDropDown() {
    this.API.getData('/PracticeSetup/GetPractice?PracticeId=' + this.SelectedPracticeCode).subscribe(
      data => {
        if (data.Status === 'Sucess') {
          this.comboFillingList = data.Response.ProvidersComboFillingList;
          this.listWCBRating = data.Response.WCBRatingList;
          this.listSpecialtyGroups = data.Response.SpecialityGroupsList;
          this.listSpecializations = data.Response.Specializations;
        }
      });
  }

  //-------------------------------Special Instruction region-------------------------------------------------


  loadPracticeNoteSIModel(check: boolean = false) {
    this.numActiveSI = 0;
    this.checkhistorySI = check;
    if (!this.SelectedPracticeCode)
      return;
    if (this.objSpecialInstructionModel.listMainSpecialInstruction)
      this.dtTriggerSI.unsubscribe();
    this.API.getData('/PracticeSetup/GetSpecialInstructionList?PracticeId=' + this.SelectedPracticeCode).subscribe(
      data => {
        if (data.Status === 'Sucess') {
          if (this.dtPracInstruction) {
            this.chRef.checkNoChanges();
            this.dtPracInstruction.destroy();
          }
          this.objSpecialInstructionModel.listCategoryList = data.Response.CategoryList;
          this.objSpecialInstructionModel.listMainSpecialInstruction = data.Response.specialInstructionModel;
          this.sortedSpecialInsList();
        }
      });
  }

  mainNotes(check: boolean = false) {
    this.checkhistorySI = check;
    this.numActiveSI = 1;
  }


  sortedSpecialInsList() {
    if (this.objSpecialInstructionModel.objSpecialInstruction.Category_Id) {
      if (this.objSpecialInstructionModel.objSpecialInstruction.Question_Id) {
        if (this.dtPracInstruction) {
          this.chRef.detectChanges();
          this.dtPracInstruction.destroy();
        }
        this.objSpecialInstructionModel.listSpecialInstruction = this.objSpecialInstructionModel.listMainSpecialInstruction.filter(x => x.Question_Id == this.objSpecialInstructionModel.objSpecialInstruction.Question_Id);
        this.chRef.detectChanges();
        this.dtPracInstruction.destroy();
        this.dtPracInstruction = $('.dtPracInstruction').DataTable({
          language: {
            emptyTable: "No data available"
          }
        });
      }
      else
        this.objSpecialInstructionModel.listSpecialInstruction = [];
    }
    else
      this.objSpecialInstructionModel.listSpecialInstruction = [];
  }

  editInstruction(QuestionId: number = 0) {
    // if(SpecialInstructionId==undefined||SpecialInstructionId==null||SpecialInstructionId==0)
    //return;
    this.numActiveSI = 1;
    var listSI = this.objSpecialInstructionModel.listSpecialInstruction.filter(x => x.Question_Id == QuestionId);
    if (listSI) {
      this.objSpecialInstructionModel.objSpecialInstruction.Question_Id = listSI[0].Question_Id;
      this.objSpecialInstructionModel.objSpecialInstruction.Special_Instruction = listSI[0].Special_Instruction;
      this.objSpecialInstructionModel.objSpecialInstruction.Created_By = listSI[0].Created_By;
      this.objSpecialInstructionModel.objSpecialInstruction.Created_Date = listSI[0].Created_Date;
      this.objSpecialInstructionModel.objSpecialInstruction.Special_Instruction_Id = listSI[0].Special_Instruction_Id;
      this.objSpecialInstructionModel.objSpecialInstruction.Status = listSI[0].Status;
      this.objSpecialInstructionModel.objSpecialInstruction.Created_Date = listSI[0].Created_Date;
    }
  }

  addTag() {
    this.objSpecialInstructionModel.objSpecialInstruction.Special_Instruction = '';
  }

  loadQuestionsSIModel(CateogyrId: number) {
    if (!this.SelectedPracticeCode)
      return;

    if (CateogyrId == undefined || CateogyrId == null || CateogyrId == 0)
      return;

    this.API.getData('/PracticeSetup/GetSpecialInstructionQuestionByCategory?CategoryId=' + CateogyrId).subscribe(
      data => {
        if (data.Status === 'Sucess') {
          if (this.practiceNotesSIQuestion) {
            this.chRef.detectChanges();
            this.practiceNotesSIQuestion.destroy();
          }
          this.objSpecialInstructionModel.listQuestion = data.Response;
          this.objSpecialInstructionModel.objSpecialInstruction.Question_Id = null;
          this.sortedSpecialInsList();
        }
      });
  }


  SavePracticeInstruction() {
    if (!this.objSpecialInstructionModel.objSpecialInstruction.Category_Id) {
      swal('Select category.', '', 'error');
      return;
    }

    if (!this.objSpecialInstructionModel.objSpecialInstruction.Question_Id) {
      swal('Select Question.', '', 'error');
      return;
    }

    if (!this.objSpecialInstructionModel.objSpecialInstruction.Special_Instruction) {
      swal('Enter Instructions', '', 'error');
      return;
    }

    this.objSpecialInstructionModel.objSpecialInstruction.Practice_Code = this.SelectedPracticeCode;
    this.objSpecialInstructionModel.objSpecialInstruction.Deleted = false;
    this.API.PostData('/PracticeSetup/SaveSpecialInstruction/', this.objSpecialInstructionModel.objSpecialInstruction, (d) => {
      if (d.Status === 'Sucess') {
        swal('', 'Practice Instruction has been saved.', 'success');
        this.objSpecialInstructionModel.listSpecialInstruction = [];
        this.objSpecialInstructionModel.objSpecialInstruction.Special_Instruction = '';
        this.objSpecialInstructionModel.objSpecialInstruction.Question_Id = 0;
        this.objSpecialInstructionModel.objSpecialInstruction.Category_Id = 0;

      } else {
        swal('Failed', d.Status, 'error');
      }
    });
  }

  deleteSINote(QuestionId: number) {

    if (QuestionId == undefined || QuestionId == null || QuestionId == 0)
      return;

    this.API.confirmFun('Do you want to delete selected instruction?', '', () => {
      this.API.getData('/PracticeSetup/DeleteSpecialInstruction?QuestionId=' + QuestionId + '&PracticeId=' + this.SelectedPracticeCode).subscribe(
        data => {

          swal({ position: 'top-end', type: 'success', title: 'Practice Instruction has been Deleted.', showConfirmButton: false, timer: 1500 })

          this.loadPracticeNoteSIModel(true);

        });
    });
  }


  // ---------------------Practice Notes Region-------------------------------------------------------------------

  savePractice_Notes() {
    if (this.SelectedPracticeCode == undefined || this.SelectedPracticeCode == null || this.SelectedPracticeCode == 0)
      return;

    if (this.ObjPractice_Notes.Response.NOTE_CONTENT == undefined || this.ObjPractice_Notes.Response.NOTE_CONTENT == null || $.trim(this.ObjPractice_Notes.Response.NOTE_CONTENT) == '') {
      swal('', "Please Enter Note Description.", 'info');
      return;
    }


    this.ObjPractice_Notes.Response.PRACTICE_Code = this.SelectedPracticeCode;
    this.ObjPractice_Notes.Response.Deleted = false;
    var curDate = new Date();
    this.ObjPractice_Notes.Response.NOTE_DATE = this.datepipe.transform(curDate, 'MM/dd/yyyy');
    this.ObjPractice_Notes.Status = "Success";
    this.API.PostData('/PracticeSetup/SavePracticeNote/', this.ObjPractice_Notes.Response, (d) => {
      if (d.Status === 'Sucess') {
        this.numActive = 0;

        swal({ position: 'top-end', type: 'success', title: 'Practice Notes has been saved.', showConfirmButton: false, timer: 1500 })
        this.numActive = 0;
        //swal('Practice Notes has been saved.', '', 'success');
        this.ObjPractice_Notes = new PracticeNotes;
        this.loadPracticeNotes();
      } else {
        swal('Failed', d.Status, 'error');
      }
    });
  }

  loadPracticeNotes() {
    this.numActive = 0;
    //this.dtTrigger.unsubscribe();
    if (!this.SelectedPracticeCode)
      return;
    this.API.getData('/PracticeSetup/GetPracticeNotesList?PracticeId=' + this.SelectedPracticeCode).subscribe(
      data => {
        if (data.Status === 'Sucess') {
          if (this.practiceNotestable) {
            this.chRef.detectChanges();
            this.practiceNotestable.destroy();
          }
          this.listPractice_Notes = data.Response;
          this.chRef.detectChanges();
          this.practiceNotestable = $('.practiceNotesTable').DataTable(
            {
              language: {
                emptyTable: "No data available"
              }
            });
        }
        else {
          swal('Failed', data.Status, 'error');
        }
      });
  }
  delPracticeNote(NoteId: string) {
    this.practiceNotes.PRACTICE_Code = this.SelectedPracticeCode;
    //this.practiceNotes.NOTE_CONTENT = this.userContent;
    this.practiceNotes.Deleted = true;
  }

  deletePracticeNote(PracticeNoteId: number) {
    this.API.confirmFun('Do you want to delete this Practice note ?', '', () => {
      this.API.getData('/PracticeSetup/DeletePracticetNote?PracticeId=' + this.SelectedPracticeCode + '&PracticeNotesId=' + PracticeNoteId).subscribe(
        data => {
          swal({ position: 'top-end', type: 'success', title: 'Practice note has been Deleted.', showConfirmButton: false, timer: 1500 })
          // swal('Practice note has been Deleted.', '', 'success');
          this.loadPracticeNotes();
        });
    });
  }

  modifyPracticeNote(PracticeNoteId: number) {
    if (PracticeNoteId == undefined || PracticeNoteId == null || PracticeNoteId == 0)
      return;
    this.API.getData('/PracticeSetup/GetPracticeNote?PracticeNotesId=' + PracticeNoteId).subscribe(
      data => {
        if (data.Status === 'Sucess') {
          this.ObjPractice_Notes.Response = data.Response;
          this.numActive = 1;
        }
        else {
          swal('Failed', data.Status, 'error');
        }

      });

  }
  // ---------------------END Practice Resources Region---------------------------------------------------------------



  // ---------------------Practice Resources Region-------------------------------------------------------------------
  loadPracticeResources() {
    this.API.getData('/PracticeSetup/GetPracticeNotesList?PracticeId=' + this.SelectedPracticeCode).subscribe(
      data => {
        if (data.Status === 'Sucess') {
          this.listPractice_Notes = data.Response;
        } else {
          swal('Failed', data.Status, 'error');
        }
      });
  }


  // ---------------------End Practice Resources Region-------------------------------------------------------------------


  // ---------------------Provider working Hours Region-------------------------------------------------------------------Verified---
  getPracticeLocation() {
    this.API.getData('/PracticeSetup/GetPracticeLocationList?PracticeId=' + this.SelectedPracticeCode).subscribe(
      data => {
        if (data.Status === 'Sucess') {
          this.objPracticeModel.Response.LocationComboFillingList = data.Response;
          if (this.objPracticeModel.Response.LocationComboFillingList.length > 0) {
            this.strUpdatedLocationCode = this.objPracticeModel.Response.LocationComboFillingList[0].Location_Code.toString();
            this.getProviderWorkingHours(this.strUpdatedLocationCode);
          }
        } else {
          swal('Failed', data.Status, 'error');
        }
      });
  }

  getProviderWorkingHours(LocationID) {
    if (!LocationID) {
      return;
    }
    if (!this.API.Gv.ProviderCode) {
      swal('', 'Invalid Provider Code', 'info');
      return;
    }
    this.API.getData('/PracticeSetup/GetProviderWorkingHours?ProviderId=' + this.API.Gv.ProviderCode + '&LocationId=' + LocationID).subscribe(
      data => {
        if (data.Status === 'Sucess') {
          this.listProvider_Working_Days_Time = data.Response;
        } else {
          swal('Failed', data.Status, 'error');
        }
      });
  }

  ///----------------------------------------------------------------------------End Provider Working Hour Region--------------



  //-------------------------------------------------------Provider Payers Region --------------------------------

  getProviderPayers(LocationId) {
    if (LocationId == 0 || LocationId == undefined || LocationId == null || LocationId == "") {
      return;
    }
    if (this.ProviderCode == 0 || this.ProviderCode == undefined || this.ProviderCode == null) {
      swal('', 'Invalid Provider Code', 'info');
      return;
    }
    this.API.getData('/PracticeSetup/GetProviderPayers?ProviderId=' + this.ProviderCode + '&LocationId=' + LocationId).subscribe((data: any) => {
      if (data.Status === 'Sucess') {
        this.listProviderPayer = data.Response;
        this.reinitializeDataTable();
      } else {
        swal('Error', data.Status, 'error');
      }
    });
  }
  //to fetch the data for practice payer - payer mapying - pir ubaid
  getPracticePayers(LocationId) {
    if (LocationId == 0 || LocationId == undefined || LocationId == null || LocationId == "") {
      return;
    }
    if (this.SelectedPracticeCode == 0 || this.SelectedPracticeCode == undefined || this.SelectedPracticeCode == null) {
      swal('', 'Invalid Practice Code', 'info');
      return;
    }

    this.API.getData('/PracticeSetup/GetPracticePayers?PracticeId=' + this.SelectedPracticeCode).subscribe((data: any) => {
      if (data.Status === 'Sucess') {
        this.listProviderPayer = data.Response;
        this.reinitializeDataTable();
      } else {
        swal('Error', data.Status, 'error');
      }
    });
  }

  reinitializeDataTable() {
    if (this.dataTable) {
      this.dataTable.destroy(); // Destroy the existing instance
    }

    this.chRef.detectChanges(); // Refresh the DOM

    this.dataTable = $('#providerPayerTable').DataTable({
      paging: true,
      searching: true,
      info: true,
      lengthMenu: [5, 10, 25, 50],
    });
  }

  getPracticeProviderLocation(Type: string = "") {
    this.API.getData('/PracticeSetup/GetPracticeLocationList?PracticeId=' + this.SelectedPracticeCode).subscribe(
      data => {
        if (data.Status === 'Sucess') {
          this.objPracticeModel.Response.LocationComboFillingList = data.Response;
          if (this.objPracticeModel.Response.LocationComboFillingList.length > 0) {
            if (Type == "ProviderPayers") {
              this.numProviderLocation = this.objPracticeModel.Response.LocationComboFillingList[0].Location_Code;
              // this.getProviderPayers(this.numProviderLocation);
              this.getPracticePayers(this.numProviderLocation);
            }
          }
        } else {
          swal('Failed', data.Status, 'error');
        }
      });
  }
  ///----------------------------------------------------------------------------End Provider Payer Region--------------
  //----------------------------Provider Notes Region --------------------------------------------------------------------

  saveProviderNotes() {
    if (this.API.Gv.ProviderCode == undefined || this.API.Gv.ProviderCode == null || this.API.Gv.ProviderCode == 0)
      return;

    if (this.objProviderNotes.Note_Content == undefined || this.objProviderNotes.Note_Content == null || $.trim(this.objProviderNotes.Note_Content) == '') {
      swal('', "Please Enter Note Description.", 'info');
      return;
    }
    this.objProviderNotes.Provider_Code = this.API.Gv.ProviderCode;

    this.objProviderNotes.Deleted = false;
    if (this.objProviderNotes.Provider_Notes_Id == undefined || this.objProviderNotes.Provider_Notes_Id == null || this.objProviderNotes.Provider_Notes_Id == 0) {
      this.objProviderNotes.Provider_Notes_Id = 0;
      var curDate = new Date();
      this.objProviderNotes.Note_Date = this.datepipe.transform(curDate, 'MM/dd/yyyy');
      this.objProviderNotes.Note_User = "0";
    }
    this.API.PostData('/PracticeSetup/SaveProviderNote/', this.objProviderNotes, (d) => {
      if (d.Status === 'Sucess') {
        this.numActiveProv = 0;
        swal({ position: 'top-end', type: 'success', title: 'Provider Note has been saved.', showConfirmButton: false, timer: 1500 })
        this.objProviderNotes = new ProviderNotes;
        this.loadProviderNotes();
      } else {
        swal('Failed', d.Status, 'error');
      }
    });
  }

  loadProviderNotes() {
    this.numActiveProv = 0;
    if (this.API.Gv.ProviderCode == undefined || this.API.Gv.ProviderCode == null || this.API.Gv.ProviderCode == 0)
      return;

    this.API.getData('/PracticeSetup/GetProviderNotesList?providerId=' + this.API.Gv.ProviderCode).subscribe(
      data => {
        if (data.Status === 'Sucess') {
          this.objProviderNotesModel.Response = data.Response;
        }
        else {
          swal('Failed', data.Status, 'error');
        }
      });
  }
  delProviderNote(NoteId: string) {
    this.objProviderNotes.Provider_Code = this.API.Gv.ProviderCode;
    this.objProviderNotes.Deleted = true;
  }

  deleteProviderNote(ProviderNotesId: number) {
    this.API.confirmFun('Do you want to delete this Provider note ?', '', () => {
      this.API.getData('/PracticeSetup/DeleteProviderNote?ProviderId=' + this.API.Gv.ProviderCode + '&ProviderNotesId=' + ProviderNotesId).subscribe(
        data => {
          swal({ position: 'top-end', type: 'success', title: 'Provider note has been Deleted.', showConfirmButton: false, timer: 1500 })
          this.loadProviderNotes();
        });
    });
  }

  modifyProviderNote(ProviderNoteId: number) {
    if (ProviderNoteId == undefined || ProviderNoteId == null || ProviderNoteId == 0)
      return;
    this.API.getData('/PracticeSetup/GetProviderNote?providerNoteId=' + ProviderNoteId).subscribe(
      data => {
        if (data.Status === 'Sucess') {
          this.objProviderNotes = data.Response;
          this.numActiveProv = 1;
        }
        else {
          swal('Failed', data.Status, 'error');
        }
      });
  }

  //-------------------------Provider Resources-----------------------------------------------

  //this.listProviderResources
  loadProviderResources() {
    if (this.API.Gv.ProviderCode == undefined || this.API.Gv.ProviderCode == null || this.API.Gv.ProviderCode == 0)
      return;
    this.API.getData('/PracticeSetup/GetProviderResources?ProviderId=' + this.API.Gv.ProviderCode).subscribe(
      data => {
        if (data.Status === 'Sucess') {
          this.listProviderResources = data.Response;
        }
        else {
          swal('Failed', data.Status, 'error');
        }
      });
  }

  transformT(time: string) {
    if (!Common.isNullOrEmpty(time)) {
      let dummyDate = new Date();
      let hms = [];
      hms = time.split(':');
      let hrs = [];
      hrs = hms[0].split('T');
      dummyDate.setHours(hrs[1]);
      dummyDate.setMinutes(hms[1]);
      dummyDate.setSeconds(hms[2]);
      return dummyDate;
    } else {
      return "";
    }
  }

  transformD(d: any) {
    let weekDay: string = '';
    if (!d)
      return;
    else
      switch (d) {
        case "1": {
          weekDay = "Monday";
          break;
        }
        case "2": {
          weekDay = "Tuesday";
          break;
        }
        case "3": {
          weekDay = "Wednesday";
          break;
        }
        case "4": {
          weekDay = "Thrusday";
          break;
        }
        case "5": {
          weekDay = "Friday";
          break;
        }
        case "6": {
          weekDay = "Saturday";
          break;
        }
        default: {
          weekDay = "Sunday";
          break;
        }
      }
    return weekDay;
  }

  transformDate(date: string) {
    if (!Common.isNullOrEmpty(date)) {
      let dummyDate = new Date();
      let d = [];
      d = date.split('T');
      dummyDate.setDate(d[0]);
      return dummyDate;
    } else {
      return "";
    }
  }

  enableSynchronization() {
    this.addEditPrac.enableSynchronization();
  }

  onChangeVendor(event) {
    if(this.syncPracticePropertyExist == true){
     this.syncDisable = event;
    }
   
  }


  //Practice reporting change  by anum
  initForm() {
    this.ReportingModelForm = this.formBuilder.group({
      ID: [''],
      Practice_Alias: [''],
      Assigned_Client:['NPM'],
      Assigned_ADO:[null],
      ManagerID: [''],
      Assigned_AMO:[''],
      Assigned_STL:[''],
      TeamLeadID: [''],
      Onshore_Lead:[''],
      BillingAssociateID: [''],
      DivisionID: [null],
      Shift: [null],
      PHDPOCId:[null],
    });

  }
  onclose() {

    this.ReportingModelForm.reset();
    this.managerData = '';
    this.PHDData='';
    this.teamLeadData = '';
    this.billingAssociateData = '';
    this.GetPracticeDropDownValues();

  }

  emailValidator(pracAlias: string): boolean {
    var EMAIL_REGEXP = /^[a-zA-z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

    if (EMAIL_REGEXP.test(pracAlias)) {
      return false;
    }
    return true;
  }


  isNullOrEmptyString(str: string): boolean {
    if (str == undefined || str == null || $.trim(str) == '')
      return true;
    else
      return false;
  }
  saveReportingDetails() {
    debugger;
    const formData = this.ReportingModelForm.value;
    const practiceCode = this.SelectedPracticeCode
    // if (this.isNullOrEmptyString(formData.Practice_Alias) && this.isNullOrEmptyString(formData.ManagerID)
    //   && this.isNullOrEmptyString(formData.TeamLeadID) && this.isNullOrEmptyString(formData.BillingAssociateID)
    //   && this.isNullOrEmptyString(formData.DivisionID)
    //   && this.isNullOrEmptyString(formData.Shift)
    // ) {
    //   // $('#practiceReporting').modal('hide');
    // }
     if (this.emailValidator(this.ReportingModelForm.value.Practice_Alias) && !this.isNullOrEmptyString(formData.Practice_Alias)) {
      this.toaster.warning('Enter valid Practice Alias', 'Validation');
    }

    else {
      //var reportingID = this.objReportingModel && this.objReportingModel[0] ? this.objReportingModel[0].ID : null;
       var reportingID = this.objReportingModel ? this.objReportingModel.ID : null;

      this.objReportingModel = {
        ID: reportingID,
        Practice_Code: practiceCode,
        Practice_Alias: formData.Practice_Alias,
        Assigned_Client:formData.Assigned_Client,
        Assigned_ADO:formData.Assigned_ADO,
        Manager_ID: formData.ManagerID,
        Assigned_AMO:formData.Assigned_AMO,
        Assigned_STL:formData.Assigned_STL,
        TeamLead_ID: formData.TeamLeadID,
        Onshore_Lead: formData.Onshore_Lead,
        BillingAssociate_ID: formData.BillingAssociateID,
        Shift: formData.Shift,
        Division_ID: formData.DivisionID,
        PHD_POCid:formData.PHDPOCId
      };
      if(this.objReportingModel.Practice_Alias == null || this.objReportingModel.Practice_Alias == "" ){
          this.toaster.warning('Enter Practice Alias','Validation');
          return;
      }
       if(this.objReportingModel.Assigned_Client == null || this.objReportingModel.Assigned_Client == "" ){
          this.toaster.warning('Please select Assigned Client','Validation');
          return;
      }
        if(this.objReportingModel.Assigned_ADO == null || this.objReportingModel.Assigned_ADO == 0 ){
          this.toaster.warning('Please Select Assistant Director Name','Validation');
          return;
      }
      if(this.objReportingModel.Assigned_AMO == null || this.objReportingModel.Assigned_AMO == 0 ){
          this.toaster.warning('Please Select Assistant Manager Name','Validation');
          return;
      }
          if(this.objReportingModel.Assigned_STL == null || this.objReportingModel.Assigned_STL == 0 ){
          this.toaster.warning('Please Select Senior Team Lead Name','Validation');
          return;
      }
      if(this.objReportingModel.PHD_POCid == null || this.objReportingModel.PHD_POCid == 0){
            this.toaster.warning('Enter PHDPOC','Validation');
            return;
      }
      this.API.PostData('/PracticeSetup/SaveReportingDetails', this.objReportingModel, (response) => {
        $('#practiceReporting').modal('hide');
        this.onclose();
        if (response.Status === 'Success') {
          swal('Success', 'Reporting Details have been saved successfully', 'success');
           this.addEditPrac.GetPracticeReportingDetail(this.SelectedPracticeCode);
          
        } else {
          swal('Failed', response.Status, 'error');
        }

      });

    }

    // Here, you can send the form values to your backend or perform any other action
  }

  getValueFromArray(dropdownVal: any[]): any {
    debugger
    if (typeof dropdownVal === 'string') {
      const str = dropdownVal as string; // Type assertion since TypeScript infers strOrArr as string | number[]
      return str.split('-')[0];
    } else if (Array.isArray(dropdownVal)) {
      for (let i = 0; i < dropdownVal.length; i++) {
        if (dropdownVal[i] !== undefined) {
          return dropdownVal[i].split('-')[0];
        }
      }
      return undefined; // Return undefined if no non-undefined value found
    } else {
      return null;
    }
  }

//   GetPracticeDropDownValues() {

//     // Fetch active users for the selected practice code
//     this.API.getData('/PracticeSetup/GetActiveUsersForPractice?practiceCode=' + this.SelectedPracticeCode).subscribe(
//       data => {
//         if (data.Status === 'Success') {
//           console.log('Active Users', data);
//           debugger
//           // Map response data to desired format for dropdown
//           const resData = data.Response.map(user => `${user.EmpId}-${user.LastName}, ${user.FirstName}`);
//           this.usersSelectList = resData;
//           this.usersSelectList = this.usersSelectList.map(u => ({
//   ...u,
//   name: `${u.EmpId} | ${u.FirstName} ${u.LastName}`
// }));
//           console.log('User List', this.usersSelectList);
//         }
//       },
//       error => {
//         console.error('Error fetching active users:', error);
//       }
//     );

//     // Fetch divisions for the user
//     this.API.getData('/PracticeSetup/GetDivisionForUser').subscribe(
//       data => {
//         if (data.Status === 'Success') {
//           console.log('Users Division', data);
//           this.divisionDropdownData = data.Response;
//         }
//       },
//       error => {
//         console.error('Error fetching divisions:', error);
//       }
//     );
//   }
GetPracticeDropDownValues() {

  this.API
    .getData('/PracticeSetup/GetActiveUsersForPractice?practiceCode=' + this.SelectedPracticeCode)
    .subscribe(
      data => {
        if (data.Status === 'Success') {
           debugger
           debugger
          this.usersSelectList = data.Response.map(user => ({
            UserId: user.UserId,
            EmpId: user.EmpId,
            FirstName: user.FirstName,
            LastName: user.LastName,
            name: user.EmpId === 0
      ? `${user.FirstName} ${user.LastName}`
      : `${user.EmpId} | ${user.FirstName} ${user.LastName}` // display text
          }));
          // Map response data to desired format for dropdown
          // const resData = data.Response.map(user => `${user.EmpId}-${user.LastName}, ${user.FirstName}`);
          // this.usersSelectList = resData;
        }
      },
      error => {
        console.error('Error fetching active users:', error);
      }
    );
    // Fetch divisions for the user
    this.API.getData('/PracticeSetup/GetDivisionForUser').subscribe(
      data => {
        if (data.Status === 'Success') {
          this.divisionDropdownData = data.Response;
        }
      },
      error => {
        console.error('Error fetching divisions:', error);
      });
}

  get f() {
    return this.ReportingModelForm.controls;
  }

  ReportingDataOnLoad() {

    this.GetReportingDetailOfUser();

  }

  GetReportingDetailOfUser() {
    this.API.getData('/PracticeSetup/GetReportingDetailOfPracticeUser?userID=' + this.gvService.currentUser.userId + '&practiceCode=' + this.SelectedPracticeCode).subscribe(data => {
      if (data.Status == 'Success') {
        debugger;
        debugger
        // this.objReportingModel = data.Response;
        // this.f.ID.setValue(this.objReportingModel[0].ID);
        // this.f.Practice_Alias.setValue(this.objReportingModel[0].Practice_Alias);
        // this.f.DivisionID.setValue(this.objReportingModel[0].Division_ID);
        //     this.f.PHDPOCId.setValue(this.objReportingModel[0].PHD_POCid);
        // this.f.Shift.setValue(this.objReportingModel[0].Shift);
        // this.getUserNameFromList(this.objReportingModel[0].Manager_ID, 'Manager').then(
        //   this.getUserNameFromList(this.objReportingModel[0].TeamLead_ID, 'TL').then(
        //     this.getUserNameFromList(this.objReportingModel[0].BillingAssociate_ID, 'BA')))
         this.objReportingModel = data.Response[0];
         if( data.Response[0].Practice_Software == 101){
            this.f.Assigned_Client.setValue("NPM Client");
         }
         else{
          this.f.Assigned_Client.setValue("Other Client");
         }
        this.f.ID.setValue(this.objReportingModel.ID);
        this.f.Practice_Alias.setValue(this.objReportingModel.Practice_Alias);
        this.f.DivisionID.setValue(this.objReportingModel.Division_ID);
        this.f.PHDPOCId.setValue(this.objReportingModel.PHD_POCid);
        this.f.Shift.setValue(this.objReportingModel.Shift);
        this.f.ManagerID.setValue(this.objReportingModel.Manager_ID);
this.f.TeamLeadID.setValue(this.objReportingModel.TeamLead_ID,);
this.f.BillingAssociateID.setValue(this.objReportingModel.BillingAssociate_ID);
this.f.Assigned_ADO.setValue(this.objReportingModel.Assigned_ADO);
this.f.Assigned_AMO.setValue(this.objReportingModel.Assigned_AMO);
this.f.Assigned_STL.setValue(this.objReportingModel.Assigned_STL);
this.f.Onshore_Lead.setValue(this.objReportingModel.Onshore_Lead);
        // this.getUserNameFromList(this.objReportingModel.Manager_ID, 'Manager').then(
        // this.getUserNameFromList(this.objReportingModel.TeamLead_ID, 'TL').then(
        // this.getUserNameFromList(this.objReportingModel.BillingAssociate_ID, 'BA').then(
        // this.getUserNameFromList(this.objReportingModel.Assigned_Assistant_Director, 'AAD').then(
        // this.getUserNameFromList(this.objReportingModel.Assigned_Assistant_Manager, 'AAM').then(
        // this.getUserNameFromList(this.objReportingModel.Assigned_Senior_Team_Lead, 'ASTL').then(
        // this.getUserNameFromList(this.objReportingModel.Onshore_Lead, 'ONSTM')
        // ))))))

      }
      else if(data.Status == 'No data found'){
          this.API.getData('/PracticeSetup/GetPracticeSoftware?PracticeCode=' + this.SelectedPracticeCode).subscribe(data => {
      if (data.Status == 'Success') {
        debugger
        if( data.Response == 101){
            this.f.Assigned_Client.setValue("NPM Client");
         }
         else{
          this.f.Assigned_Client.setValue("Other Client");
         }
      }
    })}
      {}
      
    });
  }


  getUserNameFromList(ID, dropdownType) {
    return this.usersSelectList.map(item => {
      if (item.split('-')[0] === String(ID)) {
        if (dropdownType === 'Manager') {
          this.managerData = item;
         
        }
        else if (dropdownType === 'TL') {

          this.teamLeadData = item;
        } 
         else if (dropdownType === 'PHDPOC') {

           this.PHDData =item;
        }
         else if (dropdownType === 'AAD') {

           this.f.Assigned_ADO.setValue(item);
        }
         else if (dropdownType === 'AAM') {

           this.f.Assigned_AMO.setValue(item);
        }
        else if (dropdownType === 'ASTL') {

           this.f.Assigned_STL.setValue(item);
        }
         else if (dropdownType === 'ONSTM') {

           this.f.Onshore_Lead.setValue(item);
        }
        else {
          this.billingAssociateData = item;
        }
        return item;

      }
    });
  }
  getProviderCode(Type: string = "") {
    this.toaster.warning('getProviderCode is called', 'Validation');
    this.API.Gv.ProviderCode = this.saveProviderModel.Provider_Code;
    if (Type == 'ProviderPayers') {
      this.toaster.error('ProviderPayers is called', 'Validation');
      setTimeout(function () {
        $("#btnProviderPayer").trigger("click");
      }, 100);
    }
    else if (Type == "ProviderNotes") {

    }
    else if (Type == "ProviderResources") {
      this.toaster.error('ProviderResources is called', 'Validation');
      setTimeout(function () {
        $("#btnProviderResources").trigger("click");
      }, 100);

    }
    else {
      setTimeout(function () {
        this.toaster.error('btnLoadLocation is called', 'Validation');
        $("#btnLoadLocation").trigger("click");
      }, 100);
    }
  }
  ShowInsuranceNamePopup() {
     if (!this.mapPayerPropertyExist) {
    this.toaster.error("Access Denied: Cannot Map  Practice Payer.Error");
    return; 
  }
    this.insuranceModal.show();
    //this.currentInsuranceNumber = ndx;
  }

  onCloseSearch() {
    this.prcIns.clearForm();

  }

  deleteProviderPayer(providerPayerId: string) {
     if (!this.delPracPayerPropertyExist) {
    this.toaster.error("Access Denied: Cannot Delete Practice Payer.Error");
    return; 
  }
    this.API.confirmFun('Confirmation', 'Do you want to delete this Payer?', () => {
      this.API.getData(`/PracticeSetup/DeletePracticePayers?PracticeId=${this.SelectedPracticeCode}&ProviderPayerId=${providerPayerId}`).subscribe(
        data => {
          if (data.Status === 'Success') {
            this.listProviderPayer = data.Response;
            localStorage.setItem('showSuccessSwal', 'true');
            window.location.reload();
          } else {
            alert(data.Response);
          }
        }
      );
    });
  }

  handleMapSuccess(): void {
    $('#providerpayersInfo').modal('hide');
  }
getUsersList() {
  this.API.getData('/UserManagementSetup/GetUsersList').subscribe(data => {
    if (data.Status === 'Success') {
      let users = data.Response.map((user: any) => ({
        ...user,
        DisplayLabel: `${user.UserName} | ${user.FirstName} ${user.LastName}`,
        disabled: false // all actual users are selectable
      }));
      // Add 'Select' option at top, but disable it
      this.listUser = [
        { UserId: null, DisplayLabel: 'Select PHD POC', disabled: true },
        ...users
      ];
    }
  });
}
checkPracticePayerAccess(rolesAndRights: any[]): void {
  // Step 1: Check for Module
  this.moduleExists = rolesAndRights.some(
    r => r.ModuleName === 'PracticeProfile'
  );
  // Step 2: Check for SubModule (only if module exists)
  this.subModuleExists = rolesAndRights.some(
    r => r.ModuleName === 'PracticeProfile' && r.SubModuleName === 'PracticePayers'
  );
  // Step 3: Check for Property (only if module + submodule exist)
  this.mapPayerPropertyExist = rolesAndRights.some(
    r =>
      r.ModuleName === 'PracticeProfile' &&
      r.SubModuleName === 'PracticePayers' &&
      r.PropertyName === 'MapPayer'
  );
  this.delPracPayerPropertyExist = rolesAndRights.some(
    r =>
     r.ModuleName === 'PracticeProfile' &&
      r.SubModuleName === 'PracticePayers' &&
      r.PropertyName === 'DeletePayer'
  );

 }

checkPracticeReportingAccess(rolesAndRights: any[]) : void{
  // Step 1: Check for Module
  this.moduleExists = rolesAndRights.some(
    r => r.ModuleName === 'PracticeProfile'
  );
  // Step 2: Check for SubModule (only if module exists)
  this.subModuleExists = rolesAndRights.some(
    r => r.ModuleName === 'PracticeProfile' && r.SubModuleName === 'PracticeReporting'
  );
  // Step 3: Check for Property (only if module + submodule exist)
   this.saveRepoPropertyExist = rolesAndRights.some(
    r =>
      r.ModuleName === 'PracticeProfile' &&
      r.SubModuleName === 'PracticeReporting' &&
      r.PropertyName === 'AddReporting'
  );
}
checkPracticeInstructionAccess(rolesAndRights: any[]) : void{
  // Step 1: Check for Module
  this.moduleExists = rolesAndRights.some(
    r => r.ModuleName === 'PracticeProfile'
  );
  // Step 2: Check for SubModule (only if module exists)
  this.subModuleExists = rolesAndRights.some(
    r => r.ModuleName === 'PracticeProfile' && r.SubModuleName === ' Instructions'
  );
  // Step 3: Check for Property (only if module + submodule exist)
 this.addInstructionPropertyExist = rolesAndRights.some(
    r =>
     r.ModuleName === 'PracticeProfile' &&
      r.SubModuleName === 'Instructions' &&
      r.PropertyName === 'AddInstruction'
  );
  this.editInstructionPropetyExist = rolesAndRights.some(
    r =>
    r.ModuleName === 'PracticeProfile' &&
      r.SubModuleName === 'Instructions' &&
      r.PropertyName === 'EditInstruction'
  );
}
checkPracticeNotesAccess(rolesAndRights: any[]) : void{
  // Step 1: Check for Module
  this.moduleExists = rolesAndRights.some(
    r => r.ModuleName === 'PracticeProfile'
  );
  // Step 2: Check for SubModule (only if module exists)
  this.subModuleExists = rolesAndRights.some(
    r => r.ModuleName === 'PracticeProfile' && r.SubModuleName === 'PracticeNotes'
  );
  // Step 3: Check for Property (only if module + submodule exist)
  this.addNotesPropetyExist = rolesAndRights.some(
    r =>
     r.ModuleName === 'PracticeProfile' &&
      r.SubModuleName === 'PracticeNotes' &&
      r.PropertyName === 'AddPracNotes'
  );
    this.editNotesPropetyExist = rolesAndRights.some(
    r =>
      r.ModuleName === 'PracticeProfile' &&
      r.SubModuleName === 'PracticeNotes' &&
      r.PropertyName === 'EditPracNotes'
  );
      this.deleteNotesPropertyExist = rolesAndRights.some(
    r =>
      r.ModuleName === 'PracticeProfile' &&
      r.SubModuleName === 'PracticeNotes' &&
      r.PropertyName === 'DeletePracNotes'
  );
}
checkProviderNotesAccess(rolesAndRights: any[]){
   // Step 1: Check for Module
  this.moduleExists = rolesAndRights.some(
    r => r.ModuleName === 'PracticeProfile'
  );
  // Step 2: Check for SubModule (only if module exists)
  this.subModuleExists = rolesAndRights.some(
    r => r.ModuleName === 'PracticeProfile' && r.SubModuleName === 'ProviderNotes'
  );
  // Step 3: Check for Property (only if module + submodule exist)
  this.addProviderNotesPropertyExist = rolesAndRights.some(
    r =>
      r.ModuleName === 'PracticeProfile' &&
      r.SubModuleName === 'ProviderNotes' &&
      r.PropertyName === 'AddNotes'
  );
  this.editProviderNotesPropertyExist = rolesAndRights.some(
    r =>
     r.ModuleName === 'PracticeProfile' &&
      r.SubModuleName === 'ProviderNotes' &&
      r.PropertyName === 'EditNotes'
  );
    this.DeleteProviderNotesPropertyExist = rolesAndRights.some(
    r =>
     r.ModuleName === 'PracticeProfile' &&
      r.SubModuleName === 'ProviderNotes' &&
      r.PropertyName === 'DeleteNotes'
  );
}
checkPracticeSyncAccess(rolesAndRights: any[]): void {
  // Step 1: Check for Module
  this.moduleExists = rolesAndRights.some(
    r => r.ModuleName === 'PracticeProfile'
  );
  // Step 2: Check for SubModule (only if module exists)
  this.subModuleExists = rolesAndRights.some(
    r => r.ModuleName === 'PracticeProfile' && r.SubModuleName === 'PracticeInfo'
  );
  // Step 3: Check for Property (only if module + submodule exist)
  this.syncPracticePropertyExist = rolesAndRights.some(
    r =>
     r.ModuleName === 'PracticeProfile' &&
      r.SubModuleName === 'PracticeInfo' &&
      r.PropertyName === 'SyncPrac'
  );

 }
 checkPracticeDocAccess(rolesAndRights: any[]) : void{
   // Step 1: Check for Module
  this.moduleExists = rolesAndRights.some(
    r => r.ModuleName === 'PracticeProfile'
  );
  // Step 2: Check for SubModule (only if module exists)
  this.subModuleExists = rolesAndRights.some(
    r => r.ModuleName === 'PracticeProfile' && r.SubModuleName === 'PracticeDoc'
  );
  this.pracDocSubModule = rolesAndRights.some(
    r =>
     r.ModuleName === 'PracticeProfile' &&
      r.SubModuleName === 'PracticeDoc' 
  );
  // Step 3: Check for Property (only if module + submodule exist)
  this.addPracticeDocExist = rolesAndRights.some(
    r =>
     r.ModuleName === 'PracticeProfile' &&
      r.SubModuleName === 'PracticeDoc' &&
      r.PropertyName === 'AddDoc'
  );
  this.editPracticeDocExist = rolesAndRights.some(
    r =>
     r.ModuleName === 'PracticeProfile' &&
      r.SubModuleName === 'PracticeDoc' &&
      r.PropertyName === 'EditDoc'
  );
    this.deletePracticeDocExist = rolesAndRights.some(
    r =>
     r.ModuleName === 'PracticeProfile' &&
      r.SubModuleName === 'PracticeDoc' &&
      r.PropertyName === 'DeleteDoc'
  );
 }
 checkAccess(rolesAndRights: any[]): void {
  // Step 2: Check for SubModule (only if module exists)
  this.WebPortalsExists = rolesAndRights.some(
    r => r.ModuleName === 'PracticeProfile' && r.SubModuleName === 'WebPortals'
  );
 
}
closeDOCModal() {
 

  ($('#PracDocumentModal') as any).one('hidden.bs.modal', () => {
    $('body').removeClass('modal-open');
    $('.modal-backdrop').remove();
          this.GetAllDoc();
    // Show previous modal
    ($('#practicedoc') as any).modal('show');
  });

  // Hide upload modal
  ($('#PracDocumentModal') as any).modal('hide');

  // Reset data
  this.docModel = new DocumentModel();
  this.selectedFile = [];
  this.fileValidationUpdate = true;
 
}
closeGetDOCModal() {
    setTimeout(() => {
      this.selectedDocumentType = "All";  
      this.cdr.detectChanges();  
    }, 0);   

  ($('#practicedoc') as any).modal('hide');

 
}
showDocModelHandle() {
     ($('#practicedoc') as any).modal('hide');

 this.fileValidationUpdate=false
this.docModel= new DocumentModel()
this.selectedDocumentType=""
 this.attachLink=false;
  this.clearDatePickers();
  this.chRef.detectChanges();
}
        GetDocTypeList() {
        this.API.getData('/PracticeSetup/GetPracticeDocTypeList').subscribe(
            data => {
                if (data.Status === 'Success') {
                    this.docTypeList = data.Response;
                    let docs = data.Response.map(doc => ({
    Type_Value: doc.Type_Value,
    Type_Dec: doc.Type_Dec
  }));
                   this.searchableDocTypeList = [
  { Type_Value: null, Type_Dec: 'All' },
  ...this.docTypeList.map(d => ({
      Type_Value: d.Type_Value,
      Type_Dec: d.Type_Dec
  }))
];
        this.selectedDocumentType = null;
                } else {
                    swal('Failed', data.Status, 'error');
                }
            }
        );
    }

    SearchDoc(){
   const selectedValue = this.selectedDocumentType;  
   this.selectedDocumentShow =  this.selectedDocumentType
  const selectedItem = this.searchableDocTypeList.find(item => item.Type_Dec === selectedValue);
  const description = selectedItem ? selectedItem.Type_Value : null;
  this.selectedDocumentType = description;
  if(this.selectedDocumentType=="All"){
      this.selectedDocumentType= null
  }
     this.GetAllDoc();
    } 

GetAllDoc() {
   if(this.selectedDocumentType=="All"){
      this.selectedDocumentType= null
      this.selectedDocumentShow="All"
  }
  this.API.getData(
    `/PracticeSetup/GetPracticeDocList?PracticeCode=${this.SelectedPracticeCode}&Doc_Type=${this.selectedDocumentType}`
  ).subscribe(data => {
    if (data.Status === 'Success') {
      this.selectedDocumentType =this.selectedDocumentShow
            if ($.fn.DataTable.isDataTable('#docPTable')) {
        $('#docPTable').DataTable().clear().destroy();
      }

                    this.docList=data.Response;
                    this.chRef.detectChanges();
                   setTimeout(() => {
        this.docPTable = $('#docPTable').DataTable({
          ScrollX:true,
           ScrollY:true,
          columnDefs: [
            { orderable: false, targets: -1 }
          ],
          language: {
            emptyTable: 'No data available'
          },
          pageLength: 10
        });
      }, 0);
  
      // Show modal
      ($('#practicedoc') as any).modal('show');
    } else {
      swal('Failed', data.Status, 'error');
    }
  });
}

onDateChangedIssue(event) {
  this.docModel.Issue_Date = event.formatted;
  //this.docModel.Issue_Date = event ? event.formatted : null;
}

onDateChangedExp(event) {
  this.docModel.Expiry_Date  = event.formatted;
  //this.docModel.Expiry_Date = event ? event.formatted : null;
}

clearDatePickers() {
  // Remove pickers from DOM
  this.showIssueDatePicker = false;
  this.showExpiryDatePicker = false;

  // After Angular removes them, set null dates and bring them back
  setTimeout(() => {
    this.issuedate = null;
    this.expirydate = null;

    this.docModel.Issue_Date = null;
    this.docModel.Expiry_Date = null;

    this.showIssueDatePicker = true;
    this.showExpiryDatePicker = true;
  }, 0);
}
saveDoc() {
  if (this.docModel.Document_Type === "") {
    this.toaster.error("Please Select a Document Type", "Error");
    return;
  }

  //const issue = moment(this.docModel.Issue_Date).startOf('day');
  //const expiry = moment(this.docModel.Expiry_Date).startOf('day');

 const issueDate = new Date(this.docModel.Issue_Date);
const expiryDate = new Date(this.docModel.Expiry_Date);

if (expiryDate < issueDate) {
  this.toaster.error(
    'Expiry Date cannot be earlier than Issue Date.',
    'Error'
  );
  return;
}

  if (this.selectedFile.length === 0 && this.fileValidationUpdate === false) {
    this.toaster.error("Please attach at least one document file.", "Error");
    return;
  }

  this.docModel.Practice_Code = this.SelectedPracticeCode;

  this.API.PostData('/PracticeSetup/SavePracticeDocs', this.docModel, (d) => {

    if (d.Status === 'Success') {
      this.practiceDocId = d.Response.Practice_Doc_Id;
  this.clearDatePickers();
      ($('#PracDocumentModal') as any).one('hidden.bs.modal', () => {
        $('body').removeClass('modal-open');
        $('.modal-backdrop').remove();
        this.uploadFileAfterSave();
        this.GetAllDoc();
        ($('#practicedoc') as any).modal('show');
      });

      ($('#PracDocumentModal') as any).modal('hide');
      this.chRef.detectChanges();
    }
  });
}
 onFileSelected(event: any): void {
  const files: FileList = event.target.files;
  const allowedExtensions = ['pdf', 'jpg', 'jpeg', 'png', 'docx', 'xls', 'xlsx'];
  // If no message selected, do nothing
  //if (this.selectedMessage == null) return;
  // Check if it's a new message (plain string) or an existing message (object)
  const isNewMessage = typeof this.selectedMessage === 'string';

  if (isNewMessage) {
    // Validate that the message is not empty or just whitespace
    
    // Loop through selected files
    for (let i = 0; i < files.length; i++) {
      const file = files.item(i);
      if (!file) continue;
      
      const fileName = file.name;
      const fileSize = file.size;
      const fileExt = fileName.split('.').pop().toLowerCase();
      if (!fileExt || !allowedExtensions.includes(fileExt)) {
        this.toaster.error(
        'Only supported file formats are allowed (PDF, JPG, JPEG, PNG, DOCX, XLS, XLSX).',
        'Error'
      );
        continue;
      }
        
      // Limit to 4 attachments
      if (this.selectedFile.length >= 4) {
        this.toaster.error('You cannot upload more than 4 attachments.','Error');
        break;
      }
      this.selectedFile.push(file);
    }
     event.target.value = '';
    return;
  }


  if (!this.selectedMessage.selectedFile) {
    this.selectedMessage.selectedFile = [];
  }

  if (!this.selectedFile) {
    this.selectedFile = [];
  }

  for (let i = 0; i < files.length; i++) {
    const file = files.item(i);
    if (!file) continue;

    const fileName = file.name;
    const fileSize = file.size;
    const fileExt = fileName.split('.').pop().toLowerCase();
      if (!fileExt || !allowedExtensions.includes(fileExt)) {
      this.toaster.error(
        'Only supported file formats are allowed (PDF, JPG, JPEG, PNG, DOCX, XLS, XLSX).',
        'Error'
      );
      continue;
    }

    const totalForMessage =
      (this.selectedMessage.selectedFile.length || 0) +
      (this.selectedMessage.attachments.length || 0);

    if (totalForMessage >= 4) {
      this.toaster.error('You cannot upload more than 4 attachments for this message.','Error');
      break;
    }
    this.selectedMessage.selectedFile.push(file);
    this.selectedFile.push(file);
      event.target.value = '';
  }
}
uploadFileAfterSave() {
  if (!this.selectedFile || this.selectedFile.length === 0) {
    return;
  }

  const formData = new FormData();
  formData.append("fileName", this.selectedFile[0].name);
  formData.append("id", this.practiceDocId.toString());
  formData.append("file", this.selectedFile[0]);
  this._fileHandlerService.UploadFile(formData, '/PracticeSetup/PracticeDocFileUpload')
      .subscribe(res => {
        if (res.Status === "success") {

     this.issuedate = null;
  this.docModel.Issue_Date = null;
  this.expirydate = null;
  this.docModel.Expiry_Date=null;
  this.chRef.detectChanges();

           this.GetAllDoc();
          this.selectedFile=[]
          this.fileValidationUpdate=false
        } else {
          
        }
      }, (error) => {
         
      });
}
 GetPracticeDocBYid(Id :number){
    ($('#practicedoc') as any).modal('hide')
    this.API.getData(`/PracticeSetup/GetPracticeDocBYId?id=${Id}`).subscribe(
            data => {
   if (data.Status =='Suceess'){
          this.docModel=data.Response;
          debugger
         this.setIssueDate(this.docModel.Issue_Date);
         this.setExpiryDate(this.docModel.Expiry_Date);

          this.attachLink=true;
          this.fileValidationUpdate=true;
          ($('#PracDocumentModal') as any).modal('show')

        } else {
                    swal('Failed', data.Status, 'error');
                }
            }
        );
 }
 DeletePracticeDocBYid(Id :number){
  this.API.confirm(
        'Confirmation',  
        'Are you sure you want to delete?',  
        () => {  
            this.onDelYesClick(Id);
        },
        () => {  // If user clicks "No"
            this.onDelNoClick();
        }
    );
 }
openDocument(id: number): void {
  this.API.getFile(`/PracticeSetup/DownloadPracFile/${id}`)
    .subscribe((file: Blob) => {
       const blobUrl = window.URL.createObjectURL(file);
      const newWindow = window.open(blobUrl, '_blank');

      if (!newWindow) {
        alert('Please allow popups for this website to open the document.');
      }
      setTimeout(() => {
        window.URL.revokeObjectURL(blobUrl);
      }, 10000); 
    }, error => {
      console.error('Error opening file', error);
    });
}
removeFile(index: number) {
  this.selectedFile.splice(index, 1);
    if (this.fileInput) {
    this.fileInput.nativeElement.value = '';
  }
}
deleteFile(file: any) {
  this.backupFile = {
    File_Name: this.docModel.File_Name,
    File_Path: this.docModel.File_Path
  };

  this.API.confirm(
    'Confirmation',
    'Are you sure you want to delete?',
    () => {
      this.onYesClick();   // YES
    },
    () => {
      this.onNoClick();    // NO
    }
  );
}

onNoClick(): any {
     if (this.backupFile) {
    this.docModel.File_Name = this.backupFile.File_Name;
    this.docModel.File_Path = this.backupFile.File_Path;
    this.attachLink=true;
  }
  // this.resetFields();
}

onYesClick(): any {
this.docModel.File_Name = '';
  this.docModel.File_Path = '';
   this.attachLink=false;
   this.fileValidationUpdate=false;
}
restoreOldFile() {
  if (this.backupFile) {
    this.docModel.File_Name = this.backupFile.File_Name;
    this.docModel.File_Path = this.backupFile.File_Path;
  }
}
onDelYesClick(Id: number) {
    // Proceed with the deletion if the user clicked "Yes"
    this.API.getData(`/PracticeSetup/DeletePracticeDocBYid?id=${Id}`).subscribe(
        data => {
            if (data.Status === 'Success') {
                this.GetAllDoc();
                ($('#practicedoc') as any).modal('show');  
            } else {
                swal('Failed', data.Status, 'error');
            }
        },
        error => {
            swal('Error', 'An error occurred while deleting the document', 'error');
        }
    );
}
onDelNoClick() {
   
}
    setIssueDate(date: string) {
        if (!Common.isNullOrEmpty(date)) {
            let dDate = new Date(date);
            this.issuedate = {
                year: dDate.getFullYear(),
                month: dDate.getMonth() + 1,
                day: dDate.getDate()
            };
        }
    }

    setExpiryDate(date: string) {
        if (!Common.isNullOrEmpty(date)) {
            let dDate = new Date(date);
            this.expirydate = {
                year: dDate.getFullYear(),
                month: dDate.getMonth() + 1,
                day: dDate.getDate()
            };
        }
    }
}



