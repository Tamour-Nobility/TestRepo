import { NgModule } from '@angular/core';
import { AddEditPracticeComponent } from './addeditpractice/add-edit-practice.component';
import { LocationsComponent } from './Locations/locations.component';
import { PracticeListComponent } from './practiceList/practice-list.component';
import { PracticeTABComponent } from './practiceTAB/practice-tab.component';
import { ProvidersComponent } from './providers/providers.component';
import { SharedModule } from '../shared/shared.module';
import { practiceSetupRoutingModule } from './practiceSetupRouting.module';
import { WebPortalsComponent } from './web-portals/web-portals.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
@NgModule({
  declarations: [
    AddEditPracticeComponent,
    LocationsComponent,
    PracticeListComponent,
    PracticeTABComponent,
    ProvidersComponent,
       WebPortalsComponent,
  ],
  imports: [
    SharedModule,
        NgbModule,
    practiceSetupRoutingModule
  ]
})
export class PracticeSetupModule { }
