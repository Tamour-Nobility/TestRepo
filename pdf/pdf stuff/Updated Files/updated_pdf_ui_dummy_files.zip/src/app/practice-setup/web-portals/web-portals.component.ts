import { ChangeDetectorRef, Component, OnInit, AfterViewInit, OnDestroy, Input, ViewChild } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import 'datatables.net';
import { ToastrService } from 'ngx-toastr';
import { APIService } from '../../components/services/api.service';
import { GvarsService } from '../../services/G_vars/gvars.service';
import { ModalDirective, ModalOptions } from 'ngx-bootstrap/modal';
import { CurrentUserViewModel } from '../../models/auth/auth';


interface WebPortal {
    id?: number;
  insuranceName: string;
  webLink: string;
  userName: string;
  userId?: string;
  password: string;
  emailForOtp?: string;
  phoneForOtp?: string;
  securityQuestion?: string;
  additionalInfo?: string;
  status: 'Active' | 'Inactive' | 'Blocked' | 'Disabled'|'Locked';
  createdBy?: string;
  Created_By_Name?:string;
  Modified_By_Name?:string;
  createdDate?: string;
  lastUpdatedBy?: string;
  lastUpdatedDate?: string;
}

@Component({
  selector: 'app-web-portals',
  templateUrl: './web-portals.component.html',
  styleUrls: ['./web-portals.component.css']
})
export class WebPortalsComponent implements OnInit, AfterViewInit, OnDestroy {
  portals: WebPortal[] = [];
 
@Input() practiceId?: number;
  isPayExpand = false;
  hide:boolean=false;
  editIndex: number | null = null;
@ViewChild('bsModal') bsModal: ModalDirective;
@ViewChild('sqModal') sqModal: ModalDirective;
@ViewChild('aiModal') aiModal: ModalDirective;
npmPassword: string = '';
IsPasswordCorrect: boolean | null = null; // null = not checked, true = success, false = failed
protectedPassword: string = ''; 
securityQuestions:string;
addtionInfo:string;
  pracTable: any;
  selectedPassword = '';
  selectedSecurity = '';
  selectedInfo = '';
 currentUser: CurrentUserViewModel;
      moduleExists = false;
      subModuleExists = false;
      viewWebPortalsPropertyExist=false;
     modifyWebPortalsPropertyExist=false;
  constructor(private cdr: ChangeDetectorRef,private toastr: ToastrService,private api:APIService,private GV: GvarsService,) {}

  ngOnInit(): void {
   this.checkAccess(this.GV.currentUser.RolesAndRights);
 this.getAllPortals()
  }

 ngAfterViewInit(): void {

 //setTimeout(() => this.initDataTable(), 0);
 
 
}


  ngOnDestroy(): void {
    this.destroyDataTable();
  }

  private getEmptyPortal(): WebPortal {
    return {
      insuranceName: '',
      webLink: '',
      userName: '',
      userId: '',
      password: '',
      emailForOtp: '',
      phoneForOtp: '',
      securityQuestion: '',
      additionalInfo: '',
      status: 'Active'
    };
  }


private destroyDataTable(): void {
  if (this.pracTable) {
    this.pracTable.destroy();
    this.pracTable = null;
  }
}

private initDataTable(): void {
  const tableElement = $('#tblwebportals') as any;
  if (!tableElement.length || !this.portals.length) return;

  this.pracTable = tableElement.DataTable({
    paging: true,
    searching: true,
    info: true,
    lengthChange: true,
    responsive: false,
    autoWidth: false,
    ordering: false,
    destroy: true,
    scrollX:true,
    language: { emptyTable: 'No data available' },
    columnDefs: [{ orderable: false, targets: -1 }]
  });


  [10, 11, 12, 13].forEach(i => {
    if (this.pracTable.column(i)) {
      this.pracTable.column(i).visible(this.isPayExpand);
    }
  });

  setTimeout(() => {
    this.pracTable.columns.adjust().draw();
  }, 0);
}

addNewPortalRow(): void {
  if (this.editIndex === null) {
    this.hide = true;
    if (this.isPayExpand) {
      this.isPayExpand = !this.isPayExpand;
    }
 
    const newPortal = this.getEmptyPortal();
    this.portals.unshift(newPortal);
    this.editIndex = 0;
 
    this.destroyDataTable();
    this.initDataTable();
  }
}

  payExpand(): void {
    this.isPayExpand = !this.isPayExpand;
    if (this.pracTable) {
      [10, 11, 12, 13].forEach(i => this.pracTable.column(i).visible(this.isPayExpand));
    }
  }

  editPortal(index: number): void {
    this.hide=true;
    this.editIndex = index;
  }

savePortal(): void {
  if (this.editIndex === null) return;

  const portal = this.portals[this.editIndex];

  // === VALIDATIONS ===

  // 1. Insurance Name (Mandatory | up to 100 alphanumeric + special chars)
  if (!portal.insuranceName.trim()) {
    this.toastr.warning('Insurance Name is required.');
    return;
  }
  if (!/^[\w\s@#&().,/\-:;'"!?%$^*+=~`|<>[\]{}]{1,100}$/.test(portal.insuranceName)) {
    this.toastr.warning('Insurance Name can contain up to 100 alphanumeric and special characters.');
    return;
  }

  // 2. Web Link (Mandatory | up to 300 chars | hyperlink on UI)
  if (!portal.webLink.trim()) {
    this.toastr.warning('Web Link is required.');
    return;
  }
 if (!/^.{1,300}$/.test(portal.webLink.trim())) {
    this.toastr.warning('Web Link can contain up to 300 alphanumeric and special characters.');
    return;
  }

  // 3. User Name (Mandatory | up to 50 alphanumeric only)
  if (!portal.userName.trim()) {
    this.toastr.warning('User Name is required.');
    return;
  }
  if (!/^.{1,50}$/.test(portal.userName)) {
      this.toastr.warning('User Name can contain up to 50 alphanumeric and special characters .');
    return;
  }

  // 4. User ID (Optional | up to 50 alphanumeric only)
  if (portal.userId && !/^.{0,50}$/.test(portal.userId)) {
     this.toastr.warning('User ID can contain up to 50 alphanumeric and special characters .');
    return;
  }

  // 5. Password (Mandatory | up to 25 alphanumeric + special chars)
  if (!portal.password.trim()) {
    this.toastr.warning('Password is required.');
    return;
  }
 if (!/^.{1,25}$/.test(portal.password)) {
    this.toastr.warning('Password can contain up to 25 alphanumeric and special characters.');
    return;
  }

  // 6. Email for OTP (Optional | valid format | up to 50 chars)
if (portal.emailForOtp) {
    if (portal.emailForOtp.length > 50) {
      this.toastr.warning('Email for OTP can contain up to 50 characters.');
      return;
    }
    if (!/^[\w\-.]+@([\w-]+\.)+[\w-]{2,4}$/.test(portal.emailForOtp)) {
      this.toastr.warning('Invalid Email format for OTP.');
      return;
    }
  }

  // 7. Phone for OTP (Optional | up to 10 numeric characters)
  if (portal.phoneForOtp && !/^\d{0,10}$/.test(portal.phoneForOtp)) {
    this.toastr.warning('Phone for OTP must contain up to 10 numeric characters.');
    return;
  }

if (portal.securityQuestion && !/^[\s\S]{0,300}$/.test(portal.securityQuestion)) {
  this.toastr.warning('Security Question can contain up to 300 characters.');
  return;
}
if (portal.additionalInfo && !/^[\s\S]{0,300}$/.test(portal.additionalInfo)) {
  this.toastr.warning('Additional Info can contain up to 300 characters.');
  return;
}

  // 10. Status (Dropdown | Required | Default: Active)
  if (!portal.status) {
    this.toastr.warning('Status is required.');
    return;
  }

  // === METADATA UPDATE ===
  if (!portal.createdBy) {
    portal.createdDate = new Date().toLocaleString();
  } else {
    portal.lastUpdatedDate = new Date().toLocaleString();
  }

 // === API CALL ===
  const payload = this.mapPortalToApi(portal);

  this.api.PostData('/PracticeSetup/AddOrUpdateProviderResources', payload, (res) => {
    if (res.Status === 'Success') {
      this.toastr.success('Portal saved successfully!');
      this.editIndex = null;
      this.hide = false;
      this.getAllPortals();
    } else {
      this.toastr.error(res.Status || 'There was a problem saving the entry.', 'Error');
    }
  });
}


cancelEdit(): void {
  if (this.editIndex !== null) {
    swal({
      title: 'Confirmation',
      text: "Are you sure you want to cancel?",
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      confirmButtonText: 'Yes!',
      cancelButtonText: 'No'
    }).then((result) => {
      debugger
      if (result) {
        // === YES clicked ===
        this.hide = false;
        const portal = this.portals[this.editIndex];

        // Remove the new unsaved row if needed
        if (!portal.id) {
          this.portals.splice(this.editIndex, 1);
        }

        this.editIndex = null;
        this.destroyDataTable();
        this.cdr.detectChanges();
        this.initDataTable();
        this.getAllPortals();

      }
    }).catch((dismiss) => {
      if (dismiss === 'cancel') {
        // === NO clicked ===
        
      }
    });
  }
}






  openSecurityModal(security: string): void {
    this.securityQuestions=security;
      const modalOptions: ModalOptions = {
                backdrop: 'static'
            };
            this.sqModal.config = modalOptions;
  this.sqModal.show();

  }

  openInfoModal(info: string): void {
    this.addtionInfo=info;
      const modalOptions: ModalOptions = {
                backdrop: 'static'
            };
            this.aiModal.config = modalOptions;
   this.aiModal.show();
  }

  getAllPortals(): void {

    debugger
    this.api.getData(`/PracticeSetup/GetAllProviderResources?practiceCode=${this.practiceId}`).subscribe({
      next: (res) => {
        debugger
        if(res.Status=="Success")
        this.portals = res.Response.map(this.mapApiToPortal);
        this.destroyDataTable();
         this.cdr.detectChanges();
        
          this.initDataTable();
     
      },
      error: (err) => {
        console.error(err);
        this.toastr.error('Failed to load portals.');
      }
    });
  }


  private mapApiToPortal(api: any): WebPortal {
    return {
      id: api.Resource_Id,
      insuranceName: api.Insurance_Name,
      webLink: api.URL,
      userName: api.User_Name,
      userId: api.User_Id,
      password: api.Password,
      emailForOtp: api.OTP_Email,
      phoneForOtp: api.OTP_Phone,
      securityQuestion: api.Security_Question,
      additionalInfo: api.Additional_Info,
      status: api.Status ,
      createdBy: api.Created_By,
      createdDate: api.Created_Date,
      lastUpdatedBy: api.Modified_By,
      lastUpdatedDate: api.Modified_Date,
       Created_By_Name:api.Created_By_Name,
       Modified_By_Name:api.Modified_By_Name,
    };
  }


  private mapPortalToApi(portal: WebPortal): any {
    return {
      Resource_Id: portal.id || 0,
      Insurance_Name: portal.insuranceName,
      URL: portal.webLink,
      User_Name: portal.userName,
      User_Id: portal.userId,
      Password: portal.password,
      OTP_Email: portal.emailForOtp,
      OTP_Phone: portal.phoneForOtp,
      Security_Question: portal.securityQuestion,
      Additional_Info: portal.additionalInfo,
      status: portal.status ,
      
      Deleted: false,
      Practice_Code: this.practiceId// Optional if needed by backend
    };
  }


    openPasswordModal(password: string): void {
  this.npmPassword = '';
  this.IsPasswordCorrect = null;
  this.protectedPassword = password; 
  const modalOptions: ModalOptions = {
                backdrop: 'static'
            };
            this.bsModal.config = modalOptions;
  this.bsModal.show();
}

onProceedPassword(): void {
  this.api.getData(`/Token/VerifyPassowrd?password=${this.npmPassword}`).subscribe({
    next: (res) => {
      if (res.Status === 'Success' && res.Response === true) {
        this.IsPasswordCorrect = true;
      } else {
        this.IsPasswordCorrect = false;
      }
    },
    error: (err) => {
      console.error(err);
      this.toastr.error('Failed to verify password.');
    }
  });
}

copyToClipboard(): void {
  try {
    const clipboard = (navigator as any).clipboard;
    if (clipboard && window.isSecureContext) {
      clipboard.writeText(this.protectedPassword).then(() => {
        this.toastr.success('Password copied to clipboard.');
      }).catch(() => {
        this.fallbackCopy(this.protectedPassword);
      });
    } else {
      this.fallbackCopy(this.protectedPassword);
    }
  } catch {
    this.fallbackCopy(this.protectedPassword);
  }
}


// Fallback using execCommand (works in most browsers)
private fallbackCopy(text: string): void {
  const textarea = document.createElement('textarea');
  textarea.value = text;
  textarea.style.position = 'fixed'; // prevent scrolling to bottom
  textarea.style.opacity = '0';
  document.body.appendChild(textarea);
  textarea.focus();
  textarea.select();
  try {
    document.execCommand('copy');
    this.toastr.success('Password copied to clipboard.');
  } catch (err) {
    this.toastr.error('Failed to copy password.');
    console.error('Fallback copy failed:', err);
  }
  document.body.removeChild(textarea);
}


get formattedSecurityQuestions(): string {
  if (!this.securityQuestions) return '';
  let formatted = this.securityQuestions.replace(/\n/g, '<br>');
  formatted = formatted.replace(/(.{100})/g, '$1<br>');

  return formatted;
}
get formattedaddtionInfo(): string {
  if (!this.addtionInfo) return '';
  let formatted = this.addtionInfo.replace(/(.{100})/g, '$1<br>');
  return formatted;
}
 
checkAccess(rolesAndRights: any[]): void {
  // Step 1: Check for Module
  this.moduleExists = rolesAndRights.some(r => r.ModuleName === 'PracticeProfile');

  // Step 2: Check for SubModule
  this.subModuleExists = this.moduleExists && rolesAndRights.some(
    r => r.ModuleName === 'PracticeProfile' && r.SubModuleName === 'WebPortals'
  );

  // Step 3: Check Properties
  if (this.subModuleExists) {
    this.viewWebPortalsPropertyExist = rolesAndRights.some(
      r => r.ModuleName === 'PracticeProfile' &&
           r.SubModuleName === 'WebPortals' &&
           r.PropertyName === 'View'
    );

    this.modifyWebPortalsPropertyExist = rolesAndRights.some(
      r => r.ModuleName === 'PracticeProfile' &&
           r.SubModuleName === 'WebPortals' &&
           r.PropertyName === 'Modify'
    );
  } else {
    this.viewWebPortalsPropertyExist = false;
    this.modifyWebPortalsPropertyExist = false;
  }
}
get isAddDisabled(): boolean {
  if (this.hide) return true;

  if (!this.modifyWebPortalsPropertyExist) return true;

  return false;
}

 

}
