import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WebPortalsComponent } from './web-portals.component';

describe('WebPortalsComponent', () => {
  let component: WebPortalsComponent;
  let fixture: ComponentFixture<WebPortalsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WebPortalsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WebPortalsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
