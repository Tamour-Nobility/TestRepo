import { NgModule } from '@angular/core';
import { DashBoardComponent } from './dash-board.component';
import { SharedModule } from '../shared/shared.module';
import { ChartsModule } from 'ng2-charts';
import 'chartjs-plugin-datalabels';
import {MyDatePickerModule} from 'mydatepicker';


@NgModule({
  declarations: [
    DashBoardComponent
  ],
  imports: [
    SharedModule,
    ChartsModule,
    MyDatePickerModule,
  ]
})
export class DashboardModule { }
