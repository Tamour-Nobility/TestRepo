import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CredAppReportComponent } from './cred-app-report.component';

describe('CredAppReportComponent', () => {
  let component: CredAppReportComponent;
  let fixture: ComponentFixture<CredAppReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CredAppReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CredAppReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
