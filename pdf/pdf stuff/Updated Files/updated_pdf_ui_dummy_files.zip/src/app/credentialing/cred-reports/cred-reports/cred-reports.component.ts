import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cred-reports',
  templateUrl: './cred-reports.component.html',
  styleUrls: ['./cred-reports.component.css']
})
export class CredReportsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
