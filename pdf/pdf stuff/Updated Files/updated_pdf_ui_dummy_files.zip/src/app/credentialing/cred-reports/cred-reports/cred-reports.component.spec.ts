import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CredReportsComponent } from './cred-reports.component';

describe('CredReportsComponent', () => {
  let component: CredReportsComponent;
  let fixture: ComponentFixture<CredReportsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CredReportsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CredReportsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
