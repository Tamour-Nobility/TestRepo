import { Component, OnInit } from '@angular/core';
import { APIService } from '../../../components/services/api.service';
import { DatatableService } from '../../../services/data/datatable.service';
import * as XLSX from 'xlsx-js-style'
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-cred-app-report',
  templateUrl: './cred-app-report.component.html',
  styleUrls: ['./cred-app-report.component.css']
})
export class CredAppReportComponent implements OnInit {
searchStarted = false;
  practiceList = [];
  LookupList: any;
  reportData:any;
  dataTableEdiEra:any;
   searchModel: any = {
    practice_Code: null,
    obj_Type_Id: null, 
  };
  constructor(private API:APIService,  public datatableService: DatatableService,private toaster: ToastrService) { }

  ngOnInit() {
    
    this.LoadPractices();
    this.GetLookupData();
  }
LoadPractices() {
  
    this.API.getData(`/Credentialing/GetActivePractices`).subscribe(res => {
      if (res.Status == 'Sucess') {
         this.practiceList=res.Response;
        this.practiceList = this.practiceList.map(practice => {
            return {
                ...practice,  // Keep all existing properties
                PracticeLabel: `${practice.Practice_Code} | ${practice.Prac_Name}`  // Add new combined property
              };
             });  
 }
  });
  }
    GetLookupData() {
    this.API.getData('/Credentialing/GetLookupLists').subscribe(data => {
      if (data.Status === 'Success') {
        this.LookupList = data.Response;
      }
    });
  }
 

providerHeaders: string[] = [];
maxGroupCount: number = 0;

reportrowData:any
GetReportData() {
  this.searchStarted=false;
  if(!this.searchModel.practice_Code){
 this.toaster.error("Please select practice to search", "Error");
 return;
  }
  
  this.API
    .getData(`/Credentialing/GetCredAppReport?practiceCode=${this.searchModel.practice_Code}&ObjTypeId=${this.searchModel.obj_Type_Id}`)
    .subscribe(res => {
      if (res.Status === 'Success') {
        this.searchStarted=true;
        this.reportData = res.Response;
      

        this.reportData = this.processReportData(res.Response);

         this.providerHeaders = [];

        this.reportData.forEach(payer => {
          if (payer.Providers) {
            Object.keys(payer.Providers).forEach(provider => {
              if (!this.providerHeaders.includes(provider)) {
                this.providerHeaders.push(provider);
              }
            });
          }
        });
        // Initialize DataTable AFTER Angular renders the table
setTimeout(() => {

  if (this.dataTableEdiEra) {
    this.dataTableEdiEra.destroy();
  }

  this.dataTableEdiEra = ($('#reportTable') as any).DataTable({
    scrollX: true,
    autoWidth: false,
    destroy: true,
    order: [],
    columnDefs: [
     
    ],
    language: {
      emptyTable: 'No data available'
    },
    dom: this.datatableService.getDom(),
    buttons: [
      {
        extend: 'excel',
        text: '<i class="fa fa-file-excel-o"></i> Excel',
        action: (e, dt, node, config) => {

          if (dt.rows().count() === 0) {
            return;
          }

          this.downloadExcelWithProperHeaders();
        }
      }
    ]
  });

  const hasData = this.dataTableEdiEra.rows().count() > 0;
  this.dataTableEdiEra.button('.buttons-excel').enable(hasData);

  this.dataTableEdiEra.on('draw', () => {
    const hasRows = this.dataTableEdiEra.rows({ filter: 'applied' }).count() > 0;
    this.dataTableEdiEra.button('.buttons-excel').enable(hasRows);
  });

  this.dataTableEdiEra.columns.adjust();

}, 0);

                  }
    });
}
// processReportData(rawData: any[]) {
//   const result: any[] = [];
//   let srNo = 1;

//   // Step 1: Group by PayerId + LOB
//   const payerMap = new Map<string, any>();

//   rawData.forEach(item => {
//     const payerId = item.Payer_Id;
//     const payerName = item.Payer_Name;
//     const lob = item.Line_Of_Business || '';
//     const key = `${payerId}__${lob}`;

//     if (!payerMap.has(key)) {
//       payerMap.set(key, {
//         PayerId: payerId,
//         PayerName: payerName,
//         OriginalPayerName: payerName,
//         LineOfBusiness: lob,
//         GroupApplications: [],
//         Providers: {} // providerName -> array of applications
//       });
//     }

//     const payer = payerMap.get(key);

//     if (item.Provider_Code == null && item.Provider_Name === 'Group') {
//       payer.GroupApplications.push({
//         Contract_Type: item.Contract_Type,
//         Application_Status: item.Application_Status,
//         Effective_Date: item.Effective_Date
//       });
//     } else if (item.Provider_Code != null) {
//       if (!payer.Providers[item.Provider_Name]) {
//         payer.Providers[item.Provider_Name] = [];
//       }
//       payer.Providers[item.Provider_Name].push({
//         Provider_Code: item.Provider_Code,
//         Contract_Type: item.Contract_Type,
//         Application_Status: item.Application_Status,
//         Effective_Date: item.Effective_Date
//       });
//     }
//   });

//   // Keep track of which PayerId+LOB has been shown
//   const displayedPayers = new Set<string>();

//   // Step 2: Flatten each payer into rows
//   payerMap.forEach(payer => {
//     const providerNames = Object.keys(payer.Providers);
//     const groupApps = payer.GroupApplications;
//     const providerAppsList = providerNames.map(name => payer.Providers[name]);

//     const maxGroupRows = groupApps.length;
//     const maxProviderRows = providerAppsList.length > 0
//       ? Math.max(...providerAppsList.map(arr => arr.length))
//       : 0;

//     const maxRows = Math.max(maxGroupRows, maxProviderRows, 1);

//     const payerKey = payer.PayerId;
//     const showPayer = !displayedPayers.has(payerKey);
//     if (showPayer) displayedPayers.add(payerKey);

//     // Generate rows
//     for (let i = 0; i < maxRows; i++) {
//       const row: any = {
//         SrNo: srNo++,
//         PayerId: i === 0 && showPayer ? payer.PayerId : null,
//         PayerName: i === 0 && showPayer ? payer.PayerName : '',
//           OriginalPayerName: payer.OriginalPayerName,
//         LineOfBusiness: payer.LineOfBusiness ,
//         GroupApplications: [],
//         Providers: {}
//       };

//       if (i < groupApps.length) {
//         row.GroupApplications.push(groupApps[i]);
//       }

//       providerNames.forEach((name) => {
//         const apps = payer.Providers[name];
//         if (i < apps.length) {
//           row.Providers[name] = [apps[i]];
//         }
//       });

//       result.push(row);
//     }
//   });

//   return result;
// }

processReportData(rawData: any[]) {
  const result: any[] = [];
  let srNo = 1;

  // Step 1: Group by PayerName + LOB
  const payerMap = new Map<string, any>();

  rawData.forEach(item => {
    const payerName = item.Payer_Name || '';
    const lob = item.Line_Of_Business || '';

    const key = `${payerName}__${lob}`; // ✅ FIXED KEY

    if (!payerMap.has(key)) {
      payerMap.set(key, {
        PayerKey: key,                    // ✅ replacement for PayerId
        PayerName: payerName,
        OriginalPayerName: payerName,
        LineOfBusiness: lob,
        GroupApplications: [],
        Providers: {} // providerName -> array of applications
      });
    }

    const payer = payerMap.get(key);

    if (item.Provider_Code == null && item.Provider_Name === 'Group') {
      payer.GroupApplications.push({
        Contract_Type: item.Contract_Type,
        Application_Status: item.Application_Status,
        Effective_Date: item.Effective_Date
      });
    } else if (item.Provider_Code != null) {
      if (!payer.Providers[item.Provider_Name]) {
        payer.Providers[item.Provider_Name] = [];
      }
      payer.Providers[item.Provider_Name].push({
        Provider_Code: item.Provider_Code,
        Contract_Type: item.Contract_Type,
        Application_Status: item.Application_Status,
        Effective_Date: item.Effective_Date
      });
    }
  });

  // Track displayed payer+LOB combinations
  const displayedPayers = new Set<string>();

  // Step 2: Flatten into rows
  payerMap.forEach(payer => {
    const providerNames = Object.keys(payer.Providers);
    const groupApps = payer.GroupApplications;
    const providerAppsList = providerNames.map(name => payer.Providers[name]);

    const maxGroupRows = groupApps.length;
    const maxProviderRows = providerAppsList.length > 0
      ? Math.max(...providerAppsList.map(arr => arr.length))
      : 0;

    const maxRows = Math.max(maxGroupRows, maxProviderRows, 1);

    const payerKey = payer.PayerKey;
    const showPayer = !displayedPayers.has(payerKey);
    if (showPayer) displayedPayers.add(payerKey);

    for (let i = 0; i < maxRows; i++) {
      const row: any = {
        SrNo: srNo++,
        PayerId: i === 0 && showPayer ? payerKey : null, // kept for UI safety
        PayerName: i === 0 && showPayer ? payer.PayerName : '',
        OriginalPayerName: payer.OriginalPayerName,
        LineOfBusiness: payer.LineOfBusiness,
        GroupApplications: [],
        Providers: {}
      };

      if (i < groupApps.length) {
        row.GroupApplications.push(groupApps[i]);
      }

      providerNames.forEach(name => {
        const apps = payer.Providers[name];
        if (i < apps.length) {
          row.Providers[name] = [apps[i]];
        }
      });

      result.push(row);
    }
  });

  return result;
}

getStatusClass(status: string): string {
  if (!status) return '';

  return 'status-' + status
    .toLowerCase()
    .replace(/ /g, '-');
}

getContractClass(contractType: string): string {
  if (!contractType) return '';

  if (contractType.toLowerCase().includes('direct')) {
    return 'contract-direct';
  }

else {
    return 'contract-ipa';
  }

  return '';
}
downloadExcelWithProperHeaders() {
  const wb: XLSX.WorkBook = XLSX.utils.book_new();
  const ws: XLSX.WorkSheet = {};

  const providerNames = this.providerHeaders ? this.providerHeaders : [];
  const safeVal = (v: any) => v !== null && v !== undefined ? v : '';

  /* ---------------- STYLES ---------------- */
  const cellStyle = (fillColor?: string) => {
    const style: any = {
      font: { bold: false, color: fillColor ? { rgb: 'FFFFFF' } : { rgb: '000000' } },
      alignment: { horizontal: 'center', vertical: 'center' },
      border: {
        top: { style: 'thin' },
        bottom: { style: 'thin' },
        left: { style: 'thin' },
        right: { style: 'thin' }
      }
    };
    if (fillColor) {
      style.fill = { fgColor: { rgb: fillColor } };
    }
    return style;
  };

  const headerStyle = {
    font: { bold: true, color: { rgb: 'FFFFFF' } },
    fill: { fgColor: { rgb: '4F81BD' } },
    alignment: { horizontal: 'center', vertical: 'center' },
    border: {
      top: { style: 'thin' },
      bottom: { style: 'thin' },
      left: { style: 'thin' },
      right: { style: 'thin' }
    }
  };

  const merges: XLSX.Range[] = [];
  let colIndex = 0;

  /* ---------------- HEADER ROW 1 ---------------- */

  ws[XLSX.utils.encode_cell({ r: 0, c: colIndex })] = { v: 'Payer Name', s: headerStyle };
  merges.push({ s: { r: 0, c: colIndex }, e: { r: 1, c: colIndex } });
  colIndex++;

  ws[XLSX.utils.encode_cell({ r: 0, c: colIndex })] = { v: 'Line of Business', s: headerStyle };
  merges.push({ s: { r: 0, c: colIndex }, e: { r: 1, c: colIndex } });
  colIndex++;

  ws[XLSX.utils.encode_cell({ r: 0, c: colIndex })] = { v: 'Group', s: headerStyle };
  merges.push({ s: { r: 0, c: colIndex }, e: { r: 0, c: colIndex + 2 } });
  colIndex += 3;

  for (let i = 0; i < providerNames.length; i++) {
    ws[XLSX.utils.encode_cell({ r: 0, c: colIndex })] = { v: safeVal(providerNames[i]), s: headerStyle };
    merges.push({ s: { r: 0, c: colIndex }, e: { r: 0, c: colIndex + 2 } });
    colIndex += 3;
  }

  /* ---------------- HEADER ROW 2 ---------------- */

  colIndex = 2;

  const subHeaders = ['Contract Type', 'Status', 'Effective Date'];

  for (let i = 0; i < subHeaders.length; i++) {
    ws[XLSX.utils.encode_cell({ r: 1, c: colIndex++ })] = { v: subHeaders[i], s: headerStyle };
  }

  for (let p = 0; p < providerNames.length; p++) {
    for (let s = 0; s < subHeaders.length; s++) {
      ws[XLSX.utils.encode_cell({ r: 1, c: colIndex++ })] = { v: subHeaders[s], s: headerStyle };
    }
  }

  ws['!merges'] = merges;

  /* ---------------- DATA ROWS ---------------- */

  let rowIndex = 2;

  for (let p = 0; p < this.reportData.length; p++) {
    const payer = this.reportData[p];
    const groupApps = payer.GroupApplications ? payer.GroupApplications : [];
    const providers = payer.Providers ? payer.Providers : {};

    let maxRows = groupApps.length > 0 ? groupApps.length : 1;

    for (const key in providers) {
      if (providers.hasOwnProperty(key)) {
        if (providers[key] && providers[key].length > maxRows) {
          maxRows = providers[key].length;
        }
      }
    }

    const payerStartRow = rowIndex;

    for (let i = 0; i < maxRows; i++) {
      colIndex = 0;

      ws[XLSX.utils.encode_cell({ r: rowIndex, c: colIndex++ })] = {
        v: i === 0 ? safeVal(payer.PayerName) : '',
        s: cellStyle()
      };

      ws[XLSX.utils.encode_cell({ r: rowIndex, c: colIndex++ })] = {
        v: i === 0 ? safeVal(payer.LineOfBusiness) : '',
        s: cellStyle()
      };

      const g = i < groupApps.length ? groupApps[i] : {};

      ws[XLSX.utils.encode_cell({ r: rowIndex, c: colIndex++ })] = {
        v: safeVal(g.Contract_Type),
        s: cellStyle(this.getContractExcelColor(g.Contract_Type))
      };

      ws[XLSX.utils.encode_cell({ r: rowIndex, c: colIndex++ })] = {
        v: safeVal(g.Application_Status),
        s: cellStyle(this.getStatusExcelColor(g.Application_Status))
      };

      ws[XLSX.utils.encode_cell({ r: rowIndex, c: colIndex++ })] = {
        v: g.Effective_Date ? this.formatDate(g.Effective_Date) : '',
        s: cellStyle()
      };

      for (let k = 0; k < providerNames.length; k++) {
        const pname = providerNames[k];
        let prov = null;

        if (providers[pname] && i < providers[pname].length) {
          prov = providers[pname][i];
        }

        ws[XLSX.utils.encode_cell({ r: rowIndex, c: colIndex++ })] = {
          v: prov && prov.Contract_Type ? prov.Contract_Type : '',
          s: cellStyle(prov && prov.Contract_Type ? this.getContractExcelColor(prov.Contract_Type) : undefined)
        };

        ws[XLSX.utils.encode_cell({ r: rowIndex, c: colIndex++ })] = {
          v: prov && prov.Application_Status ? prov.Application_Status : '',
          s: cellStyle(prov && prov.Application_Status ? this.getStatusExcelColor(prov.Application_Status) : undefined)
        };

        ws[XLSX.utils.encode_cell({ r: rowIndex, c: colIndex++ })] = {
          v: prov && prov.Effective_Date ? this.formatDate(prov.Effective_Date) : '',
          s: cellStyle()
        };
      }

      rowIndex++;
    }

    if (rowIndex - payerStartRow > 1) {
      ws['!merges'].push({ s: { r: payerStartRow, c: 0 }, e: { r: rowIndex - 1, c: 0 } });
      ws['!merges'].push({ s: { r: payerStartRow, c: 1 }, e: { r: rowIndex - 1, c: 1 } });
    }
  }

  /* ---------------- FINALIZE ---------------- */

  const totalCols = 2 + 3 + providerNames.length * 3 - 1;
  ws['!ref'] = 'A1:' + XLSX.utils.encode_col(totalCols) + rowIndex;

  XLSX.utils.book_append_sheet(wb, ws, 'Cred Application Report');
  XLSX.writeFile(wb, 'Cred_Application_Report.xlsx');
}




private getContractExcelColor(contractType: string): string {
  if (!contractType || contractType.trim() === '') {
    return undefined;
  }
  if (contractType === 'Direct') {
    return '0D47A1';
  } else {
    return '616161'; 
  }
}



private getStatusExcelColor(status: string): string {
  switch (status) {
    case 'New':
          return undefined;
    case 'Approved':
      return '4CAF50';
    case 'Pending':
      return '8B4513';
    case 'Out of Network':
    case 'Not Enrolled':
    case 'Rejected':
    case 'Development':
    case 'Opt Out':
      return 'F44336';
    case 'Network Closed':
      return '9E9E9E';
    case 'On Hold':
      return 'FFEB3B';
    case 'In Process':
      return '2196F3';
    case 'Status Review Required':
    case 'Awaiting Response':
      return 'FF9800';
    case 'Ineligible':
      return 'D3D3D3';
    default:
      return 'FFFFFF';
  }
}


private formatDate(dateStr: string) {
  const d = new Date(dateStr);

  const mm = ('0' + (d.getMonth() + 1)).slice(-2);
  const dd = ('0' + d.getDate()).slice(-2);
  const yyyy = d.getFullYear();

  return mm + '/' + dd + '/' + yyyy;
}

onClear(){
    if (this.dataTableEdiEra) {
            this.dataTableEdiEra.destroy();
          }
 this.searchModel = {
    practice_Code: null,
    obj_Type_Id: null, 
  };
  this.reportData=[];
  this.searchStarted=false;
}
}
