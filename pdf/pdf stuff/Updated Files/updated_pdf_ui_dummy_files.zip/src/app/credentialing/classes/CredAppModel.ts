export class CredAppViewModel {
  application_Id: number=0;
  practice_Code: number;
  provider_Id: number=null;
  insurance_Id: number ;
  Payer_Name : String;
  plan_Name: string;
  obj_Type_Id: number =null;
  contract_Type_Id: number =null;
  ipa_Name: string;
  application_Type_Id: number = null;
  application_Status_Id: number = null;
  tracking_Id: string;
  applied_Date: Date | null;
  effective_Date: Date | null;
  ind_Provider_Id: string ;
  recredentialing_Date: Date | null;
  last_Followup_Date: Date | null;
  next_Followup_Date: Date | null;
  created_Date: Date;
  created_By: number;
  assigned_To: number =null;
  assigned_By: number | null;
  assigned_Date: Date | null;
  modified_By: number | null;
  modified_Date: Date | null;
  payer_Name :string;
}
