export class CredAppNoteModel{
    Cred_App_Note_Id:number;
    Note_Description:string;
    Application_Id:number;
    Is_Auto_Note:boolean;
    Created_By:number;
    Created_By_UserName:string;
    Created_Date:string
}