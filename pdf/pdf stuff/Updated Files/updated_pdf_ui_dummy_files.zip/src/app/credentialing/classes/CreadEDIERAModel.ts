export class CredEDIERAAppViewModel {
   EDI_ERA_App_Id: number  = 0;
  Practice_Code: number  =null;
  Obj_Type_Id: number  =null;
  Payer_Name : String =null;
  Clearing_House_Id: number  =null;
  Software_Id: number =null;
  Direct_TPA: string  =null;
  TPA_Name_Id: number =null;
  TPA_user_Id: number =null;
  App_Status_Id: number =null;
  Last_FollowUp_Date: Date | null;
  Next_Followup_Date: Date | null;
  Tracking_Id: string =null;
  Applied_Date:Date | null;
  Effectice_Date: Date | null;
  Created_by: number =null;
  Created_Date:Date | null;
  Assigned_To: number =null;
  Assigned_By: number =null;
  Assigned_Date: Date | null;
  Modified_By: number =null;
  Modfied_Date: Date | null;
  Deleted: boolean;


}
