export class CredEDiERANoteModel{
  EDI_ERA_Note_Id: number;
  EDI_ERA_App_Id: number;
  Note_Desc: string;
  Is_Auto_Note: boolean;
  Created_by: number;
  Created_Date: Date;
  Modified_By: number;
  Modfied_Date: Date;
  Deleted: boolean;
      Created_By_UserName:string;

}