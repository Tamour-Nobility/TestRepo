import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CredentialingRoutingModule } from './credentialing-routing.module';
import { CredAppListComponent } from './cred-app/cred-app-list/cred-app-list.component';
import { CredAppAddeditComponent } from './cred-app/cred-app-addedit/cred-app-addedit.component';
import { SharedModule } from '../shared/shared.module';
import { CredAppAttachmentsComponent } from './cred-app/cred-app-attachments/cred-app-attachments.component';
import { CredEdiEraAppAddeditComponent } from './cred-edi-era-app/cred-edi-era-app-addedit/cred-edi-era-app-addedit.component';
import { CredEdiEraAppListComponent } from './cred-edi-era-app/cred-edi-era-app-list/cred-edi-era-app-list.component';
import { CredEdiEraAppAttachmentsComponent } from './cred-edi-era-app/cred-edi-era-app-attachments/cred-edi-era-app-attachments.component';
import { CredReportsComponent } from './cred-reports/cred-reports/cred-reports.component';
import { CredAppReportComponent } from './cred-reports/cred-app-report/cred-app-report.component';
import { CredTasksComponent } from './cred-tasks/cred-tasks.component';

@NgModule({
  declarations: [ CredAppListComponent, CredAppAddeditComponent, CredAppAttachmentsComponent, CredEdiEraAppAddeditComponent, CredEdiEraAppListComponent, CredEdiEraAppAttachmentsComponent, CredReportsComponent, CredAppReportComponent, CredTasksComponent],
  imports: [
    CommonModule,
    SharedModule,
    CredentialingRoutingModule
  ],
  exports:[
    CredAppAttachmentsComponent
  ]
})
export class CredentialingModule { }
