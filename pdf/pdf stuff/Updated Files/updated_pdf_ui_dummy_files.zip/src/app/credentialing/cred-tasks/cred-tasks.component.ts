import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { APIService } from '../../components/services/api.service';
import { Common } from '../../../app/services/common/common';
import { GvarsService } from '.././../services/G_vars/gvars.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
@Component({
  selector: 'app-cred-tasks',
  templateUrl: './cred-tasks.component.html',
  styleUrls: ['./cred-tasks.component.css']
})
export class CredTasksComponent implements OnInit {
  searchModel: any = {
    practice_Code: null,
    UserId:null,
    Obj_Type_ID:null
       
  };
  practiceList:any[];
  userData:any[];
  LookupList: any;
  CredTasks:any=[];
  searchStarted = false;
  dataTableCredTasks:any;
  constructor(private API:APIService,private gvService:GvarsService,private chRef:ChangeDetectorRef, private toaster: ToastrService,private router:Router) { 
     this.LookupList = {

      cred_Objective_Types:[],
     
    };
  }

  ngOnInit() {
   

    this.LoadUsers(this.gvService.currentUser.role);
    this.GetLookupData();
     this.practiceList = this.gvService.currentUser.Practices.map(practice => ({
        ...practice,
        PracticeLabel: `${practice.PracticeCode} | ${practice.PracticeName}`
      }));

      // Add "All" at the top with value -1
      this.practiceList.unshift({
        PracticeCode: -1,          // use -1 instead of null
        Prac_Name: 'All',
        PracticeLabel: 'All'
      });
      this.searchModel.practice_Code=-1
  }

LoadUsers(role) {
  this.API.getData(`/Credentialing/GetCredUserByRole?Role=${role}`)
    .subscribe(res => {
      if (res.Status === 'Success') {
        this.userData = res.Response.map(user => ({
          ...user,
          userLabel: `${user.UserName} | ${user.LastName}, ${user.FirstName}`
        }));
        if(role=="Credentialing"){
        this.searchModel.UserId = Number(this.gvService.currentUser.userId);

        }
        else{
 this.userData.unshift({
          UserId: -1,
          userLabel: 'All'
        });
        this.searchModel.UserId = -1;
        }
      }
    });
}

GetLookupData() {
  this.API.getData('/Credentialing/GetLookupLists').subscribe(data => {
    if (data.Status === 'Success') {
      this.LookupList = data.Response;
    }
  });
}
transformedData:any[]=[];
availableGrids :any;
Search() {

debugger
  if (this.searchModel.practice_Code == null) {
    this.toaster.error('Practice is required.');
    return;
  }

  if (this.searchModel.UserId == null) {
    this.toaster.error('User is required.');
    return;
  }

  if (this.searchModel.practice_Code === -1) {
    this.searchModel.practice_Code = null;
  }

  if (this.searchModel.UserId === -1) {
    this.searchModel.UserId = null;
  }

  if (this.dataTableCredTasks) {
    this.dataTableCredTasks.destroy();
    this.dataTableCredTasks = null;
  }

  this.searchStarted = false;
  this.transformedData = [];
  this.availableGrids = [];


this.API.getData(
  `/Credentialing/GetCredTasks?PracticeCode=${this.searchModel.practice_Code}&UserId=${this.searchModel.UserId}&Obj_Type_Id=${this.searchModel.Obj_Type_ID}`
).subscribe(data => {

  if (data.Status !== 'Success') {
    return;
  }

  this.CredTasks = data.Response || [];
  this.transformedData = []; // reset before transforming

  this.CredTasks.forEach((row: any) => {

    if (!row.TotalApplicationAssigned || row.TotalApplicationAssigned === 0) {
      return;
    }

    // Find by BOTH PracticeCode and AssignedUser
    let practice = this.transformedData.find(
      x => x.practiceCode === row.Practice_Code && x.AssignedUser === row.AssignedUser
    );

    if (!practice) {
      practice = {
        practiceCode: row.Practice_Code,
        Practice: row.Practice,
        AssignedUser: row.AssignedUser
      };
      this.transformedData.push(practice);
    }

    // Attach grid-specific data without overwriting AssignedUser
    practice[row.Grid_Type] = { ...row };
  });

  // Determine which grids actually have data
  this.availableGrids = ['Credentialing', 'EDI', 'ERA', 'EFT'].filter(grid =>
    this.transformedData.some(p =>
      p[grid] &&
      p[grid].TotalApplicationAssigned != null &&
      p[grid].TotalApplicationAssigned > 0
    )
  );

  this.searchStarted = true;

  // default search params if null
  if (this.searchModel.practice_Code == null) this.searchModel.practice_Code = -1;
  if (this.searchModel.UserId == null) this.searchModel.UserId = -1;

  // Initialize DataTable after DOM render
  setTimeout(() => {
    const table: any = $('.dataTableCredTasks');
    if (table.length) {
      this.dataTableCredTasks = table.DataTable({
        scrollX: true,
        autoWidth: false,
        destroy: true,
        ordering: true,
        language: { emptyTable: 'No Data Available' }
      });
    }
  }, 0);


});

}

goToCredApp(grid: string, column: string, data: any) {
  if (this.searchModel.practice_Code == -1) {
    this.searchModel.practice_Code = null;
  }
  if (this.searchModel.UserId == -1) {
    this.searchModel.UserId = null;
  }
debugger
    this.searchModel.practice_Code = data.Practice_Code;
    this.searchModel.UserId = data.UserId;
let queryParams;
 if(grid === 'Credentialing'){
 queryParams = {
    ...this.searchModel,
    column: column,
  };
 } else if(grid === 'EDI'){
queryParams = {
    ...this.searchModel,
    obj_type: 101,
        column: column,
  };
 } else if(grid === 'ERA'){
  queryParams = {
    ...this.searchModel,
    obj_type: 103,
        column: column,
  };
 } else {
  queryParams = {
    ...this.searchModel,
    obj_type: 102,
        column: column,
  };
 }
  if (grid === 'Credentialing') {
    this.router.navigate(['/credentialing/credApp'], {
      queryParams
    });
  } else {
    this.router.navigate(['/credentialing/credEdiEraApp'], {
      queryParams
    });
  }
}

clear(){
        this.searchModel.practice_Code = -1;  
        if(this.gvService.currentUser.role=="Credentialing"){
        this.searchModel.UserId = Number(this.gvService.currentUser.userId);

        }
        else{
        this.searchModel.UserId = -1;
        }
        this.searchModel.Obj_Type_ID=null
        this.searchStarted=false;
        this.transformedData=[];
        this.availableGrids=[]
}
}