import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CredTasksComponent } from './cred-tasks.component';

describe('CredTasksComponent', () => {
  let component: CredTasksComponent;
  let fixture: ComponentFixture<CredTasksComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CredTasksComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CredTasksComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
