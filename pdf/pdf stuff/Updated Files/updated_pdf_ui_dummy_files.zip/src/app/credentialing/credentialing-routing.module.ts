import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CredAppListComponent } from './cred-app/cred-app-list/cred-app-list.component';
import { CredAppAddeditComponent } from './cred-app/cred-app-addedit/cred-app-addedit.component';
import { CredEdiEraAppAddeditComponent } from './cred-edi-era-app/cred-edi-era-app-addedit/cred-edi-era-app-addedit.component';
import { CredEdiEraAppListComponent } from './cred-edi-era-app/cred-edi-era-app-list/cred-edi-era-app-list.component';
import { CredReportsComponent } from './cred-reports/cred-reports/cred-reports.component';
import { CredAppReportComponent } from './cred-reports/cred-app-report/cred-app-report.component';
import { CredTasksComponent } from './cred-tasks/cred-tasks.component';

const routes: Routes = [
  { path: '', component: CredAppListComponent },          
  { path: 'addedit', component: CredAppAddeditComponent }, 
  { path: 'credApp', component: CredAppListComponent },           
  { path: 'addedit', component: CredAppAddeditComponent },
  { path: 'addedit/:id', component: CredAppAddeditComponent },
  { path: 'view/:id', component: CredAppAddeditComponent }  ,
  { path: 'credEdiEraApp', component: CredEdiEraAppListComponent },  
  { path: 'addcredEdiEraaddedit', component: CredEdiEraAppAddeditComponent },
  { path: 'editcredEdiEraaddedit/:id', component: CredEdiEraAppAddeditComponent },
  { path: 'viewcredEdiEraaddedit/:id', component: CredEdiEraAppAddeditComponent },
  { path: 'reports', component: CredReportsComponent  ,
     children: [
              {
                  path:'cred-app-report',
                  component: CredAppReportComponent
              },
            ]
          },
   {path:'CredTasks', component:CredTasksComponent},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CredentialingRoutingModule { }
