import { ToastrService } from 'ngx-toastr';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ChangeDetectorRef, Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { saveAs } from 'file-saver';

import { Common } from '../../../services/common/common';
import { APIService } from '../../../components/services/api.service';
import { SelectListViewModel } from '../../../models/common/selectList.model';
import { FileHandlerService } from '../../../components/services/file-handler/filehandler.service';
import { GvarsService } from '../../../services/G_vars/gvars.service';
import { ActivatedRoute } from '@angular/router';
const validMimeTypes = [
  "image/jpg",
  "image/png",
  "image/jpeg",
  'application/pdf',
  'text/plain',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
];

const maximumFileSize = 20000000;

@Component({
  selector: 'app-cred-edi-era-app-attachments',
  templateUrl: './cred-edi-era-app-attachments.component.html',
  styleUrls: ['./cred-edi-era-app-attachments.component.css']
})
export class CredEdiEraAppAttachmentsComponent implements OnInit {

form: FormGroup;
  selectedFile: File;
  uploading: boolean;
  datatableCredAppAttachments: any;
  attachmentTypesList: SelectListViewModel[];
  attachments: any[];
  uploadedFiles: any[] = [];
   isViewMode:boolean=false;
  tempAttachments: any[] = [];
  filename:any;
  filetype:any;
  @Input() ExcludedClaimsIds: number[];
  @Input('ApplicationId') ApplicationId: number;
  @Output() attachmentEvent = new EventEmitter<any>();
   @Output() deleteattachmentEvent = new EventEmitter<any>();
  @ViewChild(ModalDirective) CredAppAttachment: ModalDirective;
   LookupList:any;
  constructor(
    private route: ActivatedRoute,
    private toastr: ToastrService,
    private _apiService: APIService,
    private _fileHandlerService: FileHandlerService,
    private _chRef: ChangeDetectorRef,private GV: GvarsService
  ) {
    this.LookupList = {
    EDI_ERA_Doc_Types: []
  };
    this.attachmentTypesList = [];
    this.attachments = [];
    this.uploading = false;
  
  }

  ngOnInit() {
      const routePath = this.route.snapshot.routeConfig.path; 
        if (routePath.startsWith('viewcredEdiEraaddedit')) {
    this.isViewMode = true;
  }
    this.initForm();
    this.form.get('ApplicationId').setValue(this.ApplicationId)
    this.GetLookupData();
  }

  initForm() {
    this.form = new FormGroup({
      attachment: new FormControl(null),
      ApplicationId: new FormControl(null, [Validators.required]),
      DocTypeId:new FormControl(null,)
    });
  }

  show() {
    this.CredAppAttachment.show();
  }

  hide() {
    this.CredAppAttachment.hide();
  }

  onCredAppAttachmentsShown() {
    
    if (!Common.isNullOrEmpty(this.ApplicationId)) {
     this.getCredAppAttachments();
      //this.getAttachmentTypeCodes();
    }
  }

  getCredAppAttachments() {
    this._apiService.getData(`/CredEDIERASetup/GetCred_EDIERA_Documents?applicationId=${this.ApplicationId}`)
      .subscribe(res => {
        if (this.datatableCredAppAttachments) {
          this._chRef.detectChanges();
          this.datatableCredAppAttachments.destroy();
        }
        ;

          this.attachments = [
        ...this.tempAttachments,
        ...res.Response
      ];
        ;
        this._chRef.detectChanges();
        const table: any = $('.datatableCredAppAttachments');
        this.datatableCredAppAttachments = table.DataTable({
          columnDefs: [
            { orderable: false, targets: -1 },
          ],
          order: [3, 'desc'],
          language: {
            emptyTable: "No data available"
          }
        })
      })
  }

  

  onCredAppAttachmentsHidden() {
    this.selectedFile = null;
    this.form.reset();
    this.uploading = false;
  }

onChangeFile(event: any) {
  const input = event.target as HTMLInputElement;
  const files = input.files;

  this.selectedFile = null;

  if (!files || files.length === 0) {
    this.toastr.warning('Please choose file to upload.', 'File Missing');
    return;
  }

  const file = files[0];
  const fileName = file.name;
  const size = file.size;

  // Extract extension
  const ext = fileName.split('.').pop().toLowerCase() || '';

  const validExtensions = ['pdf', 'jpg', 'jpeg', 'png', 'doc', 'docx', 'txt', 'xlsx'];


  if (!validExtensions.includes(ext)) {
    this.toastr.warning('Please choose file with Type: PDF, JPG, PNG, DOCX, TXT, XLSX', 'File Type');

    // Reset AFTER validation
    input.value = '';
    return;
  }

 
  const maximumFileSize = 20 * 1024 * 1024;
  if (size > maximumFileSize) {
    this.toastr.warning('Maximum file size 20MB.', 'File Size');

    // Reset AFTER validation
    input.value = '';
    return;
  }


  this.selectedFile = file;

  // Allow same file to be selected again next time
  input.value = '';
}



onUpload() {
  if (!this.selectedFile) {
    this.toastr.warning('Please choose file.', 'File Missing');
    return;
  }

  if (!this.form.get("DocTypeId").value) {
    this.toastr.warning('Please choose document type.', 'Document Type');
    return;
  }

  const docTypeId = this.form.get("DocTypeId").value;
  const docName = this.getNameFromList(
    this.LookupList.EDI_ERA_Doc_Types,
    docTypeId,
    "Doc_Type_Id",
    "Doc_Type_Desc"
  );

  // Store temporarily (application not created yet)
   var  id=Date.now()
  const newAttachment = {
    tempid:id,
    Cred_App_Doc_Id: 0,
    Attachment: this.selectedFile.name,
    Doc_Type_Desc: docName,
    Attached_By_UserName: this.GV.currentUser.unique_name,
    Attached_On: new Date()
  };

  this.tempAttachments.push(newAttachment);

  // Destroy DataTable BEFORE updating rows
  if (this.datatableCredAppAttachments) {
    this.datatableCredAppAttachments.destroy();
    this.datatableCredAppAttachments = null;
  }

  // Add only latest file into main attachments list
  this.attachments = [newAttachment, ...this.attachments];

  // Allow DOM to update, then reinitialize DataTable
  setTimeout(() => {
    const table: any = $('.datatableCredAppAttachments');
    this.datatableCredAppAttachments = table.DataTable({
      columnDefs: [{ orderable: false, targets: -1 }],
      order: [3, 'desc'],
      language: { emptyTable: "No data available" }
    });
  }, 0);

  // Emit file to parent
  this.attachmentEvent.emit([
    {
      file: this.selectedFile,
      docType: docTypeId,
      id:id,
    }
  ]);

  this.toastr.success("File uploaded", "Success");

  // Reset UI
  this.selectedFile = null;
  this.form.patchValue({ attachment: null, DocTypeId: null });
}


onDelete(id: number,tempid:number, index?: number,) {
  swal({
    title: 'Are you sure?',
    text: 'Do you want to delete this attachment?',
    icon: 'warning',
    showCancelButton: true,
    confirmButtonText: 'Yes',
    cancelButtonText: 'No',
  }).then((result) => {

    if (!result) return;

    if (id === 0 && index !== undefined) {
      this.tempAttachments.splice(index, 1);
      this.attachments = [
        ...this.tempAttachments,
        ...this.attachments.filter(x => x.Cred_App_Doc_Id >0)
      ];
      if (this.datatableCredAppAttachments) {
        this.datatableCredAppAttachments.destroy();
        this.datatableCredAppAttachments = null;
      }

      this._chRef.detectChanges();

      const table: any = $('.datatableCredAppAttachments');
      this.datatableCredAppAttachments = table.DataTable({
        columnDefs: [{ orderable: false, targets: -1 }],
        order: [3, 'desc'],
        language: { emptyTable: "No data available" }
      });
      this.deleteattachmentEvent.emit([
    {
  
      id:tempid,
    }
  ]);
      return;
    }

    // ----------------------------------------
    // DELETE FROM DATABASE (id > 0)
    // ----------------------------------------
    if (id > 0) {
      this._apiService
        .getData(`/CredEDIERASetup/DeleteCred_EDIERA_Document?documentId=${id}`)
        .subscribe((res) => {
          if (res.Status === 'success') {
            this.toastr.success('Attachment has been deleted.', 'Deleted');
            this.getCredAppAttachments();
          }
        });
    }
  });
}





  onDownload(id: number, fileName: string) {
    if(id!==0){
  this._apiService.downloadFile(`//CredEDIERASetup/GetCred_EDIERA_DocumentById?docId=${id}`).subscribe(response => {
      let blob: any = new Blob([response]);
      saveAs(blob, fileName);
    }), error => {

    }, () => console.info('File downloaded successfully');
    }
  
  }

  getFileDisplayName() {
    if (this.selectedFile && this.selectedFile.name) {
      if (this.selectedFile.name.length > 25)
        return this.selectedFile.name.substr(0, 24);
      return this.selectedFile.name;
    }
  }


  getNameFromList<T>(
    list: T[],
    idValue: any,
    idKey: keyof T,
    nameKey: keyof T
  ): string {
    const item = list.find(entry => String(entry[idKey]) === String(idValue));
    return item ? String(item[nameKey]) : '';
  }

    GetLookupData() {
    this._apiService.getData('/CredEDIERASetup/GetLookupLists').subscribe(data => {
      if (data.Status === 'Success') {
        this.LookupList = data.Response;

      }
    });
  }
  checkAccess(property:string):boolean{
    
  var res= this.GV.currentUser.RolesAndRights.some(
    r => r.ModuleName.toLowerCase().trim() === 'EdiEraSetup'.toLowerCase().trim()&&
     r.SubModuleName.toLowerCase().trim()=="EdiEraApplicationDocuments".toLowerCase().trim() &&
     r.PropertyName.toLowerCase().trim()==property.toLowerCase().trim()
  );
  return res;
}

}
