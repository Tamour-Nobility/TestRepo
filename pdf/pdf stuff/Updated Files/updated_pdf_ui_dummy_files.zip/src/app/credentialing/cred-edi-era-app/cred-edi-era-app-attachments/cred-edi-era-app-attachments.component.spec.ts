import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CredEdiEraAppAttachmentsComponent } from './cred-edi-era-app-attachments.component';

describe('CredEdiEraAppAttachmentsComponent', () => {
  let component: CredEdiEraAppAttachmentsComponent;
  let fixture: ComponentFixture<CredEdiEraAppAttachmentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CredEdiEraAppAttachmentsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CredEdiEraAppAttachmentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
