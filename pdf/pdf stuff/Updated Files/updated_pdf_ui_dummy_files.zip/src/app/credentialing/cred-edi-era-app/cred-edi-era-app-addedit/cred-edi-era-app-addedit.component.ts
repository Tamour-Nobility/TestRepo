import { ChangeDetectorRef, Component, OnInit, ViewChild,  } from '@angular/core';
import { PracticeModel } from '../../../practice-setup/practiceList/Classes/practiceClass';
import { APIService } from '../../../components/services/api.service';
import { CredAppViewModel } from '../../classes/CredAppModel';
import { CredEDIERAAppViewModel } from '../../classes/CreadEDIERAModel';
import { ModalWindow } from '../../../shared/modal-window/modal-window.component';
import { ToastrService } from 'ngx-toastr';
import { IMyDate, IMyDpOptions } from 'mydatepicker';
import { User } from '../../../user-management/classes/requestResponse';
import { CurrentUserViewModel } from '../../../models/auth/auth';
import { GvarsService } from '../../../services/G_vars/gvars.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ChangeDetectionStrategy } from '@angular/compiler/src/compiler_facade_interface';
import { CredEDiERANoteModel } from '../../classes/CredEDiERANoteModel';
import { ModalDirective, ModalOptions } from 'ngx-bootstrap/modal';
import { FileHandlerService } from '../../../components/services/file-handler/filehandler.service';
declare var $: any;import { CredEdiEraAppAttachmentsComponent } from '../cred-edi-era-app-attachments/cred-edi-era-app-attachments.component';
import { debug } from 'console';
import { startWith } from 'rxjs/operators';

@Component({
  selector: 'app-cred-edi-era-app-addedit',
  templateUrl: './cred-edi-era-app-addedit.component.html',
  styleUrls: ['./cred-edi-era-app-addedit.component.css']
})
export class CredEdiEraAppAddeditComponent implements OnInit {
 @ViewChild(CredEdiEraAppAttachmentsComponent) applicationAttachments;
  tempAttachments: any[] = [];
  model: CredEDIERAAppViewModel;
   practiceList: any = [];
   providerList: any = [];
   
   PracticeModel: PracticeModel;
   oldNotesCount:number;
   LookupList: any;
   selectedProvider: any;
 strComDate: IMyDate;
 showToaster:boolean=true;
 public placeholdertxt: string = 'MM/DD/YYYY';
   // IDs for logic
   groupAppTypeId: number;
   individualAppTypeId: number;
   ipaContractTypeId: number;
   directContractTypeId: number;
   approvedStatusId: number;
   isIpaNameDisabled:boolean =false;
   currentUser: CurrentUserViewModel;
   strlastFollowUpDate: IMyDate;
  strDatenextFollowUp: IMyDate;
  strDateappliedDate: IMyDate;
   strDateeffectiveDate: IMyDate;
    strDaterecredentialingDate: IMyDate;
     strDateassignedDate: IMyDate;
    isViewMode:boolean=false;
    dataTablenotes: any;
    credNote:CredEDiERANoteModel;
       modalOptions: { backdrop: string } = { backdrop: 'static' };
   @ViewChild('practiceNotesModel') practiceNotesModel: ModalDirective;
   gridData=[]
   public myDatePickerOptions: IMyDpOptions = {
           dateFormat: 'mm/dd/yyyy', height: '25px', width: '93%'
       };
  public myDatePickerOptionsNextFollowup: IMyDpOptions = {
           dateFormat: 'mm/dd/yyyy', height: '25px', width: '93%'
       };
         usersList =  [];
         isnotedAdded:boolean=false;
         canAddNote: boolean = true;
 isEditMode: boolean = false;
 
selectedObjective: number | null = null;
isEFT = false;
directTPAType: string | null = null; // Direct / TPA
clearingHouseName: string = '';
softwareName: string = '';
clearingHouseID: number | null = null;
softwareID: number | null = null;

 @ViewChild('AddTPAName') AddTPAName: ModalDirective;
newAddedtpaName: string = '';
routePath: string = ''
disableNextFollowUp: boolean = false;


   constructor(public API: APIService, private _fileHandlerService: FileHandlerService, private toaster: ToastrService,private GV: GvarsService,private route: ActivatedRoute,private router:Router,private chRef:ChangeDetectorRef) {
     this.model = new CredEDIERAAppViewModel();
     this.credNote= new CredEDiERANoteModel;
     this.usersList =[]; 
      this.LookupList = {
       EDI_ERA_Doc_Types:[],
       EDI_ERA_Obj_Types:[],
      TPA_Name_List:[],
       EDI_ERA_Statuses:[],
       Clearing_Houses:[],
       Practice_Software:[],

           };
    
   }
 
 ngOnInit(): void {
    this.routePath = this.route.snapshot.routeConfig.path;   // "view/:id"
   const id = Number(this.route.snapshot.paramMap.get('id'));
   this.model.EDI_ERA_App_Id=id;
   this.LoadPractices();
   
   debugger;
   if (this.routePath.startsWith('viewcredEdiEraaddedit')) {
     this.isViewMode = true;
   }
    if(this.routePath.startsWith('editcredEdiEraaddedit')){
     debugger
     this.model.App_Status_Id=201;
    }
    if(this.routePath.startsWith('addcredEdiEraaddedit')){
     debugger
  this.model.Obj_Type_Id=101;
  this.model.App_Status_Id=201;
  this.disableNextFollowUp =  true;
         this.strlastFollowUpDate=null;
         this.strDatenextFollowUp=null;

    }
    
   if (id && id > 0) {
     this.GetCredAppById(id);
     this.GetCredNotes();
   }
 this.model.Assigned_Date = new Date();
          
 this.strDateassignedDate = this.formatDateMMDDYYYY(this.model.Assigned_Date);
 
  // this.practiceList = JSON.parse(localStorage.getItem('pr') || '[]');

   this.GetLookupData();
   this.currentUser = this.GV.currentUser;
  //  this.loadUsers();
 
}
 
 
 
   GetLookupData() {
     this.API.getData('/CredEDIERASetup/GetLookupLists').subscribe(data => {
       if (data.Status === 'Success') {
        
         this.LookupList = data.Response;
          //SORT Objective Types in required order
      this.LookupList.EDI_ERA_Obj_Types = this.sortObjectives(
        this.LookupList.EDI_ERA_Obj_Types
      );
  }
     });
   }
 GetCredAppById(id) {
  
   this.API.getData(`/CredEDIERASetup/GetCredEDIERASetupById/${id}`).subscribe(data => {
     if (data.Status === 'Success') {
 
       const r = data.Response.App;
        this.model = {
         EDI_ERA_App_Id: r.EDI_ERA_App_Id,
         Practice_Code: r.Practice_Code,
         Payer_Name: r.Payer_Name,
         Obj_Type_Id: r.Obj_Type_Id,
         App_Status_Id: r.App_Status_Id,
         Tracking_Id: r.Tracking_Id,
         Applied_Date: r.Applied_Date,
         Effectice_Date: r.Effectice_Date,
         Last_FollowUp_Date: r.Last_FollowUp_Date,
         Next_Followup_Date: r.Next_Followup_Date,
         Created_Date: r.Created_Date,
         Created_by: r.Created_By,
         Assigned_To: r.Assigned_To,
         Assigned_By: r.Assigned_By,
         Assigned_Date: r.Assigned_Date,
         Modified_By: r.Modified_By,
         Modfied_Date: r.Modified_Date,
         TPA_Name_Id:r.TPA_Name_Id,
         TPA_user_Id:r.TPA_user_Id,
         Direct_TPA:r.Direct_TPA,
         Clearing_House_Id:r.Clearing_House_Id,
         Software_Id:r.Software_Id,
         Deleted:r.Deleted,
         
       };
       if(r.Obj_Type_Id === 102){
        this.isEFT =  true;
       }else{
        this.isEFT =  false;
       }
       this.strDateappliedDate=this.formatDateMMDDYYYY(this.model.Applied_Date);
       this.strDateassignedDate=this.formatDateMMDDYYYY(this.model.Assigned_Date);
       this.strDateeffectiveDate=this.formatDateMMDDYYYY(this.model.Effectice_Date);
       this.strDatenextFollowUp=this.formatDateMMDDYYYY(this.model.Next_Followup_Date);
       this.strlastFollowUpDate=this.formatDateMMDDYYYY(this.model.Last_FollowUp_Date);
       
       debugger
if(this.model.Last_FollowUp_Date ===  null){
  this.disableNextFollowUp =  true;
}
       this.GetPracticeData(this.model.Practice_Code);
   
     }
   });
 }
 formatDateMMDDYYYY(dateString: any): IMyDate {
   if (!dateString) return null;
 
   const d = new Date(dateString);  // convert string → Date
 
   return {
     year: d.getFullYear(),
     month: d.getMonth() + 1,
     day: d.getDate()
   };
 }
 LoadPractices() {
     this.API.getData(`/Credentialing/GetActivePractices`).subscribe(res => {
       if (res.Status == 'Sucess') {
          this.practiceList=res.Response;
 debugger
             this.practiceList = this.practiceList.map(practice => {
            return {
                ...practice,  // Keep all existing properties
                PracticeLabel: `${practice.Practice_Code} | ${practice.Prac_Name}`  // Add new combined property
              };
             });
                   if(  this.model.EDI_ERA_App_Id==0){
          this.model.Practice_Code=this.GV.currentUser.selectedPractice.PracticeCode;
          this.GetPracticeData(this.model.Practice_Code)
       }
      }
     });
   }
 loadUsers() {
  debugger
     const role = this.currentUser.role;
     if (['Credentialing', 'Credentialing Lead', 'Credentialing Manager'].includes(role)) {
       this.API.getData(`/Credentialing/GetCredUserListByRole?Role=${role}&practiceId=${this.model.Practice_Code}`).subscribe(res => {
         if (res.Status !== 'Success') {
           this.toaster.error(res.Status, 'Failed');
           return;
         }
         this.usersList = res.Response;
         this.usersList.forEach(u => u.displayName = u.LastName + ', ' + u.FirstName);
         if (!this.model.Assigned_By) {
           this.model.Assigned_By = this.currentUser.userId;
         }
       });
     } else {
       this.usersList = [];
     }
   }
   GetPracticeData(practiceCode: number) {
     if (!practiceCode) return;
     this.API.getData('/PracticeSetup/GetPractice?PracticeId=' + practiceCode).subscribe(data => {
       if (data.Status === 'Sucess') {
         this.PracticeModel = data;
     
    this.PracticeModel.Response.PracticeModel.Practice_Software = Number(this.PracticeModel.Response.PracticeModel.Practice_Software);



    if(this.routePath.startsWith('add')){
    this.clearingHouseID =
    this.PracticeModel.Response.PracticeModel.Prac_Clearing_house; // your numeric value
  this.softwareID =
    this.PracticeModel.Response.PracticeModel.Practice_Software; // your numeric value
//if we create application need to set ids in model 
    }else{
 this.clearingHouseID =
   this.model.Clearing_House_Id; // your numeric value
  this.softwareID =
    this.model.Software_Id; // your numeric value
    }

    // Clearing House
  const clearingHouse =
    this.LookupList.Clearing_Houses.find(ch => ch.Clearing_House_Id === this.clearingHouseID);

  this.clearingHouseName = clearingHouse
    ? clearingHouse.Clearing_House_Desc
    : '';

  // Software
  const software =
     this.LookupList.Practice_Software.find(ps => ps.Prac_Soft_ID === this.softwareID);

  this.softwareName = software
    ? software.Prac_Soft_Name
    : '';
    
         // Uppercase formatting
         const pm = this.PracticeModel.Response.PracticeModel;
         if (pm.Prac_Name) pm.Prac_Name = pm.Prac_Name.toUpperCase();
       if (pm.Prac_Address) pm.Prac_Address = pm.Prac_Address.toUpperCase();
       if (pm.Mailing_Address) pm.Mailing_Address = pm.Mailing_Address.toUpperCase();
       }
       // Reload users when practice changes
       this.loadUsers();
     });
   }
 
   onLastFollowUpChange() {
        this.disableNextFollowUp= false;

     if (!this.model.Last_FollowUp_Date) return;
 
     const last = new Date(this.model.Last_FollowUp_Date);
     const next = new Date(last);
     next.setDate(last.getDate() + 14);
  this.model.Next_Followup_Date = next;
      this.strDatenextFollowUp = {
     year: next.getFullYear(),
     month: next.getMonth() + 1,
     day: next.getDate()
   };
 debugger;
     this.setNextFollowUpDateRestrictions(last, next);
   }
 
 validateStatusAndDates(): boolean {
 
   const statusId = this.model.App_Status_Id;
   const statusDesc = this.LookupList.EDI_ERA_Statuses
     .find(x => x.Status_Id == statusId).Status_Desc;
 
   if (String(statusId) == "202" || statusDesc == 'Approved') {
 
     if (this.model.Effectice_Date==null) {
       this.toaster.error('Effective Date is required when status is Approved.');
       return false;
     }
   }
 debugger;
   if (this.model.Last_FollowUp_Date && this.model.Next_Followup_Date) {
     if (new Date(this.model.Last_FollowUp_Date)
         .toDateString() === new Date(this.model.Next_Followup_Date).toDateString()) {
       this.toaster.error('Last Follow-up Date and Next Follow-up Date cannot be same');
       this.model.Next_Followup_Date = null;
                  this.strDatenextFollowUp=null;
       return false;
     }
   }
 
   const lastFollowUpRequired = [
     'Pending','In Process','Not Enrolled','Rejected',
     'Development','Status Review Required','Out of Network','Network Closed','On Hold'
   ];
 
   if (lastFollowUpRequired.includes(statusDesc)) {
     if (!this.model.Last_FollowUp_Date) {
       this.toaster.error('Last Follow-up Date is required for this status.');
       return false;
     }
   }
 
   const nextFollowUpRequired = [
     'Pending','In Process','On Hold','Development','Status Review Required'
   ];
 
   if (nextFollowUpRequired.includes(statusDesc)) {
     if (!this.model.Next_Followup_Date) {
       this.toaster.error('Next Follow-up Date is required for this status.');
       return false;
     }
   }
 
   if (statusDesc !== 'Approved') {
     if (!this.model.Assigned_To) {
       this.toaster.error('Please fill out the Assigned To field.');
       return false;
     }
   }
   if((String(statusId) === "202" || statusDesc == 'Approved') && this.model.Next_Followup_Date != null)
{
     this.toaster.error('Status is Approved, please remove Next Follow-Up Date.'); return;}
 
   return true;
 }
 
 
   onSave(): void {
 
     // Basic mandatory validations
      if (!this.model.Practice_Code) { this.toaster.error('Please fill out the Practice field.'); return;}
     if (!this.model.Obj_Type_Id) { this.toaster.error('Please select an Objective.'); return; }
     if (!this.model.Payer_Name) { this.toaster.error('Please Enter Payer Name.'); return; }
     if(this.isEFT)
     {
          if (!this.model.Direct_TPA) { this.toaster.error('Please select option form Direct/TPA Dropdown.'); return; }
          if (!this.model.TPA_Name_Id && this.model.Direct_TPA !== 'Direct') { this.toaster.error(' Please select TPA Name.'); return; }
          if (!this.model.TPA_user_Id && this.model.Direct_TPA !== 'Direct') { this.toaster.error('Please enter TPA User ID.'); return; }
     debugger   
 

     }
          if (!this.model.App_Status_Id) { this.toaster.error('Please select a Status.'); return; }
          if (this.model.App_Status_Id === 202 && !this.model.Effectice_Date) { this.toaster.error('Effective Date is required when Application Status = Approved.'); return; }


    
     if (!this.validateStatusAndDates()) return;
   if (!this.model.Assigned_To) { this.toaster.error('Please fill out the Assigned To field.'); return; }
   
    if(this.model.EDI_ERA_App_Id >0 && this.model.App_Status_Id==201||this.model.App_Status_Id==this.LookupList.EDI_ERA_Statuses.find(s=>s.Status_Desc=='New')){
 this.toaster.error('Change status from ‘New’ to continue.'); return;
    }
    debugger
    if( this.isnotedAdded==false){
       this.toaster.error("Please add note before saving the application.", "Error")
       return;
     }

     this.model.Clearing_House_Id = this.clearingHouseID;
     this.model.Software_Id = this.softwareID;
         
   if(this.model.App_Status_Id)
     this.API.PostData('/CredEDIERASetup/AddEditCredApp/', this.model, (d) => {
    
       if (d.Status === 'Success') {
         this.toaster.success('Application has been generated', 'Success');
          const newAppId = d.Response;
             if (this.tempAttachments.length > 0) {
          this.uploadTempAttachments(newAppId);
        }
        if(this.model.EDI_ERA_App_Id==0){
          
           debugger
      
        if(this.credNote.Note_Desc!=null){
          this.showToaster=false
          this.credNote.EDI_ERA_App_Id=newAppId;
          this.credNote.EDI_ERA_Note_Id=0
          this.PostNote(this.credNote);
        }
        }
        // Update model ID if this was a new application
        if(this.model.EDI_ERA_App_Id===0) {
          this.model.EDI_ERA_App_Id = newAppId;
        }
        // Switch to view mode after saving
        this.isViewMode = true;
       } else {
         this.toaster.error('An error occured while generating application', 'Failed');
       }
     });
   }
  
   onCancel(): void {
     window.history.back();
   }

  //  onEditForm(): void {
  //   debugger
  //    // Switch to edit mode for form fields
  //    this.isViewMode = false;
  //    this.canAddNote = true; // Allow adding notes in edit mode
  //    this.chRef.detectChanges();
  //  }
 
   onReset(): void {
    debugger;
          if (!this.model.EDI_ERA_App_Id) {
            this.model = new CredEDIERAAppViewModel()
       this.model.Obj_Type_Id=101;
  this.model.App_Status_Id=201;
  this.disableNextFollowUp =  true;
       this.model.Last_FollowUp_Date = null;
this.model.Next_Followup_Date = null;
this.model.Applied_Date = null;
this.model.Effectice_Date = null;
      this.model.Assigned_Date = null;
       this.strDateappliedDate=null;
       this.strDateassignedDate=null;
       this.strDateeffectiveDate=null;
       this.strDatenextFollowUp=null;
      
       this.strlastFollowUpDate=undefined
     }
    }
  // Direct input field for payer - no modal needed
 
 
  getUsersList() {
     this.API.getData('/UserManagementSetup/GetUsersList').subscribe(
       data => {
         if (data.Status === 'Success') {
          
           this.usersList = data.Response;
          
          
         } else {
           this.toaster.error(data.Status, 'Failed');
         }
       });
   }
onDateChangedExp(event, type: string) {

  const mapping = {
    lastFollowUp: 'Last_FollowUp_Date',
    nextFollowUp: 'Next_Followup_Date',
    appliedDate: 'Applied_Date',
    effectiveDate: 'Effectice_Date',
    assignedDate: 'Assigned_Date'
  };

  const target = mapping[type];
  const date = event.formatted;

  // Clear date
  if (!date) {
    if (target) {
      this.model[target] = null;
    }

    if (target === 'Last_FollowUp_Date') {
    this.disableNextFollowUp= true;
      this.model.Next_Followup_Date = null;
    }
    return;
  }

  // Set date
  if (target) {
    this.model[target] = date;
  }

  // Special handling for Last Follow Up
  if (target === 'Last_FollowUp_Date') {

    this.onLastFollowUpChange();

    if (
      this.model.Last_FollowUp_Date &&
      this.model.Next_Followup_Date &&
      this.model.Last_FollowUp_Date === this.model.Next_Followup_Date
    ) {
      this.toaster.error(
        'Last Follow-Up Date and Next Follow-Up Date cannot be the same.',
        'Invalid Date'
      );

      
    }
  }

  // Also validate when NEXT follow-up changes
  if (target === 'Next_Followup_Date') {
    if (
      this.model.Last_FollowUp_Date &&
      this.model.Next_Followup_Date &&
      this.model.Last_FollowUp_Date === this.model.Next_Followup_Date
    ) {
      this.toaster.error(
        'Last Follow-Up Date and Next Follow-Up Date cannot be the same.',
        'Invalid Date'
      );

    }
  }
}


   setNextFollowUpDateRestrictions(minDate: Date, maxDate: Date) {
 
   this.myDatePickerOptionsNextFollowup = {
     ...this.myDatePickerOptionsNextFollowup,
     disableSince: {
       year: maxDate.getFullYear(),
       month: maxDate.getMonth() + 1,
       day: maxDate.getDate() + 1
     },
     disableUntil: {
       year: minDate.getFullYear(),
       month: minDate.getMonth() + 1,
       day: minDate.getDate() - 1
     }
   };
       if (this.model.App_Status_Id == 202) {
    this.model.Next_Followup_Date = null;
           this.strDatenextFollowUp=null;

    // do something
  }
 }
 
    onInputCleared(event: any, fieldName: string) {
 
  debugger
   if (event.value === "") {
 
     if (fieldName === 'lastFollowUp') {
       this.model.Last_FollowUp_Date = null;
       this.strlastFollowUpDate=null;
       this.model.Next_Followup_Date = null; 

       this.strDatenextFollowUp=null
     }
     
   }
 }
 
 showNotesModel(mode: string) {
 
   if (mode === 'Add') {
     this.isEditMode = false;
     this.credNote = new CredEDiERANoteModel();
 
     if (this.model.EDI_ERA_App_Id > 0) {
       // EXISTING APP -> unlimited notes
       this.canAddNote = true;
     } else {
       // NEW APP -> only allow if no note exists
       this.canAddNote = this.gridData.length === 0;
     }
   }
 
   if (mode === 'Edit') {
     this.isEditMode = true;
     //this.canAddNote = true; 
   }
 
   this.practiceNotesModel.show();
 }
 
 OnAddEditNotes() {
 
   if (!this.credNote.Note_Desc) {
     this.toaster.error("Note is Required!", "Error");
     return;
   }
   debugger
  this.credNote.Created_By_UserName=this.GV.currentUser.unique_name
  this.credNote.Created_by=this.GV.currentUser.userId
  this.credNote.Created_Date= new Date(); 
   if (this.model.EDI_ERA_App_Id > 0) {
     this.credNote.EDI_ERA_App_Id = this.model.EDI_ERA_App_Id;
     this.credNote.Is_Auto_Note = false;
     this.PostNote(this.credNote);
     return;
   }
 
 
 
   if (this.isEditMode) {
 
     const index = this.gridData.findIndex(x => x.EDI_ERA_Note_Id === this.credNote.EDI_ERA_Note_Id);
     if (index >= 0) {
       this.gridData[index] = { ...this.credNote };
     }
   } else {
 
     if (this.gridData.length >= 1) {
       this.toaster.error("Only one note is allowed before saving the application!", "Error");
       return;
     }
 
    
     this.credNote.EDI_ERA_Note_Id = Date.now(); 
     this.gridData.push({ ...this.credNote });
     
   }
 
   this.canAddNote = false;
 
   this.practiceNotesModel.hide();
   //this.credNote = new CredEDiERANoteModel();
    this.isnotedAdded=true
 }
 
 
 PostNote(note:any){
    this.API.PostData('/CredEDIERASetup/AddEditCred_EDIERA_Note/', note, (d) => {
       if (d.Status == 'Success') {
         debugger
        if (typeof note.Cred_App_Note_Id !== 'number') {
          this.canAddNote = false;
        }
         
         if(this.showToaster){
 this.toaster.success('Note has been added', 'Success');
         }
         this.showToaster=true;
         this.isnotedAdded=true;
        //  this.canAddNote = false;
         this.GetCredNotes();
    this.practiceNotesModel.hide()
    this.credNote.Note_Desc=null;
       } else {
         this.toaster.error('An error occured while adding note', 'Failed');
       }
     });
 }
 GetCredNotes() {
   if(this.model.EDI_ERA_App_Id>0){
   this.API.getData(`/CredEDIERASetup/GetCred_EDIERA_Notes?application_Id=${this.model.EDI_ERA_App_Id}`).subscribe(res => {
       if (res.Status !== 'Success') {
         this.toaster.error(res.Status, 'Failed');
         return;
       }
  
         if (this.dataTablenotes) {
                         this.chRef.detectChanges();
                         this.dataTablenotes.destroy();
                     }
                     this.gridData=res.Response;
                     this.oldNotesCount=this.gridData.length;
                     this.chRef.detectChanges();
                     const table: any = $('.dataTablenotes');
     this.dataTablenotes = table.DataTable({
       columnDefs: [
         { orderable: false, targets: -1 },  // Actions column
         { width: '45%', targets: 0 },       // Note Description
         { width: '20%', targets: 1 },       // UserName
         { width: '20%', targets: 2 },       // Created On
         { width: '15%', targets: 3 }        // Actions
       ],
       language: {
         emptyTable: "No data available"
       },
       autoWidth: false,    // important to respect our widths
       scrollX: false       // set true only if you want horizontal scroll
     });
     });
   }
   
   }
   onEdit(id:any){
     debugger
     this.credNote=this.gridData.find(g =>g.Cred_App_Note_Id ==id);
     this.showNotesModel("Edit");
   }
      onEditERAEDIApp(id: number): void {
        debugger
         this.isViewMode = false;
         this.canAddNote = true; // Allow adding notes in edit mode
         this.isnotedAdded=false;
    this.router.navigate(['credentialing/editcredEdiEraaddedit', id]);
    this.GetCredNotes();
  }
    checkAccess(property:string):boolean{
     
   var res= this.GV.currentUser.RolesAndRights.some(
     r => r.ModuleName.toLowerCase().trim() === 'EdiEraSetup'.toLowerCase().trim()&&
      r.SubModuleName.toLowerCase().trim()=="EdiEraGenerateApplication".toLowerCase().trim() &&
      r.PropertyName.toLowerCase().trim()==property.toLowerCase().trim()
   );
 
   return res;
    }

 

    isEditDisabled(createdDate: string,createdby:number): boolean {
     
     if(Number(this.GV.currentUser.userId)==createdby){
 const created = new Date(createdDate);
   const now = new Date();
 
   const diffMs = now.getTime() - created.getTime();     
   const diffHours = diffMs / (1000 * 60 * 60);          
 
   return diffHours > 24;  
     }
     else
     {
       return true;
     }
   
 }
 

 
 uploadTempAttachments(appId: number) {
 debugger    
   this.tempAttachments.forEach(att => {

     const formData = new FormData();
     formData.append("ApplicationId", appId.toString());
     formData.append("DocTypeId", att.docType);
     formData.append( att.file.name, att.file);
 
     this._fileHandlerService.UploadFile(formData, '/CredEDIERASetup/UploadCred_EDIERA_Document')
       .subscribe(res => {
         debugger
       
       });
   });
 
   // After uploading, clear memory
   this.tempAttachments = [];
 }
 onAssignedToChange(val: any) {
   debugger
   if (val) {
     const today = new Date();
     today.setHours(0, 0, 0, 0);
 
     this.model.Assigned_Date = today;
 
     this.strDateassignedDate = this.formatDateMMDDYYYY(today);
   }
 }
 isLastFollowUpRequired(): boolean {
    if(this.LookupList.EDI_ERA_Statuses.length!=0){
  const statusId = this.model.App_Status_Id;
   const statusDesc = this.LookupList.EDI_ERA_Statuses
     .find(x => x.Status_Id == statusId).Status_Desc;
 
   const lastFollowUpRequired = [
     'Pending','In Process','Need Billing Info','Portal Access Needed',
     'Copy of EOB','Document Attachment','Not Required'
   ];
 
   return lastFollowUpRequired.includes(statusDesc);
   }
  
 }
 
 isNextFollowUpRequired(): boolean {
    if(this.LookupList.EDI_ERA_Statuses.length!=0){
   const statusId = this.model.App_Status_Id;
   const statusDesc = this.LookupList.EDI_ERA_Statuses
     .find(x => x.Status_Id == statusId).Status_Desc;
 
   const nextFollowUpRequired = [
     'Pending','In Process','Need Billing Info','Portal Access Needed',
     'Copy of EOB','Document Attachment',
   ];
 
   return nextFollowUpRequired.includes(statusDesc);
 }
 
 }
 onObjectiveChange() {
  // Replace 3 with actual EFT Obj_Type_Id
  // this.model = new CredEDIERAAppViewModel();
  if(this.routePath.startsWith('add')){
                   this.model.App_Status_Id=201;
  }
  this.isEFT = this.model.Obj_Type_Id === 102;
  this.model.Payer_Name = null;

}

clearPayer() {
  this.model.Payer_Name = null;
}

openTPANamepopup(){
  this.AddTPAName.show();
}
addTPANameInList(){
  const newTPA = {
    TPA_Name_Id: this.generateTPAId(),
    TPA_Name_Desc: this.newAddedtpaName.trim()
  };

  this.API.PostData('/CredEDIERASetup/AddTPAName/', newTPA, (d) => {
    debugger;
       if (d.Status === "Success") {
          this.toaster.success('TPA Name Added', 'Success');
            this.model.TPA_Name_Id = newTPA.TPA_Name_Id;
this.LookupList.TPA_Name_List.push(newTPA);
          this.AddTPAName.hide();
       } else {
         this.toaster.error(d.STCDescription, 'Failed');
           this.model.TPA_Name_Id = null;
       }
         // clear modal input & close
       this.newAddedtpaName ='';
     });

}
generateTPAId(): number {
  if (!this.LookupList.TPA_Name_List.length) {
    return 1;
  }
  return Math.max(...this.LookupList.TPA_Name_List.map(x => x.TPA_Name_Id)) + 1;
}

 //#endregion
 
handleAttachmentFromChild(event: any[]) {
  this.tempAttachments = [...this.tempAttachments, ...event]; 

}
handleDeleteAttachment(event: any[]) {
  debugger
  const deletedId = Number(event[0].id); // or String(...)

  this.tempAttachments = this.tempAttachments.filter(
    t => Number(t.id) !== deletedId
  );
}
onStatusChange(statusId: string | null): void {

  if (statusId === null) {
    // when "Select Status" is chosen
    this.model.EDI_ERA_App_Id = null;
    return;
  }

  // find selected status object (optional)
  const selectedStatus = this.LookupList.EDI_ERA_Statuses.find(s => s.Status_Id === statusId);

  // Example conditional logic
  debugger;
  if (statusId === "202") {
    this.model.Next_Followup_Date = null;
           this.strDatenextFollowUp=null;

    // do something
  }
}
onDirectTPAChange(type: string | null): void {
if(type === 'Direct'){
  this.model.TPA_Name_Id = null;
  this.model.TPA_user_Id = null;
}
}


sortObjectives(list: any[]) {
  const order = ['EDI', 'ERA', 'EFT'];

  return list.sort((a, b) => {
    return order.indexOf(a.Obj_Desc) - order.indexOf(b.Obj_Desc);
  });
}

}
