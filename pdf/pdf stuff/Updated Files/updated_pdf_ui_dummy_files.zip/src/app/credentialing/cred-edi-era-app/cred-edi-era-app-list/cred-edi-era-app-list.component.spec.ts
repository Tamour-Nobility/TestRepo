import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CredEdiEraAppListComponent } from './cred-edi-era-app-list.component';

describe('CredEdiEraAppListComponent', () => {
  let component: CredEdiEraAppListComponent;
  let fixture: ComponentFixture<CredEdiEraAppListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CredEdiEraAppListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CredEdiEraAppListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
