import { ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import * as moment from 'moment';
import { IMyDpOptions } from 'mydatepicker';
import { IMyDate, IMyDateRangeModel } from 'mydaterangepicker';
import { ToastrService } from 'ngx-toastr';
import { APIService } from '../../../components/services/api.service';
import { Common } from '../../../../app/services/common/common';
import { GvarsService } from '../.././../services/G_vars/gvars.service';
import { ModalWindow } from '../../../shared/modal-window/modal-window.component';
import * as XLSX from 'xlsx';

@Component({
  selector: 'app-cred-edi-era-app-list',
  templateUrl: './cred-edi-era-app-list.component.html',
  styleUrls: ['./cred-edi-era-app-list.component.css']
})
export class CredEdiEraAppListComponent implements OnInit {

  
searchStarted = false;
  // Static lookup arrays
  practiceList = [];
  LookupList: any;


  providerList = [];

  
  objectiveTypes = ["New Enrollment", "Demographic Update", "Other"];

  dateCriteriaList = [
      { value: 'AppCreatedDate', description: 'Created Date' },
      { value: 'LastFollowUpDate', description: 'Last Follow Up Date' },
      { value: 'NextFollowUpDate', description: 'Next Follow Up Date' },
      { value: 'AppliedDate', description: 'Applied Date' },
      { value: 'EffectiveDate', description: 'Effective Date' },
      { value: 'AssignedDate', description: 'Assigned Date' },
   
  ];
 strComDate: IMyDate;
  usersList =  [];
dataTableEdiEra: any;
  // Search model
  searchModel: any = {
    practice_Code: null,
    Clearing_House_Id: null,
    Payer_Name: null,
    Prac_Soft_ID: null,
    obj_Type_Id: null,
    Status_Id:null,
    tracking_Id:null,
    created_by:null,
    dateFrom: null,
    dateTo: null,
    dateCriteria:null,
    assigned_To:null,    
  };
  dateRange: any = null;
  @ViewChild('insuranceSearch') insuranceModal: ModalWindow;
  gridData: any[] = [];

myDateRangePickerOptions: IMyDpOptions = {
        dateFormat: 'mm/dd/yyyy', height: '25px', width: '100%'
    };
      dateRangeModel: any = null;
 constructor(private router: Router,public API: APIService, private toaster: ToastrService,private chRef:ChangeDetectorRef,private gvService:GvarsService,private route:ActivatedRoute) {
  this.usersList=[];
  }

  ngOnInit(): void { 
    //this.practiceList = JSON.parse(localStorage.getItem('pr') || '[]');
    this.LoadPractices()
    this.GetLookupData();
    this.loadUsers('EdiEraSetup');
               this.route.queryParams.subscribe(params => {
    this.searchModel.practice_Code = Number(params['practice_Code']);
    this.searchModel.assigned_To = Number(params['UserId']);
    var column=params['column'];
    this.searchModel.obj_Type_Id =Number(params['obj_type'])
    this.applyColumnFilters(column)
    this.search();
  });
  }
  GetLookupData() {
    this.API.getData('/CredEDIERASetup/GetLookupLists').subscribe(data => {
      if (data.Status === 'Success') {
        this.LookupList = data.Response;
                  // SORT Objective Types in required order
      this.LookupList.EDI_ERA_Obj_Types = this.sortObjectives(
        this.LookupList.EDI_ERA_Obj_Types
      );

      }
    });
  }

 ShowInsuranceNamePopup() {
    this.insuranceModal.show();
  }
Insname_Description:string;
  onSelectInsurance(event: any) {
  this.searchModel.insurance_Id = event.insuranceId;
    this.Insname_Description= event.insuranceName;
    this.insuranceModal.hide();
  }
  search() {
    debugger
 
    // For now generate mock grid data
  const { dateCriteria, dateFrom, dateTo } = this.searchModel;

  // Null-safe values
  const hasCriteria = !!dateCriteria;
  const hasFrom = !!dateFrom;
  const hasTo = !!dateTo;

 

 
  if (hasCriteria && (!hasFrom || !hasTo)) {
    this.toaster.error("Both Date Criteria and From - To Dates are required.", "Error");
    return;
  }

 
  if (!hasCriteria && (hasFrom || hasTo)) {
    this.toaster.error("Both Date Criteria and From - To Dates are required.", "Error");
    return;
  }

  
  if (hasFrom && hasTo && new Date(dateFrom) > new Date(dateTo)) {
    this.toaster.error("Date From must be less than or equal to Date To.", "Invalid Date Range");
    return;
  }
      this.API.PostData('/CredEDIERASetup/SearchCredEDIERASetup/', this.searchModel, (d) => {
      if (d.Status === 'Success') {
           this.searchStarted=true
        if (this.dataTableEdiEra) {
                        this.chRef.detectChanges();
                        this.dataTableEdiEra.destroy();
                    }
                    this.gridData=d.Response;
                    this.chRef.detectChanges();
           const table: any = $('.dataTableEdiEra');

  if (!table.length) {
    return;
  }

  this.dataTableEdiEra = table.DataTable({
    scrollX: true,
    autoWidth: false,
    destroy: true,
    columnDefs:  { orderable: false, targets:  - 1 },
    language: {
      emptyTable: 'No Records Found'
    }
  });


  this.dataTableEdiEra.columns.adjust();
      } else {
        this.toaster.error('An error occured while loading data', 'Failed');
      }
    });
  }

  clear() {
    this.searchModel= {
    practice_Code: null,
    Clearing_House_Id: null,
    Payer_Name: null,
    Prac_Soft_ID: null,
    obj_Type_Id: null,
    Status_Id:null,
    tracking_Id:null,
    created_by:null,
    dateFrom: null,
    dateTo: null,
    dateCriteria:null,
    assigned_To:null, 
  };
    this.dateRange = null;
    this.providerList = [];
    this.gridData = [];
    this.searchStarted=false
    if(this.dataTableEdiEra){
    this.dataTableEdiEra.destroy();
     this.chRef.detectChanges();
    }
  }
onAdd(): void {
    debugger
    this.router.navigate(['credentialing/addcredEdiEraaddedit']);
  }
  onEdit(id: number): void {
    this.router.navigate(['credentialing/editcredEdiEraaddedit', id]);
  }

LoadPractices() {
  
    this.API.getData(`/Credentialing/GetActivePractices`).subscribe(res => {
      if (res.Status == 'Sucess') {
         this.practiceList=res.Response;
    this.practiceList = this.practiceList.map(practice => {
            return {
                ...practice,  // Keep all existing properties
                PracticeLabel: `${practice.Practice_Code} | ${practice.Prac_Name}`  // Add new combined property
              };
             });
      }

    });
  }
  onView(row: any) {
    debugger;
    this.router.navigate(['credentialing/viewcredEdiEraaddedit',row.EDI_ERA_App_Id]);
  }
  onDateRangeChanged(event: IMyDateRangeModel) {
          this.searchModel.dateFrom = Common.isNullOrEmpty(event.beginJsDate) ? null : moment(event.beginJsDate).format('MM/DD/YYYY');
          this.searchModel.dateTo = Common.isNullOrEmpty(event.endJsDate) ? null : moment(event.endJsDate).format('MM/DD/YYYY');
          this.dateRange = event;
      }
loadUsers(moduleName:string) {
    this.API.getData(`/Credentialing/GetUsersByModuleName?moduleName=${moduleName}`).subscribe(res => {
      if (res.Status !== 'Success') {
        this.toaster.error(res.Status, 'Failed');
        return;
      }
  this.usersList=res.Response;
  this.usersList.forEach(u => u.displayName = u.LastName + ', ' + u.FirstName);
     
    });
  }
     checkAccess(property:string):boolean{
  var res= this.gvService.currentUser.RolesAndRights.some(
    r => r.ModuleName.toLowerCase().trim() === 'EdiEraSetup'.toLowerCase().trim()&&
     r.SubModuleName.toLowerCase().trim()=="EdiEraSearch".toLowerCase().trim() &&
     r.PropertyName.toLowerCase().trim()==property.toLowerCase().trim()
  );
  return res;
   }
   clearDateCriteria() {
  this.searchModel.dateCriteria = null;
}
     SubModuleAllowed(submodule:string):boolean{
    var res= this.gvService.currentUser.RolesAndRights.some(
    r => r.ModuleName.toLowerCase().trim() === 'CredentialingApp'.toLowerCase().trim()&&
     r.SubModuleName.toLowerCase().trim()==submodule.toLowerCase().trim() 
  );
  return res;
}

clearPayer(){
  this.Insname_Description=null
  this.searchModel.insurance_Id=null
}
OnObjChange(){

  this .gridData=[];
     if(this.dataTableEdiEra){
  this.dataTableEdiEra.destroy();
   this.searchStarted=false;
}
}

allowAlphaNumeric(event: any) {
  event.target.value = event.target.value.replace(/[^a-zA-Z0-9]/g, '');
  this.searchModel.tracking_Id = event.target.value;
}

/**
 * Export grid data to Excel - matches grid display exactly
 */
exportToExcel() {
  if (!this.gridData || this.gridData.length === 0) {
    this.toaster.warning('No data to export', 'Export Failed');
    return;
  }

  try {
    // Map grid data to match display columns exactly
    const exportData = this.gridData.map(r => {
      const row: any = {
        'Practice Code': r.Practice_Code,
        'Application Number': r.EDI_ERA_App_Id,
        'Objective Type': r.Objective_Type,
        'Payer Name': r.Payer_Name,
      };

      // Add conditional columns based on objective type
      if (this.searchModel.obj_Type_Id == null || this.searchModel.obj_Type_Id == 102) {
        row['Direct / TPA'] = r.Direct_TPA;
        row['TPA Name'] = r.TPA_Name;
        row['TPA User Id'] = r.TPA_user_Id;
      }

      if (this.searchModel.obj_Type_Id == null || this.searchModel.obj_Type_Id == 101|| this.searchModel.obj_Type_Id == 103) {
        row['Clearing House'] = r.Clearing_House;
        row['Software'] = r.Prac_Soft_Name;
      }

      row['Status'] = r.Application_Status;
      row['Last Note'] = r.Last_Note;
      row['Last Follow Up Date'] = r.Last_FollowUp_Date ? new Date(r.Last_FollowUp_Date).toLocaleDateString() : '';
      row['Next Follow Up Date'] = r.Next_Followup_Date ? new Date(r.Next_Followup_Date).toLocaleDateString() : '';
      row['Tracking ID'] = r.Tracking_Id;
      row['Applied Date'] = r.Applied_Date ? new Date(r.Applied_Date).toLocaleDateString() : '';
      row['Effective Date'] = r.Effectice_Date ? new Date(r.Effectice_Date).toLocaleDateString() : '';
      row['Created By'] = r.Created_By_Name;
      row['Created Date'] = r.Created_Date ? new Date(r.Created_Date).toLocaleDateString() : '';
      row['Assigned To'] = r.Assigned_To_Name;
      row['Assigned Date'] = r.Assigned_Date ? new Date(r.Assigned_Date).toLocaleDateString() : '';
      row['Assigned By'] = r.Assigned_By_Name;

      return row;
    });

    // Create worksheet from mapped data
    const worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(exportData);
    
    // Auto-fit column widths
    const wscols = [
      { wch: 12 }, { wch: 18 }, { wch: 15 }, { wch: 18 }, { wch: 12 },
      { wch: 15 }, { wch: 15 }, { wch: 18 }, { wch: 18 }, { wch: 15 },
      { wch: 20 }, { wch: 15 }, { wch: 15 }, { wch: 15 }, { wch: 15 },
      { wch: 15 }, { wch: 15 }, { wch: 15 }, { wch: 15 }
    ];
    worksheet['!cols'] = wscols;
    
    // Create workbook and add worksheet
    const workbook: XLSX.WorkBook = {
      Sheets: { 'EDI ERA Applications': worksheet },
      SheetNames: ['EDI ERA Applications']
    };
    
    // Generate Excel file
    const fileName = `EDI_ERA_EFT_Applications.xlsx`;
    XLSX.writeFile(workbook, fileName);
    
    this.toaster.success('Data exported successfully', 'Export Complete');
  } catch (error) {
    console.error('Error exporting to Excel:', error);
    this.toaster.error('Error exporting data to Excel', 'Export Failed');
  }
}
sortObjectives(list: any[]) {
  const order = ['EDI', 'ERA', 'EFT'];

  return list.sort((a, b) => {
    return order.indexOf(a.Obj_Desc) - order.indexOf(b.Obj_Desc);
  });
}



private applyColumnFilters(column: string) {

  this.searchModel.dateFrom = null;
  this.searchModel.dateTo = null;
  this.searchModel.application_Status_Id = null;
  this.searchModel.dateCriteria = null;

  const today = this.today();

  switch (column) {
    case 'CompletedLast30Days':
      this.searchModel.Status_Id = 202;
      this.searchModel.dateCriteria = 'AppCreatedDate';
      this.searchModel.dateFrom = this.daysAgo(30);
      this.searchModel.dateTo = today;
      break;

    case 'AssignedToday':
      this.searchModel.dateCriteria = 'AssignedDate';
      this.searchModel.dateFrom = today;
      this.searchModel.dateTo = today;
      break;


    case 'NextFollowUpOverdue':
      this.searchModel.dateCriteria = 'NextFollowUpDate';
      this.searchModel.dateTo = this.daysAgo(1);
       this.searchModel.dateFrom = this.daysAgo(730);
      break;

    case 'NextFollowupToday':
      this.searchModel.dateCriteria = 'NextFollowUpDate';
      this.searchModel.dateFrom = today;
      this.searchModel.dateTo = today;
      break;

    case 'NextFollowUpNext7Days':
      this.searchModel.dateCriteria = 'NextFollowUpDate';
      this.searchModel.dateFrom = today;
      this.searchModel.dateTo = this.daysFromNow(7);
      break;

    case 'RecredentialingToday':
      this.searchModel.dateCriteria = 'RecredentialingDate';
      this.searchModel.dateFrom = today;
      this.searchModel.dateTo = today;
      break;

    case 'RecredentialingOverdue':
      this.searchModel.dateCriteria = 'RecredentialingDate';
      this.searchModel.dateTo = this.daysAgo(1);
       this.searchModel.dateFrom = this.daysAgo(730);
      break;

    case 'RecredentialingNext90Days':
      this.searchModel.dateCriteria = 'RecredentialingDate';
      this.searchModel.dateFrom = today;
      this.searchModel.dateTo = this.daysFromNow(90);
      break;
  }
      this.dateRangeModel = this.buildDateRangeModel(
      this.searchModel.dateFrom,
      this.searchModel.dateTo
    );
}
private formatDate(date: Date): string {
  return date.toISOString().split('T')[0];
}

private today(): string {
  return this.formatDate(new Date());
}

private daysAgo(days: number): string {
  const d = new Date();
  d.setDate(d.getDate() - days);
  return this.formatDate(d);
}

private daysFromNow(days: number): string {
  const d = new Date();
  d.setDate(d.getDate() + days);
  return this.formatDate(d);
}
private toLocalDate(dateStr: string): Date {
  const [year, month, day] = dateStr.split('-').map(Number);
  return new Date(year, month - 1, day); // LOCAL date, no timezone shift
}

 private buildDateRangeModel(from: string | null, to: string | null) {
    if (!from && !to) {
      return null;
    }

  const fromDate = from ? this.toLocalDate(from) : null;
  const toDate = to ? this.toLocalDate(to) : null;
    return {
      beginDate: fromDate
        ? { year: fromDate.getFullYear(), month: fromDate.getMonth() + 1, day: fromDate.getDate() }
        : null,
      endDate: toDate
        ? { year: toDate.getFullYear(), month: toDate.getMonth() + 1, day: toDate.getDate() }
        : null
    };
  }
}

