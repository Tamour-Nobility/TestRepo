import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CredEdiEraAppAddeditComponent } from './cred-edi-era-app-addedit.component';

describe('CredEdiEraAppAddeditComponent', () => {
  let component: CredEdiEraAppAddeditComponent;
  let fixture: ComponentFixture<CredEdiEraAppAddeditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CredEdiEraAppAddeditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CredEdiEraAppAddeditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
