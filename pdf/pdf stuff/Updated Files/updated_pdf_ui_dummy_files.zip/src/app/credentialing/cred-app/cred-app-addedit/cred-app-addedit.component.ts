import { ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { PracticeModel } from '../../../practice-setup/practiceList/Classes/practiceClass';
import { APIService } from '../../../components/services/api.service';
import { CredAppViewModel } from '../../classes/CredAppModel';
import { ModalWindow } from '../../../shared/modal-window/modal-window.component';
import { ToastrService } from 'ngx-toastr';
import { IMyDate, IMyDpOptions } from 'mydatepicker';
import { User } from '../../../user-management/classes/requestResponse';
import { CurrentUserViewModel } from '../../../models/auth/auth';
import { GvarsService } from '../../../services/G_vars/gvars.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ChangeDetectionStrategy } from '@angular/compiler/src/compiler_facade_interface';
import { CredAppNoteModel } from '../../classes/CredAppNoteModel';
import { ModalDirective, ModalOptions } from 'ngx-bootstrap/modal';
import { CredAppAttachmentsComponent } from '../cred-app-attachments/cred-app-attachments.component';
import { FileHandlerService } from '../../../components/services/file-handler/filehandler.service';
declare var $: any;
@Component({
  selector: 'app-cred-app-addedit',
  templateUrl: './cred-app-addedit.component.html',
  styleUrls: ['./cred-app-addedit.component.css']
})
export class CredAppAddeditComponent implements OnInit {
  model: CredAppViewModel;
  practiceList: any = [];
  providerList: any = [];
  tempAttachments: any[] = [];
  PracticeModel: PracticeModel;
  oldNotesCount:number;
  LookupList: any;
  selectedProvider: any;
strComDate: IMyDate;
showToaster:boolean=true;
public placeholdertxt: string = 'MM/DD/YYYY';
  // IDs for logic
  groupAppTypeId: number;
  individualAppTypeId: number;
  ipaContractTypeId: number;
  directContractTypeId: number;
  approvedStatusId: number;
  isIpaNameDisabled:boolean =false;
  currentUser: CurrentUserViewModel;
  strlastFollowUpDate: IMyDate;
 strDatenextFollowUp: IMyDate;
 strDateappliedDate: IMyDate;
  strDateeffectiveDate: IMyDate;
   strDaterecredentialingDate: IMyDate;
    strDateassignedDate: IMyDate;
   isViewMode:boolean=false;
   dataTablenotes: any;
   credNote:CredAppNoteModel;
      modalOptions: { backdrop: string } = { backdrop: 'static' };
  @ViewChild('insuranceSearch') insuranceModal: ModalWindow;
@ViewChild('practiceNotesModel') practiceNotesModel: ModalDirective;
   @ViewChild(CredAppAttachmentsComponent) applicationAttachments;
  gridData=[]
  public myDatePickerOptions: IMyDpOptions = {
          dateFormat: 'mm/dd/yyyy', height: '25px', width: '93%'
      };
 public myDatePickerOptionsNextFollowup: IMyDpOptions = {
          dateFormat: 'mm/dd/yyyy', height: '25px', width: '93%'
      };
        usersList =  [];
        isnotedAdded:boolean=false;
        canAddNote: boolean = true;
isEditMode: boolean = false;
disableNextFollowUp: boolean = false;


  constructor(public API: APIService, private _fileHandlerService: FileHandlerService, private toaster: ToastrService,private GV: GvarsService,private route: ActivatedRoute,private router:Router,private chRef:ChangeDetectorRef) {
    this.model = new CredAppViewModel();
    this.credNote= new CredAppNoteModel;
    this.usersList =[]; 
     this.LookupList = {
      cred_Document_Types: [],
      cred_Application_Types:[],
      cred_Objective_Types:[],
      cred_Contract_Types:[],
      cred_Application_Statuses:[],
    };
   
  }

ngOnInit(): void {
  
  const routePath = this.route.snapshot.routeConfig.path;   // "view/:id"
  const id = Number(this.route.snapshot.paramMap.get('id'));
  this.model.application_Id=id;
  this.LoadPractices();
  if (routePath.startsWith('view')) {
    this.isViewMode = true;
  }
   if(routePath.startsWith('addedit')){
    debugger
    // this.model.application_Id=0;
    this.model.application_Status_Id=301;
   }
  if (id && id > 0) {
    this.GetCredAppById(id);
    this.GetCredNotes();
  }
this.model.assigned_Date = new Date();
this.strDateassignedDate = this.formatDateMMDDYYYY(this.model.assigned_Date);
debugger;
    // this.model.obj_Type_Id=301;

 // this.practiceList = JSON.parse(localStorage.getItem('pr') || '[]');

  this.GetLookupData();
  this.currentUser = this.GV.currentUser;
  // this.loadUsers();
}



  GetLookupData() {
    this.API.getData('/Credentialing/GetLookupLists').subscribe(data => {
      if (data.Status === 'Success') {
        this.LookupList = data.Response;

        // Set IDs for logic use
        this.groupAppTypeId = this.LookupList.cred_Application_Types.find((t: any) => t.App_Type_Desc === 'Group').App_Type_Id;
        this.individualAppTypeId = this.LookupList.cred_Application_Types.find((t: any) => t.App_Type_Desc === 'Individual').App_Type_Id;
        this.ipaContractTypeId = this.LookupList.cred_Contract_Types.find((t: any) => t.Contract_Type_Desc === 'IPA').Contract_Type_Id;
        this.directContractTypeId = this.LookupList.cred_Contract_Types.find((t: any) => t.Contract_Type_Desc === 'Direct').Contract_Type_Id;
        this.approvedStatusId = this.LookupList.cred_Application_Statuses.find((s: any) => s.Status_Desc === 'Approved').Status_Id;
      }
    });
  }
GetCredAppById(id) {
  this.API.getData(`/Credentialing/GetCredAppById/${id}`).subscribe(data => {
    if (data.Status === 'Success') {

      const r = data.Response;

      this.model = {
        application_Id: r.Application_Id,
        practice_Code: r.Practice_Code,
        provider_Id: r.Provider_Id,
        insurance_Id: r.Insurance_Id,
        Payer_Name: r.Payer_Name,
        plan_Name: r.Plan_Name,
        obj_Type_Id: r.Obj_Type_Id,
        contract_Type_Id: r.Contract_Type_Id,
        ipa_Name: r.IPA_Name,
        application_Type_Id: r.Application_Type_Id,
        application_Status_Id: r.Application_Status_Id,
        tracking_Id: r.Tracking_Id,
        applied_Date: r.Applied_Date,
        effective_Date: r.Effective_Date,
        ind_Provider_Id: r.Ind_Provider_Id,
        recredentialing_Date: r.Recredentialing_Date,
        last_Followup_Date: r.Last_Followup_Date,
        next_Followup_Date: r.Next_Followup_Date,
        created_Date: r.Created_Date,
        created_By: r.Created_By,
        assigned_To: r.Assigned_To,
        assigned_By: r.Assigned_By,
        assigned_Date: r.Assigned_Date,
        modified_By: r.Modified_By,
        modified_Date: r.Modified_Date,
        payer_Name:r.Payer_Name
        
      };
      this.Insname_Description=this.model.payer_Name;
      this.strDateappliedDate=this.formatDateMMDDYYYY(this.model.applied_Date);
      this.strDateassignedDate=this.formatDateMMDDYYYY(this.model.assigned_Date);
      this.strDateeffectiveDate=this.formatDateMMDDYYYY(this.model.effective_Date);
      this.strDatenextFollowUp=this.formatDateMMDDYYYY(this.model.next_Followup_Date);
      this.strDaterecredentialingDate=this.formatDateMMDDYYYY(this.model.recredentialing_Date);
      this.strlastFollowUpDate=this.formatDateMMDDYYYY(this.model.last_Followup_Date);
      
      debugger
      this.GetPracticeData(this.model.practice_Code);
  
    }
  });
}
formatDateMMDDYYYY(dateString: any): IMyDate {
  if (!dateString) return null;

  const d = new Date(dateString);  // convert string → Date

  return {
    year: d.getFullYear(),
    month: d.getMonth() + 1,
    day: d.getDate()
  };
}
LoadPractices() {
    this.API.getData(`/Credentialing/GetActivePractices`).subscribe(res => {
      if (res.Status == 'Sucess') {
         this.practiceList=res.Response;

            this.practiceList = this.practiceList.map(practice => {
            return {
                ...practice,  // Keep all existing properties
                PracticeLabel: `${practice.Practice_Code} | ${practice.Prac_Name}`  // Add new combined property
              };
             });
         if(  this.model.application_Id==0){
         this.model.practice_Code=this.GV.currentUser.selectedPractice.PracticeCode;
         this.GetPracticeData(this.model.practice_Code)
         }

      }

    });
  }
loadUsers() {
  debugger
     const role = this.currentUser.role;
     if (['Credentialing', 'Credentialing Lead', 'Credentialing Manager'].includes(role)) {
       this.API.getData(`/Credentialing/GetCredUserListByRole?Role=${role}&practiceId=${this.model.practice_Code}`).subscribe(res => {
         if (res.Status !== 'Success') {
           this.toaster.error(res.Status, 'Failed');
           return;
         }
         this.usersList = res.Response;
         this.usersList.forEach(u => u.displayName = u.LastName + ', ' + u.FirstName);
         if (!this.model.assigned_By) {
           this.model.assigned_By = this.currentUser.userId;
         }
       });
     } else {
       this.usersList = [];
     }
   }
  GetPracticeData(practiceCode: number) {
    if (!practiceCode) return;
    this.API.getData('/PracticeSetup/GetPracticeWithActiveProviders?PracticeId=' + practiceCode).subscribe(data => {
      if (data.Status === 'Sucess') {
        this.PracticeModel = data;

        // Uppercase formatting
        const pm = this.PracticeModel.Response.PracticeModel;
        if (pm.Prac_Name) pm.Prac_Name = pm.Prac_Name.toUpperCase();
      if (pm.Prac_Address) pm.Prac_Address = pm.Prac_Address.toUpperCase();
      if (pm.Mailing_Address) pm.Mailing_Address = pm.Mailing_Address.toUpperCase();
        // Providers list
           const providers = this.PracticeModel.Response.ProvidersList || [];
        this.providerList = providers.filter(x => x.Practice_Code == practiceCode);
        this.providerList = this.providerList.map(p => ({
          ...p,
          ProviderLabel: `${p.Provid_LName}, ${p.Provid_FName}`
        }));
        // Reset provider info if practice changes
        
        this.onProviderChange();
        // Reload users when practice changes
        this.loadUsers();
      }
    });
  }

  onProviderChange() {
    this.selectedProvider = this.providerList.find(p => p.Provider_Code == this.model.provider_Id);
  }

  onContractTypeChange() {
    if (this.model.contract_Type_Id == this.directContractTypeId) {
      this.model.ipa_Name = '';
    }
  }

  onLastFollowUpChange() {
    if (!this.model.last_Followup_Date) return;

    const last = new Date(this.model.last_Followup_Date);
    const next = new Date(last);
    next.setDate(last.getDate() + 14);

    this.model.next_Followup_Date = next;
     this.strDatenextFollowUp = {
    year: next.getFullYear(),
    month: next.getMonth() + 1,
    day: next.getDate()
  };
    this.setNextFollowUpDateRestrictions(last, next);
  }

validateStatusAndDates(): boolean {

  const statusId = this.model.application_Status_Id;
  const statusDesc = this.LookupList.cred_Application_Statuses
    .find(x => x.Status_Id == statusId).Status_Desc;

  if (statusId == 302 || statusDesc == 'Approved') {

    if (this.model.effective_Date==null) {
      this.toaster.error('Effective Date is required when status is Approved.');
      return false;
    }

    if (!this.model.recredentialing_Date) {
      this.toaster.error('Recredentialing Date is required when status is Approved.');
      return false;
    }

    
  }

  if (this.model.last_Followup_Date && this.model.next_Followup_Date) {
    if (new Date(this.model.last_Followup_Date)
        .toDateString() === new Date(this.model.next_Followup_Date).toDateString()) {
      this.toaster.error('Last Follow-up Date and Next Follow-up Date cannot be same');
      this.model.next_Followup_Date = null;
      return false;
    }
  }

  if (this.model.recredentialing_Date && this.model.effective_Date) {

    if (new Date(this.model.recredentialing_Date)
        .toDateString() === new Date(this.model.effective_Date).toDateString()) {
      this.toaster.error('Effective Date and Recredentialing Date cannot be same');
      return false;
    }

    if (new Date(this.model.recredentialing_Date) < new Date(this.model.effective_Date)) {
      this.toaster.error('Recredentialing Date must be after Effective Date.');
      return false;
    }
  }

  const lastFollowUpRequired = [
    'Approved','Pending','In Process','Not Enrolled','Rejected',
    'Development','Status Review Required','Out of Network','Network Closed','On Hold'
  ];

  if (lastFollowUpRequired.includes(statusDesc)) {
    if (!this.model.last_Followup_Date) {
      this.toaster.error('Last Follow-up Date is required for this status.');
      return false;
    }
  }

  const nextFollowUpRequired = [
    'Pending','In Process','On Hold','Development','Status Review Required'
  ];

  if (nextFollowUpRequired.includes(statusDesc)) {
    if (!this.model.next_Followup_Date) {
      this.toaster.error('Next Follow-up Date is required for this status.');
      return false;
    }
  }

  if (statusDesc !== 'Approved') {
    if (!this.model.assigned_To) {
      this.toaster.error('Please fill out the Assigned To field.');
      return false;
    }
  }
   if((String(statusId) === "202" || statusDesc == 'Approved') && this.model.next_Followup_Date != null)
{
     this.toaster.error('Status is Approved, please remove Next Follow-Up Date.'); return;}
  return true;
}


  onSave(): void {

    // Basic mandatory validations
    if (!this.model.practice_Code) { this.toaster.error('Please fill out the Practice field.'); return; }
    if (!this.model.application_Type_Id) { this.toaster.error('Please select Application Type.'); return; }
    if(this.model.application_Type_Id==501){
 if ( !this.model.provider_Id) { this.toaster.error('Please select a Provider.'); return; }
    }
   
    if (!this.model.obj_Type_Id) { this.toaster.error('Please select an Objective.'); return; }
    // if (!this.model.insurance_Id) { this.toaster.error('Please select a Payer.'); return; }
    if (!this.model.Payer_Name) { this.toaster.error('Please Enter Payer Name.'); return; }
    if (!this.model.contract_Type_Id) { this.toaster.error('Please select a Contract Type.'); return; }
    debugger
    if (this.model.contract_Type_Id == this.ipaContractTypeId && !this.model.ipa_Name) { this.toaster.error('Please enter an IPA Name if Contract Type is IPA.'); return; }
  
    if (!this.model.application_Status_Id) { this.toaster.error('Please select an Application Status.'); return; }

    if (!this.validateStatusAndDates()) return;
  if (!this.model.assigned_To&&this.model.application_Status_Id!==302) { this.toaster.error('Please fill out the Assigned To field.'); return; }
  
   if(this.model.application_Id >0 && this.model.application_Status_Id==301||this.model.application_Status_Id==this.LookupList.cred_Application_Statuses.find(s=>s.Status_Desc=='New')){
this.toaster.error('Change status from ‘New’ to continue.'); return;
   }
   debugger
   if( this.isnotedAdded==false){
      this.toaster.error("Please add note before saving the application.", "Error")
      return;
    }
  if(this.model.application_Status_Id)
    this.API.PostData('/Credentialing/AddEditCredApp/', this.model, (d) => {
      if (d.Status === 'Success') {
        this.toaster.success('Application has been generated', 'Success');
         const newAppId = d.Response;
          if (this.tempAttachments.length > 0) {
          this.uploadTempAttachments(newAppId);
        }
        if(this.model.application_Id==0){
          
           debugger
      
        if(this.credNote.Note_Description!=null){
          this.showToaster=false
          this.credNote.Application_Id=newAppId;
          this.credNote.Cred_App_Note_Id=0
          this.PostNote(this.credNote);
        }
        }
        // Update model ID if this was a new application
        if(this.model.application_Id===0) {
          this.model.application_Id = newAppId;
        }
        // Switch to view mode after saving
        this.isViewMode = true;
      } else {
        this.toaster.error('An error occured while generating application', 'Failed');
      }
    });
  }
 
  onCancel(): void {
    window.history.back();
  }

  onEditForm(): void {
     // Switch to edit mode for form fields
     this.isViewMode = false;
     this.canAddNote = true; // Allow adding notes in edit mode
     this.chRef.detectChanges();
   }

  onReset(): void {
    if (!this.model.application_Id) { // Only allow reset on Add
      this.model = new CredAppViewModel();
      this.selectedProvider = null;
       this.Insname_Description=null;
      this.strDateappliedDate=null;
      this.strDateassignedDate=null;
      this.strDateeffectiveDate=null;
      this.strDatenextFollowUp=null;
      this.strDaterecredentialingDate=null;
      this.strlastFollowUpDate=null;
        //this.router.navigate(['credentialing']);
    }
  }

  ShowInsuranceNamePopup() {
    this.insuranceModal.show();
  }
  Insname_Description:string;
  // onSelectInsurance(event: any) {
  //   this.model.insurance_Id = event.insuranceId;
  //   this.Insname_Description = event.insuranceName;
  //   this.model.Payer_Name = event.insuranceName;
  //   this.model.payer_Name = event.insuranceName;
  //   this.insuranceModal.hide();
  // }

  onPayerInput(value: string) {
    debugger
    this.Insname_Description = value;
    // keep both Payer_Name properties in sync to satisfy different checks
    this.model.Payer_Name = value;
    this.model.payer_Name = value;
    // typing a custom payer clears any selected insurance id
    if (!value || value.trim() === '') {
      this.model.insurance_Id = null;
    } else {
      this.model.insurance_Id = null;
    }
  }

  clearPayer() {
    this.Insname_Description = null;
    this.model.insurance_Id = null;
    this.model.Payer_Name = null;
    this.model.payer_Name = null;
  }
  OnChangeContractType(){
    if(this.model.contract_Type_Id == 202 ||this.model.contract_Type_Id== this.LookupList.cred_Contract_Types.find(c=>c.Contract_Type_Desc=='Direct').Contract_Type_Id ){
      this.isIpaNameDisabled=true
     this.model.ipa_Name=null;
     
  }
  else{
 this.isIpaNameDisabled=false;
  }
   
  
  }

 getUsersList() {
    this.API.getData('/UserManagementSetup/GetUsersList').subscribe(
      data => {
        if (data.Status === 'Success') {
         
          this.usersList = data.Response;
    
         
        } else {
          this.toaster.error(data.Status, 'Failed');
        }
      });
  }
   onDateChangedExp(event, type: string) {
      const mapping = {
      lastFollowUp: 'last_Followup_Date',
      nextFollowUp: 'next_Followup_Date',
      appliedDate: 'applied_Date',
      effectiveDate: 'effective_Date',
      recredentialingDate: 'recredentialing_Date',
      assignedDate: 'assigned_Date'
    };
 const target = mapping[type];
    const date = event.formatted;
if (!date) {
    if (target) {
      this.model[target] = null;   
         if (target === 'Last_FollowUp_Date') {
    this.disableNextFollowUp= true;
      this.model.next_Followup_Date = null;
    }
    return;
  }
}

  
   
   
    if (target) this.model[target] = date;
     if(target=="last_Followup_Date"){
       this.onLastFollowUpChange()
    }
  }

  setNextFollowUpDateRestrictions(minDate: Date, maxDate: Date) {

  this.myDatePickerOptionsNextFollowup = {
    ...this.myDatePickerOptionsNextFollowup,
    disableSince: {
      year: maxDate.getFullYear(),
      month: maxDate.getMonth() + 1,
      day: maxDate.getDate() + 1
    },
    disableUntil: {
      year: minDate.getFullYear(),
      month: minDate.getMonth() + 1,
      day: minDate.getDate() - 1
    }
  };
      if (this.model.application_Status_Id == 302) {
    this.model.next_Followup_Date = null;
           this.strDatenextFollowUp=null;

    // do something
  }
}

   onInputCleared(event: any, fieldName: string) {

 debugger
  if (event.value === "") {

    if (fieldName === 'lastFollowUp') {
      this.model.last_Followup_Date = null;
      this.model.next_Followup_Date = null; 
      this.strDatenextFollowUp=null
    }
    
  }
}

showNotesModel(mode: string) {

  if (mode === 'Add') {
    this.isEditMode = false;
    this.credNote = new CredAppNoteModel();

    if (this.model.application_Id > 0) {
      // EXISTING APP -> unlimited notes
      this.canAddNote = true;
    } else {
      // NEW APP -> only allow if no note exists
      this.canAddNote = this.gridData.length === 0;
    }
  }

  if (mode === 'Edit') {
    this.isEditMode = true;
    //this.canAddNote = true; 
  }

  this.practiceNotesModel.show();
}

OnAddEditNotes() {

  if (!this.credNote.Note_Description) {
    this.toaster.error("Note is Required!", "Error");
    return;
  }
  debugger
 this.credNote.Created_By_UserName=this.GV.currentUser.unique_name
 this.credNote.Created_By=this.GV.currentUser.userId
 this.credNote. Created_Date= new Date().toString(); 
  if (this.model.application_Id > 0) {
    this.credNote.Application_Id = this.model.application_Id;
    this.credNote.Is_Auto_Note = false;
    this.PostNote(this.credNote);
    return;
  }



  if (this.isEditMode) {

    const index = this.gridData.findIndex(x => x.Cred_App_Note_Id === this.credNote.Cred_App_Note_Id);
    if (index >= 0) {
      this.gridData[index] = { ...this.credNote };
    }
  } else {

    if (this.gridData.length >= 1) {
      this.toaster.error("Only one note is allowed before saving the application!", "Error");
      return;
    }

   
    this.credNote.Cred_App_Note_Id = Date.now(); 
    this.gridData.push({ ...this.credNote });
    
  }

  this.canAddNote = false;

  this.practiceNotesModel.hide();
  //this.credNote = new CredAppNoteModel();
   this.isnotedAdded=true
}


PostNote(note:any){
   this.API.PostData('/Credentialing/AddEditCredAppNote/', note, (d) => {
      if (d.Status == 'Success') {
        debugger
       if (typeof note.Cred_App_Note_Id !== 'number' ) {
  this.canAddNote = false;
}
        
        if(this.showToaster){
this.toaster.success('Note has been added', 'Success');
        }
        this.showToaster=true;
        this.isnotedAdded=true;
        this.GetCredNotes();
   this.practiceNotesModel.hide()
   this.credNote.Note_Description=null;
      } else {
        this.toaster.error('An error occured while adding note', 'Failed');
      }
    });
}
GetCredNotes() {
  if(this.model.application_Id>0){
  this.API.getData(`/Credentialing/GetCredAppNotes?application_Id=${this.model.application_Id}`).subscribe(res => {
      if (res.Status !== 'Success') {
        this.toaster.error(res.Status, 'Failed');
        return;
      }
 
        if (this.dataTablenotes) {
                        this.chRef.detectChanges();
                        this.dataTablenotes.destroy();
                    }
                    this.gridData=res.Response;
                    this.oldNotesCount=this.gridData.length;
                    this.chRef.detectChanges();
                    const table: any = $('.dataTablenotes');
    this.dataTablenotes = table.DataTable({
      columnDefs: [
        { orderable: false, targets: -1 },  // Actions column
        { width: '45%', targets: 0 },       // Note Description
        { width: '20%', targets: 1 },       // UserName
        { width: '20%', targets: 2 },       // Created On
        { width: '15%', targets: 3 }        // Actions
      ],
      language: {
        emptyTable: "No data available"
      },
      autoWidth: false,    // important to respect our widths
      scrollX: false       // set true only if you want horizontal scroll
    });
    });
  }
  
  }
  onEdit(id:any){
    debugger
    this.credNote=this.gridData.find(g =>g.Cred_App_Note_Id ==id);
    this.showNotesModel("Edit");
  }
      onEditCredApp(id: number): void {
         this.isViewMode = false;
         this.canAddNote = true; // Allow adding notes in edit mode
         this.isnotedAdded=false;
        this.router.navigate(['credentialing/addedit', id]);
        this.GetCredNotes();

  }

   checkAccess(property:string):boolean{
    
  var res= this.GV.currentUser.RolesAndRights.some(
    r => r.ModuleName.toLowerCase().trim() === 'CredentialingApp'.toLowerCase().trim()&&
     r.SubModuleName.toLowerCase().trim()=="GenerateAppliaction".toLowerCase().trim() &&
     r.PropertyName.toLowerCase().trim()==property.toLowerCase().trim()
  );

  return res;
   }
     SubModuleAllowed(submodule:string):boolean{
    var res= this.GV.currentUser.RolesAndRights.some(
    r => r.ModuleName.toLowerCase().trim() === 'CredentialingApp'.toLowerCase().trim()&&
     r.SubModuleName.toLowerCase().trim()==submodule.toLowerCase().trim() 
  );

  return res;
  }
   isEditDisabled(createdDate: string,createdby:number): boolean {
    
    if(Number(this.GV.currentUser.userId)==createdby){
const created = new Date(createdDate);
  const now = new Date();

  const diffMs = now.getTime() - created.getTime();     
  const diffHours = diffMs / (1000 * 60 * 60);          

  return diffHours > 24;  
    }
    else
    {
      return true;
    }
  
}

handleAttachmentFromChild(event: any[]) {
  this.tempAttachments = [...this.tempAttachments, ...event]; 

}

uploadTempAttachments(appId: number) {
debugger    
  this.tempAttachments.forEach(att => {

    const formData = new FormData();
    formData.append("ApplicationId", appId.toString());
    formData.append("DocTypeId", att.docType);
    formData.append( att.file.name, att.file);

    this._fileHandlerService.UploadFile(formData, '/Credentialing/UploadCredAppDocument')
      .subscribe(res => {
        debugger
      
      });
  });

  // After uploading, clear memory
  this.tempAttachments = [];
}
onAssignedToChange(val: any) {
  debugger
  if (val) {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    this.model.assigned_Date = today;

    this.strDateassignedDate = this.formatDateMMDDYYYY(today);
  }
}
isLastFollowUpRequired(): boolean {
   if(this.LookupList.cred_Application_Statuses.length!=0){
 const statusId = this.model.application_Status_Id;
  const statusDesc = this.LookupList.cred_Application_Statuses
    .find(x => x.Status_Id == statusId).Status_Desc;

  const lastFollowUpRequired = [
    'Approved','Pending','In Process','Not Enrolled','Rejected',
    'Development','Status Review Required','Out of Network','Network Closed','On Hold'
  ];

  return lastFollowUpRequired.includes(statusDesc);
  }
 
}

isNextFollowUpRequired(): boolean {
   if(this.LookupList.cred_Application_Statuses.length!=0){
  const statusId = this.model.application_Status_Id;
  const statusDesc = this.LookupList.cred_Application_Statuses
    .find(x => x.Status_Id == statusId).Status_Desc;

  const nextFollowUpRequired = [
    'Pending','In Process','On Hold','Development','Status Review Required'
  ];

  return nextFollowUpRequired.includes(statusDesc);
}

}
handleDeleteAttachment(event: any[]) {
  debugger
  const deletedId = Number(event[0].id); // or String(...)

  this.tempAttachments = this.tempAttachments.filter(
    t => Number(t.id) !== deletedId
  );


}
onStatusChange(statusId: string | null): void {
debugger
  if (statusId === null) {
    // when "Select Status" is chosen
    this.model.application_Id = null;
    return;
  }

  // find selected status object (optional)
  const selectedStatus = this.LookupList.cred_Application_Statuses.find(s => s.Status_Id === statusId);

  // Example conditional logic
  debugger;
  if (statusId === "302") {
    this.model.next_Followup_Date = null;
           this.strDatenextFollowUp=null;

    // do something
  }
}
//#endregion

}
