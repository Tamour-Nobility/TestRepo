import { ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { APIService } from '../../../components/services/api.service';
import { ToastrService } from 'ngx-toastr';
import { ModalWindow } from '../../../shared/modal-window/modal-window.component';
import { IMyDpOptions } from 'mydatepicker';
import { IMyDate, IMyDateRangeModel } from 'mydaterangepicker';
import * as moment from 'moment';
import { Common } from '../../../services/common/common';
import { User } from '../../../user-management/classes/requestResponse';
import * as XLSX from 'xlsx';
import { GvarsService } from '../../../../app/services/G_vars/gvars.service';

@Component({
  selector: 'app-cred-app-list',
  templateUrl: './cred-app-list.component.html',
  styleUrls: ['./cred-app-list.component.css']
})
export class CredAppListComponent implements OnInit {

searchStarted = false;
  // Static lookup arrays
  practiceList = [];
  LookupList: any;


  providerList = [];

  
  objectiveTypes = ["New Enrollment", "Demographic Update", "Other"];

  dateCriteriaList = [
      { value: 'AppCreatedDate', description: 'App Created Date' },
      { value: 'LastFollowUpDate', description: 'Last Follow Up Date' },
      { value: 'NextFollowUpDate', description: 'Next Follow Up Date' },
      { value: 'AppliedDate', description: 'Applied Date' },
      { value: 'EffectiveDate', description: 'Effective Date' },
      { value: 'RecredentialingDate', description: 'Recredentialing Date' },
      { value: 'AssignedDate', description: 'Assigned Date' },
   
  ];
 strComDate: IMyDate;
  usersList =  [];
dataTablePatients: any;
  // Search model
  searchModel: any = {
    practice_Code: null,
    provider_Id: null,
    // insurance_Id: null,
    Payer_Name:null,
    contract_Type_Id: null,
    obj_Type_Id: null,
    application_Status_Id:null,
    tracking_Id:null,
    created_by:null,
    dateFrom: null,
    dateTo: null,
    dateCriteria:null,
    assigned_To:null,    
  };
  gridData: any[] = [];
  dateRange: any = null;
myDateRangePickerOptions: IMyDpOptions = {
        dateFormat: 'mm/dd/yyyy', height: '25px', width: '100%'
    };
      dateRangeModel: any = null;
 constructor(private router: Router,public API: APIService, private toaster: ToastrService,private chRef:ChangeDetectorRef,private gvService:GvarsService,private route:ActivatedRoute) {
  this.usersList=[];
  }

  ngOnInit(): void { 
 
    //this.practiceList = JSON.parse(localStorage.getItem('pr') || '[]');
    this.LoadPractices()
    this.GetLookupData();
    this.loadUsers('CredentialingApp');
           this.route.queryParams.subscribe(params => {
    this.searchModel.practice_Code = Number(params['practice_Code']);
    this.searchModel.assigned_To = Number( params['UserId']);
    this.searchModel.obj_Type_Id = Number(params['Obj_Type_ID']);
    var column=params['column'];
    this.applyColumnFilters(column)
    this.search();
  });

  }
  GetLookupData() {
    this.API.getData('/Credentialing/GetLookupLists').subscribe(data => {
      if (data.Status === 'Success') {
        this.LookupList = data.Response;

      }
    });
  }
  GetPracticeData(practiceCode: number) {
    debugger
    if (!practiceCode ||practiceCode==null) return;
    this.API.getData('/PracticeSetup/GetPracticeWithActiveProviders?PracticeId=' + practiceCode).subscribe(data => {
      if (data.Status === 'Sucess') {
 
      
         const providers =  data.Response.ProvidersList || [];
        this.providerList = providers.filter(x => x.Practice_Code == practiceCode);
        this.providerList = this.providerList.map(p => ({
          ...p,
          ProviderLabel: `${p.Provid_LName}, ${p.Provid_FName}`
        }));

      }
    });
  }
  // Direct input field for payer - no modal needed
  search() {
    debugger
 
    // For now generate mock grid data
  const { dateCriteria, dateFrom, dateTo } = this.searchModel;

  // Null-safe values
  const hasCriteria = !!dateCriteria;
  const hasFrom = !!dateFrom;
  const hasTo = !!dateTo;

 

 
  if (hasCriteria && (!hasFrom || !hasTo)) {
    this.toaster.error("Both Date Criteria and From - To Dates are required.", "Error");
    return;
  }

 
  if (!hasCriteria && (hasFrom || hasTo)) {
    this.toaster.error("Both Date Criteria and From - To Dates are required.", "Error");
    return;
  }

  
  if (hasFrom && hasTo && new Date(dateFrom) > new Date(dateTo)) {
    this.toaster.error("Date From must be less than or equal to Date To.", "Invalid Date Range");
    return;
  }
      this.API.PostData('/Credentialing/SearchCredApp/', this.searchModel, (d) => {
      if (d.Status === 'Success') {
           this.searchStarted=true
        if (this.dataTablePatients) {
                        this.chRef.detectChanges();
                        this.dataTablePatients.destroy();
                    }
                    this.gridData=d.Response;
                    this.chRef.detectChanges();
                    const table: any = $('.dataTablePatients');
                  this.dataTablePatients = table.DataTable({
    scrollX: true,
    autoWidth: false,  
    destroy: true,

    columnDefs: 
      { orderable: false, targets: -1 }
    ,

    language: {
      emptyTable: 'No application found'
    }
  });

 
  this.dataTablePatients.columns.adjust();

      } else {
        this.toaster.error('An error occured while loading data', 'Failed');
      }
    });
  }

  clear() {
    this.searchModel = {
    practice_Code: null,
    provider_Id: null,
    Payer_Name: null,
    contract_Type_Id: null,
    obj_Type_Id: null,
    application_Status_Id:null,
    tracking_Id:null,
    created_by:null,
    dateFrom: null,
    dateTo: null,
    dateCriteria:null,
    assigned_To:null,    
  };
      this.dateRange = null;
    this.providerList = [];
    this.gridData = [];
    this.searchStarted=false;
    if(this.dataTablePatients){
this.dataTablePatients.destroy();
       this.chRef.detectChanges();
    }
       
 
  }

  onAdd(): void {
    this.router.navigate(['credentialing/addedit']);
  }

  onEdit(id: number): void {
    this.router.navigate(['credentialing/addedit', id]);
  }

LoadPractices() {
  
    this.API.getData(`/Credentialing/GetActivePractices`).subscribe(res => {
      if (res.Status == 'Sucess') {
        debugger
         this.practiceList=res.Response;
            this.practiceList = this.practiceList.map(practice => {
            return {
                ...practice,  // Keep all existing properties
                PracticeLabel: `${practice.Practice_Code} | ${practice.Prac_Name}`  // Add new combined property
              };
             });
//this.searchModel.practice_Code=this.gvService.currentUser.selectedPractice.PracticeCode;


      }

    });
  }
  onView(row: any) {
    this.router.navigate(['credentialing/view',row.Application_Id]);
  }
  onDateRangeChanged(event: IMyDateRangeModel) {
          this.searchModel.dateFrom = Common.isNullOrEmpty(event.beginJsDate) ? null : moment(event.beginJsDate).format('MM/DD/YYYY');
          this.searchModel.dateTo = Common.isNullOrEmpty(event.endJsDate) ? null : moment(event.endJsDate).format('MM/DD/YYYY');
          this.dateRange = event;
        }
loadUsers(moduleName:string) {
    this.API.getData(`/Credentialing/GetUsersByModuleName?moduleName=${moduleName}`).subscribe(res => {
      if (res.Status !== 'Success') {
        this.toaster.error(res.Status, 'Failed');
        return;
      }
  this.usersList=res.Response;
    this.usersList.forEach(u => u.displayName = u.LastName + ', ' + u.FirstName);     
    });
  }
     checkAccess(property:string):boolean{
  var res= this.gvService.currentUser.RolesAndRights.some(
    r => r.ModuleName.toLowerCase().trim() === 'CredentialingApp'.toLowerCase().trim()&&
     r.SubModuleName.toLowerCase().trim()=="CredentialingStatus".toLowerCase().trim() &&
     r.PropertyName.toLowerCase().trim()==property.toLowerCase().trim()
  );
  return res;
   }
   clearDateCriteria() {
  this.searchModel.dateCriteria = null;
}
     SubModuleAllowed(submodule:string):boolean{
    var res= this.gvService.currentUser.RolesAndRights.some(
    r => r.ModuleName.toLowerCase().trim() === 'CredentialingApp'.toLowerCase().trim()&&
     r.SubModuleName.toLowerCase().trim()==submodule.toLowerCase().trim() 
  );
  return res;
}

clearPayer() {
  this.searchModel.Payer_Name = null;
}

/**
 * Export grid data to Excel - matches grid display exactly
 */
exportToExcel() {
  if (!this.gridData || this.gridData.length === 0) {
    this.toaster.warning('No data to export', 'Export Failed');
    return;
  }

  try {
    // Map grid data to match display columns exactly
    const exportData = this.gridData.map(r => ({
      'Practice Code': r.Practice_Code,
      'Application Number': r.Application_Id,
      'Provider Name': r.Provider_Name,
      'Payer Name': r.Payer_Name,
      'Plan Name': r.Plan_Name,
      'Objective Type': r.Objective_Type,
      'Application Type': r.Application_Type,
      'Application Status': r.Application_Status,
      'IPA / Direct': r.Contract_Type,
      'IPA Name': r.IPA_Name,
      'Last Note': r.Last_Note,
      'Last Follow Up Date': r.Last_Followup_Date ? new Date(r.Last_Followup_Date).toLocaleDateString() : '',
      'Next Follow Up Date': r.Next_Followup_Date ? new Date(r.Next_Followup_Date).toLocaleDateString() : '',
      'Tracking ID': r.Tracking_Id,
      'Applied Date': r.Applied_Date ? new Date(r.Applied_Date).toLocaleDateString() : '',
      'Effective Date': r.Effective_Date ? new Date(r.Effective_Date).toLocaleDateString() : '',
      'Ind Prov ID': r.Ind_Provider_Id,
      'Recredentialing Date': r.Recredentialing_Date ? new Date(r.Recredentialing_Date).toLocaleDateString() : '',
      'Created By': r.Created_By_Name,
      'Created Date': r.Created_Date ? new Date(r.Created_Date).toLocaleDateString() : '',
      'Assigned To': r.Assigned_To_Name,
      'Assigned Date': r.Assigned_Date ? new Date(r.Assigned_Date).toLocaleDateString() : '',
      'Assigned By': r.Assigned_By_Name
    }));

    // Create worksheet from mapped data
    const worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(exportData);
    
    // Auto-fit column widths
    const wscols = [
      { wch: 12 }, { wch: 18 }, { wch: 18 }, { wch: 18 }, { wch: 15 },
      { wch: 15 }, { wch: 15 }, { wch: 15 }, { wch: 12 }, { wch: 15 },
      { wch: 20 }, { wch: 15 }, { wch: 15 }, { wch: 15 }, { wch: 15 },
      { wch: 15 }, { wch: 15 }, { wch: 18 }, { wch: 15 }, { wch: 15 },
      { wch: 15 }, { wch: 15 }, { wch: 15 }
    ];
    worksheet['!cols'] = wscols;
    
    // Create workbook and add worksheet
    const workbook: XLSX.WorkBook = {
      Sheets: { 'Credentialing Applications': worksheet },
      SheetNames: ['Credentialing Applications']
    };
    
    // Generate Excel file
    const fileName = `Credentialing_Applications.xlsx`;
    XLSX.writeFile(workbook, fileName);
    
    this.toaster.success('Data exported successfully', 'Export Complete');
  } catch (error) {
    console.error('Error exporting to Excel:', error);
    this.toaster.error('Error exporting data to Excel', 'Export Failed');
  }
}



private applyColumnFilters(column: string) {

  this.searchModel.dateFrom = null;
  this.searchModel.dateTo = null;
  this.searchModel.application_Status_Id = null;
  this.searchModel.dateCriteria = null;

  const today = this.today();

  switch (column) {
    case 'CompletedLast30Days':
      this.searchModel.application_Status_Id = 302;
      this.searchModel.dateCriteria = 'AppCreatedDate';
      this.searchModel.dateFrom = this.daysAgo(30);
      this.searchModel.dateTo = today;
      break;

    case 'AssignedToday':
      this.searchModel.dateCriteria = 'AssignedDate';
      this.searchModel.dateFrom = today;
      this.searchModel.dateTo = today;
      break;


    case 'NextFollowUpOverdue':
      this.searchModel.dateCriteria = 'NextFollowUpDate';
      this.searchModel.dateTo = this.daysAgo(1);
      this.searchModel.dateFrom = this.daysAgo(730);
      break;

    case 'NextFollowupToday':
      this.searchModel.dateCriteria = 'NextFollowUpDate';
      this.searchModel.dateFrom = today;
      this.searchModel.dateTo = today;
      break;

    case 'NextFollowUpNext7Days':
      this.searchModel.dateCriteria = 'NextFollowUpDate';
      this.searchModel.dateFrom = today;
      this.searchModel.dateTo = this.daysFromNow(7);
      break;

    case 'RecredentialingToday':
      this.searchModel.dateCriteria = 'RecredentialingDate';
      this.searchModel.dateFrom = today;
      this.searchModel.dateTo = today;
      break;

    case 'RecredentialingOverdue':
      this.searchModel.dateCriteria = 'RecredentialingDate';
      this.searchModel.dateTo = this.daysAgo(1);
         this.searchModel.dateFrom = this.daysAgo(730);
      break;

    case 'RecredentialingNext90Days':
      this.searchModel.dateCriteria = 'RecredentialingDate';
      this.searchModel.dateFrom = today;
      this.searchModel.dateTo = this.daysFromNow(90);
      break;
  }
      this.dateRangeModel = this.buildDateRangeModel(
      this.searchModel.dateFrom,
      this.searchModel.dateTo
    );
}
private formatDate(date: Date): string {
  return date.toISOString().split('T')[0];
}

private today(): string {
  return this.formatDate(new Date());
}

private daysAgo(days: number): string {
  const d = new Date();
  d.setDate(d.getDate() - days);
  return this.formatDate(d);
}

private daysFromNow(days: number): string {
  const d = new Date();
  d.setDate(d.getDate() + days);
  return this.formatDate(d);
}
private toLocalDate(dateStr: string): Date {
  const [year, month, day] = dateStr.split('-').map(Number);
  return new Date(year, month - 1, day); // LOCAL date, no timezone shift
}

 private buildDateRangeModel(from: string | null, to: string | null) {
    if (!from && !to) {
      return null;
    }

  const fromDate = from ? this.toLocalDate(from) : null;
  const toDate = to ? this.toLocalDate(to) : null;
    return {
      beginDate: fromDate
        ? { year: fromDate.getFullYear(), month: fromDate.getMonth() + 1, day: fromDate.getDate() }
        : null,
      endDate: toDate
        ? { year: toDate.getFullYear(), month: toDate.getMonth() + 1, day: toDate.getDate() }
        : null
    };
  }
}
