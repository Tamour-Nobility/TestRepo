import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CredAppAttachmentsComponent } from './cred-app-attachments.component';

describe('CredAppAttachmentsComponent', () => {
  let component: CredAppAttachmentsComponent;
  let fixture: ComponentFixture<CredAppAttachmentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CredAppAttachmentsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CredAppAttachmentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
