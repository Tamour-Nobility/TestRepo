import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CredAppAddeditComponent } from './cred-app-addedit.component';

describe('CredAppAddeditComponent', () => {
  let component: CredAppAddeditComponent;
  let fixture: ComponentFixture<CredAppAddeditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CredAppAddeditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CredAppAddeditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
