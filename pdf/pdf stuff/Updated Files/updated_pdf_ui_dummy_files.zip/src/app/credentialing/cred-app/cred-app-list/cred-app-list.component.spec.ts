import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CredAppListComponent } from './cred-app-list.component';

describe('CredAppListComponent', () => {
  let component: CredAppListComponent;
  let fixture: ComponentFixture<CredAppListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CredAppListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CredAppListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
