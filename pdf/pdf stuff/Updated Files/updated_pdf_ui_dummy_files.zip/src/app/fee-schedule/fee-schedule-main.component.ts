import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fee-schedule-main',
  templateUrl: './fee-schedule-main.component.html'
})
export class FeeScheduleMainComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
