import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'charges-report',
    templateUrl: './charges.component.html'
})
export class ChargesComponent implements OnInit {

    constructor() {
    }

    ngOnInit() {

    }
}
