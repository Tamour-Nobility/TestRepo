import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'dynamic-reports',
    templateUrl: './dynamic-reports.component.html'
})
export class DynamicReportsComponent implements OnInit {

    constructor() {

    }

    ngOnInit() {

    }
}
