import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'payment-report',
    templateUrl: './payments.component.html'
})
export class PaymentsComponent implements OnInit {

    constructor() {

    }

    ngOnInit() {

    }
}
