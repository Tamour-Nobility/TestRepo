export class PhysicianSearchModel {
    Referral_Code: number = 0;
    
  Referral_Fname: string = '';

  Referral_Lname: string = '';

  NPI: string = '';

  Referral_Zip: string = '';

  Referral_City: string = null;

  Referral_State: string = '';

}

 