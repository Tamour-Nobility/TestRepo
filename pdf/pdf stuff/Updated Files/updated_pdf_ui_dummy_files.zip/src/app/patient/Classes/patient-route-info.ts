export interface PatientRouteInfo {
    Patient_Account: string;
    PatientFullNamee:string;
    PatientFirstName: string;
    PatientLastName: string;
    claimNo: number;
    disableForm: boolean;
    Is_Active : boolean;
    A_ID: number;
}