

export class PatientSummaryVM {
      PatientAccount: number;
      LastName: string;
      FirstName: string;
      MI: string;
      DOB: Date;
      Gender: number;
      Address: string;
      City: string;
      ZIP: string;
      State: string;
}