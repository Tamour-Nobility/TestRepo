export class ImageClasses {
    Status :string;
    response=new Response;
}
class Response {
    PatientAccount:number;
    PatientPictureBytes:any;
}