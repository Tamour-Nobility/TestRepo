import { ChangeDetectorRef, Component, EventEmitter, OnInit, Output } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { APIService } from '../../components/services/api.service';
import { GvarsService } from '../../services/G_vars/gvars.service';
import { claimPayments, EnteredFrom } from '../../Claims/Classes/claimPayments';
import { ClaimService } from '../../services/claim/claim.service';
import { Router } from '@angular/router';
import { Common } from '../../services/common/common';

@Component({
  selector: 'app-unapplied-payments-posting',
  templateUrl: './unapplied-payments-posting.component.html',
  styleUrls: ['./unapplied-payments-posting.component.css']
})
export class UnappliedPaymentsPostingComponent implements OnInit {

  batchDetails: any;
  claimDetails: any;
  enteredFromListPatient: EnteredFrom[];
  filteredEnteredFromListPatient: any[] = [];
  claimPaymentModel: claimPayments[];
  selectedBatch: any;
  selectedClaims: any[] = [];
  @Output() onclosemodal = new EventEmitter<void>();
  constructor(
    private claimService: ClaimService,
    private cdr: ChangeDetectorRef,
    public router: Router, private GV: GvarsService, private toaster: ToastrService,
    private API: APIService,) {
    this.enteredFromListPatient = [
      { EfId: 40, EfName: "PATIENT PAID IN OFFICE" },
      { EfId: 43, EfName: "PATIENT PAID AT THE TIME OF VISIT" },
      { EfId: 44, EfName: "PATIENT PAID AFTER GETTING STATEMENT" },
      { EfId: 60, EfName: "CareVoyant" }
    ];
  }

  ngOnInit() {
    var patient_account = this.GV.Patient_Account
    if (patient_account) {

      this.getBatchDetails(patient_account);
      this.getClaimDetails(patient_account)
    }

    this.carevoyantstatusfordivision();

  }
  getBatchDetails(patientAccount: number) {
    this.API.getData(`/Demographic/GetBatchDetailsByPatient?Patient_Account=${patientAccount}`).subscribe(
      response => {
        if (response.Status === "Success") {
          this.batchDetails = response.Response
        } else {
          this.toaster.error(response.Response, "Error");
        }
      },
      error => {
        this.toaster.error("Error while fetching batch data.", "Error");
      }
    );
  }
  getClaimDetails(patientAccount: number) {
    this.API.getData(`/Demographic/GetClaimsDetailsByPatient?Patient_Account=${patientAccount}`).subscribe(
      response => {
        if (response.Status === "Success") {
          // Add new properties to each claim
          this.claimDetails = response.Response.map((claim: any) => ({
            ...claim,
            enteredfrom: "",
            chargedproc: "",
            paytype: "",
            amount: null
          }));

        } else {
          this.toaster.error(response.Response, "Error");
        }
      },
      error => {
        this.toaster.error("Error while fetching claim data.", "Error");
      }
    );
  }

  carevoyantstatusfordivision() {
    const roleList = this.GV.currentUser.selectedPractice;
    if (roleList.PracticeCode != null) {
      if (roleList.Division == 2) {
        this.filteredEnteredFromListPatient = this.enteredFromListPatient;
      }
      else {
        this.filteredEnteredFromListPatient = this.enteredFromListPatient.filter(item => item.EfId !== 60);
      }
    }
  }
  trackByClaimNumber(index: number, claim: any): any {
    return claim.ClaimNumber;
  }

  selectBatch(batch: any, event: Event): void {
    var updateclaims = this.claimDetails
    this.claimDetails = []
    const checkbox = event.target as HTMLInputElement;
    if (checkbox.checked) {
      this.selectedBatch = batch;
    } else {
      // Unselect if already selected and checkbox is unchecked
      if (this.selectedBatch.BatchID === batch.BatchID) {
        this.selectedBatch = null;
      }
    }
    updateclaims.forEach(selected => {
      selected.enteredfrom = "";
      selected.chargedproc = "";
      selected.paytype = "";
      selected.amount = null;
    });

    this.selectedClaims = [];
    // Force table refresh by changing the reference
    this.claimDetails = updateclaims;
    this.cdr.detectChanges();
  }
  isBatchSelected(batch: any): boolean {
    if (this.selectedBatch) {
      return this.selectedBatch.BatchID === batch.BatchID && this.selectedBatch.Check_No == batch.Check_No;
    }
    else {
      return false;
    }
  }
  toggleClaimSelection(claim: any, event: Event): void {
    const checkbox = event.target as HTMLInputElement;
    if (checkbox.checked) {
      this.selectedClaims.push(claim);
    } else {
      this.selectedClaims = this.selectedClaims.filter(c => c.ClaimNumber !== claim.ClaimNumber);
    }
  }
  toggleAllClaims(event: any): void {
    if (event.target.checked) {
      this.selectedClaims = [...this.claimDetails];
    } else {
      this.selectedClaims = [];
    }
  }

isAllSelected(): boolean {
  return this.claimDetails.length > 0 && this.selectedClaims.length === this.claimDetails.length;
}
isClaimSelected(claim: any): boolean {
  if(this.selectedClaims){
  return this.selectedClaims.some(c => c.ClaimNumber === claim.ClaimNumber);
   }
   else{
    return false;
   }
}
assignFullPayAmount(claim: any) {
  debugger
 if(this.selectedBatch){
 claim.amount = this.selectedBatch.Amount;
 }
}
PostPayment() {
  debugger
  const batch = this.selectedBatch;
  const claims = this.selectedClaims;
  const IsEnterFromNull = claims.some(c => c.enteredfrom == null||c.enteredfrom == "");
  // const IsChagreProcNull = claims.some(c => c.chargedproc == null||c.chargedproc == "");
  const IsPayTypeNull = claims.some(c => c.paytype == null||c.paytype=="");
  debugger
  // const IsAmountNull = claims.some(c => c.amount == null);
const IsAmountNull = claims.some(c => c.amount == null || c.amount === '' || isNaN(Number(c.amount)));
  const totalAmount = claims.reduce((sum, c) => {
    return sum + (c.amount != null ? Number(c.amount) : 0);
  }, 0);
  if (!batch) {
    this.toaster.error("No batch selected! Kindly select at least one batch.", "Error");
    return;
  }
  if (claims.length == 0) {
    this.toaster.error("No claim selected! Kindly select at least one claim.", "Error");
    return;
  }
  if (IsEnterFromNull) {
    this.toaster.error("Please select Entered From", "Error");
    return;
  }
  // if (IsChagreProcNull) {
  //   this.toaster.error("Please select charge procedure for each selected claim", "Error");
  //   return;
  // }
  if (IsPayTypeNull) {
    this.toaster.error("Please select payment option for each selected claim", "Error");
    return;
  }
  if (IsAmountNull) {
    debugger
    this.toaster.error("Please enter partial payment for each selected claim", "Error");
    return;
  }
  

    const isZeroPartialPay = claims.some(c =>
      c.paytype === "Partial Pay" && Number(c.amount) === 0
    );
    if (isZeroPartialPay) {
      this.toaster.error("Partial payment amount must be greater than zero.", "Error");
      return;
    }

  // NEW VALIDATION: Check if any claim amount is greater than its amount_due
  const isAnyAmountGreaterThanDue = claims.some(c => c.amount != null && c.Amount_due != null && Number(c.amount) > Number(c.Amount_due));
  if (isAnyAmountGreaterThanDue) {
    this.toaster.error("One or more claim amounts exceed the claim's amount due. Please enter a valid amount.", "Error");
    return;
  }
  // Existing validation: Individual claim amount vs batch amount
  const isAnyAmountGreaterThanBatch = claims.some(c => c.amount != null && c.amount > batch.Amount);
  if (isAnyAmountGreaterThanBatch) {
    this.toaster.error("Entered Partial Pay amount cannot be greater than total batch unapplied amount.", "Error");
    return;
  }
  // Existing validation: Total claim amount vs batch amount
  if (totalAmount > batch.Amount) {
    this.toaster.error("Total of all claim amounts exceeds the batch unapplied amount. Please adjust the amounts.", "Error");
    return;
  }
  debugger;
  const payment = this.generatePaymentsFromClaims(claims, batch);
  console.log("Payments", payment);
    debugger;

  if (payment.length > 0) {
    swal({
       title: 'Confirmation',
            text: "Are you sure you want to post Unapplied Payment?",
            type: 'info',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes',
             cancelButtonText: 'No'    
    }).then((willPost) => {
      if (willPost) {
        debugger;
        this.API.PostData('/Demographic/InsertOrUpdateClaimPayments', payment, (res) => {
          if (res.Status === 'Success') {
            this.toaster.success('Claim payments posted successfully.', 'Success');
            this.MoveToClaimSummary();
          } else {
            this.toaster.error(res.Status || 'Failed to post payments.', 'Error');
          }
        });
      }
    });
  }
}
generatePaymentsFromClaims(claims: any[], batch: any): claimPayments[] {
  const payments: claimPayments[] = [];
    debugger;
  for (const claim of claims) {
    const charge = claim.Charges.find(c => c.Procedure_Code === claim.chargedproc);
    let paytype=''
      if(batch.PaymentType=='C'||batch.PaymentType=='K'||batch.PaymentType=='R'||batch.PaymentType=='O'){
         paytype=batch.PaymentType
      }
      else {
        paytype = 'O'
      }
    const payment: claimPayments = {
      isNew: true,
      claim_payments_id: 0,
      Claim_No: claim.ClaimNumber,
      Payment_No: 0,
      Payment_Type: paytype,
      Payment_Source: 'P',
      Date_Entry: batch.Created_Date,
      Date_Adj_Payment: '',
      Date_Filing: batch.CheckDate,
      Amount_Approved: 0,
      Amount_Paid: claim.amount ,
      Amount_Adjusted: 0,
      Adj_Write_Off_Type: '',
      Details: '',
      Reject_Type: '',
      Reject_Amount: 0,
      Paid_Proc_Code: claim.chargedproc,
      Charged_Proc_Code: claim.chargedproc,
      Units: charge ? charge.Units.toString() : null,
      Insurance_Id: 0,
      Check_No: batch.Check_No ,
      Cheque_Date: batch.CheckDate ,
      Created_By: 0,
      Created_Date: '',
      Modified_By: 0,
      Modified_Date: '',
      Deleted: false,
      EOB_CODE: '',
      ERA_CATEGORY_CODE: '',
      ERA_ADJUSTMENT_CODE: '',
      ICN: '',
      ERA_Rejection_CATEGORY_CODE: '',
      MODI_CODE1: '',
      MODI_CODE2: '',
      ENTERED_FROM: claim.enteredfrom ,
      Sequence_No: '',
      Contractual_Amt: 0,
      BATCH_NO: batch.BatchID.toString(),
      BATCH_DATE: batch.BatchOpenDate,
      DEPOSITSLIP_ID: '',
      IsRectify: '',
      modified_from: '',
      DepositDate: batch.DepositDate,
      DOS_From: charge ? charge.Dos_From : null ,
      Dos_To: charge ? charge.Dos_To  : null,
      Alternate_Code: '5',
      T_payment_id: null
    };
    payments.push(payment);
  }
  debugger;
  return payments;
}
MoveToClaimSummary(){

          this.onclosemodal.emit();
}
}
