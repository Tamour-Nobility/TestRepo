import { Component } from '@angular/core';

@Component({
  selector: 'app-era-layout',
  templateUrl: './era-layout.component.html',
  styleUrls: ['./era-layout.component.css']
})
export class ERALayout {

  constructor() {

  }
}
