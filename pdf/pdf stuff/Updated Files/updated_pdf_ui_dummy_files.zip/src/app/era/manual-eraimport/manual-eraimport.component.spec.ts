import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManualEraimportComponent } from './manual-eraimport.component';

describe('ManualEraimportComponent', () => {
  let component: ManualEraimportComponent;
  let fixture: ComponentFixture<ManualEraimportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManualEraimportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManualEraimportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
