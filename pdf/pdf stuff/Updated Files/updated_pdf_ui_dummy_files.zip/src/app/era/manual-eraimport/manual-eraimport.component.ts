import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { APIService } from '../../components/services/api.service';
import { GvarsService } from '../../services/G_vars/gvars.service';
import { ToastrService } from 'ngx-toastr';
import { Router, ActivatedRoute } from '@angular/router';
import { FileHandlerService } from '../../components/services/file-handler/filehandler.service';
import { ERASearchRequestModel } from '../models/era-search-request.model';
import { ERASearchResponseModel } from '../models/era-search-response.model';
import { ERACheckDetails } from '../models/era-check-details.model';
import { IMyDpOptions } from 'mydatepicker';
import { Common } from '../../services/common/common';
import * as moment from 'moment';
import { IMyDateRangeModel } from 'mydaterangepicker';
declare var $: any
const validMimeTypes = [
  'application/rmt',
  'text/rmt',
  'application/RMT',
  'text/RMT'
];
const maximumFileSize = 20000000;
const validExtensions = ['RMT','rmt'];
@Component({
  selector: 'app-manual-eraimport',
  templateUrl: './manual-eraimport.component.html',
  styleUrls: ['./manual-eraimport.component.css']
})
export class ManualEraimportComponent implements OnInit {

  dataTableERAHistory: any;
  lastSevenDaysERA:any=[];
  prac:any;
  selectedFile: File;
  uploading: boolean;
  form: FormGroup;
  filename:any;
  expandedRowIndex: number | null = null;
   ERASearchForm: FormGroup;
    eraSearchRequest: ERASearchRequestModel;
    eraSearchResponse: ERASearchResponseModel[];
    eraSummary: ERACheckDetails[];
    dataTableERA: any;
    isSearchInitiated: boolean = false;
    myDateRangePickerOptions: IMyDpOptions = {
      dateFormat: 'mm/dd/yyyy', height: '25px', width: '100%'
    };
    expandERA:any=[]
    ManualERAFiles:any=[];
  constructor(private API: APIService,
    public Gv: GvarsService,
    private _fileHandlerService: FileHandlerService,
    private toastService: ToastrService,
    private chRef: ChangeDetectorRef,
    private router: Router,
    private route: ActivatedRoute) {
    this.eraSearchRequest = new ERASearchRequestModel();
    this.eraSearchResponse = [];
    this.eraSummary = [];
  }

  


  

  ngOnInit() {
    this.initForm();
    this.eraHistory();
    const { snapshot } = this.route;
    this.ERAImportBTStatus();
    
      if( localStorage.getItem('sp') === null){
        this.prac = {PracticeCode: '1010999'}
        this.prac = Number(this.prac['PracticeCode']);
        console.log("default Practice",this.prac);
      }else{
        this.prac=JSON.parse(localStorage.getItem('sp'));
        this.prac= this.prac['PracticeCode'];
        this.prac= Number(this.prac); 
        console.log("change Practice ERA/Import?practiceCode=",this.prac);
      }
  
      this.InitializeForm();
      const { queryParamMap } = snapshot;
      this.eraSearchRequest.status = 'All'// queryParamMap.get('status');
      this.eraSearchRequest.practiceCode = Number(queryParamMap.get('practiceCode'));
      this.eraSearchRequest.patientAccount = queryParamMap.get('patientAccount');
      this.eraSearchRequest.icnNo = queryParamMap.get('icnNo');
      this.eraSearchRequest.checkNo = queryParamMap.get('checkNo');
      this.eraSearchRequest.dateTo = queryParamMap.get('dateTo');
      this.eraSearchRequest.dateFrom = queryParamMap.get('dateFrom');
      this.eraSearchRequest.checkAmount = queryParamMap.get('checkAmount');
      this.eraSearchRequest.dateType = queryParamMap.get('dateType');
      if (this.canSearch()) {
        if (!Common.isNullOrEmpty(this.eraSearchRequest.dateTo) && !Common.isNullOrEmpty(this.eraSearchRequest.dateFrom))
          this.setDateRange(new Date(this.eraSearchRequest.dateFrom), new Date(this.eraSearchRequest.dateTo));
        this.onSearch();
      }
      else {
        this.setDefaultFilter();
        this.onSearch();
      }
  }

  setDefaultFilter() {
      this.eraSearchRequest = new ERASearchRequestModel();
      let date = new Date();
      let beginDate = new Date(date.getFullYear(), date.getMonth(), 1);
      let endDate = date;
      this.setDateRange(beginDate, endDate);
      this.eraSearchRequest.dateFrom = null//moment(beginDate).format('MM/DD/YYYY');
      this.eraSearchRequest.dateTo = null //moment(endDate).format('MM/DD/YYYY');
    }

     onDateRangeChanged(event: IMyDateRangeModel) {
        this.eraSearchRequest.dateFrom = Common.isNullOrEmpty(event.beginJsDate) ? null : moment(event.beginJsDate).format('MM/DD/YYYY');
        this.eraSearchRequest.dateTo = Common.isNullOrEmpty(event.endJsDate) ? null : moment(event.endJsDate).format('MM/DD/YYYY');
        if (this.eraSearchRequest.dateFrom === null && this.eraSearchRequest.dateTo === null)
          this.eraSearchRequest.dateType = null;
      }
  
    setDateRange(begin, end): void {
      this.ERASearchForm.patchValue({
        dateRange: {
          beginDate: {
            year: begin.getFullYear(),
            month: begin.getMonth() + 1,
            day: begin.getDate()
          },
          endDate: {
            year: end.getFullYear(),
            month: end.getMonth() + 1,
            day: end.getDate()
          }
        }
      });
    }

  canSearch() {
      return (!Common.isNullOrEmpty(this.eraSearchRequest.checkNo) ||
        !Common.isNullOrEmpty(this.eraSearchRequest.checkAmount) ||
        !Common.isNullOrEmpty(this.eraSearchRequest.dateFrom) ||
        !Common.isNullOrEmpty(this.eraSearchRequest.dateTo) ||
        !Common.isNullOrEmpty(this.eraSearchRequest.patientAccount) ||
        !Common.isNullOrEmpty(this.eraSearchRequest.icnNo) ||
        !Common.isNullOrEmpty(this.eraSearchRequest.status));
    }

  InitializeForm(): any {
    this.ERASearchForm = new FormGroup({
      checkNo: new FormControl(null),
      checkAmount: new FormControl(null),
      dateRange: new FormControl(null),
      dateType: new FormControl(null),
      patientAccount: new FormControl(null),
      icnNo: new FormControl(null),
      status: new FormControl()
    });
  }

   

   initForm() {
    this.form = new FormGroup({
      attachment: new FormControl(null, [Validators.required])
    });
  }

  getFileDisplayName() {
    if (this.selectedFile && this.selectedFile.name) {
      if (this.selectedFile.name.length > 25)
        return this.selectedFile.name.substr(0, 24);
      return this.selectedFile.name;
    }
  }

   ERAImportBTStatus(){
    console.log("this.Gv.ERAImportButtonStatus.includes(this.prac)",this.Gv.ERAImportButtonStatus)
    if(this.Gv.ERAImportButtonStatus.includes(this.prac)){
      this.Gv.uploading=true
      this.Gv.ERAImportButtonTooltip="ERA Manual Import is in process , records will be updated in grid. Meanwhile you can perform other tasks"
    }else{
      this.Gv.uploading=false
      this.Gv.ERAImportButtonTooltip="Click to start ERA Manual Import process."
    }
  }

    onUpload() {
    debugger;
    if (!this.selectedFile) {
      this.toastService.warning('Please choose file.', 'File Missing');
      return;
    }

    var abc=this.ManualERAFiles.filter(file => file.File_Name == this.selectedFile.name);
    console.log("djsfjsdfhs",abc)
    if (abc.length>0) {
      this.toastService.warning('File already exist.', 'File Missing');
      return;
    }
    this.uploading = true;
    // const formData = {
    //   File:this.selectedFile.name
    // }
    
    // console.log("formData",formData);
    // debugger

    const ER = new FormData();
ER.append("File", this.selectedFile); // Append actual file
ER.append("File_Name", this.selectedFile.name); // Append file name
ER.append("Practice_code", this.prac);

console.log("formData",ER);
this.toastService.success('The processing of ERA File Import has begun. Please be patient');
localStorage.setItem('uploading', JSON.stringify(true));
this.Gv.uploading=true
localStorage.setItem('uploading', JSON.stringify(true));
this.Gv.ERAImportButtonTooltip="ERA Manual Import is in process , records will be updated in grid. Meanwhile you can perform other tasks";
localStorage.setItem('ERAImportButtonTooltip', JSON.stringify('ERA Manual Import is in process , records will be updated in grid. Meanwhile you can perform other tasks'));
  if(this.Gv.ERAImportButtonStatus.includes(this.prac)){
    
   }else{
    this.Gv.ERAImportButtonStatus.push(this.prac)
    console.log("this.Gv.ERAImportButtonStatus",this.Gv.ERAImportButtonStatus);
   }
   console.log("Final ER data",ER);
   console.log("this.selectedFile data",this.selectedFile);
    this._fileHandlerService.UploadFile(ER,'/ERA/ERAImport')
      .subscribe(res => {
        if (res.Status === "success") {
          debugger;
          this.ManualERAFileProcess();
        } else {
          this.toastService.error(res.Response, 'Upload Failure');
        }
      }, (error) => {
        this.uploading = false;
      })
  }

ManualERAFileProcess(){

  var RolesAndRights=JSON.parse(localStorage.getItem('rr'));
   let userDetails = {
    UserID  : RolesAndRights[0].UserId,
    UserName : RolesAndRights[0].UserName,
    PracticeCde:this.prac,
  };

  this.API.PostDataWithoutSpinnerERA('/ERA/ManualERAFileProcessing',userDetails, (res) => {
    console.log("Custom download ERA",res)
    
          this.selectedFile = null;
          localStorage.setItem('uploading', JSON.stringify(false));
          this.Gv.uploading=false;
          this.Gv.ERAImportButtonTooltip="Click to start ERA Manual Import process.";
          localStorage.setItem('ERAImportButtonTooltip', JSON.stringify('Click to start ERA Manual Import process.'));

          if(this.Gv.ERAImportButtonStatus.includes(this.prac)){
                this.Gv.ERADownloadButton=false
                const index = this.Gv.ERAImportButtonStatus.indexOf(this.prac);
                if (index > -1) { // only splice array when item is found
                  this.Gv.ERAImportButtonStatus.splice(index, 1); // 2nd parameter means remove one item only
                }
              }
              
          this.ERAImportBTStatus()
          this.form.reset();
          this.onSearch();
          this.toastService.success('Manual ERA Import logs has been updated in ERA Import Details  grid . Please check');
  });
}
 generateQueryString(obj: any) {
    // changes the route without moving from the current view or
    // triggering a navigation event,
    this.router.navigate([], {
      relativeTo: this.route,
      queryParams: obj,
      queryParamsHandling: 'merge',
      // preserve the existing query params in the route
      skipLocationChange: false
      // do not trigger navigation
    });
  }

onSearch() {
    if (this.canSearch()) {
      this.eraSearchRequest.practiceCode = this.Gv.currentUser.selectedPractice.PracticeCode;
      this.eraSearchRequest.status = 'all'
      this.API.PostData(`/Submission/SearchERA?imp_type=Manual`,this.eraSearchRequest, (res) => {
        this.generateQueryString(this.eraSearchRequest);
        this.isSearchInitiated = true;
        if (res.Status == "success") {
          if (this.dataTableERA) {
            this.chRef.detectChanges();
            this.dataTableERA.destroy();
          }
          console.log("jdfghdfjg",res.Response)
          this.ManualERAFiles= res.ManualERAFiles;
          this.eraSearchResponse = res.Response;
          this.chRef.detectChanges();
          const table: any = $('.dataTableERA');
          this.dataTableERA = table.DataTable({
            columnDefs: [
              { orderable: false, targets: -1 }
            ],
            language: {
              emptyTable: "No data available"
            },
            order: [1, 'desc'],
          })
        }
        else
          swal(res.status, res.Response, 'error');
      });
    } else {
      this.toastService.warning('Please provide search criteria', 'Invalid Search Criteria');
    }
  }


onToggleRow(event: MouseEvent, index: number, eraId: number): void {
  event.stopPropagation();  // Stop event bubbling
  event.preventDefault();   // Prevent scroll or navigation

  if (this.expandedRowIndex === index) {
    this.expandedRowIndex = null;
  } else {
    this.expandedRowIndex = index;
    this.getClaimDetails(eraId);
  }
}


getClaimDetails(eraId: number) {
  if (eraId) {
        this.API.PostData(`/Submission/ERAClaimSummary?imp_type=Manual`, { eraId: eraId }, (res) => {
          //this.isSearchInitiated = true;
          console.log("sdhfjksdh",res)
          const claims = res.Response.eraClaims;

          // Deduplicate by CLAIMNO
          const uniqueClaims = Array.from(
            new Map(claims.map(claim => [claim.CLAIMNO, claim])).values()
          );

          this.expandERA = uniqueClaims;

          //this.expandERA = res.Response.eraClaims
          const era = this.eraSearchResponse.find(e => e.ERAID === eraId);
    // if (era) {
    //   era.claimDetails = res;
    // }
          debugger;
          if (res.Status == "success") {
            
  
             
          } else if (res.Status === 'invalid-era-id')
            swal(res.status, res.Response, 'error');
          else
            swal(res.status, "An error occurred", 'error');
        });
      } else {
        this.toastService.warning('Please provide search criteria', 'Invalid Search Criteria');
      }


  // this.yourService.getClaimsByEraId(eraId).subscribe(claims => {
  //   const era = this.eraSearchResponse.find(e => e.ERAID === eraId);
  //   if (era) {
  //     era.claimDetails = claims;
  //   }
  // });
}



  //  getClaimDetails(ERAID) {
  //     debugger;
  //     if (ERAID) {
  //       this.API.PostData('/Submission/ERAClaimSummary', { eraId: ERAID }, (res) => {
  //         //this.isSearchInitiated = true;
  //         debugger;
  //         if (res.Status == "success") {
  //           // if (this.datatable) {
  //           //   this.datatable.destroy();
  //           //   this.chRef.detectChanges();
  //           // }
  //           // this.data = res.Response;
  //           // this.chRef.detectChanges();
  //           // const table = $('.dataTableEraClaims');
  //           // this.datatable = table.DataTable({
  //           //   lengthMenu: [[5, 10, 15, 20], [5, 10, 15, 20]],
  //           //   columnDefs: [{
  //           //     'targets': 0,
  //           //     'checkboxes': {
  //           //       'selectRow': true
  //           //     }
  //           //   },
  //           //   {
  //           //     targets: [1],
  //           //     visible: false,
  //           //     searchable: false
  //           //   },
  //           //   {
  //           //     className: 'control',
  //           //     orderable: false,
  //           //     targets: 0
  //           //   }],
  //           //   select: {
  //           //     style: 'multi'
  //           //   },
  //           //   language: {
  //           //     buttons: {
  //           //       emptyTable: "No data available"
  //           //     },
  //           //     select: {
  //           //       rows: ""
  //           //     }
  //           //   },
  //           //   order: [2, 'desc']
  //           // });
  //           // this.datatable.on('select',
  //           //   (e, dt, type, indexes) => this.onRowSelect(indexes));
  //           // this.datatable.on('deselect',
  //           //   (e, dt, type, indexes) => this.onRowDeselect(indexes));
  
             
  //         } else if (res.Status === 'invalid-era-id')
  //           swal(res.status, res.Response, 'error');
  //         else
  //           swal(res.status, "An error occurred", 'error');
  //       });
  //     } else {
  //       this.toastService.warning('Please provide search criteria', 'Invalid Search Criteria');
  //     }
  //   }
  

  onChangeFile(event: any) {
    debugger;
    this.selectedFile = null;
    const { files } = event.target;
    if (files.length === 0) {
      this.toastService.warning('Please choose file to upload.', 'File Missing');
      return;
    }
    const file = files[0];
    //const { size, type } = file;

  const { name, size, type } = file;

    const extension = name.split('.').pop().toUpperCase();
    if ((!extension || !validExtensions.includes(extension))
) {
  this.toastService.warning('Please choose a file with .rmt extension  type.', 'File Type');
  return;
}
    if (size > maximumFileSize) {
      this.toastService.warning('Maximum file size 20Mb.', 'File Size');
      return;
    }
    this.selectedFile = file;
  }
  eraHistory(){
    if( localStorage.getItem('sp') === null){
      this.prac = {PracticeCode: '1010999'}
      this.prac = Number(this.prac['PracticeCode']);
      console.log("default Practice",this.prac);
    }else{
      this.prac=JSON.parse(localStorage.getItem('sp'));
      this.prac= this.prac['PracticeCode'];
      this.prac= Number(this.prac); 
      console.log("change Practice ERA/Import?practiceCode=1011002",this.prac);
    }
    
    var RolesAndRights=JSON.parse(localStorage.getItem('rr'));
    let userDetails = {
      UserID  : RolesAndRights[0].UserId,
      UserName : RolesAndRights[0].UserName,
      PracticeCode:this.prac,
    };
    console.log("userDetails",userDetails
    )
    
  }
}
