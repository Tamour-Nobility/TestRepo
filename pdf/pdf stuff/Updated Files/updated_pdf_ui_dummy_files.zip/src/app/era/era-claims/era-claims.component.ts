import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Component, OnInit, ChangeDetectorRef,ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Common } from '../../services/common/common';
import { Location } from '@angular/common';

import { ERAClaimDetailsResponse } from '../models/era-claim-details-response.model';
import { APIService } from '../../components/services/api.service';
import { IMyDpOptions } from 'mydatepicker';
import { ModalDirective,ModalOptions } from 'ngx-bootstrap/modal';
declare var $: any;
import 'datatables.net';
import * as xlsx from 'xlsx';
import * as FileSaver from 'file-saver';
import { GvarsService } from '../../services/G_vars/gvars.service';

@Component({
  selector: 'app-era-claims',
  templateUrl: './era-claims.component.html',
  styleUrls: ['./era-claims.component.css']
})
export class ERAClaims implements OnInit {
  
  data: ERAClaimDetailsResponse;
  eraId: number;
  rowCount:any
  datatable: any;
  count:number;
  selectedClaimIds: number[];
  isSearchInitiated: boolean = false;
  dataTableEraClaims: any;
  depositDate: any;
  applyBtn:boolean=true;
  today = new Date();
  myDatePickerOptions: IMyDpOptions = {
    dateFormat: 'mm/dd/yyyy',
    height: '25px',
    width: '100%',
    disableSince: {
      year: this.today.getFullYear(),
      month: this.today.getMonth() + 1,
      day: this.today.getDate() + 1,
    },
  };
  
  @ViewChild('upModal') upModal!: ModalDirective;
  @ViewChild('exampleModal') exampleModal!: ModalDirective;
  nbDataTable: any;
  coDataTable: any;
  eraOverpaidClaims: any;
  ERAClaimCrossOver:any;
 batchPaymentInfo: any = null;
  batchId: number =0;
  batchDate: any;
  modalRef?: BsModalRef;
batchPaymentForm!: FormGroup;
modalTitle = 'Add New Batch';
  batchType = [
    { value: 'I', name: 'Insurance' }
  ];
  paymentType = [
    { value: 'C', name: 'Cash' },
    { value: 'K', name: 'Check' },
    { value: 'R', name: 'Credit' },
    { value: 'EFT', name: 'EFT' },
    { value: 'Lgb', name: 'Lock Box' },
    { value: 'E', name: 'ERA' },
    { value: 'O', name: 'Other' }
  ];
  PaymentStatus = [
    { value: 'AB', name: 'All Batches' },
    { value: 'APP', name: 'All Posted Payments' },
    { value: 'AUP', name: 'All Unposted Payments' },
  ];
  batchTypeMap: any = {
  I: 'Insurance',
  P: 'Patient',
  B: 'Both',
};
paymentTypeMap: any = {
  C: 'Cash',
  K: 'Check',
  R: 'Credit',
  EFT: 'EFT',
  Lgb: 'Lock Box',
  E: 'ERA',
  O: 'Other'
};
eraCheckList: any[] = [];
 allEraChecks: any[] = [];
isReadOnly = false;
isDepositDateDisabled: boolean = false;
  constructor(private chRef: ChangeDetectorRef,
    private route: ActivatedRoute,
    private toastService: ToastrService,
    private API: APIService,
    private _location: Location,
    private router: Router,
    private fb: FormBuilder, 
    private modalService: BsModalService,
    private gv :GvarsService
  ) {
    this.data = new ERAClaimDetailsResponse();
    this.selectedClaimIds = [];
  }

  ngOnInit() {
    this.route.params.subscribe(params => {
      if (params['id'] !== 0 && params['id'] !== '0') {
        this.eraId = params['id'];
        this.getClaimDetails();
      }
    });
    this.initBatchForm();
    this.getEraCheckDetails();
  }

  dateMask(event: any) {
    Common.DateMask(event);
  }
  

  // onDateChangedDd(event: any) {
  //   this.depositDate = event.formatted;

  //   if(this.depositDate==''){
  //     $('#AppyBtn').prop('disabled', true);
  //     $('#autoApplyBtn').prop('disabled', true);
  //   }else{
      
  //     if(this.count>=this.rowCount && this.depositDate !=null){
  //       $('#AppyBtn').prop('disabled', true);
  //       $('#autoApplyBtn').prop('disabled', false);

        
  //     }else if(this.count<this.rowCount && this.count>0 && this.depositDate !=null){
  //       $('#AppyBtn').prop('disabled', false);
  //       $('#autoApplyBtn').prop('disabled', true);

  //     }
  //     else{
  //       $('#AppyBtn').prop('disabled', true);
  //     }
  //   }
  // }
onDateChangedDd(event: any) {
  // this.depositDate = event; //  Keep the full object instead of event.formatted

  // const formattedDate = event.formatted;

   this.depositDate = event && event.formatted ? event.formatted : null; // store formatted date safely
   const formattedDate = this.depositDate;
  if (!formattedDate) {
    $('#AppyBtn').prop('disabled', true);
    $('#autoApplyBtn').prop('disabled', true);
  } else {
    if (this.count >= this.rowCount && formattedDate != null) {
      $('#AppyBtn').prop('disabled', true);
      $('#autoApplyBtn').prop('disabled', false);
    } else if (this.count < this.rowCount && this.count > 0 && formattedDate != null) {
      $('#AppyBtn').prop('disabled', false);
      $('#autoApplyBtn').prop('disabled', true);
    } else {
      $('#AppyBtn').prop('disabled', true);
    }
  }
}

  getClaimDetails() {
    if (!Common.isNullOrEmpty(this.eraId)) {
      this.API.PostData('/Submission/ERAClaimSummary', { eraId: this.eraId }, (res) => {
        this.isSearchInitiated = true;
        if (res.Status == "success") {
          // this.fetchBatchPayment(res.Response.era.CHECKNUMBER);
           const checkNo = res.Response.era.CHECKNUMBER;
        if (checkNo) {
          this.fetchBatchPayment(checkNo);
        }

          if (this.datatable) {
            this.datatable.destroy();
            this.chRef.detectChanges();
          }
          this.data = res.Response;
          this.chRef.detectChanges();
          const table = $('.dataTableEraClaims');
          this.datatable = table.DataTable({
            lengthMenu: [[5, 10, 15, 20], [5, 10, 15, 20]],
            columnDefs: [{
              'targets': 0,
              'checkboxes': {
                'selectRow': true
              }
            },
            {
              targets: [1],
              visible: false,
              searchable: false
            },
            {
              className: 'control',
              orderable: false,
              targets: 0
            }],
            select: {
              style: 'multi'
            },
            language: {
              buttons: {
                emptyTable: "No data available"
              },
              select: {
                rows: ""
              }
            },
            order: [2, 'desc']
          });
          this.datatable.on('select',
            (e, dt, type, indexes) => this.onRowSelect(indexes));
          this.datatable.on('deselect',
            (e, dt, type, indexes) => this.onRowDeselect(indexes));

           
        } else if (res.Status === 'invalid-era-id')
          swal(res.status, res.Response, 'error');
        else
          swal(res.status, "An error occurred", 'error');
      });
    } else {
      this.toastService.warning('Please provide search criteria', 'Invalid Search Criteria');
    }
  }

  onRowDeselect(indexes: any) {
    let ndx = this.selectedClaimIds.findIndex(p => p === this.datatable.cell(indexes, 1).data());
    if (ndx > -1) {
      this.selectedClaimIds.splice(ndx, 1);
    }
    this.count = this.datatable.rows( { selected: true } ).count();
   
    if(this.count==this.rowCount && this.depositDate !=null && this.depositDate !=''){
      $('#AppyBtn').prop('disabled', true);
      $('#autoApplyBtn').prop('disabled', false);

      
    }else if(this.count<=this.rowCount && this.count>=1 && this.depositDate !=null && this.depositDate !=''){
      $('#AppyBtn').prop('disabled', false);
      $('#autoApplyBtn').prop('disabled', true);

    }
    else{
      $('#autoApplyBtn').prop('disabled', true);
      $('#AppyBtn').prop('disabled', true);
    }
    // console.log(this.count)
    // console.log(this.rowCount)
   
  }

  onRowSelect(indexes: any) {
    if (this.selectedClaimIds.findIndex(p => p == this.datatable.cell(indexes, 1).data()) < 0) {
      this.selectedClaimIds.push(this.datatable.cell(indexes, 1).data());
    }
    $('#AppyBtn').prop('disabled', false);
    this.count = this.datatable.rows( { selected: true } ).count();
    if(this.count==this.rowCount && this.depositDate !=null && this.depositDate !=''){
      $('#AppyBtn').prop('disabled', true);

      $('#autoApplyBtn').prop('disabled', false);
      $('#autoApplyBtn').addClass('btn-primary').removeClass('btn-default');

      
    }else if(this.count<=this.rowCount && this.count>0 && this.depositDate !=null && this.depositDate !=''){
      $('#AppyBtn').prop('disabled', false);

      $('#autoApplyBtn').prop('disabled', true);
   


    }
    else{
      $('#autoApplyBtn').prop('disabled', true);
      $('#AppyBtn').prop('disabled', true);
    }
    var rows = this.datatable.rows({ selected: true }).data();
    console.log(rows)
  }

  getAdjustmentAmount(amt1:any, amt2:any,amt3:any,amt4:any) {

    if(amt3==null){
      amt3=0
    }
    if(amt4==null){
      amt4=0
    }

    return parseFloat(amt1) + parseFloat(amt2) + parseFloat(amt3) +parseFloat(amt4);
  }
  getPRESAMTAmount(amts1:any, amts2:any,amts3:any) {
    if(amts1==null){
      amts1=0
    }
    if(amts2==null){
      amts2=0
    }
    if(amts3==null){
      amts3=0
    }
    return parseFloat(amts1) + parseFloat(amts2) + parseFloat(amts3);
  }

  goBack() {
    this._location.back();
  }

  // onApply() {
  //    if (!this.batchPaymentInfo || !this.batchPaymentInfo.BatchID) {
  //     swal(
  //           'Error',
  //           'Please add batch to post ERA payment.',
  //           'error'
  //         );
  //   return; 
  // }
    
  //   var filteredClaimIds = this.selectedClaimIds.filter(id => this.data.eraClaims.find(claim => Number(claim.CLAIMNO) === Number(id) && claim.CLAIMPOSTEDSTATUS === 'U'));
  //   if (this.selectedClaimIds.length > 0) {
  //     this.API.PostData('/Submission/ApplyERA', { eraId: this.eraId, claims: filteredClaimIds, depositDate: this.depositDate.formatted, Batchid: this.batchId,  BatchDate: this.batchDate }, (res) => {
  //       if (res.Status == "success") {
  //         this.toastService.success('ERA Apply Success', 'Success');
  //         // this.depositDate = '';
  //         this.getEraCheckDetails();
  //         if (this.datatable) {
  //           this.datatable.destroy();
  //           this.chRef.detectChanges();
  //         }
  //         this.data = res.Response;
  //         this.chRef.detectChanges();
  //         const table = $('.dataTableEraClaims');
  //         this.datatable = table.DataTable({
  //           lengthMenu: [[5, 10, 15, 20], [5, 10, 15, 20]],
  //           columnDefs: [{
  //             'targets': 0,
  //             'checkboxes': {
  //               'selectRow': true
  //             }
  //           },
  //           {
  //             targets: [1],
  //             visible: false,
  //             searchable: false
  //           },
  //           {
  //             className: 'control',
  //             orderable: false,
  //             targets: 0
  //           }],
  //           select: {
  //             style: 'multi'
  //           },
  //           language: {
  //             buttons: {
  //               emptyTable: "No data available"
  //             },
  //             select: {
  //               rows: ""
  //             }
  //           },
  //           order: [2, 'desc']
  //         });
  //         this.datatable.on('select',
  //           (e, dt, type, indexes) => this.onRowSelect(indexes));
  //         this.datatable.on('deselect',
  //           (e, dt, type, indexes) => this.onRowDeselect(indexes));

  //         //..below method is to check whether overpayment exist for ear claims or not.
  //         this.eraClaimsOverPaid();
  //         this.disableapplyButtons();
  //       }
  //       else {
  //         this.toastService.error('An error occurred while applying ERA', 'Failed to apply ERA');
  //       }
  //     });
  //   } else
  //     this.toastService.warning('Please select at least one claim to apply.', 'Invalid Selection');
  // }
onApply() {
  debugger;
 
  if (!this.batchPaymentInfo || !this.batchPaymentInfo.BatchID) {
    swal(
      'Error',
      'Please add batch to post ERA payment.',
      'error'
    );
    return;
  }
 
  const selectedRows = this.datatable
    ? this.datatable.rows({ selected: true }).data().toArray()
    : [];
 
  if (!selectedRows || selectedRows.length === 0) {
    this.toastService.warning(
      'Please select at least one claim to apply.',
      'Invalid Selection'
    );
    return;
  }
  const selectedClaimNos = selectedRows
    .map(row => Number(row[1]))  // column index 1 = CLAIMNO
    .filter(id => !isNaN(id));
  const filteredClaimIds = this.data.eraClaims
    .filter(
      claim =>
        selectedClaimNos.includes(Number(claim.CLAIMNO)) &&
        claim.CLAIMPOSTEDSTATUS === 'U'
    )
    .map(claim => claim.CLAIMNO);
 
  if (filteredClaimIds.length === 0) {
    this.toastService.warning(
      'No unposted claims selected.',
      'Invalid Selection'
    );
    return;
  }
 
  this.API.PostData(
    '/Submission/ApplyERA',
    {
      eraId: this.eraId,
      claims: filteredClaimIds,
      depositDate: this.depositDate.formatted,
      Batchid: this.batchId,
      BatchDate: this.batchDate
    },
    (res) => {
      if (res.Status === 'success') {
        this.toastService.success('ERA Apply Success', 'Success');
 
        this.getEraCheckDetails();
 
        if (this.datatable) {
          this.datatable.destroy();
          this.chRef.detectChanges();
        }
 
        this.data = res.Response;
        this.chRef.detectChanges();
 
        const table = $('.dataTableEraClaims');
        this.datatable = table.DataTable({
          lengthMenu: [[5, 10, 15, 20], [5, 10, 15, 20]],
          columnDefs: [
            {
              targets: 0,
              checkboxes: { selectRow: true }
            },
            {
              targets: [1],
              visible: false,
              searchable: false
            },
            {
              className: 'control',
              orderable: false,
              targets: 0
            }
          ],
          select: { style: 'multi' },
          language: {
            buttons: { emptyTable: 'No data available' },
            select: { rows: '' }
          },
          order: [2, 'desc']
        });
 
        this.datatable.on('select',
          (e, dt, type, indexes) => this.onRowSelect(indexes));
        this.datatable.on('deselect',
          (e, dt, type, indexes) => this.onRowDeselect(indexes));
 
        this.eraClaimsOverPaid();
        this.disableapplyButtons();
      } else {
        this.toastService.error(
          'An error occurred while applying ERA',
          'Failed to apply ERA'
        );
      }
    }
  );
}
  onAutoPost() {
     if (!this.batchPaymentInfo || !this.batchPaymentInfo.BatchID) {
    // swal({
    //   title: 'Error',
    //   text: 'Please add batch to post ERA payment.',
    //   icon: 'error',
    //   allowOutsideClick: false,
    //   allowEscapeKey: false
    // });
      swal(
            'Error',
            'Please add batch to post ERA payment.',
            'error'
          );
    return; // stop execution if no batch is selected
  }
    this.API.PostData(`/Submission/AutoPost/`, { id: this.eraId, depositDate: this.depositDate.formatted,Batchid: this.batchId,  BatchDate: this.batchDate }, (res) => {
      if (res.Status == "success") {
        this.toastService.success('ERA has been Auto Posted successfully.', 'ERA Auto Post Success');
        // this.depositDate = '';
        this.getEraCheckDetails();
        if (this.datatable) {
          this.datatable.destroy();
          this.chRef.detectChanges();
        }
        if (res.Response.eraClaims.length > 0)
          this.data = res.Response;
        this.chRef.detectChanges();
        const table = $('.dataTableEraClaims');
        this.datatable = table.DataTable({
          lengthMenu: [[5, 10, 15, 20], [5, 10, 15, 20]],
          columnDefs: [{
            'targets': 0,
            'checkboxes': {
              'selectRow': true
            }
          },
          {
            targets: [1],
            visible: false,
            searchable: false
          },
          {
            className: 'control',
            orderable: false,
            targets: 0
          }],
          select: {
            style: 'multi'
          },
          language: {
            buttons: {
              emptyTable: "No data available"
            },
            select: {
              rows: ""
            }
          },
          order: [2, 'desc']
        });
        this.datatable.on('select',
          (e, dt, type, indexes) => this.onRowSelect(indexes));
        this.datatable.on('deselect',
          (e, dt, type, indexes) => this.onRowDeselect(indexes));

        //..below method is to check whether overpayment exist for ear claims or not.
        this.eraClaimsOverPaid();
        this.disableapplyButtons();
      }
      else {
        this.toastService.error('An error occurred while auto posting ERA', 'Failed to Auto Post ERA');
      }
    });
  }

  getEncodedUrl(claimNo, patientAccount, firstname, lastName) {
    return Common.encodeBase64(JSON.stringify({
      Patient_Account: patientAccount,
      PatientFirstName: firstname,
      PatientLastName: lastName,
      claimNo: claimNo,
      disableForm: false
    }));
  }

  isMismatched(patAccount) {
    return Common.isNullOrEmpty(patAccount);
  }

  // canSelectAll() {
  //   this.data.eraClaims.filter(claim => claim.CLAIMPOSTEDSTATUS === 'U').length > 0 && this.data.era.ERAPOSTEDSTATUS !== 'P'
  //   this.rowCount=this.data.eraClaims.length
  //   return ( this.data.eraClaims)
  // }
canSelectAll() {
  if (!this.data || !this.data.eraClaims || !this.data.era) {
    return false;
  }
 
  this.rowCount = this.data.eraClaims.length;
 
  return (
    this.data.eraClaims.some(claim => claim.CLAIMPOSTEDSTATUS === 'U') &&
    this.data.era.ERAPOSTEDSTATUS !== 'P'
  );
}
  canAutoPost() {
    return (this.data.era.ERAPOSTEDSTATUS !== 'P' && this.data.eraClaims.some(claim => claim.CLAIMPOSTEDSTATUS !== 'P'))
  }

  canApply() {
    return this.canSelectAll();
  }


  //...below is negative balance implementation by tamour

  hideNegativeBalanceModel() {
     $('#staticBackdrop1').modal('hide'); // Hide the first modal

    $('#staticBackdrop1').on('hidden.bs.modal', () => {
      if(this.ERAClaimCrossOver.length>0){
        $('#staticBackdrop').modal('show'); // Only show second modal after the first is fully hidden
      }
    });
  }

  callModel(){
    
     
  }

  disableapplyButtons() {
    $('#AppyBtn').prop('disabled', true);
    $('#autoApplyBtn').prop('disabled', true);
  }

  eraClaimsOverPaid() {
    this.API.PostData('/Submission/ERAClaimsOverPayment', { eraId: this.eraId }, (res) => {
      if (res.Status == "success") {
        if (res.Response.length > 0) {
          //set the modal body static.will close on click OK or Cross
          // const modalOptions: ModalOptions = {
          //   backdrop: 'static'
          // };
          // this.upModal.config = modalOptions; 
          // this.upModal.show();
          $('#staticBackdrop1').modal('show');
          if (this.nbDataTable) {
            this.chRef.detectChanges();
            this.nbDataTable.destroy();
          }
          this.eraOverpaidClaims = res.Response;
          this.chRef.detectChanges();
          const table = $('.nbDataTable');
          this.nbDataTable = table.DataTable({
            language: {
              buttons: {
                emptyTable: "No data available"
              }
            }
          });
        }

        if (res.ERAClaimCrossOver.length > 0) {
          
          if (this.coDataTable) {
            this.chRef.detectChanges();
            this.coDataTable.destroy();
          }
          this.ERAClaimCrossOver = res.ERAClaimCrossOver;
          this.chRef.detectChanges();
          const table = $('.coDataTable');
          this.coDataTable = table.DataTable({
            language: {
              buttons: {
                emptyTable: "No data available"
              }
            }
          });

          console.log("this.eraOverpaidClaims",this.eraOverpaidClaims)

          if(res.ERAClaimCrossOver.length > 0 && this.eraOverpaidClaims === undefined){
            $('#staticBackdrop').modal('show');
          }
        }
      }
      else {
        this.toastService.error('An error occurred while checking Overpayment Details', 'Failed to Check OverPayments');
      }

      

    });
  }

  exportExcel() {
  const worksheet = xlsx.utils.json_to_sheet(this.eraOverpaidClaims);
 
  // Format the cells to treat all values as text
  Object.keys(worksheet).forEach(cell => {
    if (worksheet[cell] && worksheet[cell].t === 'n') {
      worksheet[cell].t = 's'; // Treat the cell as a string
    }
  });
 
  // Specify column widths as before
  worksheet['!cols'] = [];
  this.eraOverpaidClaims.forEach(row => {
    Object.keys(row).forEach(key => {
      if (typeof row[key] === 'number') {
        worksheet['!cols'].push({ wch: String(row[key]).length + 2 });
      }
    });
  });
 
  // Format date cells as "MM/DD/YY"
  const dateColIndices = [/* Add the indices of columns containing date values */];
  dateColIndices.forEach(colIndex => {
    for (let row = 2; row <= this.eraOverpaidClaims.length; row++) {
      const cellRef = xlsx.utils.encode_cell({ c: colIndex, r: row });
      if (worksheet[cellRef] && worksheet[cellRef].t === 's') {
        const dateValue = new Date(worksheet[cellRef].v);
        if (!isNaN(dateValue.getTime())) {
          worksheet[cellRef].v = dateValue.toLocaleDateString('en-US', { month: '2-digit', day: '2-digit', year: '2-digit' });
        }
      }
    }
  });
 
  const workbook = { Sheets: { data: worksheet }, SheetNames: ['data'] };
  const excelBuffer: any = xlsx.write(workbook, {
    bookType: 'xlsx',
    type: 'array',
  });
 
  this.saveAsExcelFile(excelBuffer, 'Negative Balance Claims');
}

exportExcelCrossOver() {
  const worksheet = xlsx.utils.json_to_sheet(this.ERAClaimCrossOver);
 
  // Format the cells to treat all values as text
  Object.keys(worksheet).forEach(cell => {
    if (worksheet[cell] && worksheet[cell].t === 'n') {
      worksheet[cell].t = 's'; // Treat the cell as a string
    }
  });
 
  // Specify column widths as before
  worksheet['!cols'] = [];
  this.ERAClaimCrossOver.forEach(row => {
    Object.keys(row).forEach(key => {
      if (typeof row[key] === 'number') {
        worksheet['!cols'].push({ wch: String(row[key]).length + 2 });
      }
    });
  });
 
  // Format date cells as "MM/DD/YY"
  const dateColIndices = [/* Add the indices of columns containing date values */];
  dateColIndices.forEach(colIndex => {
    for (let row = 2; row <= this.ERAClaimCrossOver.length; row++) {
      const cellRef = xlsx.utils.encode_cell({ c: colIndex, r: row });
      if (worksheet[cellRef] && worksheet[cellRef].t === 's') {
        const dateValue = new Date(worksheet[cellRef].v);
        if (!isNaN(dateValue.getTime())) {
          worksheet[cellRef].v = dateValue.toLocaleDateString('en-US', { month: '2-digit', day: '2-digit', year: '2-digit' });
        }
      }
    }
  });
 
  const workbook = { Sheets: { data: worksheet }, SheetNames: ['data'] };
  const excelBuffer: any = xlsx.write(workbook, {
    bookType: 'xlsx',
    type: 'array',
  });
 
  this.saveAsExcelFile(excelBuffer, 'Cross Over Claims');
}

saveAsExcelFile(buffer: any, fileName: string): void {
  let EXCEL_TYPE ='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
  let EXCEL_EXTENSION = '.xlsx';
  const data: Blob = new Blob([buffer], {
    type: EXCEL_TYPE,
  });
  FileSaver.saveAs(
    data,
    fileName + EXCEL_EXTENSION
  );
}


fetchBatchPayment(checkNo: string): void {
  // this.API.getData(`/Submission/GetBatchPaymentForERA?checkNo=${checkNo}`).subscribe({
  this.API.getData(
  `/Submission/GetBatchPaymentForERA?checkNo=${checkNo}&practice_id=${this.gv.currentUser.selectedPractice.PracticeCode}`
).subscribe({
    next: (summary: any) => {
      if (summary.Status === 'Success') {
        this.batchPaymentInfo = summary.Response;
        this.batchId = this.batchPaymentInfo.BatchID;
        this.batchDate = this.batchPaymentInfo.date_created;

        if (this.batchPaymentInfo.DepositDate) {
          const deposit = new Date(this.batchPaymentInfo.DepositDate);
          this.depositDate = {
            date: {
              year: deposit.getFullYear(),
              month: deposit.getMonth() + 1,
              day: deposit.getDate()
            },
            formatted: deposit.toISOString()
          };

          //  Disable field when auto-populated
          this.isDepositDateDisabled = true;
        } else {
          // enable field for manual entry
          this.depositDate = null;
          this.isDepositDateDisabled = false;
        }

      } else {
        this.batchPaymentInfo = null;
      }
    },
    error: (err) => {
      console.error('Error fetching batch payment:', err);
      this.batchPaymentInfo = null;
      this.toastService.error('Server error occurred while fetching batch payment.');
    }
  });
}


initBatchForm() {
  this.batchPaymentForm = this.fb.group({
    batchId: [''],
    batchType: ['', Validators.required],
    fileName: ['', Validators.required],
    paymentType: ['', Validators.required],
    checkNo: [''],
    checkDate: [''],
    batchAmount: ['', Validators.required],
    depositDate: [''],
    batchDate: [''],
    receivedDate: [''],
    note: ['']
  });
}

openBatchModal(template: any) {
  this.modalRef = this.modalService.show(template, { 
    class: 'modal-xlg', 
    backdrop: 'static',  
    keyboard: false
  });

  const tempCheckNo = this.data.era.CHECKNUMBER || '';
  const tempCheckDate = this.data.era.CHECKDATE ? new Date(this.data.era.CHECKDATE) : null;

  //  Check if check number exists in the global list
  const isCheckInList = this.allEraChecks.some(item => item.CHECKNUMBER === tempCheckNo);

  setTimeout(() => {
    const today = new Date();

    // Format batch date (today)
    const formattedBatchDate = {
      date: {
        year: today.getFullYear(),
        month: today.getMonth() + 1,
        day: today.getDate()
      }
    };

    // Format check date (from ERA)
    const formattedCheckDate = tempCheckDate
      ? {
          date: {
            year: tempCheckDate.getFullYear(),
            month: tempCheckDate.getMonth() + 1,
            day: tempCheckDate.getDate()
          }
        }
      : null;
let formattedDepositDate = null;

if (this.depositDate && this.depositDate.date) {
  formattedDepositDate = { date: this.depositDate.date };
}

    if (this.batchPaymentForm) {
      //  Always patch payment type and batch date
      const patchData: any = {
        paymentType: 'E',
        batchDate: formattedBatchDate,
         batchType: 'I'
      };

      //  Only add checkNo & checkDate if found in global list
      if (isCheckInList) {
        patchData.checkNo = tempCheckNo;
        patchData.checkDate = formattedCheckDate;
      }

      if (formattedDepositDate) {
        patchData.depositDate = formattedDepositDate; // only if selected
      }
      this.batchPaymentForm.patchValue(patchData);

      // Disable relevant fields
      this.batchPaymentForm.get('paymentType').disable();
        this.batchPaymentForm.get('batchType').disable(); 
      if (isCheckInList) {
        this.batchPaymentForm.get('checkNo').disable();
      }

      this.chRef.detectChanges();
    }
  }, 0);
}


closeBatchModal() {
  if (this.modalRef) {
    this.modalRef.hide();
  }
}

onDateChanged(event: any, controlName: string) {
  this.batchPaymentForm.get(controlName).setValue(event.formatted || '');
}

allowNumbersWithDecimal(event: KeyboardEvent) {
  const pattern = /^[0-9.]$/;
  if (!pattern.test(event.key)) {
    event.preventDefault();
  }
}
  onSubmitBatch() {
  const paymentType = this.batchPaymentForm.get('paymentType').value;

  // Step 1: Apply validators
  if (paymentType === 'K' || paymentType === 'E') {
    this.batchPaymentForm.get('checkNo').setValidators([Validators.required]);
    this.batchPaymentForm.get('checkDate').setValidators([Validators.required]);
  } else {
    this.batchPaymentForm.get('checkNo').clearValidators();
    this.batchPaymentForm.get('checkDate').clearValidators();
  }

  if (paymentType === 'E') {
    this.batchPaymentForm.get('depositDate').setValidators([Validators.required]);
  } else {
    this.batchPaymentForm.get('depositDate').clearValidators();
  }

  this.batchPaymentForm.get('checkNo').updateValueAndValidity();
  this.batchPaymentForm.get('checkDate').updateValueAndValidity();
  this.batchPaymentForm.get('depositDate').updateValueAndValidity();

  // Step 2: Validate form
  if (this.batchPaymentForm.invalid) {
    this.toastService.warning('Please fill all required fields.', 'Validation');
    return;
  }

  // Step 3: Prepare variables
  const batchId = this.batchPaymentForm.value.batchId || 0;
  const checkNo = this.batchPaymentForm.getRawValue().checkNo; 
  const practiceCode = this.gv.currentUser.selectedPractice.PracticeCode;

  const batchDateValue = this.batchPaymentForm.value.batchDate;
  let batchMonth: number = null;
  let batchYear: number = null;

  if (batchDateValue.date) {
    batchMonth = batchDateValue.date.month;
    batchYear = batchDateValue.date.year;
  }

  const BatchOpenDate = `${batchMonth}/01/${batchYear}`;

  // Step 4: Duplicate Check Validation for ERA
  if (paymentType === 'E') {
    this.API.getData(
      `/Payments/ValidateCheckNo?CheckNo=${checkNo}&Practice_Code=${practiceCode}&BatchOpenDate=${BatchOpenDate}&PaymentType=${paymentType}&BatchID=${batchId}`
    ).subscribe(
      (response: any) => {
        if (response.Status === 'Duplicate') {
          swal(
            'Error',
            'A batch with this Check No already exists for this month. Please choose another Check No.',
            'error'
          );
          return;
        }
        this.saveBatch(batchId, practiceCode);
      },
      (error) => {
        this.toastService.error('Error validating Check No.', 'Error');
      }
    );
  } else {
    this.saveBatch(batchId, practiceCode);
  }
}

// Save Batch Helper
saveBatch(batchId: number, practiceCode: number) {
  const rawForm = this.batchPaymentForm.getRawValue(); //  includes disabled fields

  const checkDateValue = rawForm.checkDate;
  let formattedCheckDate: string = null;

  if (checkDateValue.date) {
    const { year, month, day } = checkDateValue.date;
    formattedCheckDate = `${month}/${day}/${year}`;
  }
let batchOpenDateFormatted = null;
const batchDateValue = rawForm.batchDate;

if (batchDateValue) {
  if (batchDateValue.formatted) {
    batchOpenDateFormatted = batchDateValue.formatted;
  } else if (batchDateValue.date) {
    const { year, month, day } = batchDateValue.date;
    batchOpenDateFormatted = `${month}/${day}/${year}`;
  }
}
 // Format Deposit Date (fixed)
  let depositDateFormatted: string = null;
  const depositDateValue = rawForm.depositDate;
  if (depositDateValue) {
    if (depositDateValue.formatted) {
      depositDateFormatted = depositDateValue.formatted;
    } else if (depositDateValue.date) {
      const { year, month, day } = depositDateValue.date;
      depositDateFormatted = `${month}/${day}/${year}`;
    }
  }
  const formData = {
    BatchID: batchId,
    BatchType: rawForm.batchType,
    PaymentType: rawForm.paymentType,
    CheckNo: rawForm.checkNo || null,
    CheckDate: formattedCheckDate,
    FileName: rawForm.fileName,
    BatchOpenDate:batchOpenDateFormatted,
    // DepositDate: rawForm.depositDate ? rawForm.depositDate.formatted : null,
    DepositDate: depositDateFormatted,  
    ReceivedDate: rawForm.receivedDate ? rawForm.receivedDate.formatted : null,
    Notes: rawForm.note || null,
    BatchAmount: rawForm.batchAmount,
    BatchStatus: 1,
    RemainingAmount: rawForm.batchAmount,
    PostedAmount: 0,
    Practice_Code: practiceCode
  };

  const endpoint = '/Payments/CreateUpdateBatch';
  const successMessage =
    batchId > 0
      ? 'Batch has been updated successfully.'
      : 'Batch has been created successfully.';

  this.API.PostData(endpoint, formData,
    (response) => {
      if (response.Status === 'Success') {
        swal('Batch', successMessage, 'success');
        this.fetchBatchPayment(rawForm.checkNo);
        this.closeBatchModal();
        this.batchPaymentForm.reset();
      }
    },
    (error) => {
      this.toastService.error('Error while saving the batch.', 'Error');
    }
  );
}

getEraCheckDetails(): void {
  console.log('getEraCheckDetails() called');
  const practiceCode = this.gv.currentUser.selectedPractice.PracticeCode;
  console.log('Practice Code:', practiceCode);

  this.API.getData(`/Submission/GetERACheckDetails?practice_id=${practiceCode}`).subscribe(response=> {
      console.log('API Response:', response);
      if (response.Status === 'Success') {
        this.eraCheckList = response.Response.map((item: any) => ({
          CHECKNUMBER: item.CHECKNUMBER,
            CHECKDATE: item.CHECKDATE,
        }));
                //  Save globally for reuse later
        this.allEraChecks = [...this.eraCheckList];
        console.log('All ERA Checks Saved:', this.allEraChecks);

      } else {
        this.eraCheckList = [];
          this.allEraChecks = [];  // clear if failed
        this.toastService.error('Failed to fetch ERA Check details', response.Status);
      }
    },
    (error: any) => {
      console.error('API Error:', error);
      this.toastService.error('API Error', error.message);
    }
  );
}

onSelectCheckNo(selectedCheckNumber: string): void {
  console.log('Selected Check Number:', selectedCheckNumber);

  // Find the full object in the eraCheckList based on CHECKNUMBER
  const selectedItem = this.eraCheckList.find(
    (item: any) => item.CHECKNUMBER === selectedCheckNumber
  );

  if (selectedItem && selectedItem.CHECKDATE) {
    console.log('Full Selected Item:', selectedItem);

    // Convert the string date into the format required by my-date-picker
    const dateObj = new Date(selectedItem.CHECKDATE);
    const formattedDate = {
      date: {
        year: dateObj.getFullYear(),
        month: dateObj.getMonth() + 1,
        day: dateObj.getDate()
      }
    };

    //  Patch form fields
    this.batchPaymentForm.patchValue({
      checkNo: selectedItem.CHECKNUMBER,
      checkDate: formattedDate,

    });

    console.log('Auto-filled Check Date:', formattedDate);
  } else {
    console.warn('Selected check not found or CHECKDATE missing');
  }
}

}

