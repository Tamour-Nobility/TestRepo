import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Common } from '../../services/common/common';
import { EraSummaryDetailsResponse } from '../models/era-claim-details-response.model';

declare var $: any;

import { APIService } from '../../components/services/api.service';
@Component({
  selector: 'app-era-viewer',
  templateUrl: './era-viewer.component.html',
  styleUrls: ['./era-viewer.component.css'],
  encapsulation: ViewEncapsulation.Emulated
})
export class ERAViewer implements OnInit {
  eraId: number;
  
  data: EraSummaryDetailsResponse;
  constructor(private route: ActivatedRoute,
    private toastService: ToastrService,
    private API: APIService
  ) {
    this.data = new EraSummaryDetailsResponse();
    this.data.era = null;
  }

  code: number = 0; // Default value for the code
  description: string = ''; // To store the description

  // Define the mapping of codes to descriptions in the component
  private codeDescriptionMap = {
    1: 'Processed as Primary',
    2: 'Processed as Secondary',
    3: 'Processed as Tertiary',
    4: 'The claim has been denied.',
    19: 'Processed as Primary, Forwarded to Additional Payer(s)',
    20: 'Processed as Secondary, Forwarded to Additional Payer(s)',
    21: 'Processed as Tertiary, Forwarded to Additional Payer(s)',
    22: 'Reversal of Previous Payment',
    23: 'Not Our Claim, Forwarded to Additional Payer(s)',
    25: 'Predetermination Pricing Only - No Payment'
  };



  ngOnInit() {
    this.route.params.subscribe(params => {
      if (params['id'] !== 0 && params['id'] !== '0') {
        this.eraId = params['id'];
        this.getEraDetails();
      }
    });
    // this.getDescription();
    console.log("hfgsdfdhgdfgdjfghdjfg",this.description)
  }

  getDescription(ClaimProcessedas) {
    this.description = this.codeDescriptionMap[ClaimProcessedas] || 'Code not found';
  }

  getEraDetails() {
    this.data = new EraSummaryDetailsResponse();
    this.data.era = null;
    if (!Common.isNullOrEmpty(this.eraId)) {
      this.API.PostData('/Submission/EraSummary', { eraId: this.eraId }, (res) => {
        if (res.Status == "success")
          this.data = res.Response;
        else if (res.Status === 'invalid-era-id')
          this.toastService.error('Please provide valid ERA Id', 'Invalid ERA Id');
        else
          this.toastService.error('An error occurred', 'Error');
      });
    } else {
      this.toastService.error('Invalid ERA Id');
    }
  }

  getAdjustmentAmount(amt1, amt2) {
    return parseFloat(amt1) + parseFloat(amt2);
  }
}