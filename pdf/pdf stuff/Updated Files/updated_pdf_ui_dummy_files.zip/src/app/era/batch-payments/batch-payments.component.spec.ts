import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BatchPaymentsComponent } from './batch-payments.component';

describe('BatchPaymentsComponent', () => {
  let component: BatchPaymentsComponent;
  let fixture: ComponentFixture<BatchPaymentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BatchPaymentsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BatchPaymentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
