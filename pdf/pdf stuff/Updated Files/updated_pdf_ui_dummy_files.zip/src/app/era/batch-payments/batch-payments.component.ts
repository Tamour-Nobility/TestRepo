import { ChangeDetectorRef, Component, ElementRef, HostListener, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { IMyDate, IMyDrpOptions, } from 'mydaterangepicker';
import { IMyOptions, IMyDateModel } from 'mydatepicker';
import { Common } from '../../services/common/common';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { APIService } from '../../components/services/api.service';
import { PaymentAdvisoryComponent } from '../../payment/payment-advisory/payment-advisory/payment-advisory.component';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { SelectListViewModel } from '../../models/common/selectList.model';
import { TreeviewItem, TreeviewConfig } from 'ngx-treeview';
import { IMyDrpOptions as IMyDateRangePickerOptions } from 'mydaterangepicker'; // for range
import { DatePipe } from '@angular/common';
import { GvarsService } from '../../services/G_vars/gvars.service';
import * as moment from 'moment';
import { BatchStateService } from '../../services/batch-state.service';
import { CurrentUserViewModel } from '../../models/auth/auth';
import { ActivatedRoute, NavigationStart, Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { User } from '../../user-management/classes/requestResponse';
import { ModalControllerService } from '../../shared/modal-controller.service';

@Component({
  selector: 'app-batch-payments',
  templateUrl: './batch-payments.component.html',
  styleUrls: ['./batch-payments.component.css']
})
export class BatchPaymentsComponent implements OnInit {
  isPayExpand: boolean = false;
  selectedUser: any = null;
  showPostedByDropdown = true;
  ShowPayBtn: boolean = true;
  searchBatchForm: FormGroup; // Separate search form
  dataPayments: any[] = []; // Holds search results
  isSearchInitiated: boolean = false;
  remainingAmount: number;
  allPayments: any[] = [];
  postedAmount: number;
  batchRemainingAmount: number;
  modalTitle: string = 'New Batch'; // Default title
  buttonLabel: string = 'Save';
  today = new Date();
  isLoading = false;
  practiceCode = this.GV.currentUser.selectedPractice.PracticeCode;
  usersSelectList: User[];
  userSelectListBackup: User[];
  items: TreeviewItem[];
  batchStatus: boolean;
  batchPaymentForm: FormGroup;
  patientPaymentModalRef: BsModalRef;
  paymentAdvisoryModalRef: BsModalRef;
  paymentModalRef : BsModalRef;
  loggedInUser: CurrentUserViewModel;


  currentUser: CurrentUserViewModel;
  isSetup: boolean = false;
  savedBatch: any = null;
  isBatchUpdated: boolean = false;
  isSwalOpen: boolean = false;
  isEditDisabled: boolean = false;
  userSelectListFormattedBackup: any[] = [];


  public myDatePickerOptions: IMyDrpOptions = {
    dateFormat: 'mm/dd/yyyy', height: '25px', width: '100%',
    disableSince: {
      year: this.today.getFullYear(),
      month: this.today.getMonth() + 1,
      day: this.today.getDate() + 1,
    }
  };
  public myDateRangePickerOptions: IMyDateRangePickerOptions = {
    dateFormat: 'mm/dd/yyyy',
    height: '24px',
    width: '100%',
    // Disable future dates
    disableSince: {
      year: this.today.getFullYear(),
      month: this.today.getMonth() + 1,
      day: this.today.getDate() + 1,
    }
  };
  selDateDOB: IMyDate = {
    day: 0,
    month: 0,
    year: 0
  };
  advisoryOpendFrom: string;
  batchType = [
    { value: 'I', name: 'Insurance' },
    { value: 'P', name: 'Patient' },
    { value: 'B', name: 'Both' }
  ];

  paymentType = [
    { value: 'C', name: 'Cash' },
    { value: 'K', name: 'Check' },
    { value: 'R', name: 'Credit' },
    { value: 'EFT', name: 'EFT' },
    { value: 'Lgb', name: 'Lock Box' },
    { value: 'E', name: 'ERA' },
    { value: 'O', name: 'Other' }
  ];
  PaymentStatus = [
    { value: 'AB', name: 'All Batches' },
    { value: 'APP', name: 'All Posted Payments' },
    { value: 'AUP', name: 'All Unposted Payments' },
  ];
  batchTypeMap: any = {
    I: 'Insurance',
    P: 'Patient',
    B: 'Both',
  };
  paymentTypeMap: any = {
    C: 'Cash',
    K: 'Check',
    R: 'Credit',
    EFT: 'EFT',
    Lgb: 'Lock Box',
    E: 'ERA',
    O: 'Other'
  };

  @ViewChild('PAC') PAC: PaymentAdvisoryComponent;
  @ViewChild('postedByUserRef') postedByUserRef: any;
  @ViewChild('postedByUserRef', { read: ElementRef }) postedByUserInputRef: ElementRef;
  @ViewChild('setups') setups: ElementRef;
  @ViewChild('patientPaymentModalTemplate') patientPaymentModalTemplate: TemplateRef<any>;
  @ViewChild('paymentAdvisoryModalTemplate') paymentAdvisoryModalTemplate: TemplateRef<any>;
  @ViewChild('paymentModalTemplate') paymentModalTemplate: TemplateRef<any>;

  dataTableBatchSearch: any;
  selectedBatch: any;
  isPaymentAdvisoryDisabled: boolean;
  isPostedClaimsDisabled: boolean;
  isReadOnly: boolean;
  eraCheckList: any[] = [];
  selectedCheckNo: string | null = null;
  savedBatchFormData: any = null;
  advisoryBtn: number;
  isAdvisoryDisabled: boolean = false;
  showInputForCheckNo: boolean = false;
  claimNo:number=0;
  paymentBatchStatus:string;
  batchNumber:number=0;
  updateBatchDisable:boolean=false

  constructor(private modalService: BsModalService,
    private route: ActivatedRoute,
    private API: APIService,
    private fb: FormBuilder,
    private GV: GvarsService,
    private chRef: ChangeDetectorRef,
    private toaster: ToastrService,
    private apiService: APIService,
    private router: Router,
    private spinner: NgxSpinnerService,
    private batchDataService: BatchStateService,
    private modalController: ModalControllerService,
    private modalCleanup: ModalControllerService,
    public datepipe: DatePipe

  ) {
    this.usersSelectList = [];
    this.items = [];
    this.userSelectListBackup = [];
    this.router.events.subscribe(event => {
      if (event instanceof NavigationStart) {
        this.modalController.closeAll();  // This closes EVERY modal instantly
      }
    });
  }
  @HostListener('window:popstate', ['$event'])
  onBrowserBack() {
    this.modalCleanup.closeAllModals();
  }

  ngOnInit() {
    this.updateBatchDisable=false
    this.GetUsers();
    this.initializeForm();
  
    // Detect query param
    this.route.queryParams.subscribe(params => {
      if (params['openModal'] === 'true') {
        setTimeout(() => {
          this.onAddPatientPayment(this.patientPaymentModalTemplate);
          // Remove param after modal opens
          this.router.navigate([], { queryParams: { openModal: null }, queryParamsHandling: 'merge' });
        }, 300);
      }
    });
    // Use BatchDateRange instead of BatchDateFrom & BatchDateTo
    this.searchBatchForm = this.fb.group({
      Practice_Code: this.practiceCode,
      BatchID: ['', [Validators.pattern('^[0-9]*$')]],
      FileName: [''],
      BatchStatus: [''],
      BatchType: [''],
      PostedBy: [''],
      PaymentType: [''],
      PaymentStatus: [''],
      checkNo: [''],
      CheckDate: [''],
      BatchDateRange: [null],

    });

    this.batchDataService.remainingAmount$.subscribe(amount => {
      this.remainingAmount = amount;
      // this.isCloseBatchDisabled = this.remainingAmount !== 0;
    });
  this.route.queryParams.subscribe(params => {
    const encodedData = params['data'];
    if (encodedData) {
      const payload = JSON.parse(Common.decodeBase64(encodedData));
      if (payload.fromPaymentScreen) {
        this.updateBatchDisable=true
        this.claimNo = payload.claimNo;
        this.paymentBatchStatus="paymentBatch"
        this.setCurrentMonthDateRange();
        this.onLookUp();
      }


    }
  });
    this.getEraCheckDetails();
  }
  ngOnDestroy() {
    this.modalCleanup.closeAllModals();
  }
  initializeDefaultFiltersForBatchPayments() {
    const today = new Date();
    const firstDay = new Date(today.getFullYear(), today.getMonth(), 1);
    this.searchBatchForm.patchValue({
      BatchDateRange: {
        beginDate: {
          year: firstDay.getFullYear(),
          month: firstDay.getMonth() + 1,
          day: firstDay.getDate(),
        },
        endDate: {
          year: today.getFullYear(),
          month: today.getMonth() + 1,
          day: today.getDate(),
        },
      },
      BatchStatus: '',  // All statuses
      BatchType: '',    // All types
    });
  }

  initializeForm() {
    this.batchPaymentForm = this.fb.group({
      batchId: [''],
      batchType: ['', Validators.required],
      fileName: ['', Validators.required],
      paymentType: ['', Validators.required],
      checkNo: [''],
      checkDate: [''],
      // batchAmount: ['', [Validators.required, Validators.pattern('^[0-9]*$')]],
      batchAmount: ['', [Validators.required, Validators.pattern(/^\d+(\.\d{1,2})?$/)]],
      depositDate: [''],
      batchDate: [''],
      receivedDate: [''],
      note: ['']
    });
    this.onPaymentTypeChange();
  }
  onPaymentTypeChange() {
    this.batchPaymentForm.get('paymentType').valueChanges.subscribe(value => {
      const checkNoControl = this.batchPaymentForm.get('checkNo');
      const checkDateControl = this.batchPaymentForm.get('checkDate');

      if (value === 'K') {
        checkNoControl.setValidators([Validators.required]);
        checkDateControl.setValidators([Validators.required]);
      } else {
        checkNoControl.clearValidators();
        checkDateControl.clearValidators();
      }

      checkNoControl.updateValueAndValidity();
      checkDateControl.updateValueAndValidity();
    });
  }

  setDate(date: string) {
    if (!Common.isNullOrEmpty(date)) {
      let dDate = new Date(date);
      this.selDateDOB = {
        year: dDate.getFullYear(),
        month: dDate.getMonth() + 1,
        day: dDate.getDate()
      };
    }
  }
  onDateChanged(event: any, controlName: string) {
    if (event && event.jsdate) {
      this.batchPaymentForm.patchValue({
        [controlName]: event.jsdate // Store the actual Date object
      });
    }
  }
  allowOnlyNumbers(event: KeyboardEvent) {
    const charCode = event.key.charCodeAt(0);
    // Allow only digits (0-9)
    if (charCode < 48 || charCode > 57) {
      event.preventDefault();
    }
  }
  allowNumbersWithDecimal(event: KeyboardEvent) {
    const input = event.target as HTMLInputElement;
    const char = event.key;

    // Allow digits
    if (/[0-9]/.test(char)) {
      // If there's a decimal, check digits after it
      const value = input.value;
      const decimalIndex = value.indexOf('.');
      if (decimalIndex >= 0) {
        const decimals = value.substring(decimalIndex + 1);
        if (decimals.length >= 2 && input.selectionStart > decimalIndex) {
          event.preventDefault(); // Block if already 2 decimals
        }
      }
      return;
    }

    // Allow one decimal point
    if (char === '.') {
      if (input.value.includes('.')) {
        event.preventDefault(); // Block multiple dots
      }
      return;
    }
    // Block everything else
    event.preventDefault();
  }

  allowOnlyAlphaNumeric(event: KeyboardEvent) {
    const char = event.key;
    // Allowed special characters for cheque numbers
    const allowedSpecialChars = ['-', '_', '/', '.', ' '];
    const isAlphaNumeric = /^[a-zA-Z0-9]$/.test(char);
    const isAllowedSpecial = allowedSpecialChars.includes(char);
    const isControlKey =
      event.key === 'Backspace' ||
      event.key === 'Tab' ||
      event.key === 'Delete' ||
      event.key === 'ArrowLeft' ||
      event.key === 'ArrowRight';
    if (!isAlphaNumeric && !isAllowedSpecial && !isControlKey) {
      event.preventDefault();
    }
  }

  GetUsers(): any {
    this.API.getData('/UserManagementSetup/GetUsersList').subscribe(data => {
      if (data.Status === 'Success') {
        // Keep raw response for future filtering
        this.userSelectListBackup = data.Response;
        // Create formatted list with DisplayLabel
        const users = data.Response.map((user: any) => ({
          ...user,
          DisplayLabel: `${user.UserName} | ${user.FirstName} ${user.LastName}`
        }));

        // Create final dropdown list
        this.usersSelectList = [
          { UserId: null, DisplayLabel: 'Select User' },
          ...users
        ];
        // Keep formatted list backup as well
        this.userSelectListFormattedBackup = this.usersSelectList;
      }
    });
  }

  onTypeUsers(value: string) {
    const search = (value || '').trim().toLowerCase();
    if (!search) {
      this.usersSelectList = JSON.parse(JSON.stringify(this.userSelectListBackup));
      return;
    }

    this.usersSelectList = this.userSelectListBackup.filter(u => {

      // Convert all possible fields to lowercase strings
      const firstName = (u.FirstName || '').toLowerCase();
      const lastName = (u.LastName || '').toLowerCase();
      const userName = (u.UserName || '').toLowerCase();
      const email = (u.Email || '').toLowerCase();
      const empId = (u.Empid ? u.Empid.toString() : '').toLowerCase();

      // Combine them into one searchable text block
      const fullText = `${firstName} ${lastName} ${userName} ${email} ${empId}`;

      return fullText.includes(search);
    });

    this.usersSelectList = JSON.parse(JSON.stringify(this.usersSelectList));
  }
  onSelectUser(event: any) {
    if (typeof event === 'string' || typeof event === 'number') {
      this.searchBatchForm.patchValue({ PostedBy: event });
    }
    // If it's an object
    else if (event && event.Id) {
      this.searchBatchForm.patchValue({ PostedBy: event.Id });
    } else {
      console.warn('Unexpected value received in onSelectUser:', event);
    }
  }

  onSubmit() {
    const paymentType = this.batchPaymentForm.get('paymentType').value;

    // --- Step 1: Apply validators dynamically ---
    if (paymentType === 'K' || paymentType === 'E') {
      this.batchPaymentForm.get('checkNo').setValidators([Validators.required]);
      this.batchPaymentForm.get('checkDate').setValidators([Validators.required]);
    } else {
      this.batchPaymentForm.get('checkNo').clearValidators();
      this.batchPaymentForm.get('checkDate').clearValidators();
    }

    if (paymentType === 'E') {
      this.batchPaymentForm.get('depositDate').setValidators([Validators.required]);
      this.batchPaymentForm.patchValue({ batchType: 'I' }); // auto set batchType
    } else {
      this.batchPaymentForm.get('depositDate').clearValidators();
    }

    // Update validity after dynamic changes
    this.batchPaymentForm.get('checkNo').updateValueAndValidity();
    this.batchPaymentForm.get('checkDate').updateValueAndValidity();
    this.batchPaymentForm.get('depositDate').updateValueAndValidity();

    // --- Step 2: Validate form ---
    if (this.batchPaymentForm.invalid) {
      this.toaster.warning('Please fill all required fields.', 'Validation');
      return;
    }

    // --- Step 3: Extract form values (including disabled fields) ---
    const formValues = this.batchPaymentForm.getRawValue(); // includes disabled fields
    const batchId = formValues.batchId || 0;
    const checkNo = formValues.checkNo;
    const practiceCode = this.GV.currentUser.selectedPractice.PracticeCode;

    // --- Step 4: Handle batchDate ---
    const batchDateValue = formValues.batchDate;
    let batchMonth: number = null;
    let batchYear: number = null;

    if (batchDateValue) {
      if (batchDateValue.formatted) {
        const dateObj = new Date(batchDateValue.formatted);
        batchMonth = dateObj.getMonth() + 1;
        batchYear = dateObj.getFullYear();
      } else if (batchDateValue.date) {
        batchMonth = batchDateValue.date.month;
        batchYear = batchDateValue.date.year;
      }
    }

    const BatchOpenDate = `${batchMonth}/01/${batchYear}`;

    // --- Step 5: Call Validation API if paymentType is 'E' ---
    if (paymentType === 'E') {
      this.API.getData(
        `/Payments/ValidateCheckNo?CheckNo=${checkNo}&Practice_Code=${practiceCode}&BatchOpenDate=${BatchOpenDate}&PaymentType=${paymentType}&BatchID=${batchId}`
      ).subscribe(
        (response: any) => {
          if (response.Status === 'Duplicate') {
            this.isSwalOpen = true;

            // Temporarily disable all except batchDate
            Object.keys(this.batchPaymentForm.controls).forEach((control) => {
              if (control !== 'batchDate') this.batchPaymentForm.get(control).disable();
            });

            swal({
              title: 'Error',
              text: 'A batch with this Check No is already used in the same month. Please pick a different Check No.',
              type: 'error',
              allowOutsideClick: false,
              allowEscapeKey: false,
            }).then(() => {
              this.isSwalOpen = false;
              // Re-enable all except batchDate
              Object.keys(this.batchPaymentForm.controls).forEach((control) => {
                if (control !== 'batchDate') this.batchPaymentForm.get(control).enable();
              });
            });

            return; // stop further execution
          } else {
            // Proceed to save if not duplicate
            this.saveBatch(batchId, practiceCode, formValues);
          }
        },
        (error) => {
          this.toaster.error('Error validating Check No.', 'Error');
        }
      );
    } else {
      // PaymentType not 'E', directly save
      this.saveBatch(batchId, practiceCode, formValues);
    }
  }

  // Helper function to handle batch save
 saveBatch(batchId: number, practiceCode: number, formValues: any) {
  const formatDateField = (dateField: any) => {
    if (!dateField) return null;
    if (dateField.formatted) return dateField.formatted;
    if (dateField.date) {
      const { year, month, day } = dateField.date;
      return `${month}/${day}/${year}`;
    }
    return null;
  };

  const formData = {
    BatchID: batchId,
    BatchType: formValues.batchType,
    PaymentType: formValues.paymentType,
    CheckNo: formValues.checkNo || null,
    CheckDate: formatDateField(formValues.checkDate),
    FileName: formValues.fileName,
    BatchOpenDate: formatDateField(formValues.batchDate),
    DepositDate: formatDateField(formValues.depositDate),
    ReceivedDate: formatDateField(formValues.receivedDate),
    Notes: formValues.note || null,
    BatchAmount: formValues.batchAmount,
    BatchStatus: 1,
    RemainingAmount: formValues.batchAmount,
    PostedAmount: 0,
    Practice_Code: practiceCode
  };

  const endpoint = '/Payments/CreateUpdateBatch';
  const successMessage = batchId > 0
    ? 'Batch has been updated successfully.'
    : 'Batch has been created successfully.';

  this.API.PostData(
    endpoint,
    formData,
    (response) => {
      if (response.Status === 'Success') {
        debugger;

        if (this.claimNo == 0) {
          this.modalController.unregister(this.patientPaymentModalRef);
          this.patientPaymentModalRef.hide();
          this.batchPaymentForm.reset();
          this.onClear();
        }

        swal('Batch', successMessage, 'success').then(() => {

          if (this.claimNo != 0) {
               this.modalController.unregister(this.patientPaymentModalRef);
          this.patientPaymentModalRef.hide();
             this.savedBatch = {
                      ...this.savedBatch,
                      BatchID:   response.Response.BatchID,
                      CheckNo:   formValues.checkNo,
                      BatchType: formValues.batchType,
                      FileName:  formValues.fileName,
                      DepositDate: formatDateField(formValues.depositDate),
                      BatchAmount:formValues.batchAmount,  


    };
                     this.postedAmount=0;
                     this.remainingAmount=formValues.batchAmount;
                     this.claimNo=this.claimNo;


            this.paymentAdvisoryModalRef = this.modalService.show(this.paymentAdvisoryModalTemplate, {
            class: 'modal-xlg',
            backdrop: 'static',
            keyboard: false,
      });
      this.modalController.register(this.paymentAdvisoryModalRef);
        
          } else {
            window.location.reload();
          }

        });
      }
    },
    (error) => {
      this.toaster.error('Error while saving the batch.', 'Error');
    }
  );
}


  onClear() {
    this.chRef.detectChanges();
    this.isSearchInitiated = false;
    if (this.dataTableBatchSearch) {
      this.dataTableBatchSearch.destroy();
    }
    this.dataPayments = [];
    this.isPayExpand = false;
    this.searchBatchForm.reset({
      Practice_Code: this.practiceCode,
      BatchID: '',
      FileName: '',
      BatchStatus: '',
      BatchType: '',
      PaymentType: '',
      PaymentStatus: '',
      checkNo: '',
      CheckDate: '',
      // BatchDateFrom: '',
      // BatchDateTo: ''
      BatchDateRange: null
    });
    // Reset selected user
    this.selectedUser = null;
    this.usersSelectList = [...this.userSelectListBackup];
    // Force destroy and re-create ngx-select (this clears everything visually and internally)
    this.showPostedByDropdown = false;
    setTimeout(() => {
      this.showPostedByDropdown = true;
    }, 10);
    this.modalController.unregister(this.patientPaymentModalRef);
    this.patientPaymentModalRef.hide();
  }

  onCloseModal() {
    this.chRef.detectChanges();
    this.isSearchInitiated = false;
    this.modalController.unregister(this.patientPaymentModalRef);
    this.patientPaymentModalRef.hide();
  }

  onAddPatientPayment(template: TemplateRef<any>) {
    this.batchPaymentForm.reset(); // Clear previous data
    this.modalTitle = 'Add New Batch'; // Set title for new batch
    this.buttonLabel = 'Save';
    this.isReadOnly = false; // Reset read-only mode for Add New
    this.advisoryBtn = null;
    // Format date as MM/DD/YYYY
    const today = new Date();
    const batchDateValue = {
      date: {
        year: today.getFullYear(),
        month: today.getMonth() + 1, // Months are 0-based in JS
        day: today.getDate()
      },
      jsdate: today,
      formatted: `${(today.getMonth() + 1).toString().padStart(2, '0')}/` +
        `${today.getDate().toString().padStart(2, '0')}/` +
        `${today.getFullYear()}`
    };

    this.batchPaymentForm.get('batchDate').setValue(batchDateValue);
    // Ensure all form fields are enabled
    Object.keys(this.batchPaymentForm.controls).forEach(field => {
      this.batchPaymentForm.get(field).enable();
    });

    //  Auto-select Batch Type = Insurance when Payment Type = ERA
    this.batchPaymentForm.get('paymentType').valueChanges.subscribe((value: string) => {
      if (value === 'E') {
        this.batchPaymentForm.get('batchType').setValue('I');
        this.batchPaymentForm.get('batchType').disable(); // Lock it
      } else {
        this.batchPaymentForm.get('batchType').enable(); // Unlock for others
      }
    });

    this.patientPaymentModalRef = this.modalService.show(template, {
      class: 'modal-xlg', backdrop: 'static',
      keyboard: false
    });
    this.modalController.register(this.patientPaymentModalRef);
  }

openPaymentAdvisoryModal() {
  //  Prevent double clicks
  if (this.isAdvisoryDisabled) return;
  this.isAdvisoryDisabled = true;
  try {
    // Close the first modal if it’s open
    if (this.patientPaymentModalRef) {
      this.modalController.unregister(this.patientPaymentModalRef);
      this.patientPaymentModalRef.hide();
    }
    const firstModal = document.querySelector('.modal.show .modal-content');
    if (firstModal) {
      firstModal.classList.add('blur-content');
    }
    const selectedBatchId = this.batchPaymentForm.getRawValue().batchId;
    const searchParams: any = { ...this.searchBatchForm.value };
    if (searchParams.BatchStatus === 'open') {
      searchParams.BatchStatus = 1;
    } else if (searchParams.BatchStatus === 'closed') {
      searchParams.BatchStatus = 0;
    } else if (searchParams.BatchStatus === 'reopened') {
      searchParams.BatchStatus = 2;
    } else if (searchParams.BatchStatus === 'autoClosed') {
      searchParams.BatchStatus = 3;
    }

    const { from, to } = this.extractDateRange(this.searchBatchForm.value.BatchDateRange);
    searchParams.BatchDateFrom = from;
    searchParams.BatchDateTo = to;
    searchParams.CheckDate = this.formatDates(this.searchBatchForm.value.CheckDate);
    delete searchParams.BatchDateRange;

    this.API.PostData('/Payments/SearchBatch', searchParams, (response) => {
      const dataPayments = (response.Status === 'Success' && response.Response.length > 0)
        ? response.Response
        : [];

      this.allPayments = dataPayments;

      const selectedPayment = dataPayments.find(p => p.BatchID === selectedBatchId);
      const remainingAmount = selectedPayment.Remaining_Amount || 0;
      this.batchStatus = selectedPayment.Batch_Status;

      const initialState = {
        batchId: selectedBatchId,
        batchType: this.batchPaymentForm.value.batchType,
        fileName: this.batchPaymentForm.value.fileName,
        depositDate: this.batchPaymentForm.value.depositDate,
        batchAmount: this.batchPaymentForm.value.batchAmount,
        postedAmount: this.postedAmount,
        remainingAmount: this.remainingAmount
      };

      // Open modal as before
      
        this.paymentAdvisoryModalRef = this.modalService.show(this.paymentAdvisoryModalTemplate, {
        class: 'modal-xlg',
        backdrop: 'static',
        keyboard: false,
        initialState
      });
      this.modalController.register(this.paymentAdvisoryModalRef);


   
    
    }, (error) => {
      console.error('Error fetching payment data:', error);
    });

  } 
  finally {
    setTimeout(() => {
      this.isAdvisoryDisabled = false;
    }, 1000);
  }
}

claimPaymentModelSkipHandling(){
this.openPaymentAdvisoryModal();
  // const batchId = this.batchPaymentForm.get('batchId').value;
  //   this.batchNumber=batchId
  // if (this.claimNo !== 0){

  //   this.opnePaymentModel();
  //   return;
  // }
  // else{
  //   this.openPaymentAdvisoryModal();

  // }

}
// opnePaymentModel(){
//   // try {
//   //   // Close the first modal if it’s open
//   //   if (this.patientPaymentModalRef) {
//   //     this.modalController.unregister(this.patientPaymentModalRef);
//   //     this.patientPaymentModalRef.hide();
//   //   }

//   //   const firstModal = document.querySelector('.modal.show .modal-content');
//   //   if (firstModal) {
//   //     firstModal.classList.add('blur-content');
//   //   }

//   //   const selectedBatchId = this.batchPaymentForm.getRawValue().batchId;
//   //   const searchParams: any = { ...this.searchBatchForm.value };

//   //   if (searchParams.BatchStatus === 'open') {
//   //     searchParams.BatchStatus = 1;
//   //   } else if (searchParams.BatchStatus === 'closed') {
//   //     searchParams.BatchStatus = 0;
//   //   } else if (searchParams.BatchStatus === 'reopened') {
//   //     searchParams.BatchStatus = 2;
//   //   } else if (searchParams.BatchStatus === 'autoClosed') {
//   //     searchParams.BatchStatus = 3;
//   //   }

//   //   const { from, to } = this.extractDateRange(this.searchBatchForm.value.BatchDateRange);
//   //   searchParams.BatchDateFrom = from;
//   //   searchParams.BatchDateTo = to;
//   //   searchParams.CheckDate = this.formatDates(this.searchBatchForm.value.CheckDate);
//   //   delete searchParams.BatchDateRange;

//   //   this.API.PostData('/Payments/SearchBatch', searchParams, (response) => {
//   //     const dataPayments = (response.Status === 'Success' && response.Response.length > 0)
//   //       ? response.Response
//   //       : [];

//   //     this.allPayments = dataPayments;

//   //     const selectedPayment = dataPayments.find(p => p.BatchID === selectedBatchId);
//   //     const remainingAmount = selectedPayment.Remaining_Amount || 0;
//   //     this.batchStatus = selectedPayment.Batch_Status;

//   //     const initialState = {
//   //       batchId: selectedBatchId,
//   //       batchType: this.batchPaymentForm.value.batchType,
//   //       fileName: this.batchPaymentForm.value.fileName,
//   //       depositDate: this.batchPaymentForm.value.depositDate,
//   //       batchAmount: this.batchPaymentForm.value.batchAmount,
//   //       postedAmount: this.postedAmount,
//   //       remainingAmount: this.remainingAmount
//   //     };

//   //     // Open modal as before
      
//   //       this.paymentModalRef = this.modalService.show(this.paymentModalTemplate, {
//   //       class: 'modal-xlg',
//   //       backdrop: 'static',
//   //       keyboard: false,
//   //       initialState
//   //     });
//   //     this.modalController.register(this.paymentModalRef);


   
    
//   //   }, (error) => {
//   //     console.error('Error fetching payment data:', error);
//   //   });

//   // } 
//   // finally {
//   //   setTimeout(() => {
//   //     this.isAdvisoryDisabled = false;
//   //   }, 1000);
//   // }
//   debugger
//    if (this.claimNo !== 0) {
//   const payload = {
//   claimNo: this.claimNo,
//   batchId:this.batchNumber
// };

// const encoded = Common.encodeBase64(JSON.stringify(payload));
// this.router.navigate(['/era/BatchPaymentAdvisory'], {
//   queryParams: {
//     data: encoded
//   }
// });
// // if (this.patientPaymentModalRef) {
// //       this.modalController.unregister(this.patientPaymentModalRef);
// //       this.patientPaymentModalRef.hide();
// //     }
//       return; // Exit the method, no modal
//     }

// }

  closeData() {
    // Hide Payment Advisory modal
    if (this.paymentAdvisoryModalRef) {
      this.paymentAdvisoryModalRef.hide();
    }

    // Revert form to saved DB values if batch was not updated
    if (!this.isBatchUpdated && this.savedBatch) {
      // Convert plain date strings to full object format
      const convertToDateObject = (dateValue: any) => {
        if (!dateValue) return null;
        try {
          const dateObj = new Date(dateValue);
          return {
            year: dateObj.getFullYear(),
            month: dateObj.getMonth() + 1,
            day: dateObj.getDate(),
            formatted: this.formatDateForApi(dateObj)
          };
        } catch {
          return null;
        }
      };

      const checkDateObj = convertToDateObject(this.savedBatch.CheckDate);
      const depositDateObj = convertToDateObject(this.savedBatch.DepositDate);
      const receivedDateObj = convertToDateObject(this.savedBatch.ReceivedDate);

      this.batchPaymentForm.patchValue({
        batchId: this.savedBatch.BatchID,
        batchType: this.savedBatch.BatchType,
        fileName: this.savedBatch.FileName,
        paymentType: this.savedBatch.PaymentType,
        checkNo: this.savedBatch.CheckNo,
        checkDate: checkDateObj,
        batchAmount: this.savedBatch.BatchAmount,
        depositDate: depositDateObj,
        receivedDate: receivedDateObj,
        note: this.savedBatch.NOtes
      });
    }
  }

  canSearch(): boolean {
    const formValues = this.searchBatchForm.value;
    const hasDateRange = formValues.BatchDateRange &&
      formValues.BatchDateRange.beginDate &&
      formValues.BatchDateRange.endDate;
    return !Common.isNullOrEmpty(formValues.BatchID) ||
      !Common.isNullOrEmpty(formValues.FileName) ||
      !Common.isNullOrEmpty(formValues.BatchType) ||
      !Common.isNullOrEmpty(formValues.PaymentType) ||
      !Common.isNullOrEmpty(formValues.PaymentStatus) ||
      !Common.isNullOrEmpty(formValues.PostedBy) ||
      !Common.isNullOrEmpty(formValues.BatchStatus) ||
      !Common.isNullOrEmpty(formValues.checkNo) ||
      !Common.isNullOrEmpty(formValues.CheckDate) ||
      hasDateRange;
  }

  formatDates(date: any): string | null {
    if (!date) return null;

    let ds: string;
    if (typeof date === 'object' && date.formatted) {
      ds = date.formatted;
    }
    else if (typeof date === 'string') {
      ds = date;
    }
    else {
      return null;
    }

    // now split the MM/DD/YYYY
    const parts = ds.split('/');
    if (parts.length !== 3) return null;
    let [month, day, year] = parts;

    // ensure two‑digit month/day
    month = month.padStart(2, '0');
    day = day.padStart(2, '0');

    return `${month}/${day}/${year}`;
  }
  extractDateRange(dateRange: any): { from: string | null, to: string | null } {
    if (!dateRange) return { from: null, to: null };

    const from = dateRange.beginJsDate
      ? this.formatDateForApi(dateRange.beginJsDate)
      : null;

    const to = dateRange.endJsDate
      ? this.formatDateForApi(dateRange.endJsDate)
      : null;

    return { from, to };
  }

  // Convert Date → MM/dd/yyyy for API
  formatDateForApi(date: Date): string {
    if (!date) return null;

    const month = (date.getMonth() + 1).toString().padStart(2, '0'); // ensure 2 digits
    const day = date.getDate().toString().padStart(2, '0');          // ensure 2 digits
    const year = date.getFullYear();

    return `${month}/${day}/${year}`;
  }


  formatDateToMMDDYYYY(date: any): string | null {
    if (!date) return null;

    // case 1: when you already have a JS Date
    if (date instanceof Date) {
      const month = date.getMonth() + 1; // JS months are 0-based
      const day = date.getDate();
      const year = date.getFullYear();
      return `${month}/${day}/${year}`;
    }

    // case 2: when coming from date picker object { year, month, day }
    if (date.year && date.month && date.day) {
      return `${date.month}/${date.day}/${date.year}`;
    }

    return null;
  }

  onLookUp() {
    //  First auto-close eligible batches
    if (this.canSearch()) {
      this.apiService.PostData('/Payments/AutoCloseEligibleBatches', {}, (res: any) => {
        // Optionally show success/error message
        if (res.Status === "Success") {
        } else {
          console.error(res.Response);
        }
      });
    }
    //  this.spinner.show();
    if (!this.canSearch()) {
      this.toaster.warning('Please provide search criteria', 'Invalid Search Criteria');
      // this.spinner.hide();
      return;
    }
    this.isLoading = true;
    const searchParams: any = { ...this.searchBatchForm.value };
    // const searchParams = this.searchBatchForm.value;
    if (searchParams.BatchStatus === 'open') {
      searchParams.BatchStatus = 1;
    } else if (searchParams.BatchStatus === 'closed') {
      searchParams.BatchStatus = 0;
    }
    else if (searchParams.BatchStatus === 'reopened') {
      searchParams.BatchStatus = 2;
    }
    else if (searchParams.BatchStatus === 'autoClosed') {
      searchParams.BatchStatus = 3;
    }
     else if (this.paymentBatchStatus === 'paymentBatch') {
      searchParams.BatchStatus = 100;
    }
    const { from, to } = this.extractDateRange(this.searchBatchForm.value.BatchDateRange);
    searchParams.BatchDateFrom = from;
    searchParams.BatchDateTo = to;
    delete searchParams.BatchDateRange; // API doesn’t need this
    searchParams.CheckDate = this.formatDates(this.searchBatchForm.value.CheckDate);
    this.API.PostData('/Payments/SearchBatch', searchParams,
      (response) => {
        this.isLoading = false;
        this.isSearchInitiated = true;
        if (this.dataTableBatchSearch) {
          this.dataTableBatchSearch.destroy();
          this.dataTableBatchSearch = null;
        }
        this.dataPayments = (response.Status === 'Success' && response.Response.length > 0) ? response.Response : [];
        const batchID = this.searchBatchForm.get('BatchID').value;
        this.batchNumber=batchID;
        this.formatDateEntryt();
        if (batchID) {

          const matchedBatch = this.dataPayments.find(p => p.BATCH_ID == batchID);
          this.batchRemainingAmount = matchedBatch ? matchedBatch.Remaining_Amount : 0;
        } else {
          // this.spinner.hide();
        }
        this.chRef.detectChanges();
        const table: any = $('.dataTableBatchSearch');
        this.dataTableBatchSearch = table.DataTable({
          columnDefs: [
            { orderable: false, targets: -1 }
          ],
          language: {
            emptyTable: "No data available"
          },
          //  order: [1, 'desc'],
        });
      },
      (error) => {
        this.isLoading = false;
        console.error('Error fetching batch payments:', error);
      }
    );
  }

  formatDateEntryt() {
    this.dataPayments.forEach(p => {
      if (p.BatchDate) {
        p.BatchDate = moment(p.BatchDate.substring(0, 10)).format("MM/DD/YYYY");
      }
      if (p.BatchOpenDate) {
        p.BatchOpenDate = moment(p.BatchOpenDate.substring(0, 10)).format("MM/DD/YYYY");
      }
      if (p.CheckDate) {
        p.CheckDate = moment(p.CheckDate.substring(0, 10)).format("MM/DD/YYYY");
      }
      if (p.DepositDate) {
        p.DepositDate = moment(p.DepositDate.substring(0, 10)).format("MM/DD/YYYY");
      }
      if (p.CreatedDate) {
        p.CreatedDate = moment(p.CreatedDate.substring(0, 10)).format("MM/DD/YYYY");
      }
      if (p.ReceivedDate) {
        p.ReceivedDate = moment(p.ReceivedDate.substring(0, 10)).format("MM/DD/YYYY");
      }
      if (p.date_modified) {
        p.date_modified = moment(p.date_modified.substring(0, 10)).format("MM/DD/YYYY");
      }
    });
  }

  onEditBatch(selectedBatch: any, patientPaymentModalRef: any, isViewOnly: boolean) {

    this.showInputForCheckNo = false;
    this.isEditDisabled = true;
    this.chRef.detectChanges();

    try {
      this.isReadOnly = isViewOnly;
      this.isBatchUpdated = false;
      this.savedBatch = { ...selectedBatch };
      this.selectedBatch = { ...selectedBatch };
      this.advisoryBtn = this.selectedBatch.BatchID;

      const batchID = this.searchBatchForm.get('BatchID').value;
      if (batchID) {
        this.remainingAmount = this.selectedBatch.Remaining_Amount;
      }

      let batchTypeTitle = '';
      switch (selectedBatch.BatchType) {
        case 'I': batchTypeTitle = 'Insurance'; break;
        case 'P': batchTypeTitle = 'Patient'; break;
        case 'B': batchTypeTitle = 'Both'; break;
      }

      this.modalTitle = isViewOnly ? batchTypeTitle : 'Edit Batch';
      this.buttonLabel = isViewOnly ? '' : 'Update';

      const depositDateObject = this.selectedBatch.DepositDate
        ? { formatted: moment(this.selectedBatch.DepositDate).format('MM/DD/YYYY') }
        : null;

      const receivedDateObject = this.selectedBatch.ReceivedDate
        ? { formatted: moment(this.selectedBatch.ReceivedDate).format('MM/DD/YYYY') }
        : null;

      const checkDateObject = this.selectedBatch.CheckDate
        ? { formatted: moment(this.selectedBatch.CheckDate).format('MM/DD/YYYY') }
        : null;

      const batchDateObject = this.selectedBatch.BatchOpenDate
        ? { formatted: moment(this.selectedBatch.BatchOpenDate).format('MM/DD/YYYY') }
        : null;

      const batchDateRange = this.selectedBatch.BatchDateFrom && this.selectedBatch.BatchDateTo
        ? [
          new Date(this.selectedBatch.BatchDateFrom),
          new Date(this.selectedBatch.BatchDateTo)
        ]
        : null;

      this.batchPaymentForm.patchValue({
        batchId: this.selectedBatch.BatchID,
        fileName: this.selectedBatch.FileName,
        BatchStatus: this.selectedBatch.BatchStatus,
        batchType: this.selectedBatch.BatchType,
        PostedBy: this.selectedBatch.PostedBy,
        paymentType: this.selectedBatch.PaymentType,
        PaymentStatus: this.selectedBatch.PaymentStatus,
        BatchDateRange: batchDateRange,
        batchDate: batchDateObject,
        batchAmount: this.selectedBatch.BatchAmount,
        note: this.selectedBatch.NOtes,
        checkNo: this.selectedBatch.CheckNo,
        checkDate: checkDateObject,
        receivedDate: receivedDateObject,
        depositDate: depositDateObject,
      });

      this.patientPaymentModalRef = this.modalService.show(patientPaymentModalRef, {
        class: 'modal-xlg',
        backdrop: 'static',
        keyboard: false
      });
      this.modalController.register(this.patientPaymentModalRef);

      if (this.isReadOnly) {
        this.batchPaymentForm.disable();
        this.batchPaymentForm.get('batchType').disable();
      } else {
        this.batchPaymentForm.enable();
      }

      // -------------------------
      // FIXED ERA PaymentType = 'E' logic
      // -------------------------
      setTimeout(() => {
        if (this.selectedBatch.PaymentType === 'E' && this.eraCheckList.length > 0) {
          const selectedCheckNo = this.selectedBatch.CheckNo;

          // Find the check in ERA list
          const checkInfo = this.eraCheckList.find(
            (item: any) =>
              String(item.CHECKNUMBER || item.CheckNumber).trim() ===
              String(selectedCheckNo || '').trim()
          );

          if (!checkInfo) {
            // Check not found → show disabled input if there is existing DB value
            if (selectedCheckNo && this.selectedBatch.CheckDate) {
              this.batchPaymentForm.get('paymentType').disable();
              this.batchPaymentForm.get('checkNo').disable();
              this.batchPaymentForm.get('checkDate').disable();
              this.batchPaymentForm.get('batchType').disable();
              this.showInputForCheckNo = true;
            } else {
              // No check yet → show dropdown
              this.showInputForCheckNo = false;
            }
          } else {
            // Check found → inspect POSTED status
            if (checkInfo.POSTED && checkInfo.POSTED !== 'U' && checkInfo.POSTED !== 'A') {
              this.batchPaymentForm.get('paymentType').disable();
              this.batchPaymentForm.get('checkNo').disable();
              this.batchPaymentForm.get('checkDate').disable();
              this.batchPaymentForm.get('batchType').disable();
              this.showInputForCheckNo = true; // show disabled input
            } else {
              // Unposted → allow dropdown
              this.showInputForCheckNo = false;
            }
          }
        }
      }, 50);
      // -------------------------
      // END FIX
      // -------------------------

      this.API.PostData(`/Payments/CheckIfBatchHasPayments?batchID=${this.selectedBatch.BatchID}`, {}, (res) => {
        if (res.Status === 'Success' && res.Response === true) {
          const hasPayments = res.Response;
          if (hasPayments) {
            this.batchPaymentForm.get('batchType').disable();
            this.batchPaymentForm.get('paymentType').disable();
            const paymentType = this.batchPaymentForm.get('paymentType').value;
            if (paymentType === 'K' || paymentType === 'E') {
              this.batchPaymentForm.get('checkNo').disable();
              this.batchPaymentForm.get('checkDate').disable();
            }
          } else {
            this.batchPaymentForm.get('batchType').enable();
            this.batchPaymentForm.get('paymentType').enable();
            this.batchPaymentForm.get('checkNo').enable();
            this.batchPaymentForm.get('checkDate').enable();
          }
        }
      });

    } finally {
      setTimeout(() => {
        this.isEditDisabled = false;
      }, 1000);
    }
  }


  convertToDatePickerFormat(dateString: string): any {
    if (!dateString) return null;
    const dateObj = new Date(dateString);
    return {
      date: {
        year: dateObj.getFullYear(),
        month: dateObj.getMonth() + 1, // Months are 0-based in JS
        day: dateObj.getDate()
      }
    };
  }
  formatDate(date: string) {
    if (date == null)
      return;
    var day = parseInt(date.split('/')[1]) < 10 ? date.split('/')[1] : date.split('/')[1];
    var month = parseInt(date.split('/')[0]) < 10 ? date.split('/')[0] : date.split('/')[0];
    var year = date.split('/')[2];
    if (year != undefined && month != undefined && day != undefined)
      return month + "/" + day + "/" + year;
  }

  confirmCloseBatch(batch: any) {
    if (!batch) {
      this.toaster.warning("No batch selected. Please select a batch before closing.", "Validation");
      return;
    }

    this.apiService.confirmFun(
      'Confirmation',
      'Are you sure you want to close this batch?',
      () => {
        this.closeBatch(batch);
      }
    );
  }

  closeBatch(batchId: string) {
    const formData = {
      BatchID: batchId,
    };
    const endpoint = "/Payments/CloseBatch";
    const successMessage = "Batch has been closed successfully.";
    this.API.PostData(endpoint, formData,
      (response) => {
        if (response.Status === "Success") {
          swal("Batch Closed", successMessage, "success");
          if (this.paymentAdvisoryModalRef) {

            this.paymentAdvisoryModalRef.hide();
          }
          if (this.patientPaymentModalRef) {
            this.modalController.unregister(this.patientPaymentModalRef);
            this.patientPaymentModalRef.hide();
          }
          this.onLookUp();
          this.disableButtons(batchId);
          this.chRef.detectChanges();
        } else {
          this.toaster.error(response.Response, "Error");
        }
      },
      (error) => {
        this.toaster.error("Error while closing the batch.", "Error");
      }
    );
  }

  disableButtons(batchId: string) {
    const batch = this.selectedBatch;
    if (batch && batch.BatchID === batchId) {
      batch.isClosed = true;
      this.batchStatus = false; // <-- Set this to false to reflect the closed state
    }
  }

  // Close the modal after edit
  closeModal() {
    if (this.patientPaymentModalRef) {
      this.modalController.unregister(this.patientPaymentModalRef);
      this.patientPaymentModalRef.hide();
    }
  }
  checkProperty(moduleName: string, propertyName: string): boolean {
    const rights = this.GV.currentUser.RolesAndRights;

    if (!rights || rights.length === 0) {
      this.isSetup = false;
      return false;
    }

    // Look for a match
    const found = rights.some((item: any) =>
      item.ModuleName.toLowerCase().trim() === moduleName.toLowerCase().trim() &&
      item.PropertyName.toLowerCase().trim() === propertyName.toLowerCase().trim()
    );

    this.isSetup = found;
    return found;
  }

  onReopenBatch(BatchID: any) {
    this.API.confirmFun(
      'Reopen Batch Confirmation',
      'Are you sure you want to reopen the closed batch?',
      () => {
        this.API.PostData('/Payments/ReopenBatch?BatchId=' + BatchID, {}, (res) => {
          if (res.Status === "Success") {
            swal("Batch Reopened", 'Batch Reopened Successfully', "success");
            this.onLookUp();
            this.chRef.detectChanges();
            this.toaster.success(res.Response);
          } else {
            this.toaster.error(res.Response);
          }
        });
      }
    );
  }

  isCurrentMonth(date: string | Date): boolean {
    if (!date) return false;
    const batchDate = new Date(date);
    const today = new Date();

    return (
      batchDate.getMonth() === today.getMonth() &&
      batchDate.getFullYear() === today.getFullYear()
    );
  }
  isCurrentMonth2(date: any): boolean {
    if (!date) {
      return false;
    }

    // If it's coming as { formatted: '09/24/2025' }, use the formatted property
    const rawDate = typeof date === 'object' && date.formatted ? date.formatted : date;

    const batchDate = new Date(rawDate);
    const today = new Date();


    return (
      batchDate.getMonth() === today.getMonth() &&
      batchDate.getFullYear() === today.getFullYear()
    );
  }

  onOpenPaymentTemplate(template: TemplateRef<any>) {
    // Hide advisory before opening payment template
    this.paymentAdvisoryModalRef.hide();
    this.patientPaymentModalRef = this.modalService.show(template, { class: 'modal-lg' });
    this.modalController.register(this.patientPaymentModalRef);
  }
  

  onClosePaymentTemplate() {
    this.modalController.unregister(this.patientPaymentModalRef);
    // Hide payment template modal
    this.patientPaymentModalRef.hide();

    // Reopen advisory modal
    this.paymentAdvisoryModalRef = this.modalService.show(this.paymentAdvisoryModalRef, {
      class: 'modal-xlg',
      backdrop: 'static',
      keyboard: false
    });
    this.modalController.register(this.paymentAdvisoryModalRef);
  }
  getEraCheckDetails(): void {
    const practiceCode = this.GV.currentUser.selectedPractice.PracticeCode;

    this.API.getData(`/Submission/GetERACheckDetails?practice_id=${practiceCode}`).subscribe(response => {
      if (response.Status === 'Success') {
        this.eraCheckList = response.Response.map((item: any) => ({
          CHECKNUMBER: item.CHECKNUMBER,
          CHECKDATE: item.CHECKDATE,
          POSTED: item.POSTED,
        }));
      } else {
        this.eraCheckList = [];
        this.toaster.error('Failed to fetch ERA Check details', response.Status);
      }
    },
      (error: any) => {
        console.error('API Error:', error);
        this.toaster.error('API Error', error.message);
      }
    );
  }

  onSelectCheckNo(selectedCheckNumber: string): void {

    // Find the full object in the eraCheckList based on CHECKNUMBER
    const selectedItem = this.eraCheckList.find(
      (item: any) => item.CHECKNUMBER === selectedCheckNumber
    );

    if (selectedItem && selectedItem.CHECKDATE) {

      // Convert the string date into the format required by my-date-picker
      const dateObj = new Date(selectedItem.CHECKDATE);
      const formattedDate = {
        date: {
          year: dateObj.getFullYear(),
          month: dateObj.getMonth() + 1,
          day: dateObj.getDate()
        }
      };

      // Patch form fields
      this.batchPaymentForm.patchValue({
        checkNo: selectedItem.CHECKNUMBER,
        checkDate: formattedDate,

      });

    } else {
      console.warn('Selected check not found or CHECKDATE missing');
    }
  }
  payExpand() {
    this.isPayExpand = !this.isPayExpand;
  }

  checkBatchHasPayments(batchNo: string) {
    this.API.getData(`/Payments/CheckIfBatchHasPayments?batchNo=${encodeURIComponent(batchNo)}`)
      .subscribe(res => {
        if (res.Status === 'Success') {
          const hasPayments = res.Response;
          if (hasPayments) {
            this.batchPaymentForm.get('batchType').disable();
            this.batchPaymentForm.get('paymentType').disable();
            const paymentType = this.batchPaymentForm.get('paymentType').value;
            // If Payment Type = Check → disable Check Number & Check Date after payment/unapplied payment entry
            if (paymentType === 'K') {
              this.batchPaymentForm.get('checkNo').disable();
              this.batchPaymentForm.get('CheckDate').disable();
            }

          } else {
            this.batchPaymentForm.get('batchType').enable();
            this.batchPaymentForm.get('paymentType').enable();
            this.batchPaymentForm.get('checkNo').enable();
            this.batchPaymentForm.get('CheckDate').enable();

          }
        }
      });
  }
  onClearUserSelection() {
    this.fillDDl_onBlur(); // reset dropdown list
    this.usersSelectList = null;
  }

  fillDDl_onBlur() {
    // Reset usersSelectList to full backup list
    if (this.userSelectListBackup != null) {
      const users = this.userSelectListBackup.map((user: any) => ({
        ...user,
        DisplayLabel: `${user.UserName} | ${user.FirstName} ${user.LastName}`
      }));
      this.usersSelectList = [
        { UserId: null, DisplayLabel: 'Select User' },
        ...JSON.parse(JSON.stringify(users))
      ];
    }
  }
setCurrentMonthDateRange(): void {
  const today = new Date();

  // Start date: 1st of current month
  const startOfMonth = { 
    year: today.getFullYear(),
    month: today.getMonth() + 1, // JS months are 0-based
    day: 1
  };

  // End date: today
  const endOfMonth = { 
    year: today.getFullYear(),
    month: today.getMonth() + 1,
    day: today.getDate()
  };

  // Only patch if form exists
  if (this.searchBatchForm && this.searchBatchForm.get('BatchDateRange')) {

    this.searchBatchForm.patchValue({
      BatchDateRange: {
        beginDate: startOfMonth,
        endDate: endOfMonth,
        // Some pickers auto-generate these if missing:
        beginJsDate: new Date(startOfMonth.year, startOfMonth.month - 1, startOfMonth.day),
        endJsDate: new Date(endOfMonth.year, endOfMonth.month - 1, endOfMonth.day),
        formatted: `${this.formatDates(startOfMonth)} - ${this.formatDates(endOfMonth)}`
      }
    });
  }




}
}
