import { Component, EventEmitter, Input, OnInit, Output, TemplateRef } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { ToastrService } from 'ngx-toastr';
import { APIService } from '../../components/services/api.service';
import { GvarsService } from '../../services/G_vars/gvars.service';
import * as moment from 'moment';
import { IMyDrpOptions } from 'mydaterangepicker';
import { IMyDateModel } from 'mydatepicker';
@Component({
  selector: 'app-unapplied-payments',
  templateUrl: './unapplied-payments.component.html',
  styleUrls: ['./unapplied-payments.component.css']
})
export class UnappliedPaymentsComponent implements OnInit {
 
 @Input() batchId;
 @Input() checkNo;
 @Input() check_date;
 @Output() totalAmountCalculated = new EventEmitter<number>();
 @Input() batchRemainingAmount;
 @Input() Batch_Status;
  unappliedPaymentForm:FormGroup;
  unappliedRef:BsModalRef;
  dataTableUnappliedPayments:any;
    batchOpenDate: any;
    locationList: any[] = [];
    resourceList : any[] = [];
       today = new Date();
 
  public myDatePickerOptions: IMyDrpOptions = {
    dateFormat: 'mm/dd/yyyy', height: '25px', width: '100%',
    disableSince: {
      year: this.today.getFullYear(),
      month: this.today.getMonth() + 1,
      day: this.today.getDate() + 1,
    }
  };
 
 
 
  isEdit:boolean=false;
   patientOptions: any[] = [];
      billingPhysicianList: any[] = [];
         resourcePhysicianList: any[] = [];
            location: any[] = [];
 
 
 
  constructor(private GV: GvarsService, private toaster: ToastrService,
      private API: APIService,
      private fb: FormBuilder,
    private modalService: BsModalService,) {
   }
 
  ngOnInit() {
   
    if(this.batchId){
this.getUnappliedPaymentByBatch();
this.loadPatientData();
this.getBatchDate();
this.getDropdownValues();
    }
   
    debugger;
     
 this.unappliedPaymentForm = this.fb.group({
      id: [null], // Change this to a value to test "Edit" behavior
      batch_no: [this.batchId, Validators.required],
      patient_account: [null],
      selected_Patient: [null],
      checkno: [null],
      amount: [null, [ Validators.pattern(/^[+]?([0-9]*[.])?[0-9]+$/)]],
       billing_physician: [''],
        location: [''] ,
      checkDate:[null],
       resource_physician: ['']
    });
 
    // Set checkno value if available
    if (this.checkNo) {
      this.unappliedPaymentForm.get('checkno').setValue(this.checkNo);
    }
if (this.check_date) {
  // const dateObj = new Date(this.check_date);
  // const formattedDate = {
  //   date: {
  //     year: dateObj.getFullYear(),
  //     month: dateObj.getMonth() + 1,
  //     day: dateObj.getDate()
  //   }
  const [year, month, day] = this.check_date.substring(0, 10).split('-').map(Number);
const formattedDate = {
  date: {
    year,
    month,
    day
  }
  };
  this.unappliedPaymentForm.get('checkDate').setValue(formattedDate);
          //s    this.unappliedPaymentForm.get('checkDate').setValue(moment(this.check_date).format('MM/DD/YYYY'));

}
 
    //   billing_physician: [''],
    //     location: [''] ,
    //   cheque_Date:[null],
    //    resource_physician: ['']
    // });
 
    // // Set checkno value if available
    // if (this.checkNo) {
    //   this.unappliedPaymentForm.get('checkno').setValue(this.checkNo);
    // }
    // if(this.check_date){
    //         this.unappliedPaymentForm.get('cheque_Date').setValue(moment(this.check_date).format('MM/DD/YYYY'));
    // }
 
    // Control enabling/disabling checkno based on id
    setTimeout(() => {
      const idControl = this.unappliedPaymentForm.get('id');
      const checkNoControl = this.unappliedPaymentForm.get('checkno');
      if (this.checkNo && idControl && !idControl.value && checkNoControl) {
        checkNoControl.disable();
      } else if (checkNoControl) {
        checkNoControl.enable();
      }
        const checkDateControl = this.unappliedPaymentForm.get('checkDate');

   // 🔹 If batch already has a checkDate, keep it disabled
  if (this.check_date && idControl && !idControl.value  && checkDateControl) {
    checkDateControl.disable();
  } else {
    checkDateControl.enable();
  }
    });
 
    // Sync: patient_account → selected_Patient
  this.unappliedPaymentForm.get('patient_account').valueChanges.subscribe(val => {
  const dropdown = this.unappliedPaymentForm.get('selected_Patient');
  const accountControl = this.unappliedPaymentForm.get('patient_account');
  // If user typed something
  if (val) {
    const match = this.patientOptions.find(x => x.Patient_Account.toString() === val.toString());
    if (match) {
      dropdown.setValue(match.Patient_Account, { emitEvent: false });
         dropdown.disable({ emitEvent: false });
    } else {
      dropdown.setValue(null, { emitEvent: false });
      dropdown.enable();
    }
 
 
    accountControl.enable({ emitEvent: false });
  } else {
    dropdown.enable({ emitEvent: false });
  }
});
 
this.unappliedPaymentForm.get('selected_Patient').valueChanges.subscribe(val => {
  const accountControl = this.unappliedPaymentForm.get('patient_account');
  const dropdown = this.unappliedPaymentForm.get('selected_Patient');
  if (val) {
    accountControl.setValue(val, { emitEvent: false });
    accountControl.disable({ emitEvent: false });
    dropdown.enable({ emitEvent: false });
  } else {
    accountControl.enable({ emitEvent: false });
  }
});
 
  }
 
   loadPatientData() {
    const practiceCode = this.GV.currentUser.selectedPractice.PracticeCode;
    const isDueOnly = false; // true => Amt_Due > 0, false => All
 
    this.getPatientsWithDue(isDueOnly, practiceCode);
  }
  getPatientsWithDue(isDueOnly: boolean, practiceCode: number) {
 
    const successMessage = "Patients data retrieved successfully.";
 
    this.API.getData(`/Payments/GetPatientsWithDue?isDueOnly=${isDueOnly}&practiceCode=${practiceCode}`).subscribe(
      response => {
        if (response.Status === "Success") {
          const resData = response.Response.map((patient: any) => ({ FullName: patient.Name, Patient_Account: patient.Id }));
          this.patientOptions = resData
        } else {
          this.toaster.error(response.Response, "Error");
        }
      },
      error => {
        this.toaster.error("Error while fetching patient data.", "Error");
      }
    );
  }

  onDateChanged(event: IMyDateModel, controlName: string): void {
    debugger;
  if (event && event.formatted) {
    // Set only the formatted string in the form control
    this.unappliedPaymentForm.get(controlName).setValue(event.formatted);
  } else {
    // Clear if no date selected
    this.unappliedPaymentForm.get(controlName).setValue(null);
  }
}
onSubmit() {
   if(!this.isCurrentMonth(this.batchOpenDate)){
     this.toaster.error("This Batch belongs to previous month.Next month Unapplied Payments cannot be added in previous month batch", "Error");
return;
  }
    const formValues = this.unappliedPaymentForm.value;
    debugger;
    console.log('FormValues', formValues);
    const selectPatient = formValues.selected_Patient;
    const patientAccount = formValues.patient_account || selectPatient;
    const amount = Number(formValues.amount);
    if(patientAccount){
    const match = this.patientOptions.find(x => x.Patient_Account.toString() === patientAccount.toString());
    if ((!formValues.patient_account && !selectPatient) || !match) {
    this.toaster.error('Please enter a valid Patient account.', 'Invalid Patient');
    return;
  }
    }
    else{
       this.toaster.error('Please enter a valid Patient account.', 'Invalid Patient');
       return;
    }

    if (!amount || amount <= 0) {
      this.toaster.error('Please enter a valid amount greater than 0.', 'Invalid Amount');
      return;
    }
    // if(amount>this.batchRemainingAmount){
    //   this.toaster.error(`Please enter a  amount less than batch remaining amount ($${this.batchRemainingAmount}).`, 'Invalid Amount');
    //   return;
    // }
 
 
    const selected = this.unappliedPaymentForm.get('checkDate').value;
  const checkDateControl = this.unappliedPaymentForm.get('checkDate');
let checkDateString: string | null = null;

if (selected && selected.date && checkDateControl) {
  const { year, month, day } = selected.date;
  checkDateString = `${month.toString().padStart(2, '0')}/${day
    .toString()
    .padStart(2, '0')}/${year}`;
} else {
  checkDateString =  this.unappliedPaymentForm.get('checkDate').value
  ? this.unappliedPaymentForm.get('checkDate').value.formatted : null
}

 
    const request = {
      id: formValues.id,
      Patient_Account: patientAccount,
      BATCH_NO: formValues.batch_no,
      Check_No:  this.unappliedPaymentForm.get('checkno').value,
      Amount: amount,
      Billing_Physician: this.unappliedPaymentForm.get('billing_physician').value,
      Resource_Physician: this.unappliedPaymentForm.get('resource_physician').value,
      Location_Code: this.unappliedPaymentForm.get('location').value,
      CheckDate :checkDateString,
            // CheckDate: moment(this.unappliedPaymentForm.get('checkDate').value).format('MM/DD/YYYY').toString(),
// CheckDate: this.unappliedPaymentForm.get('checkDate').value
//   ? (this.unappliedPaymentForm.get('checkDate').value.formatted 
//       ? this.unappliedPaymentForm.get('checkDate').value.formatted 
//       : this.unappliedPaymentForm.get('checkDate').value)
//   : null,
    };

    debugger
    console.log('API Request', request);
 
    this.API.PostData('/Demographic/SaveUnappliedAmount', request, (res) => {
      if (res.Status === 'Success') {
        const toasterMsg = this.isEdit
          ? 'Unapplied payment updated successfully.'
          : 'Unapplied payment posted successfully.';
 
        this.toaster.success(toasterMsg, 'Success');
        this.getUnappliedPaymentByBatch();
        this.unappliedPaymentForm.get('patient_account').setValue(null);
        this.unappliedPaymentForm.get('selected_Patient').setValue(null);
        this.unappliedPaymentForm.get('amount').setValue(null);
     
          this.unappliedPaymentForm.get('billing_physician').setValue(null);
           this.unappliedPaymentForm.get('resource_physician').setValue(null);
            this.unappliedPaymentForm.get('location').setValue(null);
 
this.unappliedPaymentForm.get('id').setValue(null);
 const checkNoControl = this.unappliedPaymentForm.get('checkno');  
const checkDateControl = this.unappliedPaymentForm.get('checkDate');
if(this.checkNo === null && checkNoControl != null)
   this.unappliedPaymentForm.get('checkno').setValue(null);
  if(this.check_date === null && checkDateControl != null)
  {

    this.unappliedPaymentForm.get('checkDate').setValue(null);
  }
  if (checkNoControl && checkNoControl.enabled) {
    checkNoControl.setValue(null);
  }
  
        this.isEdit=false
      } else {
        this.toaster.error(res.Response || 'Failed to post Unapplied payments.', 'Error');
      }
    });
 
}
 
unappliedPaymentDetails:any;
getUnappliedPaymentByBatch() {
  this.API.getData(`/Demographic/GetUnappliedPaymentsByBatchNo?batchNo=${this.batchId}`).subscribe(res => {
    if (res.Status === 'Success') {
      if (this.dataTableUnappliedPayments) {
        this.dataTableUnappliedPayments.destroy();
        this.dataTableUnappliedPayments = null;
      }
 
      this.unappliedPaymentDetails = res.Response;
      // Calculate total amount
      const totalAmount = this.unappliedPaymentDetails.reduce((sum, payment) => sum + Number(payment.Amount || 0), 0);

      // Emit the total to parent
      this.totalAmountCalculated.emit(totalAmount);
 
      setTimeout(() => {
        const table: any = $('.dataTableUnappliedPayments');
        this.dataTableUnappliedPayments = table.DataTable({
          destroy: true,
          columnDefs: [
            { orderable: false, targets: -1 }
          ],
          language: {
            emptyTable: "No claims data available"
          },
          order: [1, 'desc'],
        });
      }, 100);
    }
  });
}
 
 
 
 onEdit(payment: any) {
  debugger
  var formattedDate = null;
 if (payment.Check_Date) {
  // const dateObj = new Date(payment.CheckDate);
  // const formatted = moment(dateObj).format('MM/DD/YYYY');
 
  // formattedDate = {
  //   date: {
  //     year: dateObj.getFullYear(),
  //     month: dateObj.getMonth() + 1,
  //     day: dateObj.getDate()
  //   },
  //   jsdate: dateObj,
  //   formatted: formatted,
  //   epoc: Math.floor(dateObj.getTime() / 1000)
  // };


 const [year, month, day] = payment.Check_Date.substring(0, 10).split('-').map(Number);
 formattedDate = {
  date: {
    year,
    month,
    day
  }
};
 }
  this.isEdit=true,
    this.unappliedPaymentForm.patchValue({
      batch_no: payment.BATCH_NO || null,
      id:payment.Id,
      selected_Patient: payment.Patient_Account || null,
      patient_account: payment.Patient_Account || null,
      checkno: payment.Check_No || null,
      amount: payment.Amount || null,
      checkDate: formattedDate  || null,
      billing_physician: payment.Billing_Physician || null,
      resource_physician: payment.Resource_Physician || null,
      location: payment.Location_Code || null,
    });
 
     const checkNoControl = this.unappliedPaymentForm.get('checkno');
  // If batch already has a checkNo, keep it disabled
  if (this.checkNo && checkNoControl) {
    checkNoControl.disable();
  } else {
    checkNoControl.enable();
  }

            const checkDateControl = this.unappliedPaymentForm.get('checkDate');

   // 🔹 If batch already has a checkDate, keep it disabled
  if (this.check_date && checkDateControl) {
    checkDateControl.disable();
  } else {
    checkDateControl.enable();
  }
}
 onRemove(payment: any, index: number) {
   swal({
       title: 'Confirmation',
            text: `Are you sure want to remove the unapplied amount?`,
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes',
             cancelButtonText: 'No'    
    }).then((willDelete) => {
    if (willDelete) {
      // Call the API to delete the payment
      this.API.PostData(`/Demographic/DeleteUnappliedPayment?unappliedPaymentId=${payment.Id}`,{},(res) => {
      if (res.Status === 'Success') {
       
        this.toaster.success('The entry has been removed successfully.', 'Success');
        this.getUnappliedPaymentByBatch();
       
      } else {
        this.toaster.error(res.Status || 'There was a problem removing the entry.', 'Error');
      }
    });
 
  } else {
    this.unappliedPaymentForm.markAsTouched();
  }
}
)}  
 
getBatchDate(){
    this.API.getData(`/Payments/GetBatchDate?batchID=${this.batchId}`).subscribe(summary => {
      if (summary.Status === 'Success') {
        this.batchOpenDate = summary.Response.BatchOpenDate;
      } else {
        this.toaster.error('Failed to fetch.', 'Error');
      }
    });
  }

    isCurrentMonth(batchOpenDate: string | Date): boolean {
    if (!batchOpenDate) return false;
    const batchDate = new Date(batchOpenDate);
    const today = new Date();
    return (
      batchDate.getMonth() === today.getMonth() &&
      batchDate.getFullYear() === today.getFullYear()
    );
  }
 
  // //new changes by Anum
getDropdownValues() {
  this.API.PostData(`/Demographic/GetBillingPhysiciansList?practiceCode=${this.GV.currentUser.selectedPractice.PracticeCode}`, {}, (res) => {
    if (res.Status === 'Success') {
      debugger;
      this.billingPhysicianList = res.Response.BillingPhysicians || [];
       this.locationList = res.Response.Locations || [];
       this.resourceList =  res.Response.BillingPhysicians || [];
 
 
      console.log('Billing Physicians:', this.billingPhysicianList);
      console.log('Locations:', this.location);
    } else {
      this.toaster.error(res.Status || 'There was a problem fetching billing physicians.', 'Error');
    }
  });
}
 
}
 
 