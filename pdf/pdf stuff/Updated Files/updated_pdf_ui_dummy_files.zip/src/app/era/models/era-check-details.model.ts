export class ERACheckDetails {
    ERAID: number;
    PAYERNAME: string;
    PAYERADDRESS: string;
    PAYEENAME: string;
    PAYEEADDRRESS: string;
    CHECKNUMBER: string;
    CHECKDATE: Date;
    CHECKAMOUNT: string;
    CLAIMNO: string;
    PATFULLNAME: string;
}
export class BatchFormData {
  BatchID: number;
  BatchType: string;
  PaymentType: string;
  CheckNo: string | null;
  CheckDate: string | null;
  FileName: string;
  BatchOpenDate: string | null;
  DepositDate: string | null;
  ReceivedDate: string | null;
  NOtes: string | null;
  BatchAmount: number;
  RemainingAmount: number;
  PostedAmount: number;
  Practice_Code: number;
  BatchStatus?: number; 
}