import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BatchPaymentAdvisoryComponent } from './batch-payment-advisory.component';

describe('BatchPaymentAdvisoryComponent', () => {
  let component: BatchPaymentAdvisoryComponent;
  let fixture: ComponentFixture<BatchPaymentAdvisoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BatchPaymentAdvisoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BatchPaymentAdvisoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
