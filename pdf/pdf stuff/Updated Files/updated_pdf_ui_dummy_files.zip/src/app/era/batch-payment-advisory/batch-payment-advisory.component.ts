import { ChangeDetectorRef, Component, EventEmitter, HostListener, Input, NgZone, OnInit, Output, TemplateRef, ViewChild } from '@angular/core';
import { BsModalRef, BsModalService, ModalDirective, ModalOptions } from 'ngx-bootstrap/modal';
import { IMyDate, IMyDrpOptions } from 'mydaterangepicker';
import { Common } from '../../services/common/common';
import { APIService } from '../../components/services/api.service';
import { PaymentAdvisoryComponent } from '../../payment/payment-advisory/payment-advisory/payment-advisory.component';
import { GvarsService } from '../../services/G_vars/gvars.service';
import { ToastrService } from 'ngx-toastr';
import { AbstractControl, FormBuilder, FormGroup, ValidationErrors, Validators } from '@angular/forms';
import { ClaimsPost, ClaimsPaymentDetailModel } from '../../payment/models/payment-search-request.model';
import { PaymentsComponent } from '../../Claims/Payments/payments.component';
import { ClaimModel, claimNotes, claimPayments, ClaimViewModel } from '../../Claims/Classes/ClaimsModel';
import { ClaimInsurancesComponent } from '../../Claims/Insurances/claim-insurances.component';
import { PaymentServiceService } from '../../services/payment-service.service';
import { BatchStateService } from '../../services/batch-state.service';
import { ClaimCharges, claimPayment } from '../../Claims/Classes';
import { ActivatedRoute, NavigationStart, Router } from '@angular/router';
import { template } from '@angular/core/src/render3';
import { PaymentResponsbility } from '../../models/payment-responsbility.model';
import { ModalControllerService } from '../../shared/modal-controller.service';
import * as moment from 'moment';
import { DatePipe } from '@angular/common';
import { debug } from 'console';
import { NgxSpinnerService } from 'ngx-spinner';




@Component({
  selector: 'app-batch-payment-advisory',
  templateUrl: './batch-payment-advisory.component.html',
  styleUrls: ['./batch-payment-advisory.component.css']
})

export class BatchPaymentAdvisoryComponent implements OnInit {
  [x: string]: any;
  DueAmountGreaterThanZero: boolean = true;
  @Input() batchId: string;
  @Input() checkNo: string;
  @Input() batchType: string;
  @Input() fileName: string;
  @Input() typeBatch: boolean = false;
  @Input() Claim_Number: number = 0;
  @Input() depositDate: Date | { formatted: string };
  @Input() batchAmount: number;
  @Input() postedAmount: number;
  @Input() remainingAmount: number;
  @Output() openPaymentTemplate = new EventEmitter<TemplateRef<any>>();
  @Output() closePaymentTemplate = new EventEmitter<void>();
  @Output() onSelectPayment: EventEmitter<any> = new EventEmitter();
  @Output() updateRemaingAmount = new EventEmitter<number>();
  @Output() refreshParent: EventEmitter<void> = new EventEmitter<void>();
  claimsPaymentDetailModel: ClaimsPaymentDetailModel[];
  claimsPost: ClaimsPost;
  claimViewModel: ClaimViewModel;
  claimviewmodel_default: ClaimViewModel;
  @ViewChild(ClaimInsurancesComponent) InsChild;
  @ViewChild(PaymentsComponent) paymentChild;
  searchForm: FormGroup;
  unappliedPaymentForm: FormGroup;
  claimModalRef: BsModalRef;
  unappliedRef: BsModalRef;
  dataTableUnappliedPayments: any;
  updateOverPaymentModle: BsModalRef
  addOverPaymentModel : BsModalRef
  tcbModel: BsModalRef // Added By hamza akhlaq transfer credit balance popup model
  claimswithPatientDue: any; // Added By hamza akhlaq transfer credit balance
  tPatientAcc:any; // Added By hamza akhlaq transfer credit balance
  transfercrditbalPayment: any; // Added By hamza akhlaq transfer credit balance
  tcbModalShow : boolean =false // Added By hamza akhlaq transfer credit balance
  BillNext: string = '0';
  isDueOnly: boolean = true;
  patientOptions: any[] = [];
  postedClaim: any[] = [];
  claimOptions: any[] = [];
  list: number[];
  claimsData: any[]
  selectedPatient: any = null;
  claimValue: any = null;
  Adjustment: any;
  amt_due: any;
  amt_paid: any;
  claim_total: any;
  BATCHTYPE: any;
  Batch_Status: any;
  Gindex: number = 0;
  manualClaimNumber: string = '';
  postAmount: number = 0;
  Balance: number = 0;
  indexs: number = 0;
  batchDate: string = '';
  selectedClaimNo: string = '';
  totalPaid: number = 0;
  totalAdjusted: number = 0;
  totalApproved: number = 0;
  totalRejected: number = 0;
  paymentType: string = 'I'; // or 'P' or 'Both'
  allowedSources: string[] = [];
  totalBatchAmtPaid: any;
  patientInfo: any;
  showTooltip = false;
  showBillNextStatusDDL: boolean = false;
  preRemovePaymentsSnapshot: any[] = [];
  removeSelectedStatusMap: { [key: string]: string } | null = null;
  claimLevelPayments: any[] = [];
  removedClaimNo : any;
  private _preservedStatuses: any;
  selectedBillNextStatus: string = '';
  billNextStatusOptions: string[] = [];
  claimPaymentModel: claimPayment[];
  remainingBatchAmount: any;
  //  claimPaymentModel: claimPayment[];
  public claimNotesModel: claimNotes;
  claimCharges: ClaimCharges[];
  selectedPatientNum: any;
  encodedPatientInfo: string;
  disabledIcon = true; // start disabled by default
  AddPaymentClaims: number[];
  oldclaimpayments: any[] = []
  patientData
  patName: string;
  patAccount: any;
  claimsNo: any;
  batchID: any;
  isClaimEntered: boolean = false; // Flag to track whether Claim # is entered
  isClaimDropdownSelected: boolean = false; // Tracks whether claim dropdown has a selected value
  isPAyAdded: boolean = false;
  dataTablePostedClaims: any;
  //tcbModalShow: boolean = false; // Added By hamza akhlaq Flag to show  transfer credit balance popup model 
  isRemovePayment: boolean = false;
  removeBatchId: any;
  removeClaimdue: any;
  careformattedDate: any;
  
  // Button disabled flags to prevent double-click
  isGoButtonDisabled: boolean = false;
  isEditButtonDisabled: boolean = false;
  isRemoveButtonDisabled: boolean = false;
  isSavePaymentButtonDisabled: boolean = false;
  isSkipConfirmationDisabled: boolean = false;
  isSaveOverpaymentDisabled: boolean = false;
  Batch_Number:any;
  @ViewChild(PaymentsComponent) pay;
  @ViewChild('paymentAdvisoryModalTemplate') paymentAdvisoryModalTemplate: TemplateRef<any>;
  @ViewChild('addoverPaymentTemplate') overPaymentModalTemplate: TemplateRef<any>;
  @ViewChild('billNextModal') billNextModalTemplate: TemplateRef<any>;
  @ViewChild('tcbModalTemplate') tcbModalTemplate: TemplateRef<any>; // Added By hamza akhlaq transfer credit balance popup model
  @ViewChild('paymentTemplate') paymentTemplate : TemplateRef<any>;

  Check_No: any;
  Cheque_Date: any;
  batchOpenDate: any;
  Deposit_Date: any
  show_Insurance_Overpaid: any;
  show_Patient_Credit_Balance: any;
  totaloverpayment:any=0;
  editOverPaymentButton: boolean = false;
  selectedResponsibleParty: any = "Select Responsible";
  TotaldueAmt: any;
  TtalCharges: any;
  TotalPaidAmt: any;
  TotalAdjamt: any;
  Totalamtadj: any;
  ClaimDueAmt: any;
  TotalCharges: any;
  dueAmtForOverPayment: any = 0;
  overPaymentNotes: any = '';
  overPaymentCheck: boolean = false;
  paymentResponsibilityForm: FormGroup;
  paymentresponsbility: PaymentResponsbility;
  allPayments: any[] = [];
  existingPayments: any[] = [];
  batchRemovePayments:any[]=[];
  TCBPayment : any[]=[];
  TCBPaymentId:any[]=[];
  @ViewChild('upModal') upModal: ModalDirective; PatientFirstName: any;
  claimsResponse: any = [];
  isPosting: boolean = false;
  isTCB : boolean = false
  billNextModalRef: BsModalRef;
  currentResponsible: string="";
  updatedNotes=[];
  //changes by Anum for bill next Validation

  billNextOptions: string[] = [];
  selectedBillNext: string = '';
  processedPaymentList: any[] = [];
  lastTPaidAmount : any;
  totalTPaid : any;
  claimNo:any;
  PaymentClaimNo:any=0;
  claimPayment:boolean=false

  constructor(
    private modalService: BsModalService,
    private GV: GvarsService,
    private toaster: ToastrService,
    private API: APIService,
    private fb: FormBuilder,
    private cdr: ChangeDetectorRef,
    private _apiService: APIService,
    private batchDataService: BatchStateService,
    private toast: ToastrService,
    public PC: PaymentServiceService,
    public router: Router,
    private route: ActivatedRoute,
    public datepipe: DatePipe,
    private modalController: ModalControllerService,
    private spinner: NgxSpinnerService,
    public Gv: GvarsService) {
    this.AddPaymentClaims = [];

    this.claimsPaymentDetailModel = [];
    this.paymentresponsbility = new PaymentResponsbility();
    this.claimNotesModel = new claimNotes;
    this.paymentResponsibilityForm = this.fb.group({
      creditbalance: ['-', [Validators.required, this.negativeValueValidator]], // Apply the validators
      overpaid: ['-', [Validators.required, this.negativeValueValidator]]
    });
    this.router.events.subscribe(event => {
      if (event instanceof NavigationStart) {
        this.modalController.closeAll();  // This closes EVERY modal instantly
      }
    });
  }
  @HostListener('window:popstate', ['$event'])
  onBrowserBack() {
    this.modalCleanup.closeAllModals();
  }
  ngOnInit() {    
    if (this.batchId) {
      this.getBatchDate()
    }
    this.searchForm = this.fb.group({
      selected_Patient: [null],
      claimValue: [null],
      ClaimId: [''],
      ClaimIds: [null],

    });
    if(this.Claim_Number!=0){
        this.searchForm.patchValue({
    ClaimIds: this.Claim_Number
  });
   this.searchForm.get('ClaimIds').disable();
this.manualClaimNumber = this.Claim_Number.toString();
this.PaymentClaimNo=this.Claim_Number
  this.claimPayment=true
    }
    this.searchForm.get('claimValue').valueChanges.subscribe((selectedClaimId: string) => {
      if (selectedClaimId) {
        this.onClaimSelectionChange(selectedClaimId);
      }
    });
    this.searchForm.get('claimValue').valueChanges.subscribe((claimID) => {
      // Find the selected claim based on ClaimID
      const selectedClaim = this.claimOptions.find(claim => claim.ClaimID === claimID);
      if (selectedClaim) {
        this.setClaimDetails(selectedClaim);
      }
    });
    this.loadPatientData();
    if (this.depositDate && typeof this.depositDate === 'object' && 'formatted' in this.depositDate) {
      const formattedDate = (this.depositDate as { formatted: string }).formatted;
      const [month, day, year] = formattedDate.split('/').map(num => parseInt(num, 10));
      this.depositDate = new Date(year, month - 1, day);
    }
    this.searchForm.get('claimValue').valueChanges.subscribe(claimId => {
      if (claimId) {
        this.searchForm.get('ClaimId').setValue(claimId);
      }
    });

    //payment posting

    this.PC.paymentModel.subscribe(
      data => {
        this.claimViewModel[this.Gindex].claimPayments = data;
      }
    )
    console.log('calim view model in ngOnInit', this.PC.paymentModel.subscribe(
      data => {
        this.claimViewModel[this.Gindex].claimPayments = data;
      }
    ))

    this.getPostedClaims();
    this.getPaymentType();
    this.getCheckDetail();
    this.setAllowedSources();
    this.getUnappliedPaymentByBatch();
    this.route.children[0].params.subscribe(params => {
      if (params) {
        this.encodedPatientInfo = params['param'];
        this.patientInfo = this.searchForm.get('selected_Patient').value,
          this.patientInfo = JSON.parse(Common.decodeBase64(this.encodedPatientInfo));
      }
    });

  }
  ngAfterViewInit() {
    this.claimsPaymentDetailModel[this.Gindex].claimPayments = this.pay.claimPaymentModel;

  }

//   getClaimModel(claimNo: string, patientAccount: string, template: TemplateRef<any>) {
//     this.spinner.show();
//     this.API.getData('/Demographic/GetClaimModel?PatientAccount=' + patientAccount + '&ClaimNo=' + claimNo).subscribe({
//       next:
//       data => {
//         this.claimViewModel = new ClaimViewModel();
//         // this.clearClaimAmount();
//         // this.refresh();
//         this.claimViewModel = data.Response;
           
//         this.claimViewModel.claimPayments.forEach((item) => {
//           // these below two lines are added to keep the original date as it is unless it is changed from frontend, to resolve date reversal issue
//           item.claimPayments.Date_Entry_Original = item.claimPayments.Date_Entry;
//           item.claimPayments.Date_Entry = moment.utc(item.claimPayments.Date_Entry).format('MM/DD/YYYY');
//           //  item.claimPayments.Date_Entry = this.datepipe.transform(item.claimPayments.Date_Entry, 'MM/dd/yyyy');

//           item.claimPayments.Date_Filing = this.datepipe.transform(item.claimPayments.Date_Filing, 'MM/dd/yyyy');
//           item.claimPayments.DepositDate = this.datepipe.transform(item.claimPayments.DepositDate, 'MM/dd/yyyy');
//           item.claimPayments.BATCH_DATE = this.datepipe.transform(item.claimPayments.BATCH_DATE, 'MM/dd/yyyy');
//         })

//         // Add this block: store original values for change detection
//         this.claimViewModel.claimPayments.forEach(p => {
//           p.claimPayments['originalData'] = { ...p.claimPayments }; // shallow clone
//         });
//         this.oldclaimpayments = JSON.parse(JSON.stringify(this.claimViewModel.claimPayments));
//         // this.onOpenPaymentModalClaim(template);
//         if (template) {
//           this.onOpenPaymentModalClaim(template);
//         }
//         // Filter only the claimPayments with non-null BATCH_NO
//         const filteredPayments = this.claimViewModel.claimPayments
//           .filter(p => p.claimPayments.BATCH_NO !== null && p.claimPayments.BATCH_NO !== '');

//         this.paymentChild.claimPaymentModel = filteredPayments;
// this.spinner.hide();  
//       },
//       error: err => {
//         this.spinner.hide();
//       }
//     });
//   }
// getClaimModel(claimNo: string, patientAccount: string, template: TemplateRef<any>) {

//   // Show spinner before API call
//   this.spinner.show();

//   this.API
//     .getDataClaimModel('/Demographic/GetClaimModel?PatientAccount=' + patientAccount + '&ClaimNo=' + claimNo)
//     .subscribe({
//       next: data => {

//         // Keep existing logic: assign claimViewModel
//         this.claimViewModel = new ClaimViewModel();
//         this.claimViewModel = data.Response;

//         // Format claim payment dates
//         this.claimViewModel.claimPayments.forEach(item => {
//           item.claimPayments.Date_Entry_Original = item.claimPayments.Date_Entry;
//           item.claimPayments.Date_Entry = moment.utc(item.claimPayments.Date_Entry).format('MM/DD/YYYY');

//           item.claimPayments.Date_Filing = this.datepipe.transform(item.claimPayments.Date_Filing, 'MM/dd/yyyy');
//           item.claimPayments.DepositDate = this.datepipe.transform(item.claimPayments.DepositDate, 'MM/dd/yyyy');
//           item.claimPayments.BATCH_DATE = this.datepipe.transform(item.claimPayments.BATCH_DATE, 'MM/dd/yyyy');
//         });

//         // Store original values for change detection
//         this.claimViewModel.claimPayments.forEach(p => {
//           p.claimPayments['originalData'] = { ...p.claimPayments };
//         });

//         // Deep copy for backup
//         this.oldclaimpayments = JSON.parse(JSON.stringify(this.claimViewModel.claimPayments));

//         // Open modal if template provided
//         if (template) {
//           this.onOpenPaymentModalClaim(template);
//         }

//         // Hide spinner AFTER UI updates are rendered
//         setTimeout(() => this.spinner.hide(), 0);
//         // Filter only payments with non-null BATCH_NO
//         const filteredPayments = this.claimViewModel.claimPayments
//           .filter(p => p.claimPayments.BATCH_NO !== null && p.claimPayments.BATCH_NO !== '');

//         this.paymentChild.claimPaymentModel = filteredPayments;


//       },
//       error: err => {
//         // Always hide spinner on error
//         this.spinner.hide();
//       }
//     });
// }
getClaimModel(claimNo: string, patientAccount: string, template: TemplateRef<any>): Promise<void> {

  this.spinner.show();

  return new Promise((resolve, reject) => {
    this.API
      .getDataClaimModel(`/Demographic/GetClaimModel?PatientAccount=${patientAccount}&ClaimNo=${claimNo}`)
      .subscribe({
        next: data => {
          this.claimViewModel = new ClaimViewModel();
          this.claimViewModel = data.Response;

          this.claimViewModel.claimPayments.forEach(item => {
            item.claimPayments.Date_Entry_Original = item.claimPayments.Date_Entry;
            item.claimPayments.Date_Entry = moment.utc(item.claimPayments.Date_Entry).format('MM/DD/YYYY');

            item.claimPayments.Date_Filing = this.datepipe.transform(item.claimPayments.Date_Filing, 'MM/dd/yyyy');
            item.claimPayments.DepositDate = this.datepipe.transform(item.claimPayments.DepositDate, 'MM/dd/yyyy');
            item.claimPayments.BATCH_DATE = this.datepipe.transform(item.claimPayments.BATCH_DATE, 'MM/dd/yyyy');
          });

          this.claimViewModel.claimPayments.forEach(p => {
            p.claimPayments['originalData'] = { ...p.claimPayments };
          });

          this.oldclaimpayments = JSON.parse(JSON.stringify(this.claimViewModel.claimPayments));

          if (template) {
            this.onOpenPaymentModalClaim(template);
          }

          const filteredPayments = this.claimViewModel.claimPayments
            .filter(p => p.claimPayments.BATCH_NO !== null && p.claimPayments.BATCH_NO !== '');
          //this.paymentChild.claimPaymentModel = filteredPayments;
         
          setTimeout(() => this.spinner.hide(), 0);
          
          resolve(); 
        },
        error: err => {
          this.spinner.hide();
          reject(err); 
        }
      });
  });
}

  closeModal() {
    this.isGoButtonDisabled = false;
              this.isEditButtonDisabled = false;

    this.isButtonDisabled = false;
    this.claimModalRef.hide();
    this.modalController.unregister(this.claimModalRef);
    // this.claimViewModel.claimPayments = [];
  }
  //   async  savePostPayments() {
  //     const paymentList = this.claimViewModel.claimPayments.map(p => p.claimPayments);
  //     const batchID = this.batchID;
  //     const batchDate = this.batchDate;
  //     const claimNo = this.claimsNo;
  //     const Check_Number = this.Check_No;
  //     const Check_Date = this.Cheque_Date;

  //     const processedPaymentList = paymentList
  //       .filter(payment => {
  //         if (payment.Deleted === true) return true;
  //         if (payment.claim_payments_id === 0) return true;
  //         if (!payment.originalData) return true;

  //         const original = payment.originalData;
  //         return (
  //           original.Amount_Paid !== payment.Amount_Paid ||
  //           original.Payment_Type !== payment.Payment_Type||
  //           original.ENTERED_FROM!== payment.ENTERED_FROM ||
  //           original.Amount_Adjusted !== payment.Amount_Adjusted ||
  //           original.Payment_Source !== payment.Payment_Source ||
  //           original.Details !== payment.Details ||
  //           original.Reject_Type !== payment.Reject_Type ||
  //           original.Reject_Amount !== payment.Reject_Amount ||
  //           original.Paid_Proc_Code !== payment.Paid_Proc_Code ||
  //           original.Charged_Proc_Code !== payment.Charged_Proc_Code ||
  //           original.Check_No !== payment.Check_No ||
  //           original.Cheque_Date !== payment.Cheque_Date ||
  //           original.Date_Adj_Payment !== payment.Date_Adj_Payment ||
  //           original.DEPOSITSLIP_ID !== payment.DEPOSITSLIP_ID||
  //           original.Contractual_Amt !==payment.Contractual_Amt||
  //           original.DepositDate !== payment.DepositDate||
  //           original.ERA_Rejection_CATEGORY_CODE !== payment.ERA_Rejection_CATEGORY_CODE
  //           // original. !== original.
  //         );
  //       })
  //       .map(payment => ({
  //         ...payment,
  //         Claim_No: claimNo,
  //         // BATCH_NO: batchID,
  //         //BATCH_DATE: batchDate,
  //         Check_No: Check_Number,
  //         Cheque_Date: Check_Date,
  //         Charged_Proc_Code: payment.Charged_Proc_Code ? payment.Charged_Proc_Code.split(' ')[0] : '',
  //         DepositDate: payment.DepositDate 
  //       }));

  //   for (let i = 0; i < processedPaymentList.length; i++) {        
  // const payment = processedPaymentList[i];

  //     // Validate Entry Date
  //     // const isValidDate = await this.validateDateEntry(payment.Date_Entry, i);
  //     // if (!isValidDate) return;
  //     const CareVoyant = payment.ENTERED_FROM === "60"; // CareVoyant
  // if (CareVoyant) {
  //   const isValidDate = await this.validateDateEntry(payment.Date_Entry, i);
  //   if (!isValidDate) return;
  // }
  //     // for (const payment of processedPaymentList) {
  //       const pmtSrc = payment.Payment_Source;
  //       const pmtType = payment.Payment_Type;
  //       const enteredFrom = payment.ENTERED_FROM;
  //       const chargedProc = payment.Charged_Proc_Code;
  //       const paidProc = payment.Paid_Proc_Code;
  //       const amountPaid = payment.Amount_Paid;
  //       const amountAdjusted = payment.Amount_Adjusted;
  //       const rejectAmount = payment.Reject_Amount;

  //       if (["I", "Q", "P", "C"].includes(pmtSrc)) {
  //         if (!pmtType || pmtType === '') {
  //           swal('Failed', 'Claim Payment cannot be saved without the mandatory payment information, please fill in the required fields.', 'error');
  //           return;
  //         }
  //       }
  //       if (!["I", "Q", "P", "C"].includes(pmtSrc)) {
  //         if (!pmtType || !enteredFrom || !chargedProc || !paidProc) {
  //           swal('Failed', 'Payment cannot be saved without the mandatory payment information, please fill in the required fields.', 'error');
  //           return;
  //         }
  //       }
  //       if (["Q", "O"].includes(pmtSrc)) {
  //         if (!isNaN(amountPaid) && amountPaid > 0 || amountPaid == undefined) {
  //           // swal({title: 'Error',text: 'Amount paid can not be greater than 0',icon: 'error'}).then(() => {payment.Amount_Paid = null;});
  //            swal('Failed', 'Amount paid can not be greater than 0.', 'error');
  //            payment.Amount_Paid = null;
  //           return;
  //         }
  //       }
  //       let amtPaid = payment.Amount_Paid;
  //       let amtAdj = payment.Amount_Adjusted;
  //       let amtAppr = payment.Amount_Approved;
  //       const isCareVoyant = payment.ENTERED_FROM === "60"; // CareVoyant
  //       // Strict validation ONLY if not CareVoyant
  //            if (amtPaid == null ) {
  //           // amtPaid = 0;
  //           payment.Amount_Paid = 0;
  //         }
  //         if (amtAppr == null ) {
  //           // amtAppr = 0;
  //           payment.Amount_Approved = 0;
  //         }
  //         if(payment.Amount_Adjusted == "0.00"){
  //           payment.Amount_Adjusted = "0" 
  //         }
  //       if (!isCareVoyant) {
  //      //   const isAmtAdjInvalid = amtAdj === null || amtAdj === '';

  //         if (payment.Amount_Adjusted ==="" || payment.Amount_Adjusted === null && payment.Amount_Adjusted === "0"  && payment.Amount_Approved === 0 && payment.Amount_Paid === 0) {
  //           swal('Failed', "Amount Paid / Amount Adjusted / Amount Approved can't be null.", 'error');
  //           return false;
  //         }
  //       }
  //       // if ((amountAdjusted) && amountAdjusted !== '0' || amountAdjusted !== '0.00')
  //       // if (amountAdjusted && parseFloat(amountAdjusted) !== 0) {
  //       //   if (!payment.ERA_ADJUSTMENT_CODE || payment.ERA_ADJUSTMENT_CODE === '') {
  //       //     swal('Failed', 'Please enter an adjustment code if you have entered an amount in adjustment field.', 'error');
  //       //     return;
  //       //   }
  //       // }
  //       if (amountAdjusted && parseFloat(amountAdjusted) !== 0) {
  //         const isCareVoyant = payment.ENTERED_FROM === "60"; // CareVoyant

  //         if (!isCareVoyant) {
  //           if (!payment.ERA_ADJUSTMENT_CODE || payment.ERA_ADJUSTMENT_CODE === '') {
  //             swal('Failed', 'Please enter an adjustment code if you have entered an amount in adjustment field.', 'error');
  //             return;
  //           }
  //         }
  //       }
  //       if (payment.Date_Entry == null || payment.Date_Entry == "") {
  //         swal('Failed', "Please Enter Entry Date.", 'error');
  //         return false;

  //       }

  //     //   let amtPaid = payment.Amount_Paid;
  //     //   let amtAdj = payment.Amount_Adjusted;
  //     //   let amtAppr = payment.Amount_Approved;
  //     //   const isCareVoyant = payment.ENTERED_FROM === "60"; // CareVoyant
  //     //   // Strict validation ONLY if not CareVoyant
  //     //        if (amtPaid == null ) {
  //     //       // amtPaid = 0;
  //     //       payment.Amount_Paid = 0;
  //     //     }
  //     //     if (amtAppr == null ) {
  //     //       // amtAppr = 0;
  //     //       payment.Amount_Approved = 0;
  //     //     }
  //     //     if(payment.Amount_Adjusted == "0.00"){
  //     //       payment.Amount_Adjusted = "0" 
  //     //     }
  //     //   if (!isCareVoyant) {
  //     //  //   const isAmtAdjInvalid = amtAdj === null || amtAdj === '';

  //     //     if (payment.Amount_Adjusted =="" || payment.Amount_Adjusted == null && payment.Amount_Adjusted == "0"  && payment.Amount_Approved == 0 && payment.Amount_Paid == 0) {
  //     //       swal('Failed', "Amount Paid / Amount Adjusted / Amount Approved can't be null.", 'error');
  //     //       return false;
  //     //     }
  //     //   }





  //       // Auto-assign 0 if any value is null, undefined, or empty
  //       // if (amtPaid === null || amtPaid === undefined || amtPaid.toString() === '') {
  //       //   amtPaid = 0;
  //       //   payment.Amount_Paid = 0;
  //       // }

  //       // if (amtAdj === null || amtAdj === undefined || amtAdj === '') {
  //       //   amtAdj = '0';
  //       //   payment.Amount_Adjusted = '0';
  //       // }

  //       // if (amtAppr === null || amtAppr === undefined || amtAppr.toString() === '') {
  //       //   amtAppr = 0;
  //       //   payment.Amount_Approved = 0;
  //       // }




  //       // Now proceed to save payment safely

  //       // const amtPaid = payment.Amount_Paid;
  //       // const amtAdj = payment.Amount_Adjusted;
  //       // const amtAppr = payment.Amount_Approved;

  //       // const isAmtPaidInvalid = amtPaid === null || amtPaid === undefined || amtPaid.toString() === '';
  //       // const isAmtAdjInvalid = amtAdj === null || amtAdj=== '';
  //       // const isAmtApprInvalid = amtAppr === null || amtAppr === undefined || amtAppr.toString() === '';

  //       // if (isAmtPaidInvalid || isAmtAdjInvalid || isAmtApprInvalid) {
  //       //   swal('Failed', "Amount Paid / Amount Adjusted / Amount Approved can't be null..", 'error');
  //       //   return;
  //       // }

  //       if (!isNaN(rejectAmount) && rejectAmount > 0) {
  //            
  //         const isCareVoyant = payment.ENTERED_FROM === "60"; // CareVoyant
  //         if (!isCareVoyant) {

  //           if (!payment.Reject_Type || !payment.Reject_Amount) {
  //             swal('Failed', 'Please enter Payment Rejection Type.', 'error');
  //             return;
  //           }
  //         }
  //       }
  //     }

  //     this.API.PostData('/Demographic/InsertOrUpdateClaimPayments', processedPaymentList, (res) => {
  //       if (res.Status === 'Success') {
  //         this.claimModalRef.hide();
  //         this.cdr.detectChanges();
  //         this.claimViewModel.claimPayments = [];
  //         this.cdr.detectChanges();
  //         this.getPostedClaims();
  //         this.cdr.detectChanges();
  //         this.fetchBatchDataAndUpdateRemainingAmount(batchID);
  //         this.cdr.detectChanges();
  //       } else {
  //         this.toaster.error(res.Status || 'Failed to post payments.', 'Error');
  //       }
  //     });
  //   }

  // async savePostPayments() {   
  //   const paymentList = this.claimViewModel.claimPayments.map(p => p.claimPayments);
  //   const batchID = this.batchID;
  //   const batchDate = this.batchDate;
  //   const claimNo = this.claimsNo;
  //   const Check_Number = this.Check_No;
  //   const Check_Date = this.Cheque_Date;
  //   const Deposit_Date = this.Deposit_Date;

  //   const processedPaymentList = paymentList
  //     .filter(payment => {
  //       if (payment.Deleted === true) return true;
  //       if (payment.claim_payments_id === 0) return true;
  //       if (!payment.originalData) return true;

  //       const original = payment.originalData;
  //       return (
  //         original.Amount_Paid !== payment.Amount_Paid ||
  //         original.Payment_Type !== payment.Payment_Type ||
  //         original.ENTERED_FROM !== payment.ENTERED_FROM ||
  //         original.Amount_Adjusted !== payment.Amount_Adjusted ||
  //         original.Payment_Source !== payment.Payment_Source ||
  //         original.Details !== payment.Details ||
  //         original.Reject_Type !== payment.Reject_Type ||
  //         original.Reject_Amount !== payment.Reject_Amount ||
  //         original.Paid_Proc_Code !== payment.Paid_Proc_Code ||
  //         original.Charged_Proc_Code !== payment.Charged_Proc_Code ||
  //         original.Check_No !== payment.Check_No ||
  //         original.Cheque_Date !== payment.Cheque_Date ||
  //         original.Date_Adj_Payment !== payment.Date_Adj_Payment ||
  //         original.DEPOSITSLIP_ID !== payment.DEPOSITSLIP_ID ||
  //         original.Contractual_Amt !== payment.Contractual_Amt ||
  //         original.DepositDate !== payment.DepositDate ||
  //         original.ERA_Rejection_CATEGORY_CODE !== payment.ERA_Rejection_CATEGORY_CODE
  //       );
  //     })
  //     .map(payment => ({
  //       ...payment,
  //       Claim_No: claimNo,
  //     //  Check_No: Check_Number,//here this is handled from batch cheque but it should be handle when there is no data in batch then from payment it should be bind if user entered from calim/or manually.
  //      Check_No: Check_Number ? Check_Number : payment.Check_No,
  //   Cheque_Date: Check_Date ? Check_Date : payment.Cheque_Date,
  //       Charged_Proc_Code: payment.Charged_Proc_Code ? payment.Charged_Proc_Code.split(' ')[0] : '',
  //       DepositDate: Deposit_Date ? Deposit_Date : payment.DepositDate,
  //     }));

  //   for (let i = 0; i < processedPaymentList.length; i++) {
  //     const payment = processedPaymentList[i];
  //     const isCareVoyant = payment.ENTERED_FROM === "60";

  //     if (isCareVoyant) {
  //       const isValidDate = await this.validateDateEntry(payment.Date_Entry, i);
  //       if (!isValidDate) return;
  //     }

  //     const pmtSrc = payment.Payment_Source;
  //     const pmtType = payment.Payment_Type;
  //     const enteredFrom = payment.ENTERED_FROM;
  //     const chargedProc = payment.Charged_Proc_Code;
  //     const paidProc = payment.Paid_Proc_Code;
  //     const amountPaid = payment.Amount_Paid;
  //     const amountAdjusted = payment.Amount_Adjusted;
  //     const rejectAmount = payment.Reject_Amount;

  //     if (["I", "Q", "P", "C"].includes(pmtSrc)) {
  //       if (!pmtType || pmtType === '') {
  //         swal('Failed', 'Claim Payment cannot be saved without the mandatory payment information, please fill in the required fields.', 'error');
  //         return;
  //       }
  //     }

  //     if (!["I", "Q", "P", "C"].includes(pmtSrc)) {
  //       if (!pmtType || !enteredFrom || !chargedProc || !paidProc) {
  //         swal('Failed', 'Payment cannot be saved without the mandatory payment information, please fill in the required fields.', 'error');
  //         return;
  //       }
  //     }

  //     if (["Q", "O"].includes(pmtSrc)) {
  //       if (!isNaN(amountPaid) && (amountPaid > 0 || amountPaid === undefined)) {
  //         swal('Failed', 'Amount paid can not be greater than 0.', 'error');
  //         payment.Amount_Paid = null;
  //         return;
  //       }
  //     }

  //     if (payment.Amount_Paid == null) {
  //       payment.Amount_Paid = 0;
  //     }
  //     if (payment.Amount_Approved == null) {
  //       payment.Amount_Approved = 0;
  //     }
  //     if (payment.Amount_Adjusted === "0.00") {
  //       payment.Amount_Adjusted = "0";
  //     }

  //     if (!isCareVoyant) {
  //       if (
  //         (payment.Amount_Adjusted === "" || payment.Amount_Adjusted == null || payment.Amount_Adjusted === "0") &&
  //         payment.Amount_Approved === 0 &&
  //         payment.Amount_Paid === 0
  //       ) {
  //         swal('Failed', "Amount Paid / Amount Adjusted / Amount Approved can't be null.", 'error');
  //         return false;
  //       }
  //     }

  //     if (amountAdjusted && parseFloat(amountAdjusted) !== 0) {
  //       if (!isCareVoyant) {
  //         if (!payment.ERA_ADJUSTMENT_CODE || payment.ERA_ADJUSTMENT_CODE === '') {
  //           swal('Failed', 'Please enter an adjustment code if you have entered an amount in adjustment field.', 'error');
  //           return;
  //         }
  //       }
  //     }

  //     if (!payment.Date_Entry) {
  //       swal('Failed', "Please Enter Entry Date.", 'error');
  //       return false;
  //     }

  //     if (!isNaN(rejectAmount) && rejectAmount > 0) {
  //       if (!isCareVoyant) {
  //         if (!payment.Reject_Type || !payment.Reject_Amount) {
  //           swal('Failed', 'Please enter Payment Rejection Type.', 'error');
  //           return;
  //         }
  //       }
  //     }
  //   }

  //   this.API.PostData('/Demographic/InsertOrUpdateClaimPayments', processedPaymentList, (res) => {
  //     if (res.Status === 'Success') {
  //       this.claimModalRef.hide();
  //       this.cdr.detectChanges();
  //       this.claimViewModel.claimPayments = [];
  //       this.getPostedClaims();
  //       this.fetchBatchDataAndUpdateRemainingAmount(batchID);
  //     } else {
  //       this.toaster.error(res.Status || 'Failed to post payments.', 'Error');
  //     }
  //   });
  // }


  validateDateEntry(dateValue: string, ndx: number): Promise<boolean> {
    return new Promise((resolve) => {
      const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/\d{4}$/; // MM/DD/YYYY format
      if (!dateRegex.test(dateValue)) {
        swal({
          title: 'Confirmation',
          text: "Invalid date format. Please use MM/DD/YYYY.",
          type: 'warning',
          confirmButtonColor: '#3085d6',
          confirmButtonText: 'OK',
        }).then(() => {
          this.claimPaymentModel[ndx].claimPayments.Date_Entry = '';
          resolve(false);
        });
        this.isSavePaymentButtonDisabled = false;
        return;
      }

      const today = new Date();
      const enteredDate = new Date(dateValue);
      if (enteredDate > today) {
        swal({
          title: 'Confirmation',
          text: "Future dates are not allowed in Entry Date field. Please select a date on or before current date.",
          type: 'error',
          confirmButtonColor: '#3085d6',
          confirmButtonText: 'OK',
        }).then(() => {
          this.claimPaymentModel[ndx].claimPayments.Date_Entry = '';
          resolve(false);
        });
        this.isSavePaymentButtonDisabled = false;
        return;
      }

      // this.AddNotesForCareVoyant(ndx,dateValue);
      resolve(true);
    });
  }




  fetchBatchDataAndUpdateRemainingAmount(batchID: number) {
    const searchParams = { BatchID: batchID };
    this.API.PostData('/Payments/SearchBatch', searchParams, (response) => {
      if (response.Status === 'Success' && response.Response.length > 0) {
        const matchedBatch = response.Response.find(p => p.BatchID == batchID);

        if (matchedBatch) {
          const remainingAmount = matchedBatch.Remaining_Amount;
          this.batchDataService.updateRemainingAmount(remainingAmount);
        } else {
          console.warn(`No batch found for batchID: ${batchID}`);
        }
      } else {
        console.warn('Batch search returned empty or failed.');
      }
    });

  }
  getPaymentType() {
    //     if(this.PaymentClaimNo != 0){
    //   this.batchId=this.batchID
    //  }
    this.API.getData(`/Payments/GetBatchType?batchID=${this.batchId}`).subscribe(summary => {
      if (summary.Status === 'Success') {
        this.Batch_Status = summary.Response;
      } else {
        this.resetAllButtonFlags();
        this.toaster.error('Failed to fetch.', 'Error');
        this.isSavePaymentButtonDisabled = false;

      }
    });
  }
  getCheckDetail() {
    this.API.getData(`/Payments/GetBatchCheckDetail?batchID=${this.batchId}`).subscribe(summary => {
      if (summary.Status === 'Success') {
        this.Check_No = summary.Response.CheckNo;
        this.Cheque_Date = summary.Response.CheckDate;
        this.batchOpenDate = summary.Response.BatchOpenDate;
        this.Deposit_Date = summary.Response.DepositDate;
      } else {
        this.resetAllButtonFlags();
        this.toaster.error('Failed to fetch.', 'Error');

      }
    });
  }
  setAllowedSources() {
    if (this.batchType === 'I') {
      this.allowedSources = ['1', '2', '3', 'A', 'W', 'L', 'K', 'Z', 'D'];
    } else if (this.batchType === 'P') {
      this.allowedSources = ['P', 'I', 'C', 'Q', 'O', 'Z', 'W', 'D'];
    } else {
      this.allowedSources = [];
    }
  }
  onPaymentListChanged(updatedPayments: any[]) {
    this.claimViewModel.claimPayments = updatedPayments;
  }
  public clearFields() {
    this.claimsData = []
    this.AddPaymentClaims = []
    this.Gindex = 0;
    this.isPAyAdded = false;
    this.claimsPaymentDetailModel = [];
    this.indexs = 0;
  }

  clearClaimAmount() {
    this.claimViewModel.ClaimModel.Pri_Ins_Payment = 0.00;
    this.claimViewModel.ClaimModel.Sec_Ins_Payment = 0.00;
    this.claimViewModel.ClaimModel.Oth_Ins_Payment = 0.00;
    this.claimViewModel.ClaimModel.Patient_Payment = 0.00;
    this.claimViewModel.ClaimModel.Adjustment = 0.00;
    this.claimViewModel.ClaimModel.Amt_Due = 0.00;
    this.claimViewModel.ClaimModel.Amt_Paid = 0.00;
    this.claimViewModel.ClaimModel.Claim_Total = 0.00;
    this.claimViewModel.ClaimModel.Hospital_From = "";
    this.claimViewModel.ClaimModel.Hospital_To = "";
    this.claimViewModel.ClaimModel.Bill_Date = "";
    this.claimViewModel.ClaimModel.DOS = "";
  }
  refresh() {
    this.cdr.detectChanges();
    this.claimViewModel.claimPayments = [];
  }

  onClaimNumberChange(event: Event): void {
    const claimValue = (event.target as HTMLInputElement).value;
    this.isClaimEntered = claimValue.trim() !== '';
    this.manualClaimNumber = claimValue;
    this.resetFields();
  }
  resetFields() {
    this.searchForm.get('selected_Patient').reset();
    this.searchForm.get('claimValue').reset();
    //Clear the available dropdown data arrays

    this.claimOptions = [];
  }

  onClaimDropdownChange(selectedValue: any): void {
    this.selectedPatientNum = this.patientOptions.find(
      x => x.Patient_Account === selectedValue
    );

    this.isClaimDropdownSelected = !!selectedValue;
    this.disabledIcon = !selectedValue; // enable only if a patient is selected
    this.cdr.detectChanges();
  }

  loadPatientData() {
    const practiceCode = this.GV.currentUser.selectedPractice.PracticeCode;
    const isDueOnly = this.isDueOnly; // true => Amt_Due > 0, false => All

    this.getPatientsWithDue(isDueOnly, practiceCode);
  }

  getPatientName(account: string): string {
    const patient = this.patientOptions.find(p => p.Patient_Account === account);
    if (patient) {
      return patient.FullName.split(' | ')[0];
    }
    return '';
  }

  // Method to set claim details for the modal
  setClaimDetails(claim: any) {

    this.claim_total = claim.claim_Total;
    this.amt_paid = claim.amt_paid;
    this.amt_due = claim.amt_due;
    this.Adjustment = claim.Adjustment;
  }
  onOpenPaymentModal(template: TemplateRef<any>) {

    const patient = this.searchForm.value.selected_Patient;
    // const claim = this.searchForm.value.claimValue.split(' | ')[0];
    const claimValue = this.searchForm.value.claimValue;
    const claim = claimValue ? claimValue.split(' | ')[0] : '';
    const batchID = this.batchId


    if (!patient || !claim) {
      this.toaster.error('Please select both Patient and Claim');
      return;
    }

    // Assign selected values to modal-bound properties
    this.patName = this.getPatientName(patient);
    this.patAccount = patient;
    this.claimsNo = claim;
    this.batchID = batchID;
    this.claimModalRef = this.modalService.show(template, {
      class: 'modal-xlg', backdrop: 'static',
      keyboard: false
    })
    this.modalController.register(this.claimModalRef);
  }


  getPatientsWithDue(isDueOnly: boolean, practiceCode: number) {
    
    const successMessage = "Patients data retrieved successfully.";

    this.API.getData(`/Payments/GetPatientsWithDue?isDueOnly=${isDueOnly}&practiceCode=${practiceCode}`).subscribe(
      response => {
        if (response.Status === "Success") {
          const resData = response.Response.map((patient: any) => ({ FullName: patient.Name, Patient_Account: patient.Id }));
          this.patientOptions = resData
          if (this.patientOptions.length > 0) {
            this.selectedPatient = null
            // this.selectedPatient = this.patientOptions[0].Patient_Account;
            this.searchForm.get('selected_Patient').setValue(this.selectedPatient);  // Set value manually
          }

        } else {
          this.resetAllButtonFlags();
          this.toaster.error(response.Response, "Error");

        }
      },
      error => {
        this.resetAllButtonFlags();
        this.toaster.error("Error while fetching patient data.", "Error");

      }
    );
  }
  // getClaimsByPatient(patientAccount: string) {

  //   if (!patientAccount) {
  //     return; // Stop if patientAccount is null, undefined, or empty
  //   }
  //   const showDueOnly = this.isDueOnly; // true if checkbox checked

  //   this.API.getData(`/Payments/GetPatientsClaims?patient_account=${patientAccount}&due_only=${showDueOnly}`).subscribe(
  //     response => {
  //       if (response.Status === "Success") {
  //         this.claimsResponse = response.Response;
  //         this.claimOptions = response.Response.map((claim: any) => ({
  //           ClaimID: claim.ClaimID,
  //           ClaimDetails: claim.ClaimDetails,  // Combine ClaimID and DOS for display
  //           Adjustment: claim.Adjustment,
  //           amt_due: claim.Amt_due,
  //           amt_paid: claim.Amt_Paid,
  //           claim_total: claim.Claim_Total,
  //           PatientLastName: claim.PatientLastName,
  //           PatientFirstName: claim.PatientFirstName,

  //         }));

  //         // If you just need the first record:

  //         // Optionally, you can set the first claim's values to the modal if needed
  //         if (this.claimOptions.length > 0) {
  //           this.setClaimDetails(this.claimOptions[0]); // Set the details for the first claim
  //         }
  //       } else {
  //         this.toaster.error(response.Response, "Error");
  //       }
  //     },
  //     error => {
  //       this.resetAllButtonFlags();
  //       this.toaster.error('An error occurred while fetching claims', 'Error');

  //     }
  //   );
  // }
  getClaimsByPatient(patientAccount: string) {

  if (!patientAccount) {
    return; // Stop if patientAccount is null, undefined, or empty
  }

  const showDueOnly = this.isDueOnly;

  this.spinner.show();

  this.API
    .getDataClaimModel(`/Payments/GetPatientsClaims?patient_account=${patientAccount}&due_only=${showDueOnly}`)
    .subscribe({
      next: (response: any) => {
        if (response.Status === "Success") {
          this.claimsResponse = response.Response;

          this.claimOptions = response.Response.map((claim: any) => ({
            ClaimID: claim.ClaimID,
            ClaimDetails: claim.ClaimDetails,
            Adjustment: claim.Adjustment,
            amt_due: claim.Amt_due,
            amt_paid: claim.Amt_Paid,
            claim_total: claim.Claim_Total,
            PatientLastName: claim.PatientLastName,
            PatientFirstName: claim.PatientFirstName,
          }));

          // Set first claim automatically
          if (this.claimOptions.length > 0) {
            this.setClaimDetails(this.claimOptions[0]);
          }
        } else {
          this.toaster.error(response.Response, "Error");
        }
      },
      error: () => {
        this.resetAllButtonFlags();
        this.toaster.error('An error occurred while fetching claims', 'Error');
      },
      complete: () => {
        // Always hide spinner after processing & UI render
        setTimeout(() => this.spinner.hide(), 0);
      }
    });
}

  onClaimSelectionChange(selectedClaimId: string) {
    this.editOverPaymentButton = false;
    this.isRemovePayment = false;
    if (!selectedClaimId) return;
    const claimNumber = selectedClaimId ? String(selectedClaimId).split('|')[0].trim() : null;

    this.API.getData(`/Payments/GetClaimDetails?claimID=${claimNumber}`).subscribe(
      (response) => {
        if (response.Status === "Success") {
          const claim = response.Response;
          this.tPatientAcc
        claim.PatientCreditBalance = claim.PatientCreditBalance == null ? 0 : claim.PatientCreditBalance;
        claim.InsuranceOverpaid = claim.InsuranceOverpaid == null ? 0 : claim.InsuranceOverpaid;
          this.claim_total = claim.Claim_total;
          this.amt_paid = claim.Amt_paid;
          this.amt_due = claim.Amt_due;
          this.Adjustment = claim.Adjustment;
          this.show_Insurance_Overpaid = claim.InsuranceOverpaid;
          this.show_Patient_Credit_Balance = claim.PatientCreditBalance;
          if (this.amt_due < 0) {
            this.editOverPaymentButton = true;
          }
        } else {
          this.resetAllButtonFlags();
          this.toaster.error(response.Response, "Error");

        }
      },
      (error) => {
        this.resetAllButtonFlags();
        this.toaster.error("Error fetching claim details", "Error");

      }
    );
  }

  fetchBatchData(batchId: number) {
    const searchParams = { BatchID: batchId };

    this.API.PostData('/Payments/SearchBatch', searchParams, (response) => {
      if (response.Status === 'Success' && response.Response.length > 0) {
        const matchedBatch = response.Response.find(p => p.BATCH_ID === batchId);
        const remainingAmount = matchedBatch ? matchedBatch.Remaining_Amount : 0;
        // update the service so other components get notified
        this.batchDataService.updateRemainingAmount(remainingAmount);
      }
    });
  }

  onGoClick(template?: TemplateRef<any>, action?: string, claimNo?: string) {
    this.isSavePaymentButtonDisabled = false;
    const practiceCode = this.GV.currentUser.selectedPractice.PracticeCode;
    // // Check if already processing
    // if (action === 'edit') {
    //   if (this.isEditButtonDisabled) return;
    //   this.isEditButtonDisabled = true;
    //   this.isGoButtonDisabled = true;
    // } else {
    //   if (this.isGoButtonDisabled) return;
    //   this.isGoButtonDisabled = true;
    // }

    this.editOverPaymentButton = false;
    this.isRemovePayment = false;
    
if (action === 'edit' && claimNo && template) {

  // Prevent double click
  if (this.isEditButtonDisabled) return;

  this.isEditButtonDisabled = true;
  this.isGoButtonDisabled = true;

  this.spinner.show(); 

  this.selectedClaimNo = claimNo;

  this.API
    .getDataClaimModel(`/Payments/GetClaimDetailsByClaimNumber?claimID=${claimNo}&practiceCode=${practiceCode}`)
    .subscribe({
      next: (response) => {
        if (response.Status === "Success") {

          const claim = response.Response;

          this.patAccount = claim.AccountNo;
          this.tPatientAcc = claim.AccountNo;
          this.patName = `${claim.LastName}, ${claim.FirstName}`;
          this.claimsNo = claim.ClaimNo;
          this.Adjustment = claim.Adjustments;
          this.amt_due = claim.DueAmount;
          this.amt_paid = claim.AmtPaid;
          this.claim_total = claim.ClaimTotal;
          this.TotaldueAmt = parseFloat(claim.amt_due.toFixed(2));
          this.show_Insurance_Overpaid = claim.OverpaidAmount;
          this.show_Patient_Credit_Balance = claim.CreditBalance;
          this.totaloverpayment =
            this.show_Insurance_Overpaid + this.show_Patient_Credit_Balance;

          this.setClaimDetails(claim);

          // WAIT for getClaimModel to finish
          this.getClaimModel(this.claimsNo, this.patAccount, template)
            .then(() => {
              return this.getClaimsWithPatientDue(); // if Promise, else remove return
            })
            .finally(() => {
              // hide spinner ONLY AFTER everything finishes
              setTimeout(() => this.spinner.hide(), 0);
            });

          this.searchForm.get('selected_Patient').reset();
          this.searchForm.get('claimValue').reset();
          this.searchForm.get('ClaimIds').reset();

          if (claim.amt_due < 0) {
            this.editOverPaymentButton = true;
          }

        } else {
          this.resetAllButtonFlags();
          this.toaster.error(response.Response, "Error");
          this.spinner.hide();
        }
      },
      error: () => {
        this.resetAllButtonFlags();
        this.toaster.error("Error fetching claim for edit", "Error");
        this.spinner.hide();
      }
    });

  return;
}

    if (this.isOldOpenBatch()) {
      this.toaster.error("This Batch belongs to previous month. Payments cannot be posted in previous month", "Error");
      this.isGoButtonDisabled = false;
      return;
    }
    
    const accountControl = this.searchForm.get('patientAccount');
    const claimControl = this.searchForm.get('claimValue');
    const accountEmpty = accountControl ? !accountControl.value : true;
    const dropdownEmpty = claimControl ? !claimControl.value : true;
    
    const claimNumberToUse = this.manualClaimNumber.trim()
      ? this.manualClaimNumber.trim()
      : (!dropdownEmpty ? this.searchForm.value.claimValue.split(' | ')[0] : '');

    if (claimNumberToUse) {
         // Check if already processing
    if (action === 'edit') {
      this.spinner.show();
      if (this.isEditButtonDisabled) return;
      this.isEditButtonDisabled = true;
      this.isGoButtonDisabled = true;
    } else {
      if (this.isGoButtonDisabled) return;
      this.isGoButtonDisabled = true;
    }
 this.spinner.show();
      this.API.getDataClaimModel(`/Payments/GetClaimDetailsByClaimNumber?claimID=${claimNumberToUse}&practiceCode=${practiceCode}`)
        .subscribe({
          next: (response) => {
            if (response.Status === "Success") {
              const claim = response.Response;
              this.patAccount = claim.AccountNo;
              this.tPatientAcc = this.patAccount;
              this.patName = `${claim.LastName}, ${claim.FirstName}`;
              this.claimsNo = claim.ClaimNo;
              this.Adjustment = claim.Adjustments;
              this.amt_due = claim.DueAmount;
              this.amt_paid = claim.AmtPaid;
              this.claim_total = claim.ClaimTotal;
              this.TotaldueAmt = claim.amt_due;
              this.show_Insurance_Overpaid = claim.OverpaidAmount;
              this.show_Patient_Credit_Balance = claim.CreditBalance;
          this.totaloverpayment= this.show_Insurance_Overpaid+this.show_Patient_Credit_Balance;
              // Set claim details and load claim model
              this.setClaimDetails(claim);
          //     this.getClaimModel(this.claimsNo, this.patAccount, template);
          // this.getClaimsWithPatientDue();
this.getClaimModel(this.claimsNo, this.patAccount, template)
  .then(() => {
    return this.getClaimsWithPatientDue();
  })
  .finally(() => {
    setTimeout(() => this.spinner.hide(), 0);
  });

              // Show Overpayment button only if due amount < 0
              // this.editOverPaymentButton = this.amt_due < 0;
              if (claim.amt_due < 0) {
                this.editOverPaymentButton = true;
              }
              // Reset search fields
              if(this.Claim_Number === 0){
              this.searchForm.patchValue({
                claimValue: '',
                ClaimIds: ''
              });
            
              this.manualClaimNumber = '';
              this.isClaimEntered = false;
            }
              // this.spinner.hide();
            } else {
              this.resetAllButtonFlags();
              this.toaster.error(response.Response || 'Failed to fetch claim details', 'Error');
              this.spinner.hide();
            }
          },
          error: () => {
            this.resetAllButtonFlags();
            this.toaster.error('Error fetching claim by claim number', 'Error');

          },
          complete: () => {
            // Always re-enable the button
            this.isButtonDisabled = false;
          }
        });

    } else {
      // Case: manual selection of patient and claim
      const patient = this.searchForm.value.selected_Patient;
      const claimValue = this.searchForm.value.claimValue;
      const claim = claimValue ? claimValue.split(' | ')[0] : '';

      // Validation
      if (!patient || !claim) {
        this.toaster.error('Please select both Patient and Claim', 'Error');
        this.isGoButtonDisabled = false;
        return;
      }

      // Assign values
      this.patName = this.getPatientName(patient);
      this.patAccount = patient;
      this.claimsNo = claim;

      // Load claim model
      this.getClaimModel(this.claimsNo, this.patAccount, template);

      // Reset fields after loading
      this.searchForm.patchValue({
        selected_Patient: '',
        claimValue: '',
        ClaimIds: ''
      });
      this.manualClaimNumber = '';
      this.isClaimEntered = false;

      // Enable button
      this.isGoButtonDisabled = false;
    }

    // this.openPaymentTemplate.emit(this.paymentAdvisoryModalTemplate);
  }

  onOpenPaymentModalClaim(template: TemplateRef<any>) {

    const batchID = this.batchId;
    this.batchID = batchID;

    this.claimModalRef = this.modalService.show(template, {
      class: 'modal-xlg',
      backdrop: 'static',
      keyboard: false
    });
    this.modalController.register(this.claimModalRef);
    this.getCurrentResposibleValue();
  }

  // Method to handle checkbox change for filtering data
  onCheckboxChange() {

    this.getClaimsByPatient(this.searchForm.get('selected_Patient').value)
    //this.loadPatientData(); // Reload patient data based on checkbox status
  }

  onCheckboxChangePatientGet() {
    // 1. Clear input field
    const claimInput = this.searchForm.get('ClaimIds');
    if(this.Claim_Number==0){
    if (claimInput) {
      claimInput.setValue('');
      claimInput.markAsPristine();
      claimInput.markAsUntouched();
    }
  }
    // 2. Clear selected value in dropdown
    const claimDropdown = this.searchForm.get('claimValue');
    if (claimDropdown) {
      claimDropdown.setValue(null);  // or ''
      claimDropdown.markAsPristine();
      claimDropdown.markAsUntouched();
    }

    // 3. Clear dropdown list values
    this.claimOptions = [];

    // 4. Reload patient list logic (if applicable)
    this.loadPatientData();
  }

  getPostedClaims() {
    this.API.getData(`/Payments/GetPostedClaims?batchID=${this.batchId}`).subscribe(
      response => {
        if (response.Status === "Success") {
          this.postedClaim = response.Response || [];

          if (this.dataTablePostedClaims) {
            this.dataTablePostedClaims.destroy();
            this.dataTablePostedClaims = null;
          }

          if (this.postedClaim.length > 0) {
            this.totalBatchAmtPaid = this.postedClaim[0].TotalAmtPaidForBatchID;
            this.remainingAmount = this.batchAmount - this.totalBatchAmtPaid - this.unappliedAmount;
            this.remainingBatchAmount = this.batchAmount - this.totalBatchAmtPaid
            this.batchDataService.updateRemainingAmount(this.remainingAmount);
            const rawDate = this.postedClaim[0].BatchOpenDate;
            const dateObj = new Date(rawDate);
            this.batchDate = `${(dateObj.getMonth() + 1).toString().padStart(2, '0')}/${dateObj.getDate().toString().padStart(2, '0')}/${dateObj.getFullYear()}`;
          } else {
            this.totalBatchAmtPaid = 0;
            this.batchDate = '';
          }

          // this.cdr.detectChanges();
          setTimeout(() => {
            const table: any = $('.dataTablePostedClaims');
            this.dataTablePostedClaims = table.DataTable({
              destroy: true,
              columnDefs: [
                { orderable: false, targets: -1 }
              ],
              language: {
                emptyTable: "No claims data available"
              },
              order: [1, 'desc'],
            });
          }, 100);
        } else {
          this.postedClaim = [];
          // this.totalBatchAmtPaid = 0;
          // this.batchDate = '';

          if (this.dataTablePostedClaims) {
            this.dataTablePostedClaims.destroy();
            this.dataTablePostedClaims = null;
          }

          //this.cdr.detectChanges();
        }
      },
      error => {
        this.toaster.error("Error while fetching patient data.", "Error");
      }
    );
  }

  allowOnlyNumbers(event: KeyboardEvent) {
    const charCode = event.key.charCodeAt(0);
    // Allow only digits (0-9)
    if (charCode < 48 || charCode > 57) {
      event.preventDefault();
    }
  }
  // //changes by Anum for bill next Validation
  // getCurrentResposibleValue() {
  //   this.API.getData(`/Payments/GetCurrentResponsible?claimId=${this.claimsNo}`).subscribe(res => {
  //     if (res.Status === 'Success') {
  //       this.currentResponsible = res.Response;
  //     } else {
  //       this.toaster.error('Failed to fetch.', 'Error');
  //     }
  //   });
  // }
getCurrentResposibleValue() {
  this.spinner.show();

  this.API
    .getDataClaimModel(`/Payments/GetCurrentResponsible?claimId=${this.claimsNo}`)
    .subscribe({
      next: (res: any) => {
        if (res.Status === 'Success') {
          this.currentResponsible = res.Response;
        } else {
          this.isSavePaymentButtonDisabled = false;
          this.toaster.error('Failed to fetch.', 'Error');
        }

        // hide spinner after success response handling
        setTimeout(() => this.spinner.hide(), 0);
      },
      error: () => {
        // always hide spinner on error
        this.spinner.hide();
        this.toaster.error('Failed to fetch.', 'Error');
        this.isSavePaymentButtonDisabled = false;
      }
    });
}

  checkClaimDueAmount(template: TemplateRef<any>) {
    
    this.CalculateNegativeBalance();
    if (this.ClaimDueAmt > 0) {
      this.populateBillNextOptions();   // build dropdown dynamically
      
      this.onOpenBillNextModal(template);
    } else if (this.ClaimDueAmt === 0 || this.ClaimDueAmt < 0) {
      // Set insurance + patient status = "Paid"
      this.claimViewModel.ClaimModel.Pat_Status = "P";
      this.claimViewModel.ClaimModel.Pri_Status = "P";
      this.claimViewModel.ClaimModel.Sec_Status = "P";
      this.claimViewModel.ClaimModel.Oth_Status = "P";
      this.savePayment();
    }
  }

  removeBatchPaymentwithBillNext(template: TemplateRef<any>) {
    if (this.removeClaimdue == 0 || this.removeClaimdue < 0) {
      this.claimViewModel.ClaimModel.Pat_Status = "P";
      this.claimViewModel.ClaimModel.Pri_Status = "P";
      this.claimViewModel.ClaimModel.Sec_Status = "P";
      this.claimViewModel.ClaimModel.Oth_Status = "P";
      this.updateClaimInsuranceAndPatientStatus();
    }
    if (this.removeClaimdue > 0) {
      
      this.resetBillNextModalState();   // 
      this.populateBillNextOptions();   // build dropdown dynamically
      this.onOpenBillNextModal(template);
    }
    
  this.reApplyRemoveSelectedStatus();
  }
  
  updateClaimInsuranceAndPatientStatus() {
  if (!this.claimViewModel.ClaimModel) {
    this.claimViewModel.ClaimModel = new ClaimModel();
  }
  if (!this.claimViewModel.ClaimModel.Claim_No || this.claimViewModel.ClaimModel.Claim_No === 0) {
    this.claimViewModel.ClaimModel.Claim_No = this.removedClaimNo ; 
  }
  //..
    // this.isPosting = true;
    this.API.PostData('/Demographic/SaveClaimModel', this.claimViewModel, (d) => {
      if (d.Status === "Success") {
               if (this.PaymentClaimNo !== 0) {
    const payload = {
      claimNo: this.PaymentClaimNo,
      Patient_Account:this.patAccount,
      disableForm: false,
      PatientFirstName: this.patName,
    };
    if (this.billNextModalRef) {
  this.billNextModalRef.hide();
}

if (this.claimModalRef) {
  this.claimModalRef.hide();
}
    const encoded = Common.encodeBase64(JSON.stringify(payload));
    this.router.navigate([
      '/Patient/Demographics',
      'ClaimDetail',
      encoded
    ]);
  }
        if (this.isRemovePayment == false) {
          this.toaster.success('Claim payments posted successfully.', 'Success');
          this.refreshParent.emit();
           
          if (this.billNextModalRef !== undefined) {
            this.billNextModalRef.hide();
            this.resetBillNextModalState();
          }
          this.claimModalRef.hide();
          this.claimViewModel.claimPayments = [];
          this.allPayments = [];
          this.isPosting = false;
          return;
        }

        if (this.isRemovePayment == true) {
          swal('Claim Removal', 'Claim has been deleted successfully.', 'success');
          this.getPostedClaims();
          this.refreshParent.emit();
          const searchParams = { BatchID: this.removeBatchId };
          this.API.PostData('/Payments/SearchBatch', searchParams, (response) => {
            if (response.Status === 'Success' && response.Response.length > 0) {
              const matchedBatch = response.Response.find(p => p.BatchID == this.removeBatchId);
              if (matchedBatch) {
                const remainingAmount = matchedBatch.Remaining_Amount;
                this.batchDataService.updateRemainingAmount(remainingAmount);
              }
            }
          });
          // this.toaster.success('Bill Next Set successfully.', 'Success');
          this.refreshParent.emit();

          if (this.billNextModalRef !== undefined) {
            this.billNextModalRef.hide();
            this.resetBillNextModalState();
          }
          this.claimModalRef.hide();
          this.claimViewModel.claimPayments = [];
          this.allPayments = [];
          this.isPosting = false;

        }


      }
      else {
        this.toaster.error("Error Occurred While Saving Bill Next Responsible");
        this.isSavePaymentButtonDisabled = false;
        this.isPosting = false;

      }
    })
//     if (this.isRemovePayment && this.selectedBillNextStatus) {
//   this.forceApplySelectedStatus();
// }
  }
  populateBillNextOptions() {
    
    this.billNextOptions = []; // reset
    this.selectedBillNext = ''

    if (this.claimViewModel.claimInusrance.length > 0) {
      this.claimViewModel.claimInusrance.forEach(ci => {
        if (ci.claimInsurance.Pri_Sec_Oth_Type === 'P') {
          this.billNextOptions.push('Primary');
        } else if (ci.claimInsurance.Pri_Sec_Oth_Type === 'S') {
          this.billNextOptions.push('Secondary');
        }
        else {
          // this.billNextOptions.push('Other');
           this.billNextOptions.push('Tertiary');
        }
      });
    }

    // Always add Patient
    this.billNextOptions.push('Patient');
  }



  billNextToSecondary() {

    // Check Primary payments
    const primaryPayments = this.allPayments.filter(
      (p: any) => p.Payment_Source === "1" &&  (p.Deleted === false  || p.Deleted === 0 || p.Deleted == null )
    );
    if (primaryPayments.length > 0) {

      const isPrimaryValid =
        primaryPayments.length > 0 &&
        primaryPayments.some(
          (p: any) => p.Amount_Approved > 0
        );

      if (isPrimaryValid) {

        // Primary is valid
        this.claimViewModel.ClaimModel.Pri_Status = "P";

        //  Secondary check
        const secondaryPayments = this.allPayments.filter(
          (p: any) => p.Payment_Source === "2" &&  (p.Deleted === false  || p.Deleted === 0 || p.Deleted == null )
        );
  // if (!(this.isRemovePayment && this.selectedBillNextStatus)) {
        if (secondaryPayments.length === 0) {
          this.claimViewModel.ClaimModel.Sec_Status = "N";
        } else {
          this.claimViewModel.ClaimModel.Sec_Status = "R";
        }
      // }
        const hasO = this.claimViewModel.claimInusrance.some(ci => ci.claimInsurance.Pri_Sec_Oth_Type === 'O');
        // Step 2: Set others to Waiting
        hasO ? this.claimViewModel.ClaimModel.Oth_Status = "W" : this.claimViewModel.ClaimModel.Oth_Status = "";

        // // Other insurance
        // if (this.claimViewModel.ClaimModel.Oth_Status) {
        //   this.claimViewModel.ClaimModel.Oth_Status = "W";
        // }

        // Patient status always waiting
        this.claimViewModel.ClaimModel.Pat_Status = "W";

      }
      else {
        // Primary not processed → show error toast
        this.toaster.error(
          "Secondary insurance cannot be billed when primary has not processed the claim."
        );
        this.isSavePaymentButtonDisabled = false;
        return;
      }
    } else {
      //  Primary not processed → show error toast
      this.toaster.error(
        "Secondary insurance cannot be billed when primary has not processed the claim."
      );
      this.isSavePaymentButtonDisabled = false;
      return;
    }
  if (this.isRemovePayment && this.selectedBillNextStatus) {
    this.forceApplySelectedStatus();
  }
    if (this.isRemovePayment == false) {
      this.savePayment();
      return
    }
    if (this.isRemovePayment == true) {
      this.updateClaimInsuranceAndPatientStatus();
    }
  }
  setBillNextStatusToPatient() {
    const claim = this.claimViewModel.ClaimModel;
    // Helper: check if payment exists for given sources
    const hasPatientPayment = this.allPayments.some(
      (p: any) =>
          (p.Deleted === false  ||p.Deleted === 0 || p.Deleted == null ) &&
        ["P", "I", "C", "T"].includes(
          p.Payment_Source
        )
    );

    // Step 2: Patient Status logic
    if (!(this.isRemovePayment && this.selectedBillNextStatus)) {
    if (hasPatientPayment) {
      claim.Pat_Status = "R";
    } else {
      claim.Pat_Status = "N";
    }
  }
    // Check if any 'S', any 'P' and any 'O' exist
    const hasP = this.claimViewModel.claimInusrance.some(ci => ci.claimInsurance.Pri_Sec_Oth_Type === 'P');
    const hasS = this.claimViewModel.claimInusrance.some(ci => ci.claimInsurance.Pri_Sec_Oth_Type === 'S');
    const hasO = this.claimViewModel.claimInusrance.some(ci => ci.claimInsurance.Pri_Sec_Oth_Type === 'O');

    if (hasP) {
      const primaryPayments = this.allPayments.filter(
        (p: any) => p.Payment_Source === "1" &&  (p.Deleted === false  || p.Deleted === 0 || p.Deleted == null )
      );

      const isPrimaryValid =
        primaryPayments.length > 0 &&
        primaryPayments.some(
          (p: any) => p.Amount_Approved > 0
        );

      if (isPrimaryValid) {
        claim.Pri_Status = "P";
      } else if (claim.Pri_Status) {
        claim.Pri_Status = "W";
      }

    }
    else {
      this.claimViewModel.ClaimModel.Pri_Status = "";
    }
    if (hasS) {

      const secondaryPayments = this.allPayments.filter(
        (p: any) => p.Payment_Source === "2" &&  (p.Deleted === false  || p.Deleted === 0 || p.Deleted == null )
      );

      const isSecondaryValid =
        secondaryPayments.length > 0 &&
        secondaryPayments.some(
          (p: any) => p.Amount_Approved > 0
        );

      if (isSecondaryValid) {
        claim.Sec_Status = "P";
      } else if (claim.Sec_Status) {
        claim.Sec_Status = "W";
      }

    } else {
      this.claimViewModel.ClaimModel.Sec_Status = "";
    }
    if (hasO) {
      const otherPayments = this.allPayments.filter(
        (p: any) => p.Payment_Source === "3" &&  (p.Deleted === false  || p.Deleted === 0 || p.Deleted == null )
      );

      const isOtherValid =
        otherPayments.length > 0 &&
        otherPayments.some(
          (p: any) => p.Amount_Approved > 0
        );

      if (isOtherValid) {
        claim.Oth_Status = "P";
      } else if (claim.Oth_Status) {
        claim.Oth_Status = "W";
      }
    }
    else {
      this.claimViewModel.ClaimModel.Oth_Status = "";
    }

    if (this.isRemovePayment == false) {
      this.savePayment();
      return
    }
    if (this.isRemovePayment && this.selectedBillNextStatus) {
  this.claimViewModel.ClaimModel.Pat_Status = this.selectedBillNextStatus;
}

    if (this.isRemovePayment == true) {
      this.updateClaimInsuranceAndPatientStatus();
    }
  }

  onBillNextSave() {
              this.isEditButtonDisabled = false;
       
    if (this.selectedBillNext === '') {
      this.toaster.error('Please select next responsible from Bill Next Dropdown.');
      this.isSavePaymentButtonDisabled = false;
      return;
    }
    
  if (this.showBillNextStatusDDL && !this.selectedBillNextStatus) {
    this.toaster.error('Please select status from Select Status dropdown.');
    this.isSavePaymentButtonDisabled = false;
    return;
  }
  // if (this.isRemovePayment && this.selectedBillNextStatus) {
  //   this.preserveClaimStatuses();
  // }
    if (this.isRemovePayment == true) {
      if (this.selectedBillNext === "Primary") {
        this.billNextToPrimary()
      }
      else if (this.selectedBillNext === "Secondary") {
        this.billNextToSecondary();
      }
      // else if (this.selectedBillNext === "Other")
      else if (this.selectedBillNext === "Tertiary") {        
        this.billNextToOther();
      } else if (this.selectedBillNext === "Patient") {
        this.setBillNextStatusToPatient();

      }
    }
    else {
      if (this.allPayments.length > 0) {
        if (this.selectedBillNext === "Primary") {
          this.billNextToPrimary()
        }
        else if (this.selectedBillNext === "Secondary") {
          this.billNextToSecondary();
        }
        // else if (this.selectedBillNext === "Other")
        else if (this.selectedBillNext === "Tertiary") {

          this.billNextToOther();
        } else if (this.selectedBillNext === "Patient") {
          this.setBillNextStatusToPatient();

        }

      }
    }
  if (!this.isRemovePayment) {
    this.applySelectedStatusNonBreaking();
  }
  //   if (this.showBillNextStatusDDL && this.selectedBillNextStatus) {
  //   // this.restoreUnchangedStatuses();
  //   this.forceApplySelectedStatus();
  // }
  }




savePayment() {
  try {
    if (this.processedPaymentList.length > 0) {
      this.API.PostData('/Demographic/InsertOrUpdateClaimPayments', this.processedPaymentList, (res) => {
          
      if (res.Status === 'Success') {
      this.tcbModalShow = false
             if(this.ClaimDueAmt >= 0){
                this.UpdateCliamOverPayment();
             }
          // Added By Hamza Akhlaq For Transfer Credit Balance
          if (this.transfercrditbalPayment && this.transfercrditbalPayment.length > 0) {
            const claimPayments = res.Response;

            this.transfercrditbalPayment.forEach(tp => {
                
              if (tp.claimPayments.Payment_Source === 'T') {
                tp.claimPayments.Amount_Paid = Math.abs(tp.claimPayments.Amount_Paid); // ignore +/- sign

                const match = claimPayments.find(cp =>
                  Math.abs(cp.Amount_Paid) === tp.claimPayments.Amount_Paid &&
                  cp.Payment_Source === tp.claimPayments.Payment_Source &&
                  cp.Sequence_No === Number(tp.claimPayments.Sequence_No)
                );

                if (match) {
                  tp.claimPayments.T_payment_id = match.claim_payments_id;
                    tp.claimPayments.Check_No = match.Check_No;
      tp.claimPayments.Date_Filing = match.Date_Filing || match.Date_Entry;
      tp.claimPayments.DepositDate = match.DepositDate || match.BATCH_DATE;
                }
              }
              tp.claimPayments.Sequence_No = null;
           
            });
            
            this.PostPayment();
          }
           this.AddPaymentNotesInDB();
          this.cdr.detectChanges();
          this.getPostedClaims();
          this.fetchBatchDataAndUpdateRemainingAmount(this.batchID);
          this.updateClaimInsuranceAndPatientStatus();
          this.isSavePaymentButtonDisabled = false;
          return;
        } else {
          this.toaster.error(res.Status || 'Failed to post payments.', 'Error');
          this.isSavePaymentButtonDisabled = false;
        }
      });
    } else {
      this.isSavePaymentButtonDisabled = false;
      if (this.allPayments.length > 0) {
        if (this.selectedBillNext === "Primary") {
          this.billNextToPrimary();
        } else if (this.selectedBillNext === "Secondary") {
          this.billNextToSecondary();
        }
        //  else if (this.selectedBillNext === "Other") 
          else if (this.selectedBillNext === "Tertiary"){
          this.billNextToOther();
        } else if (this.selectedBillNext === "Patient") {
          this.setBillNextStatusToPatient();
        }
      }
    }
  } catch (error) {
    this.isSavePaymentButtonDisabled = false;
    console.error('Error in savePayment:', error);
  }
}

  // savePayment() {
  //   if (this.processedPaymentList.length > 0) {
  //     this.API.PostData('/Demographic/InsertOrUpdateClaimPayments', this.processedPaymentList, (res) => {
  //       if (res.Status === 'Success') {
  //         this.cdr.detectChanges();
  //         this.getPostedClaims();
  //         this.fetchBatchDataAndUpdateRemainingAmount(this.batchID);
  //         this.updateClaimInsuranceAndPatientStatus();
  //         return;
  //       } else {
  //         this.toaster.error(res.Status || 'Failed to post payments.', 'Error');
  //       }
  //     });
  //   } else {
  //     this.updateClaimInsuranceAndPatientStatus();
  //     return;
  //   }
  // }
  // savePayment() {
  //   if (this.processedPaymentList.length > 0) {
  //     this.API.PostData('/Demographic/InsertOrUpdateClaimPayments', this.processedPaymentList, (res) => {
  //       if (res.Status === 'Success') {
  //         this.cdr.detectChanges();
  //             if(this.ClaimDueAmt >= 0){
  //             this.UpdateCliamOverPayment();
  //          }
  //         this.getPostedClaims();
  //         this.fetchBatchDataAndUpdateRemainingAmount(this.batchID);
  //         this.updateClaimInsuranceAndPatientStatus();
  //         return;
  //       } else {
  //         this.toaster.error(res.Status || 'Failed to post payments.', 'Error');
  //       }
  //     });
  //   } else {
  //     this.updateClaimInsuranceAndPatientStatus();
  //     return;
  //   }
  // }
  billNextToOther() {

    //  Step 1: Check Secondary payments
    const secondaryPayments = this.allPayments.filter(
      (p: any) => p.Payment_Source === "2" &&  (p.Deleted === false  || p.Deleted === 0 || p.Deleted == null )
    );
    if (secondaryPayments.length > 0) {

      const isSecondaryValid =
        secondaryPayments.length > 0 &&
        secondaryPayments.some(
          (p: any) => p.Amount_Approved > 0
        );

      if (isSecondaryValid) {
        //  if (!(this.isRemovePayment && this.selectedBillNextStatus)) {
        // Step 2: Update Secondary status
        this.claimViewModel.ClaimModel.Sec_Status = "P";
        //  }
        //  Step 3: Other insurance check
        const otherPayments = this.allPayments.filter(
          (p: any) => p.Payment_Source === "3" &&  (p.Deleted === false  || p.Deleted === 0 || p.Deleted == null )
        );
  // if (!(this.isRemovePayment && this.selectedBillNextStatus)) {
        if (otherPayments.length === 0) {
          this.claimViewModel.ClaimModel.Oth_Status = "N";
        } else {
          this.claimViewModel.ClaimModel.Oth_Status = "R";
        }
      // }
        //  Step 4: Patient always waiting
        this.claimViewModel.ClaimModel.Pat_Status = "W";
      } else {


        //  Secondary not processed → block
        this.toaster.error(
          "Tertiary insurance cannot be billed when secondary has not processed the claim."
        );
        this.isSavePaymentButtonDisabled = false;
        return;
      }
    } else {

      //  Secondary not processed → block
      this.toaster.error(
        "Tertiary insurance cannot be billed when secondary has not processed the claim."
      );
      this.isSavePaymentButtonDisabled = false;
      return;
    }
  if (this.isRemovePayment && this.selectedBillNextStatus) {
    this.forceApplySelectedStatus();
  }
    if (this.isRemovePayment == false) {
      this.savePayment();
      return
    }
    if (this.isRemovePayment == true) {
      this.updateClaimInsuranceAndPatientStatus();
    }
  }
  // billNextToPrimary() {

  //   // Step 1: Check Primary payments
  //   const primaryPayments = this.allPayments.filter(
  //     (p: any) => p.Payment_Source === "1" && !p.Deleted
  //   );

  //   if (primaryPayments.length === 0) {
  //     this.claimViewModel.ClaimModel.Pri_Status = "N";
  //   } else {
  //     this.claimViewModel.ClaimModel.Pri_Status = "R";
  //   }

  //   // Check if any 'S' and any 'O' exist
  //   const hasS = this.claimViewModel.claimInusrance.some(ci => ci.claimInsurance.Pri_Sec_Oth_Type === 'S');
  //   const hasO = this.claimViewModel.claimInusrance.some(ci => ci.claimInsurance.Pri_Sec_Oth_Type === 'O');
  //   //  Step 2: Set others to Waiting
  //   hasS ? this.claimViewModel.ClaimModel.Sec_Status = "W" : this.claimViewModel.ClaimModel.Sec_Status = "";
  //   hasO ? this.claimViewModel.ClaimModel.Oth_Status = "W" : this.claimViewModel.ClaimModel.Oth_Status = "";
  //   this.claimViewModel.ClaimModel.Pat_Status = "W";
  //   if (this.isRemovePayment == false) {
  //     this.savePayment();
  //     return
  //   }
  //   if (this.isRemovePayment == true) {
  //     this.updateClaimInsuranceAndPatientStatus();
  //   }

  // }

  billNextToPrimary() {

  // Step 1: Check Primary payments
  const primaryPayments = this.allPayments.filter(
    (p: any) => p.Payment_Source === "1" &&  (p.Deleted === false  || p.Deleted === 0 || p.Deleted == null )
  );

  // 🔒 AUTO STATUS — SKIP IN REMOVE MODE WHEN USER SELECTED
  if (!(this.isRemovePayment && this.selectedBillNextStatus)) {
    if (primaryPayments.length === 0) {
      this.claimViewModel.ClaimModel.Pri_Status = "N";
    } else {
      this.claimViewModel.ClaimModel.Pri_Status = "R";
    }
  }

  // Check if any 'S' and any 'O' exist
  const hasS = this.claimViewModel.claimInusrance.some(
    ci => ci.claimInsurance.Pri_Sec_Oth_Type === 'S'
  );
  const hasO = this.claimViewModel.claimInusrance.some(
    ci => ci.claimInsurance.Pri_Sec_Oth_Type === 'O'
  );

  // Step 2: Set others to Waiting (THIS IS OK)
  hasS ? this.claimViewModel.ClaimModel.Sec_Status = "W" : this.claimViewModel.ClaimModel.Sec_Status = "";
  hasO ? this.claimViewModel.ClaimModel.Oth_Status = "W" : this.claimViewModel.ClaimModel.Oth_Status = "";
  this.claimViewModel.ClaimModel.Pat_Status = "W";

  // 🔑 APPLY USER STATUS BEFORE UPDATE (THIS WAS MISSING)
  if (this.isRemovePayment && this.selectedBillNextStatus) {
    this.forceApplySelectedStatus();
  }

  // SAVE / UPDATE
  if (!this.isRemovePayment) {
    this.savePayment();
    return;
  }

  if (this.isRemovePayment) {
    this.updateClaimInsuranceAndPatientStatus();
  }
}


CalculateNegativeBalance()
    {
          this.TotalCharges = 0;
          this.TotalPaidAmt = 0;
          this.TotalAdjamt = 0;
          this.Totalamtadj = 0;
          this.ClaimDueAmt = 0;
          this.dueAmtForOverPayment=0
          this.TotalPaidAmt = 0;
          this.TotalAdjamt = 0;
         this.allPayments.forEach(payment => {
            const paidAmount =
              payment.Amount_Paid != null &&
              (payment.Amount_Paid) &&
              (payment.Deleted == null || payment.Deleted === false)
                ? (payment.Amount_Paid)
                : 0;
         
            this.TotalPaidAmt += paidAmount;
         
            const adjustedAmount =
              payment.Amount_Adjusted != null &&
              !isNaN(parseFloat(payment.Amount_Adjusted)) &&
              (payment.Deleted == null || payment.Deleted === false)
                ? parseFloat(payment.Amount_Adjusted)
                : 0;
         
            this.TotalAdjamt += adjustedAmount;
          });
         
                  this.Totalamtadj = this.TotalPaidAmt + this.TotalAdjamt + this.amt_paid + this.Adjustment ;
                  if (this.Totalamtadj > this.claim_total) {
                      let calculatedAmount = this.claim_total - this.Totalamtadj;
                      this.dueAmtForOverPayment = calculatedAmount < 0 ? calculatedAmount : -calculatedAmount;
                      this.dueAmtForOverPayment = parseFloat(this.dueAmtForOverPayment.toFixed(2));
                  }
                  this.ClaimDueAmt = this.claim_total - (this.TotalPaidAmt + this.TotalAdjamt)
         
}
// getProcessedPaymentList() {
//      
//   const paymentList = this.claimViewModel.claimPayments.map(p => p.claimPayments);
//        this.allPayments = [
//       ...paymentList
//     ].filter(p => !p.Deleted);
//      console.log('Payment List', this.allPayments);
//   const batchDate = this.batchDate;
//   const claimNo = this.claimsNo;
//   const Check_Number = this.Check_No;
//   const Check_Date = this.Cheque_Date;
//   const Deposit_Date = this.Deposit_Date;
 
//   return paymentList
//     .filter(payment => {
//       if (payment.Deleted === true)
//       {
//         this.Adjustment=0
//         this.amt_paid=0
//         return true;
//       }
//       if (payment.claim_payments_id === 0) return true;
//       if (!payment.originalData) return true;
//       const original = payment.originalData;
//       return (
//         original.Amount_Paid !== payment.Amount_Paid ||
//         original.Payment_Type !== payment.Payment_Type ||
//         original.ENTERED_FROM !== payment.ENTERED_FROM ||
//         original.Date_Entry !== payment.Date_Entry ||
//         original.Amount_Adjusted !== payment.Amount_Adjusted ||
//         original.Payment_Source !== payment.Payment_Source ||
//         original.Details !== payment.Details ||
//         original.Reject_Type !== payment.Reject_Type ||
//         original.Reject_Amount !== payment.Reject_Amount ||
//         original.Paid_Proc_Code !== payment.Paid_Proc_Code ||
//         original.Charged_Proc_Code !== payment.Charged_Proc_Code ||
//         original.Check_No !== payment.Check_No ||
//         original.Cheque_Date !== payment.Cheque_Date ||
//         original.Date_Filing !== payment.Date_Filing ||
//         original.Date_Adj_Payment !== payment.Date_Adj_Payment ||
//         original.DEPOSITSLIP_ID !== payment.DEPOSITSLIP_ID ||
//         original.Contractual_Amt !== payment.Contractual_Amt ||
//         original.DepositDate !== payment.DepositDate ||
//         original.ERA_Rejection_CATEGORY_CODE !== payment.ERA_Rejection_CATEGORY_CODE
//       );
//     })
//     .map(payment => ({
//       ...payment,
//       Claim_No: claimNo,
//       Check_No: Check_Number ? Check_Number : payment.Check_No,
//       Cheque_Date: Check_Date ? Check_Date : payment.Cheque_Date,
//       Date_Filing: Check_Date ? Check_Date : payment.Date_Filing,
//       Charged_Proc_Code: payment.Charged_Proc_Code ? payment.Charged_Proc_Code.split(' ')[0] : '',
//       DepositDate: Deposit_Date ? Deposit_Date : payment.DepositDate,
//     }));
   
// }
// getProcessedPaymentList() {
//   const paymentList = this.claimViewModel.claimPayments.map(p => p.claimPayments);

//   this.allPayments = [...paymentList].filter(p => !p.Deleted);

//   console.log('Payment List', this.allPayments);

//   const batchDate = this.batchDate;
//   const claimNo = this.claimsNo;
//   const Check_Number = this.Check_No;
//   const Check_Date = this.Cheque_Date;
//   const Deposit_Date = this.Deposit_Date;

//   // 1) Sum of Amount_Paid for Payment_Source = 'T'
//   const totalTPaid = paymentList
//  .filter(p =>
//   p &&
//   p.Payment_Source === 'T' &&
//   p.claim_payments_id === 0 &&
//   p.Amount_Paid != null &&
//   !isNaN(+p.Amount_Paid)
// )
//     .reduce((sum, p) => sum + Number(p.Amount_Paid), 0);
//   // 2) Find the *last* T-payment entry
//   //    (assuming “last” means last in array order)
//   const lastTPayment = [...paymentList]
//     .reverse()
//     .find(p => p.Payment_Source === 'T');

//   const lastTPaidAmount = lastTPayment ? Number(lastTPayment.Amount_Paid) : 0;

//   console.log('Total T Paid:', totalTPaid);
//   console.log('Last T Paid Amount:', lastTPaidAmount);

//   // Now you can save these to component-level variables
//   this.totalTPaid = totalTPaid;
//   this.lastTPaidAmount = lastTPaidAmount;

//   return paymentList
//     .filter(payment =>
//       payment.BATCH_NO !== null &&
//       payment.BATCH_NO !== undefined &&
//       payment.BATCH_NO !== "" &&
//       payment.BATCH_NO !== "0" &&
//       payment.BATCH_NO !== "null"
//     )

//     .filter(payment => {
//       if (payment.Deleted === true) {
//         this.Adjustment = 0;
//         this.amt_paid = 0;
//         return true;
//       }

//       if (payment.claim_payments_id === 0) return true;
//       if (!payment.originalData) return true;

//       const original = payment.originalData;

//       return (
//         original.Amount_Paid !== payment.Amount_Paid ||
//         original.Payment_Type !== payment.Payment_Type ||
//         original.ENTERED_FROM !== payment.ENTERED_FROM ||
//         original.Date_Entry !== payment.Date_Entry ||
//         original.Amount_Adjusted !== payment.Amount_Adjusted ||
//         original.Payment_Source !== payment.Payment_Source ||
//         original.Details !== payment.Details ||
//         original.Reject_Type !== payment.Reject_Type ||
//         original.Reject_Amount !== payment.Reject_Amount ||
//         original.Paid_Proc_Code !== payment.Paid_Proc_Code ||
//         original.Charged_Proc_Code !== payment.Charged_Proc_Code ||
//         original.Check_No !== payment.Check_No ||
//         original.Date_Filing !== payment.Date_Filing ||
//         original.Date_Adj_Payment !== payment.Date_Adj_Payment ||
//         original.DEPOSITSLIP_ID !== payment.DEPOSITSLIP_ID ||
//         original.Contractual_Amt !== payment.Contractual_Amt ||
//         original.DepositDate !== payment.DepositDate ||
//         original.ERA_Rejection_CATEGORY_CODE !== payment.ERA_Rejection_CATEGORY_CODE
//       );
//     })

//     .map(payment => ({
//       ...payment,
//       Claim_No: claimNo,
//       Check_No: Check_Number ? Check_Number : payment.Check_No,
//       Date_Filing: Check_Date ? Check_Date : payment.Date_Filing,
//       Charged_Proc_Code: payment.Charged_Proc_Code ? payment.Charged_Proc_Code.split(' ')[0] : '',
//       DepositDate: Deposit_Date ? Deposit_Date : payment.DepositDate,
//     }));
// }


getProcessedPaymentList() {

  if (!this.claimViewModel.claimPayments.length) {
    return [];
  }

  // ---------------------------
  // STEP 1: BUILD CLEAN PAYMENT LIST
  // ---------------------------
  const paymentList = this.claimViewModel.claimPayments
    .map(p => p.claimPayments)
    .filter(p => p != null);

  // All non-deleted payments (for UI)
  this.allPayments = paymentList.filter(p => !p.Deleted);
  const claimNo = this.claimsNo;
  const Check_Number = this.Check_No;
  const Check_Date = this.Cheque_Date;
  const Deposit_Date = this.Deposit_Date;

  // ---------------------------
  // STEP 2: TOTAL T PAYMENTS
  // ---------------------------
  const totalTPaid = paymentList
    .filter(p =>
      p &&
      p.Payment_Source === 'T' &&
      p.claim_payments_id === 0 &&
      p.Amount_Paid != null &&
      !isNaN(+p.Amount_Paid)
    )
    .reduce((sum, p) => sum + Number(p.Amount_Paid), 0);

  const lastTPayment = [...paymentList]
    .reverse()
    .find(p => p && p.Payment_Source === 'T');

  const lastTPaidAmount = lastTPayment
    ? Number(lastTPayment.Amount_Paid)
    : 0;

  this.totalTPaid = totalTPaid;
  this.lastTPaidAmount = lastTPaidAmount;

  // ---------------------------
  // STEP 3: FIND CHANGED PAYMENTS
  // ---------------------------
  const changedPayments = paymentList
    .filter(payment =>
      payment.BATCH_NO !== null &&
      payment.BATCH_NO !== undefined &&
      payment.BATCH_NO !== '' &&
      payment.BATCH_NO !== '0' &&
      payment.BATCH_NO !== 'null'
    )
    .filter(payment => {

      if (payment.Deleted === true) {
        this.Adjustment = 0;
        this.amt_paid = 0;
        return true;
      }

      // New record
      if (payment.claim_payments_id === 0) return true;

      // No original snapshot → treat as changed
      if (!payment.originalData) return true;

        const original = payment.originalData;

      return (
        original.Amount_Paid !== payment.Amount_Paid ||
        original.Payment_Type !== payment.Payment_Type ||
        original.ENTERED_FROM !== payment.ENTERED_FROM ||
        original.Date_Entry !== payment.Date_Entry ||
        original.Amount_Adjusted !== payment.Amount_Adjusted ||
        original.Payment_Source !== payment.Payment_Source ||
        original.Details !== payment.Details ||
        original.Reject_Type !== payment.Reject_Type ||
        original.Reject_Amount !== payment.Reject_Amount ||
        original.Paid_Proc_Code !== payment.Paid_Proc_Code ||
        original.Charged_Proc_Code !== payment.Charged_Proc_Code ||
        original.Check_No !== payment.Check_No ||
        original.Date_Filing !== payment.Date_Filing ||
        original.Date_Adj_Payment !== payment.Date_Adj_Payment ||
        original.DEPOSITSLIP_ID !== payment.DEPOSITSLIP_ID ||
        original.Contractual_Amt !== payment.Contractual_Amt ||
        original.DepositDate !== payment.DepositDate ||
        original.ERA_Rejection_CATEGORY_CODE !== payment.ERA_Rejection_CATEGORY_CODE
      );
    });

  // ---------------------------
  // STEP 4: IF NO CHANGES → RETURN ORIGINAL LIST
  // ---------------------------
  const resultSource =
    changedPayments.length > 0 ? changedPayments : paymentList;

  // ---------------------------
  // STEP 5: MAP FINAL PAYLOAD
  // ---------------------------
  const finalResult = resultSource.map(payment => ({
    ...payment,
    Claim_No: claimNo,
    Check_No: Check_Number ? Check_Number : payment.Check_No,
    Date_Filing: Check_Date ? Check_Date : payment.Date_Filing,
    Charged_Proc_Code: payment.Charged_Proc_Code
      ? payment.Charged_Proc_Code.split(' ')[0]
      : '',
    DepositDate: Deposit_Date ? Deposit_Date : payment.DepositDate
  }));

  return finalResult;
}



  postPaymentClick(template: TemplateRef<any>) {
              this.isEditButtonDisabled = false;

    // Just call savePostPayments - it handles the flag management internally
    const processedPaymentLists = this.getProcessedPaymentList();
    this.savePostPayments('', template);
  }


  onOpenBillNextModal(template: TemplateRef<any>) {
    
    // this.closeModal();
      this.resetBillNextModalState(); 
    this.billNextModalRef = this.modalService.show(template, {
      class: 'modal-xlg',
      backdrop: 'static',
      keyboard: false
    });
    this.modalController.register(this.billNextModalRef);
   this.isGoButtonDisabled = false;
  }
  closeBillNextModal() {
        this.isSavePaymentButtonDisabled = false;
    this.billNextModalRef.hide();
    this.resetBillNextModalState();
  }

  removeClaim(claimNo: string, Amtdue: string, overPaymentTemplate: TemplateRef<any>, billNextTemplate: TemplateRef<any>) {
    
    if (this.isPreviousMonthBatch()) {
      this.toaster.error(
        "This Batch belongs to previous month. Claim entry cannot be removed",
        "Error"
      );
      return;
    }
//  const amt = parseFloat(Amtdue);
//     if(amt < 0){
//        this.TotaldueAmt = amt
//     }

    const batchID = this.batchId;
    this.Batch_Number=this.batchId
    this.removeBatchId = batchID;
    this.isRemovePayment = false;
    if (claimNo && batchID) {
      this._apiService.confirmFun(
        'Confirm',
        'Are you sure you want to remove the claim?',
        () => {
          this.preRemovePaymentsSnapshot = JSON.parse(
  JSON.stringify(this.allPayments || [])
);
 
// Added BY Pir Ubaid For Generate auto-note for claim removal - only for payments matching this batchID
                const paymentsForThisBatch = (this.claimViewModel.claimPayments || []).filter(p =>
                  p.claimPayments.BATCH_NO == batchID
                );
                if (paymentsForThisBatch.length > 0) {
                  this.updatedNotes = [];
                  const removeNote = this.generatePaymentNotes(paymentsForThisBatch, "removeClaim");
                  // if (removeNote && removeNote.trim().length > 0) {
                  //   this.updatedNotes.push(removeNote);
                  // }
                  // Save the removal auto-note
                  this.AddPaymentNotesInDB();
                }

          this.API.getData(`/Payments/DeleteClaimPayment?batchID=${batchID}&claimNo=${claimNo}&Amtdue=${Amtdue}`)
            .subscribe(res => {
              if (res.Status === 'Success') {

      this.API.getData(`/Payments/GetPayments?claimId=${claimNo}`)
            .subscribe(res => { 
              if (res.Status === 'Success') {
this.claimLevelPayments = res.Response
this.allPayments = res.Response
    // this.generatePaymentNotes(this.claimViewModel.claimPayments, "removeClaim");
    // this.AddPaymentNotesInDB();
              }
              else {
         
              }
            },
              (error) => {
         
              });
                setTimeout(() => {
                  this.getPostedClaims();
                  if (!this.claimList || this.claimList.length === 0) {
                    this.totalBatchAmtPaid = 0; // reset total posted amount
                    this.remainingAmount = this.batchAmount - this.totalBatchAmtPaid - this.unappliedAmount;
                  }
                  this.cdr.detectChanges();
                }, 300);
                this.removeClaimdue = parseFloat(res.Response);
                if (this.removeClaimdue < 0) {
                  this.TotaldueAmt = this.removeClaimdue
                  this.isRemovePayment = true;
                  this.claimsNo = claimNo;
                  this.showOverPaymentUpdateModel(overPaymentTemplate);
                  return;
                }

                if (this.removeClaimdue >= 0) {
                  this.paymentresponsbility.Claim_No = this.claimsNo;
                  this.paymentresponsbility.Insurance_over_paid = "0";
                  this.paymentresponsbility.Patient_credit_balance = "0";
                  this.paymentresponsbility.Total_Responsibility = "0";

                  this.API.PostData('/Demographic/AddClaimOverPayment', this.paymentresponsbility, (d) => {
                    if (d.Status === "Success") {
                      setTimeout(() => {
                        this.getPostedClaims();
                        if (!this.claimList || this.claimList.length === 0) {
                          this.totalBatchAmtPaid = 0; // reset total posted amount
                          this.remainingAmount = this.batchAmount - this.totalBatchAmtPaid - this.unappliedAmount;

                        }
                        this.cdr.detectChanges();
                      }, 300);
                      this.isRemovePayment = true;
                      // this.getPostedClaims();
                      // this.removeBatchPaymentwithBillNext(billNextTemplate);

                      setTimeout(() => {
  this.removeBatchPaymentwithBillNext(billNextTemplate);
}, 300);
                    } else {
                    }
                  });
                }
              }
              else {
                swal('Claim Removal', res.Response, 'error');
              }
            },
              (error) => {
                console.error("Error while deleting claim:", error);
                this.toaster.error("Failed to remove claim. Please try again.", "Error");
              });
        }
      );
    }
  }

  //#region  unapplied payments

  getEncodedUrl(claimNo: string, patientAccount: string, firstname: string, lastName: string) {
    return Common.encodeBase64(JSON.stringify({
      Patient_Account: patientAccount,
      PatientFirstName: firstname,
      PatientLastName: lastName,
      claimNo: claimNo,
      disableForm: true,
    }));

  }

  isPreviousMonthBatch(): boolean {
    if (!this.batchDate) return false;

    const batchDate = new Date(this.batchDate);
    const today = new Date();

    // Compare year and month together
    return (
      batchDate.getFullYear() < today.getFullYear() ||
      (batchDate.getFullYear() === today.getFullYear() &&
        batchDate.getMonth() < today.getMonth())
    );
  }
  onAction(action: { type: string, payload: any }) {
    switch (action.type) {
      case 'View':
        this.router.navigate([
          '/Patient/Demographics/ClaimSummary',
          Common.encodeBase64(JSON.stringify({
            Patient_Account: this.searchForm.get('selected_Patient').value,
            disableForm: true
          }))
        ]);
        break;
    }
  }

  getEncodedSummaryUrl(): string {
    const claim = this.claimsResponse[0]; // first element of the array
    if (!claim) return '';

    return Common.encodeBase64(JSON.stringify({
      Patient_Account: this.searchForm.get('selected_Patient').value,
      PatientFirstName: claim.PatientFirstName,
      PatientLastName: claim.PatientLastName,
      claimNo: 0,
      disableForm: false
    }));
  }

  onOpenUnappliedPaymentModal(template: TemplateRef<any>) {
    this.unappliedRef = this.modalService.show(template, {
      class: 'modal-xlg',
      backdrop: 'static',
      keyboard: false
    });
    this.modalController.register(this.unappliedRef);

  }

  isOldOpenBatch(): boolean {
    if (!this.batchDate) return false;

    const batchDate = new Date(this.batchDate);
    const today = new Date();

    const batchMonth = batchDate.getMonth();
    const batchYear = batchDate.getFullYear();

    const currentMonth = today.getMonth();
    const currentYear = today.getFullYear();

    //  Condition: Batch is older than current month-year and not closed
    const isOldBatch =
      batchYear < currentYear ||
      (batchYear === currentYear && batchMonth < currentMonth);

    return isOldBatch && this.Batch_Status !== 'Closed';
  }


  unappliedAmount: any;

  onTotalAmountReceived(amount: number) {
    this.unappliedAmount = amount;
    this.remainingAmount = this.batchAmount - this.totalBatchAmtPaid - this.unappliedAmount;
    this.batchDataService.updateRemainingAmount(this.remainingAmount);
    this.updateRemaingAmount.emit()
  }
  //#endregion
  unappliedPaymentDetails: any;
  getUnappliedPaymentByBatch() {
    this.API.getData(`/Demographic/GetUnappliedPaymentsByBatchNo?batchNo=${this.batchId}`).subscribe(res => {
      if (res.Status === 'Success') {
        if (this.dataTableUnappliedPayments) {
          this.dataTableUnappliedPayments.destroy();
          this.dataTableUnappliedPayments = null;
        }

        this.unappliedPaymentDetails = res.Response;


        this.unappliedAmount = this.unappliedPaymentDetails.reduce((sum, payment) => sum + Number(payment.Amount || 0), 0);

        if (!this.totalBatchAmtPaid) {
          this.totalBatchAmtPaid = 0
        }
        this.remainingAmount = this.batchAmount - this.totalBatchAmtPaid - this.unappliedAmount;
        this.batchDataService.updateRemainingAmount(this.remainingAmount);

        this.cdr.markForCheck();
      }
    });
  }

  oncloseUnapplied() {
    this.isSavePaymentButtonDisabled = false;

    this.unappliedRef.hide()
  }
  getBatchDate() {
    this.API.getData(`/Payments/GetBatchDate?batchID=${this.batchId}`).subscribe(summary => {
      if (summary.Status === 'Success') {
        const data = summary.Response;

        this.batchOpenDate = data.BatchOpenDate;

      // store individual disable states
      this.disableCheckNo = !!data.CheckNo;
      this.disableCheckDate = !!data.CheckDate;
      this.disableDepositDate = !!data.DepositDate;
    } else {
      this.toaster.error('Failed to fetch batch details.', 'Error');
    }
  }, error => {
    console.error('API Error:', error);
    this.toaster.error('An error occurred while fetching batch details.', 'Error');
  });
}


  isCurrentMonth(batchOpenDate: string | Date): boolean {
    if (!batchOpenDate) return false;
    const batchDate = new Date(batchOpenDate);
    const today = new Date();

    return (
      batchDate.getMonth() === today.getMonth() &&
      batchDate.getFullYear() === today.getFullYear()
    );
  }
  // #region Batch Overpayment Handle below
  negativeValueValidator(control: AbstractControl): ValidationErrors | null {
    let value = control.value;

    // Allow empty input; required validator will handle it
    if (value === null || value === undefined || value === '') return null;

    // Always treat value as a string
    value = value.toString();

    // Allow typing in-progress negative numbers:
    // "-" or "-." or "-<digits>" or "-<digits>."
    if (/^-?\d*\.?\d*$/.test(value) && value.startsWith('-')) {
      return null; // valid in-progress negative number
    }

    // Otherwise, invalid
    return { invalidValue: true };
  }

  // Helper method to reset all button disabled flags
  resetAllButtonFlags(): void {
    this.isGoButtonDisabled = false;
    this.isEditButtonDisabled = false;
    this.isRemoveButtonDisabled = false;
    this.isSavePaymentButtonDisabled = false;
    this.isSkipConfirmationDisabled = false;
    this.isSaveOverpaymentDisabled = false;
  }

  EditPaymentResponsibility(template: TemplateRef<any>) {
    if (this.TotaldueAmt != 0) {
      this.TotaldueAmt = this.TotaldueAmt;
      this.showOverPaymentUpdateModel(template)
    }
  }
  showOverPaymentUpdateModel(template: TemplateRef<any>) {
    this.updateOverPaymentModle = this.modalService.show(template, {
      class: 'modal-xlg',
      backdrop: 'static',
      keyboard: false
    });
    this.modalController.register(this.updateOverPaymentModle);
    return;
  }

  UpdateResponseBility(value: string) {
        this.isSavePaymentButtonDisabled = false;
    if (value === '' || value === undefined || value === 'Select Responsible') {
      this.toast.error('Please select an overpayment responsible option before saving');
      return;
    }
    let noteDetail = "";
    const userid = this.Gv.currentUser.RolesAndRights[0].UserId;
    const username = this.Gv.currentUser.RolesAndRights[0].UserName;
    var batchId = this.batchID;
    if(batchId==undefined){
     batchId=this.Batch_Number
    }
    if (value === "creditbalance") {
      this.paymentResponsibilityForm.get('creditbalance').setValue(this.TotaldueAmt);
      this.paymentResponsibilityForm.get('overpaid').setValue('')
      noteDetail = `Claim moved to patient credit balance bucket $${this.TotaldueAmt} By User ${userid},${username},By Batch ID : [${batchId}]`;
    }
    if (value === "overpaid") {
      this.paymentResponsibilityForm.get('overpaid').setValue(this.TotaldueAmt)
      this.paymentResponsibilityForm.get('creditbalance').setValue('');
      noteDetail = `Claim moved to insurance overpaid bucket $${this.TotaldueAmt} By User ${userid},${username},By Batch ID : [${batchId}]`;
    }
    if (value === "bothpatientinsurance") {
      const overpaidValue = Number(this.paymentResponsibilityForm.get('overpaid').value) || 0;
      const creditBalanceValue = Number(this.paymentResponsibilityForm.get('creditbalance').value) || 0;
      const totalResponsibilityAmount = overpaidValue + creditBalanceValue;
      noteDetail = `Claim moved to insurance overpaid bucket $${overpaidValue}, patient credit balance bucket ${creditBalanceValue} By User ${userid},${username},By Batch ID : [${batchId}]`;
      if (overpaidValue == null || creditBalanceValue == null) {
        this.toast.error('credit balance & overpaid can not be null.');
        this.isSavePaymentButtonDisabled = false;
        return;
      }
      if (overpaidValue == 0 && creditBalanceValue == 0) {
        this.toast.error('Both field are required. Please enter amounts for Patient Credit Balance and Insurance Overpaid.');
        this.isSavePaymentButtonDisabled = false;
        return;
      }
      if (overpaidValue == 0) {
        this.toast.error('Please enter amounts less than zero.');
        this.isSavePaymentButtonDisabled = false;
        return;
      }
      if (creditBalanceValue == 0) {
        this.toast.error('Please enter amounts less than zero.');
        this.isSavePaymentButtonDisabled = false;
        return;
      }
      if (totalResponsibilityAmount != this.TotaldueAmt) {
        this.toast.error('The amounts you entered do not match the total due amount at claim level. Please review and adjust accordingly');
        this.isSavePaymentButtonDisabled = false;
        return;
      }
    }
    this.paymentresponsbility.Claim_No = this.claimsNo;
    this.paymentresponsbility.Insurance_over_paid = this.paymentResponsibilityForm.get('overpaid').value;
    this.paymentresponsbility.Patient_credit_balance = this.paymentResponsibilityForm.get('creditbalance').value;
    this.paymentresponsbility.Total_Responsibility = this.TotaldueAmt;
    this.API.PostData('/Demographic/AddClaimOverPayment', this.paymentresponsbility, (d) => {
      if (d.Status == "Success") {
        if (this.isRemovePayment == false) {
          this.AddNotesForOverPayment(noteDetail);
          swal('Payment', 'Overpayment Updated Successfully.', 'success');
          this.onClaimSelectionChange(this.claimsNo);
          this.UpdatePaymentModelHidden();
          // this.checkClaimDueAmount(this.billNextModalTemplate);
          this.refreshParent.emit();
        }
        if (this.isRemovePayment == true) {
          swal('Claim Removal', 'Claim has been deleted successfully.', 'success');
          this.UpdatePaymentModelHidden();
          this.AddNotesForOverPayment(noteDetail);
          this.getPostedClaims();
          this.refreshParent.emit();
          const searchParams = { BatchID: this.removeBatchId };
          this.API.PostData('/Payments/SearchBatch', searchParams, (response) => {
            if (response.Status === 'Success' && response.Response.length > 0) {
              const matchedBatch = response.Response.find(p => p.BatchID == this.removeBatchId);
              if (matchedBatch) {
                const remainingAmount = matchedBatch.Remaining_Amount;
                this.batchDataService.updateRemainingAmount(remainingAmount);
              }
            }
          });
        }

      }

      else {
        this.isSavePaymentButtonDisabled = false;
        swal({
          title: 'Error',
          text: "Failed to update payment.",
          icon: 'error',
          button: 'OK'
        });

        this.refresh();
      }
    });

  }
  UpdatePaymentModelClose() {
        this.isSavePaymentButtonDisabled = false;
    this.selectedResponsibleParty = 'Select Responsible';
    this.paymentResponsibilityForm.reset({
      creditbalance: '-', // Reset to initial value '-'
      overpaid: '-'       // Reset to initial value '-'
    });
    this.updateOverPaymentModle.hide();
  }
  UpdatePaymentModelHidden() {
    this.paymentResponsibilityForm.reset({ creditbalance: '-', overpaid: '-' });
    this.selectedResponsibleParty = 'Select Responsible'
    this.updateOverPaymentModle.hide();
    this.editOverPaymentButton = true

  }
  async savePostPayments(value: string, template: TemplateRef<any>) {
    this.isGoButtonDisabled = false;
    // Prevent double-click
    if (this.isSavePaymentButtonDisabled) return;
    this.isSavePaymentButtonDisabled = true;

    if (this.isOldOpenBatch()) {
      this.toaster.error("This Batch belongs to previous month. Payments cannot be posted in previous month", "Error");
      this.isSavePaymentButtonDisabled = false;
      return;
    }
    // this.processedPaymentLists = this.getProcessedPaymentList();
    // this.existingPayments = this.getProcessedPaymentList()
    // const paymentList = this.claimViewModel.claimPayments.map(p => p.claimPayments);
    // const batchID = JSON.stringify(this.batchId).trim();
    // const batchDate = this.batchDate;
    // const claimNo = this.claimsNo;
    // const Check_Number = this.Check_No;
    // const Check_Date = this.Cheque_Date;
    // const Deposit_Date = this.Deposit_Date;

 this.processedPaymentList = this.getProcessedPaymentList();
this.existingPayments=this.getProcessedPaymentList()
  const paymentList = this.claimViewModel.claimPayments.map(p => p.claimPayments);
  this.generatePaymentNotes(this.claimViewModel.claimPayments,"oldclaim")
  this.transfercrditbalPayment = this.claimViewModel.claimPayments.filter(p => p.claimPayments.Payment_Source == "T" && p.claimPayments.claim_payments_id === 0);
 
  const batchID = JSON.stringify(this.batchId).trim();
  const batchDate = this.batchDate;
  const claimNo = this.claimsNo;
  const Check_Number = this.Check_No;
  const Check_Date = this.Cheque_Date;
  const Deposit_Date = this.Deposit_Date;
    this.processedPaymentList = this.getProcessedPaymentList();
    this.existingPayments = this.getProcessedPaymentList()
    // const paymentList = this.claimViewModel.claimPayments.map(p => p.claimPayments);
    // const batchID = JSON.stringify(this.batchId).trim();
    // const batchDate = this.batchDate;
    // const claimNo = this.claimsNo;
    // const Check_Number = this.Check_No;
    // const Check_Date = this.Cheque_Date;
    // const Deposit_Date = this.Deposit_Date;

    this.processedPaymentLists = paymentList
      .filter(payment => {
        if (payment.Deleted === true) return true;
        if (payment.claim_payments_id === 0) return true;
        if (payment.BATCH_NO === "0" || payment.BATCH_NO == null) return true;
        if (!payment.originalData) return true;
        const original = payment.originalData;
        return (
          original.Amount_Paid !== payment.Amount_Paid ||
          original.Payment_Type !== payment.Payment_Type ||
          original.ENTERED_FROM !== payment.ENTERED_FROM ||
          original.Date_Entry !== payment.Date_Entry ||
          original.Amount_Adjusted !== payment.Amount_Adjusted ||
          original.Payment_Source !== payment.Payment_Source ||
          original.Details !== payment.Details ||
          original.Reject_Type !== payment.Reject_Type ||
          original.Reject_Amount !== payment.Reject_Amount ||
          original.Paid_Proc_Code !== payment.Paid_Proc_Code ||
          original.Charged_Proc_Code !== payment.Charged_Proc_Code ||
          original.Check_No !== payment.Check_No ||
          original.Date_Filing !== payment.Date_Filing ||
          original.Date_Adj_Payment !== payment.Date_Adj_Payment ||
          original.DEPOSITSLIP_ID !== payment.DEPOSITSLIP_ID ||
          original.Contractual_Amt !== payment.Contractual_Amt ||
          original.DepositDate !== payment.DepositDate ||
          original.ERA_Rejection_CATEGORY_CODE !== payment.ERA_Rejection_CATEGORY_CODE
        );
      })
      .map(payment => ({
        ...payment,
        Claim_No: claimNo,
        //  Check_No: Check_Number,//here this is handled from batch cheque but it should be handle when there is no data in batch then from payment it should be bind if user entered from calim/or manually.
        Check_No: Check_Number ? Check_Number : payment.Check_No,
        Date_Filing: Check_Date ? Check_Date : payment.Date_Filing,
        Charged_Proc_Code: payment.Charged_Proc_Code ? payment.Charged_Proc_Code.split(' ')[0] : '',
        DepositDate: Deposit_Date ? Deposit_Date : payment.DepositDate,
      }));
    const hasNewRow = (this.claimViewModel.claimPayments || []).some(
      p => p.claimPayments && p.claimPayments.claim_payments_id === 0
    );

    const validPayments = hasNewRow
      ? [{}] // pretend one valid payment exists
      : (this.claimViewModel.claimPayments || []).filter(
        p =>
          p.claimPayments &&
          p.claimPayments.claim_payments_id !== 0 &&
          p.claimPayments.BATCH_NO != null &&
          p.claimPayments.BATCH_NO !== '' &&
          p.claimPayments.BATCH_NO === batchID &&
          p.claimPayments.Deleted === false
      );

    if (validPayments.length === 0) {
      swal('Failed', 'Please add a payment entry', 'error');
      this.isSavePaymentButtonDisabled = false;
      return;
    }

    this.CalculateNegativeBalance();
    for (let i = 0; i < this.processedPaymentList.length; i++) {

      const payment = this.processedPaymentList[i];


      const isCareVoyant = payment.ENTERED_FROM === "60";

      if (isCareVoyant) {

        const isValidDate = await this.validateDateEntry(payment.Date_Entry, i);
        if (!isValidDate) return;

        const today = new Date();
        const enteredDate = new Date(payment.Date_Entry);
        if (enteredDate > today) {
          this.isSavePaymentButtonDisabled = false;
          swal({
            title: 'Confirmation',
            text: "Future dates are not allowed in Entry Date field.Please select a date on or before current date",
            type: 'error',
            confirmButtonColor: '#3085d6',
            confirmButtonText: 'OK',
          }).then(() => {
            payment.Date_Entry = ''
          });
          return;
        }
        if (payment.claim_payments_id != 0) {
          let sequence = 0
          sequence = payment.Sequence_No;
          sequence = sequence - 1
          this.careformattedDate = ""
          const userid = this.Gv.currentUser.RolesAndRights[0].UserId;
          const username = this.Gv.currentUser.RolesAndRights[0].UserName;
          const entrydate = payment.Date_Entry;
          const currentDateStr = this.oldclaimpayments[sequence].claimPayments.Date_Entry;
          const currentDate = new Date(currentDateStr);
          this.careformattedDate = `${(currentDate.getMonth() + 1).toString().padStart(2, '0')}/${currentDate.getDate().toString().padStart(2, '0')}/${currentDate.getFullYear()}`;
          let value = `Entry date in Payment section has been modified from Current Date ${this.careformattedDate} to ${entrydate} BY User ${username}`;
          this.claimNotesModel.Response.Note_Detail = value
          this.claimNotesModel.Response.IsAuto_Note = true
          this.claimNotesModel.Response.Claim_No = this.claimsNo;
          if (this.careformattedDate != entrydate) {
            this.API.PostData('/Demographic/SaveClaimNotes/', this.claimNotesModel.Response, (d) => {
              if (d.Status == "Sucess") {
                value = ""
              }
            });

      }
           

        }

      }
      const pmtSrc = payment.Payment_Source;
      const pmtType = payment.Payment_Type;
      const enteredFrom = payment.ENTERED_FROM;
      const chargedProc = payment.Charged_Proc_Code;
      const paidProc = payment.Paid_Proc_Code;
      const amountPaid = payment.Amount_Paid;
      const amountAdjusted = payment.Amount_Adjusted;
      const rejectAmount = payment.Reject_Amount;
      if(pmtSrc != "T"){
      
        
      if (["I", "Q", "P", "C"].includes(pmtSrc)) {
        if (payment.BATCH_NO ==batchID && !pmtType || pmtType === '' ) {
          swal('Failed', 'Claim Payment cannot be saved without the mandatory payment information, please fill in the required fields.', 'error');
                                this.isSavePaymentButtonDisabled = false;
          return;
        }
      }

      if (!["I", "Q", "P", "C"].includes(pmtSrc)) {
        if (payment.BATCH_NO ==batchID && !pmtType || !enteredFrom || !chargedProc || !paidProc) {
          swal('Failed', 'Payment cannot be saved without the mandatory payment information, please fill in the required fields.', 'error');
                      this.isSavePaymentButtonDisabled = false;
          return;
        }
      }

      if (payment.BATCH_NO ==batchID && ["Q", "O"].includes(pmtSrc)) {
        if (!isNaN(amountPaid) && (amountPaid > 0 || amountPaid === undefined)) {
          swal('Failed', 'Amount paid can not be greater than 0.', 'error');
          payment.Amount_Paid = null;
                      this.isSavePaymentButtonDisabled = false;
          return;
        }
      }

      



      if (payment.Amount_Paid == null) {
        payment.Amount_Paid = 0;
      }
      if (payment.Amount_Approved == null) {
        payment.Amount_Approved = 0;
      }
      if (payment.Amount_Adjusted === "0.00") {
        payment.Amount_Adjusted = "0";
      }

      if(pmtSrc!="T"){
         if (!isCareVoyant) {
        if (payment.Amount_Approved > this.claim_total) {
          return;
        }
        if (
          (payment.Amount_Adjusted === "" || payment.Amount_Adjusted == null || payment.Amount_Adjusted === "0") &&
          payment.Amount_Approved === 0 &&
          payment.Amount_Paid === 0
        ) {
          swal('Failed', "Amount Paid / Amount Adjusted / Amount Approved can't be null.", 'error');
                      this.isSavePaymentButtonDisabled = false;
          return false;
        }
      }

      if (amountAdjusted && parseFloat(amountAdjusted) !== 0) {
        if (!isCareVoyant) {
          if (!payment.ERA_ADJUSTMENT_CODE || payment.ERA_ADJUSTMENT_CODE === '') {
            swal('Failed', 'Please enter an adjustment code if you have entered an amount in adjustment field.', 'error');
                        this.isSavePaymentButtonDisabled = false;
            return;
          }
        }
      } else {
        // Case 2: No adjustment but code entered
        if (payment.BATCH_NO ==batchID && payment.ERA_ADJUSTMENT_CODE && payment.ERA_ADJUSTMENT_CODE.trim() !== '') {
          swal('Failed', 'Adjustment code is not allowed when adjustment amount is 0 or empty.', 'error');
                      this.isSavePaymentButtonDisabled = false;
          return;
        }
      }

      if (!payment.Date_Entry) {
        swal('Failed', "Please Enter Entry Date.", 'error');
                    this.isSavePaymentButtonDisabled = false;
        return false;
      }

      if (!isNaN(rejectAmount) && rejectAmount > 0) {
        if (!isCareVoyant) {
          // if (!payment.Reject_Type || !payment.Reject_Amount) {
          if (!payment.Reject_Type && !payment.ERA_Rejection_CATEGORY_CODE) {

            swal('Failed', 'Please enter Payment Rejection Type.', 'error');
                        this.isSavePaymentButtonDisabled = false;
            return;
          }
        }
      }

      }
         
    }
    if(pmtSrc =="T" && (payment.Amount_Paid >= 0  && payment.T_payment_id ==null)){
     
        swal('Failed', "Amt. Paid is required. Please enter a negative amount", 'error');
            this.isSavePaymentButtonDisabled = false;
          return;
        }
        if(payment.T_payment_id ==null){
 if(pmtSrc =="T" &&payment.Delete==false && (Math.abs(payment.Amount_Paid) >  Math.abs(this.totaloverpayment) )){
           swal('Failed', "Please enter an amount Amt. Paid equal to or less than the Patient Credit balance", 'error');
                       this.isSavePaymentButtonDisabled = false;
          return;
        }
        if(pmtSrc =="T" && (payment.Amount_Paid ==0 || payment.Amount_Paid == undefined || payment.Amount_Paid == null || isNaN(Number(payment.Amount_Paid)))){
      swal('Failed', "Amount Paid can't be null ", 'error');
                  this.isSavePaymentButtonDisabled = false;
      return;
    }
        if(   Math.abs(this.totalTPaid) > Math.abs(this.totaloverpayment)){
          swal('Failed', "Please enter an amount Amt. Paid equal to or less than the Patient Credit balance", 'error');
                      this.isSavePaymentButtonDisabled = false;
          return;
        }
         if( pmtSrc =="T" && Math.abs(this.totaloverpayment) >= Math.abs(payment.Amount_Paid) &&  this.lastTPaidAmount < 0 ){
      
          this.isTCB=true
    }
        }
       
  


  }
  if (this.transfercrditbalPayment.length > 0 && this.tcbModalShow == false && this.isTCB == true ) 
      {
        this.showtcbmodel(this.tcbModalTemplate);
        return;
      }
    
    if (this.ClaimDueAmt < 0) {
      this.TotaldueAmt = parseFloat(this.TotaldueAmt.toFixed(2));
      this.showOverPaymentModel(this.overPaymentModalTemplate);
      return;
    }
    else {
      this.checkClaimDueAmount(template);
    }
  }

  // async savePostPaymentsWithOverpayment(value : string)
  //  {
  //   const paymentList = this.claimViewModel.claimPayments.map(p => p.claimPayments);
  //   const batchID = this.batchID;
  //   const batchDate = this.batchDate;
  //   const claimNo = this.claimsNo;
  //   const Check_Number = this.Check_No;
  //   const Check_Date = this.Cheque_Date;
  //   const Deposit_Date = this.Deposit_Date;

  //    this.processedPaymentList = paymentList
  //     .filter(payment => {
  //       if (payment.Deleted === true) return true;
  //       if (payment.claim_payments_id === 0) return true;
  //       if (!payment.originalData) return true;

  //       const original = payment.originalData;
  //       return (
  //         original.Amount_Paid !== payment.Amount_Paid ||
  //         original.Payment_Type !== payment.Payment_Type ||
  //         original.ENTERED_FROM !== payment.ENTERED_FROM ||
  //         original.Amount_Adjusted !== payment.Amount_Adjusted ||
  //         original.Payment_Source !== payment.Payment_Source ||
  //         original.Details !== payment.Details ||
  //         original.Reject_Type !== payment.Reject_Type ||
  //         original.Reject_Amount !== payment.Reject_Amount ||
  //         original.Paid_Proc_Code !== payment.Paid_Proc_Code ||
  //         original.Charged_Proc_Code !== payment.Charged_Proc_Code ||
  //         original.Check_No !== payment.Check_No ||
  //         original.Cheque_Date !== payment.Cheque_Date ||
  //         original.Date_Adj_Payment !== payment.Date_Adj_Payment ||
  //         original.DEPOSITSLIP_ID !== payment.DEPOSITSLIP_ID ||
  //         original.Contractual_Amt !== payment.Contractual_Amt ||
  //         original.DepositDate !== payment.DepositDate ||
  //         original.ERA_Rejection_CATEGORY_CODE !== payment.ERA_Rejection_CATEGORY_CODE
  //       );
  //     })
  //     .map(payment => ({
  //       ...payment,
  //       Claim_No: claimNo,
  //     //  Check_No: Check_Number,//here this is handled from batch cheque but it should be handle when there is no data in batch then from payment it should be bind if user entered from calim/or manually.
  //      Check_No: Check_Number ? Check_Number : payment.Check_No,
  //   Cheque_Date: Check_Date ? Check_Date : payment.Cheque_Date,
  //       Charged_Proc_Code: payment.Charged_Proc_Code ? payment.Charged_Proc_Code.split(' ')[0] : '',
  //       DepositDate: Deposit_Date ? Deposit_Date : payment.DepositDate,
  //     }));

  //   for (let i = 0; i < this.processedPaymentList.length; i++) {
  //     const payment = this.processedPaymentList[i];
  //     const isCareVoyant = payment.ENTERED_FROM === "60";

  //     if (isCareVoyant) {
  //       const isValidDate = await this.validateDateEntry(payment.Date_Entry, i);
  //       if (!isValidDate) return;
  //     }

  //     const pmtSrc = payment.Payment_Source;
  //     const pmtType = payment.Payment_Type;
  //     const enteredFrom = payment.ENTERED_FROM;
  //     const chargedProc = payment.Charged_Proc_Code;
  //     const paidProc = payment.Paid_Proc_Code;
  //     const amountPaid = payment.Amount_Paid;
  //     const amountAdjusted = payment.Amount_Adjusted;
  //     const rejectAmount = payment.Reject_Amount;

  //     if (["I", "Q", "P", "C"].includes(pmtSrc)) {
  //       if (!pmtType || pmtType === '') {
  //         swal('Failed', 'Claim Payment cannot be saved without the mandatory payment information, please fill in the required fields.', 'error');
  //         return;
  //       }
  //     }

  //     if (!["I", "Q", "P", "C"].includes(pmtSrc)) {
  //       if (!pmtType || !enteredFrom || !chargedProc || !paidProc) {
  //         swal('Failed', 'Payment cannot be saved without the mandatory payment information, please fill in the required fields.', 'error');
  //         return;
  //       }
  //     }

  //     if (["Q", "O"].includes(pmtSrc)) {
  //       if (!isNaN(amountPaid) && (amountPaid > 0 || amountPaid === undefined)) {
  //         swal('Failed', 'Amount paid can not be greater than 0.', 'error');
  //         payment.Amount_Paid = null;
  //         return;
  //       }
  //     }

  //     if (payment.Amount_Paid == null) {
  //       payment.Amount_Paid = 0;
  //     }
  //     if (payment.Amount_Approved == null) {
  //       payment.Amount_Approved = 0;
  //     }
  //     if (payment.Amount_Adjusted === "0.00") {
  //       payment.Amount_Adjusted = "0";
  //     }

  //     if (!isCareVoyant) {
  //       if (
  //         (payment.Amount_Adjusted === "" || payment.Amount_Adjusted == null || payment.Amount_Adjusted === "0") &&
  //         payment.Amount_Approved === 0 &&
  //         payment.Amount_Paid === 0
  //       ) {
  //         swal('Failed', "Amount Paid / Amount Adjusted / Amount Approved can't be null.", 'error');
  //         return false;
  //       }
  //     }

  //     if (amountAdjusted && parseFloat(amountAdjusted) !== 0) {
  //       if (!isCareVoyant) {
  //         if (!payment.ERA_ADJUSTMENT_CODE || payment.ERA_ADJUSTMENT_CODE === '') {
  //           swal('Failed', 'Please enter an adjustment code if you have entered an amount in adjustment field.', 'error');
  //           return;
  //         }
  //       }
  //     }

  //     if (!payment.Date_Entry) {
  //       swal('Failed', "Please Enter Entry Date.", 'error');
  //       return false;
  //     }

  //     if (!isNaN(rejectAmount) && rejectAmount > 0) {
  //       if (!isCareVoyant) {
  //         if (!payment.Reject_Type || !payment.Reject_Amount) {
  //           swal('Failed', 'Please enter Payment Rejection Type.', 'error');
  //           return;
  //         }
  //       }
  //     }
  //   }



  //        if (value === '' || value === undefined || value === 'Select Responsible') {
  //             this.toast.error('Please select an overpayment responsible option before saving');
  //             return;
  //         }
  //         let noteDetail = "";
  //         const userid = this.Gv.currentUser.RolesAndRights[0].UserId;
  //         const username = this.Gv.currentUser.RolesAndRights[0].UserName;
  //         if (value === "creditbalance") {
  //             this.paymentResponsibilityForm.get('creditbalance').setValue(this.ClaimDueAmt);
  //             this.paymentResponsibilityForm.get('overpaid').setValue('')
  //             this.overPaymentNotes = `Claim moved to patient credit balance bucket $${this.ClaimDueAmt} By User ${userid},${username}`;
  //         }
  //         if (value === "overpaid") {
  //             this.paymentResponsibilityForm.get('overpaid').setValue(this.ClaimDueAmt)
  //             this.paymentResponsibilityForm.get('creditbalance').setValue('');
  //              this.overPaymentNotes  = `Claim moved to insurance overpaid bucket $${this.ClaimDueAmt} By User ${userid},${username}`;
  //         }
  //         if (value === "bothpatientinsurance") {
  //             const overpaidValue = Number(this.paymentResponsibilityForm.get('overpaid').value) || 0;
  //             const creditBalanceValue = Number(this.paymentResponsibilityForm.get('creditbalance').value) || 0;
  //             const totalResponsibilityAmount = overpaidValue + creditBalanceValue;
  //              this.overPaymentNotes  = `Claim moved to insurance overpaid bucket $${overpaidValue}, patient credit balance bucket ${creditBalanceValue} By User ${userid},${username}`;
  //             if (overpaidValue == null || creditBalanceValue == null) {
  //                 this.toast.error('credit balance & overpaid can not be null.');
  //                 return;
  //             }
  //                       if (overpaidValue == 0 && creditBalanceValue == 0) {
  //                 this.toast.error('Both field are required. Please enter amounts for Patient Credit Balance and Insurance Overpaid.');
  //                 return;
  //             }
  //                        if (overpaidValue == 0 ) {
  //                 this.toast.error('Please enter amounts less than zero.');
  //                 return;
  //             }
  //                 if (creditBalanceValue == 0 ) {
  //                 this.toast.error('Please enter amounts less than zero.');
  //                 return;
  //             }
  //             if (totalResponsibilityAmount !=   this.ClaimDueAmt) {
  //                 this.toast.error('The amounts you entered do not match the total due amount at claim level. Please review and adjust accordingly');
  //                 return;
  //             }
  //         }
  //             // this.SaveResponsbility();
  //   this.API.PostData('/Demographic/InsertOrUpdateClaimPayments', this.processedPaymentList, (res) => {
  //     if (res.Status === 'Success') {
  //       this.toaster.success('Claim payments posted successfully.', 'Success');
  //           this.claimModalRef.hide();
  //       this.cdr.detectChanges();
  //       this.claimViewModel.claimPayments = [];
  //       this.getPostedClaims();
  //       this.fetchBatchDataAndUpdateRemainingAmount(batchID);
  //       this.SaveResponsbility();
  //          


  //     } else {
  //       this.toaster.error(res.Status || 'Failed to post payments.', 'Error');
  //       this.AddOverPaymentModelHidden();
  //     }
  //   });
  // }

async savePostPaymentsWithOverpayment(value: string) {
            this.isEditButtonDisabled = false;

  // Prevent double-click
  if (this.isSaveOverpaymentDisabled) return;
  this.isSaveOverpaymentDisabled = true;
  
  try {
    await this._savePostPaymentsWithOverpaymentImpl(value);
  } catch (error) {
    console.error('Error in savePostPaymentsWithOverpayment:', error);
  } finally {
    this.isSaveOverpaymentDisabled = false;
  }
}

private async _savePostPaymentsWithOverpaymentImpl(value: string) {
  const paymentLists = (this.claimViewModel.claimPayments || []).reduce(
    (acc, p) => acc.concat(p.claimPayments || []),
    []
  );
  // Filter only payments that belong to this batch

  const batchID = this.batchID;
  const batchDate = this.batchDate;
  const claimNo = this.claimsNo;
  const Check_Number = this.Check_No;
  const Check_Date = this.Cheque_Date;
  const Deposit_Date = this.Deposit_Date;
  const paymentList = paymentLists.filter(p => p.BATCH_NO == batchID);
    this.processedPaymentList = paymentList.filter(payment => {
      // Exclude deleted payments except when Source === 'T'
      if (payment.Deleted === true && payment.Payment_Source !== 'T') return false;

      if (payment.claim_payments_id === 0) return true; // new
      if (!payment.originalData) return true; // manually added

            const original = payment.originalData;
            const isUpdated =
              original.Amount_Paid !== payment.Amount_Paid ||
              original.Payment_Type !== payment.Payment_Type ||
              original.ENTERED_FROM !== payment.ENTERED_FROM ||
              original.Amount_Adjusted !== payment.Amount_Adjusted ||
              original.Payment_Source !== payment.Payment_Source ||
              original.Details !== payment.Details ||
              original.Reject_Type !== payment.Reject_Type ||
              original.Reject_Amount !== payment.Reject_Amount ||
              original.Paid_Proc_Code !== payment.Paid_Proc_Code ||
              original.Charged_Proc_Code !== payment.Charged_Proc_Code ||
              original.Check_No !== payment.Check_No ||
              original.Date_Filing !== payment.Date_Filing ||
              original.Date_Adj_Payment !== payment.Date_Adj_Payment ||
              original.DEPOSITSLIP_ID !== payment.DEPOSITSLIP_ID ||
              original.Contractual_Amt !== payment.Contractual_Amt ||
              original.DepositDate !== payment.DepositDate ||
              original.ERA_Rejection_CATEGORY_CODE !== payment.ERA_Rejection_CATEGORY_CODE;

            return true; // Include unchanged too (as per your latest request)
          })
          .map(payment => ({
            ...payment,
            Claim_No: claimNo,
            Check_No: Check_Number ? Check_Number : payment.Check_No,
            Date_Filing: Check_Date ? Check_Date : payment.Date_Filing,
            Charged_Proc_Code: payment.Charged_Proc_Code
              ? payment.Charged_Proc_Code.split(' ')[0]
              : '',
            DepositDate: Deposit_Date ? Deposit_Date : payment.DepositDate,
          }));

        for (let i = 0; i < this.processedPaymentList.length; i++) {
          const payment = this.processedPaymentList[i];
          const isCareVoyant = payment.ENTERED_FROM === "60";

          if (isCareVoyant) {
            const isValidDate = await this.validateDateEntry(payment.Date_Entry, i);
            if (!isValidDate) {
              this.isSaveOverpaymentDisabled = false;
              return;
            }
          }

          const pmtSrc = payment.Payment_Source;
          const pmtType = payment.Payment_Type;
          const enteredFrom = payment.ENTERED_FROM;
          const chargedProc = payment.Charged_Proc_Code;
          const paidProc = payment.Paid_Proc_Code;
          const amountPaid = payment.Amount_Paid;
          const amountAdjusted = payment.Amount_Adjusted;
          const rejectAmount = payment.Reject_Amount;
          if(pmtSrc!="T")
            {
             if (["I", "Q", "P", "C"].includes(pmtSrc)) {
            if (payment.BATCH_NO ==batchID && !pmtType || pmtType === '') {
              swal('Failed', 'Claim Payment cannot be saved without the mandatory payment information, please fill in the required fields.', 'error');
              this.isSaveOverpaymentDisabled = false;
              return;
            }
          }

          if (!["I", "Q", "P", "C"].includes(pmtSrc)) {
            if (payment.BATCH_NO ==batchID && !pmtType || !enteredFrom || !chargedProc || !paidProc) {
              swal('Failed', 'Payment cannot be saved without the mandatory payment information, please fill in the required fields.', 'error');
              this.isSaveOverpaymentDisabled = false;
              return;
        }
      }

      if (["Q", "O"].includes(pmtSrc)) {
        if (!isNaN(amountPaid) && (amountPaid > 0 || amountPaid === undefined)) {
          swal('Failed', 'Amount paid can not be greater than 0.', 'error');
          payment.Amount_Paid = null;
          return;
        }
      }

      }
    
     

      if (payment.Amount_Paid == null) {
        payment.Amount_Paid = 0;
      }
      if (payment.Amount_Approved == null) {
        payment.Amount_Approved = 0;
      }
      if (payment.Amount_Adjusted === "0.00") {
        payment.Amount_Adjusted = "0";
      }

       if(pmtSrc!="T"){
          if (!isCareVoyant) {
        if (
          (payment.Amount_Adjusted === "" || payment.Amount_Adjusted == null || payment.Amount_Adjusted === "0") &&
          payment.Amount_Approved === 0 &&
          payment.Amount_Paid === 0
        ) {
          swal('Failed', "Amount Paid / Amount Adjusted / Amount Approved can't be null.", 'error');
          this.isSavePaymentButtonDisabled = false;
          return false;
        }
      }

      if (amountAdjusted && parseFloat(amountAdjusted) !== 0) {
        if (!isCareVoyant) {
          if (!payment.ERA_ADJUSTMENT_CODE || payment.ERA_ADJUSTMENT_CODE === '') {
            swal('Failed', 'Please enter an adjustment code if you have entered an amount in adjustment field.', 'error');
            this.isSavePaymentButtonDisabled = false;
            return;
          }
        }
      }

      if (!payment.Date_Entry) {
        swal('Failed', "Please Enter Entry Date.", 'error');
        this.isSavePaymentButtonDisabled = false;
        return false;
      }

      if (!isNaN(rejectAmount) && rejectAmount > 0) {
        if (!isCareVoyant) {
          if (!payment.Reject_Type && !payment.ERA_Rejection_CATEGORY_CODE) {
            swal('Failed', 'Please enter Payment Rejection Type.', 'error');
            this.isSavePaymentButtonDisabled = false;
            return;
          }
        }
      }
       }
    
    }


 
       if (value === '' || value === undefined || value === 'Select Responsible') {
            this.toast.error('Please select an overpayment responsible option before saving');
            this.isSavePaymentButtonDisabled = false;
            return;
        }
        let noteDetail = "";
        const batchId = this.batchID;
        const userid = this.Gv.currentUser.RolesAndRights[0].UserId;
        const username = this.Gv.currentUser.RolesAndRights[0].UserName;
        if (value === "creditbalance") {
            this.paymentResponsibilityForm.get('creditbalance').setValue(this.ClaimDueAmt);
            this.paymentResponsibilityForm.get('overpaid').setValue('')
            this.overPaymentNotes = `Claim moved to patient credit balance bucket $${this.ClaimDueAmt} By User ${userid},${username},By Batch ID : [${batchId}]`;
        }
       else if (value === "overpaid") {
            this.paymentResponsibilityForm.get('overpaid').setValue(this.ClaimDueAmt)
            this.paymentResponsibilityForm.get('creditbalance').setValue('');
             this.overPaymentNotes  = `Claim moved to insurance overpaid bucket $${this.ClaimDueAmt} By User ${userid},${username},By Batch ID : [${batchId}]`;
        }
       else if (value === "bothpatientinsurance") {
            const overpaidValue = Number(this.paymentResponsibilityForm.get('overpaid').value) || 0;
            const creditBalanceValue = Number(this.paymentResponsibilityForm.get('creditbalance').value) || 0;
            const totalResponsibilityAmount = overpaidValue + creditBalanceValue;
             this.overPaymentNotes  = `Claim moved to insurance overpaid bucket $${overpaidValue}, patient credit balance bucket ${creditBalanceValue} By User ${userid},${username},By Batch ID : [${batchId}]`;
            if (overpaidValue == null || creditBalanceValue == null) {
                this.toast.error('credit balance & overpaid can not be null.');
                this.isSavePaymentButtonDisabled = false;
                return;
            }
                      if (overpaidValue == 0 && creditBalanceValue == 0) {
                this.toast.error('Both field are required. Please enter amounts for Patient Credit Balance and Insurance Overpaid.');
                this.isSavePaymentButtonDisabled = false;
                return;
            }
                       if (overpaidValue == 0 ) {
                this.toast.error('Please enter amounts less than zero.');
                this.isSavePaymentButtonDisabled = false;
                return;

            }
                if (creditBalanceValue == 0 ) {
                this.toast.error('Please enter amounts less than zero.');
                this.isSavePaymentButtonDisabled = false;
                return;
            }
            if (totalResponsibilityAmount !=   this.ClaimDueAmt) {
                this.toast.error('The amounts you entered do not match the total due amount at claim level. Please review and adjust accordingly');
               this.isSavePaymentButtonDisabled = false;
                return;
            }
        }
           
        if (this.ClaimDueAmt === 0  || this.ClaimDueAmt < 0) {
      // Set insurance + patient status = "Paid"
      this.claimViewModel.ClaimModel.Pat_Status = "P";
      this.claimViewModel.ClaimModel.Pri_Status = "P";
      this.claimViewModel.ClaimModel.Sec_Status = "P";
      this.claimViewModel.ClaimModel.Oth_Status = "P";
        }
  this.API.PostData('/Demographic/InsertOrUpdateClaimPayments', this.processedPaymentList, (res) => {
    if (res.Status === 'Success') {
      this.toaster.success('Claim payments posted successfully.', 'Success');

             this.addOverPaymentModel.hide();

         this.tcbModalShow = false
             if(this.ClaimDueAmt >= 0){
              this.UpdateCliamOverPayment();
           }
        // Add
        // Added By Hamza Akhlaq For Transfer Credit Balance
        if (this.transfercrditbalPayment && this.transfercrditbalPayment.length > 0) {
          const claimPayments = res.Response;

          this.transfercrditbalPayment.forEach(tp => {
              
            if (tp.claimPayments.Payment_Source === 'T') {
              tp.claimPayments.Amount_Paid = Math.abs(tp.claimPayments.Amount_Paid); // ignore +/- sign

              const match = claimPayments.find(cp =>
                Math.abs(cp.Amount_Paid) === tp.claimPayments.Amount_Paid &&
                cp.Payment_Source === tp.claimPayments.Payment_Source &&
                cp.Sequence_No === Number(tp.claimPayments.Sequence_No)
              );

              if (match) {
                tp.claimPayments.T_payment_id = match.claim_payments_id;
                   tp.claimPayments.Check_No = match.Check_No;
    tp.claimPayments.Date_Filing = match.Date_Filing || match.Date_Entry;
    tp.claimPayments.DepositDate = match.DepositDate || match.BATCH_DATE;
              }
            }
            tp.claimPayments.Sequence_No = null;
          });
          this.PostPayment();
        }
           this.AddPaymentNotesInDB();
          this.SaveResponsbility();
      this.cdr.detectChanges();
      this.claimViewModel.claimPayments = [];
        if(this.ClaimDueAmt >= 0){
              this.UpdateCliamOverPayment();
           }
           
      this.getPostedClaims();
      this.fetchBatchDataAndUpdateRemainingAmount(batchID);
           this.processedPaymentList = []
        //this.checkClaimDueAmount(null);
         
      this.checkClaimDueAmount(null);
          

              
      // this.SaveResponsbility();
      if (this.PaymentClaimNo !== 0) {
    const payload = {
      claimNo: this.PaymentClaimNo,
      Patient_Account:this.patAccount,
      disableForm: false,
      PatientFirstName: this.patName,
    };
    if (this.billNextModalRef) {
  this.billNextModalRef.hide();
}

if (this.claimModalRef) {
  this.claimModalRef.hide();
}
    const encoded = Common.encodeBase64(JSON.stringify(payload));

   setTimeout(() => {
  this.router.navigate([
    '/Patient/Demographics',
    'ClaimDetail',
    encoded
  ]);
}, 2000);
  }
      
    }
     else {
      this.toaster.error(res.Status || 'Failed to post payments.', 'Error');
      this.isSavePaymentButtonDisabled = false;
      this.AddOverPaymentModelHidden();
    }
  });
}
 
async SavePostPaymentSkipOverPayment() {
            this.isEditButtonDisabled = false;

  // Prevent double-click
  if (this.isSkipConfirmationDisabled) return;
  this.isSkipConfirmationDisabled = true;
  
  try {
    await this._SavePostPaymentSkipOverPaymentImpl();
  } catch (error) {
    console.error('Error in SavePostPaymentSkipOverPayment:', error);
    this.isSavePaymentButtonDisabled = false;
  } finally {
    this.isSkipConfirmationDisabled = false;
  }
}

 async _SavePostPaymentSkipOverPaymentImpl() {
  const paymentLists = (this.claimViewModel.claimPayments || []).reduce(
    (acc, p) => acc.concat(p.claimPayments || []),
    []
  );
  const batchID = this.batchID;
  const batchDate = this.batchDate;
  const claimNo = this.claimsNo;
  const Check_Number = this.Check_No;
  const Check_Date = this.Cheque_Date;
  const Deposit_Date = this.Deposit_Date;
  const paymentList = paymentLists.filter(p => p.BATCH_NO == batchID);


        this.processedPaymentList = paymentList
          .filter(payment => {
            if (payment.Deleted === true) return false; // exclude deleted

            if (payment.claim_payments_id === 0) return true; // new
            if (!payment.originalData) return true; // manually added

        const original = payment.originalData;
        const isUpdated =
          original.Amount_Paid !== payment.Amount_Paid ||
          original.Payment_Type !== payment.Payment_Type ||
          original.ENTERED_FROM !== payment.ENTERED_FROM ||
          original.Amount_Adjusted !== payment.Amount_Adjusted ||
          original.Payment_Source !== payment.Payment_Source ||
          original.Details !== payment.Details ||
          original.Reject_Type !== payment.Reject_Type ||
          original.Reject_Amount !== payment.Reject_Amount ||
          original.Paid_Proc_Code !== payment.Paid_Proc_Code ||
          original.Charged_Proc_Code !== payment.Charged_Proc_Code ||
          original.Check_No !== payment.Check_No ||
          original.Date_Filing !== payment.Date_Filing ||
          original.Date_Adj_Payment !== payment.Date_Adj_Payment ||
          original.DEPOSITSLIP_ID !== payment.DEPOSITSLIP_ID ||
          original.Contractual_Amt !== payment.Contractual_Amt ||
          original.DepositDate !== payment.DepositDate ||
          original.ERA_Rejection_CATEGORY_CODE !== payment.ERA_Rejection_CATEGORY_CODE;

        return true; // Include unchanged too (as per your latest request)
      })
      .map(payment => ({
        ...payment,
        Claim_No: claimNo,
        Check_No: Check_Number ? Check_Number : payment.Check_No,
        Date_Filing: Check_Date ? Check_Date : payment.Date_Filing,
        Charged_Proc_Code: payment.Charged_Proc_Code
          ? payment.Charged_Proc_Code.split(' ')[0]
          : '',
        DepositDate: Deposit_Date ? Deposit_Date : payment.DepositDate,
      }));

    for (let i = 0; i < this.processedPaymentList.length; i++) {
      const payment = this.processedPaymentList[i];
      const isCareVoyant = payment.ENTERED_FROM === "60";

      if (isCareVoyant) {
        const isValidDate = await this.validateDateEntry(payment.Date_Entry, i);
        if (!isValidDate) return;
      }

      const pmtSrc = payment.Payment_Source;
      const pmtType = payment.Payment_Type;
      const enteredFrom = payment.ENTERED_FROM;
      const chargedProc = payment.Charged_Proc_Code;
      const paidProc = payment.Paid_Proc_Code;
      const amountPaid = payment.Amount_Paid;
      const amountAdjusted = payment.Amount_Adjusted;
      const rejectAmount = payment.Reject_Amount;
       if(pmtSrc!="T")
        {
           if (["I", "Q", "P", "C"].includes(pmtSrc)) {
        if (payment.BATCH_NO ==batchID && !pmtType || pmtType === '') {
          swal('Failed', 'Claim Payment cannot be saved without the mandatory payment information, please fill in the required fields.', 'error');
         this.isSavePaymentButtonDisabled = false;
          return;
        }
      }

      if (!["I", "Q", "P", "C"].includes(pmtSrc)) {
        if ( payment.BATCH_NO ==batchID && !pmtType || !enteredFrom || !chargedProc || !paidProc) {
          swal('Failed', 'Payment cannot be saved without the mandatory payment information, please fill in the required fields.', 'error');
         this.isSavePaymentButtonDisabled = false;
          return;
        }
      }

      if (["Q", "O"].includes(pmtSrc)) {
        if (payment.BATCH_NO ==batchID && !isNaN(amountPaid) && (amountPaid > 0 || amountPaid === undefined)) {
          swal('Failed', 'Amount paid can not be greater than 0.', 'error');
          this.isSavePaymentButtonDisabled = false;
          payment.Amount_Paid = null;
          return;
        }
      }
        }

     

      if (payment.Amount_Paid == null) {
        payment.Amount_Paid = 0;
      }
      if (payment.Amount_Approved == null) {
        payment.Amount_Approved = 0;
      }
      if (payment.Amount_Adjusted === "0.00") {
        payment.Amount_Adjusted = "0";
      }

      if(pmtSrc!="T"){
          if (!isCareVoyant) {
        if (
          (payment.Amount_Adjusted === "" || payment.Amount_Adjusted == null || payment.Amount_Adjusted === "0") &&
          payment.Amount_Approved === 0 &&
          payment.Amount_Paid === 0
        ) {
          swal('Failed', "Amount Paid / Amount Adjusted / Amount Approved can't be null.", 'error');
          this.isSavePaymentButtonDisabled = false;
          return false;
        }
      }

      if (amountAdjusted && parseFloat(amountAdjusted) !== 0) {
        if (!isCareVoyant) {
          if (payment.BATCH_NO ==batchID && !payment.ERA_ADJUSTMENT_CODE || payment.ERA_ADJUSTMENT_CODE === '') {
            swal('Failed', 'Please enter an adjustment code if you have entered an amount in adjustment field.', 'error');
            this.isSavePaymentButtonDisabled = false;
            return;
          }
        }
      }

      if ( payment.BATCH_NO ==batchID && !payment.Date_Entry) {
        swal('Failed', "Please Enter Entry Date.", 'error');
        this.isSavePaymentButtonDisabled = false;
        return false;
      }

      if (!isNaN(rejectAmount) && rejectAmount > 0) {
        if (!isCareVoyant) {
          // if (!payment.Reject_Type || !payment.Reject_Amount) {
          if (payment.BATCH_NO ==batchID && !payment.Reject_Type && !payment.ERA_Rejection_CATEGORY_CODE) {

            swal('Failed', 'Please enter Payment Rejection Type.', 'error');
            this.isSavePaymentButtonDisabled = false;
            return;
          }
        }
      }
       }
   
    }

  let noteDetail = "";
        const userid = this.Gv.currentUser.RolesAndRights[0].UserId;
        const username = this.Gv.currentUser.RolesAndRights[0].UserName;
        //  this.show_Insurance_Overpaid = claim.InsuranceOverpaid;
        //   this.show_Patient_Credit_Balance = claim.PatientCreditBalance;
        if ( this.show_Insurance_Overpaid < 0 ) {
       
       this.overPaymentNotes =`Claim saved without confirming overpayment responsibility. Previous Responsible: [Insurance Overpaid] | Previous amount: [$${this.show_Insurance_Overpaid}] Reset to amount: $0 from Batch [${this.batchId}].`
   // this.overPaymentNotes = `Overpayment removed from insurance overpaid bucket ${this.show_Insurance_Overpaid} by User ${userid},By User ,${username}`;
        }
             if ( this.show_Patient_Credit_Balance < 0 ) {
       this.overPaymentNotes =`Claim saved without confirming overpayment responsibility. Previous Responsible: [Patient Credit Balance] | Previous amount: [$${this.show_Patient_Credit_Balance}] Reset to amount: $0 from Batch [${this.batchId}].`

              // this.overPaymentNotes = `Overpayment removed from patient credit balance bucket ${this.show_Patient_Credit_Balance} by User ${userid},By User ,${username}`;
        }
                 if (this.show_Insurance_Overpaid < 0 &&  this.show_Patient_Credit_Balance < 0  ) {
            // this.overPaymentNotes = `Overpayment removed from insurance overpaid bucket ${this.show_Insurance_Overpaid}, patient credit balance bucket ${this.show_Patient_Credit_Balance} by User ${userid}, JS1`;
     this.overPaymentNotes =  `Claim saved without confirming overpayment responsibility. Previous Responsible: [Insurance Overpaid ] | Previous amount: [$${this.show_Insurance_Overpaid}] Reset to amount: $0 | [Patient Credit Balance] | Previous amount: [$${this.show_Patient_Credit_Balance}] Reset to amount: $0 from Batch [${this.batchId}].`
          }
  //       
  //       if (value === "overpaid") {
  //           this.paymentResponsibilityForm.get('overpaid').setValue(this.ClaimDueAmt)
  //           this.paymentResponsibilityForm.get('creditbalance').setValue('');
  //            this.overPaymentNotes  = `Claim moved to insurance overpaid bucket $${this.ClaimDueAmt} By User ${userid},${username}`;
  //       }
  //       if (value === "bothpatientinsurance") {
  //           const overpaidValue = Number(this.paymentResponsibilityForm.get('overpaid').value) || 0;
  //           const creditBalanceValue = Number(this.paymentResponsibilityForm.get('creditbalance').value) || 0;
  //           const totalResponsibilityAmount = overpaidValue + creditBalanceValue;
  //            this.overPaymentNotes  = `Claim moved to insurance overpaid bucket $${overpaidValue}, patient credit balance bucket ${creditBalanceValue} By User ${userid},${username}`;

// this.UpdateCliamOverPayment();
  this.API.PostData('/Demographic/InsertOrUpdateClaimPayments', this.processedPaymentList, (res) => {
    if (res.Status === 'Success') {
      this.toaster.success('Claim payments posted successfully.', 'Success');
        this.addOverPaymentModel.hide();
         this.tcbModalShow = false
        // Added By Hamza Akhlaq For Transfer Credit Balance
        if (this.transfercrditbalPayment && this.transfercrditbalPayment.length > 0) {
          const claimPayments = res.Response;

          this.transfercrditbalPayment.forEach(tp => {
              
            if (tp.claimPayments.Payment_Source === 'T') {
              tp.claimPayments.Amount_Paid = Math.abs(tp.claimPayments.Amount_Paid); // ignore +/- sign

              const match = claimPayments.find(cp =>
                Math.abs(cp.Amount_Paid) === tp.claimPayments.Amount_Paid &&
                cp.Payment_Source === tp.claimPayments.Payment_Source &&
                cp.Sequence_No === Number(tp.claimPayments.Sequence_No)
              );

              if (match) {
                tp.claimPayments.T_payment_id = match.claim_payments_id;
                   tp.claimPayments.Check_No = match.Check_No;
    tp.claimPayments.Date_Filing = match.Date_Filing || match.Date_Entry;
    tp.claimPayments.DepositDate = match.DepositDate || match.BATCH_DATE;
              }
            }
            tp.claimPayments.Sequence_No = null;

          });
          this.PostPayment();
        }
      this.AddPaymentNotesInDB();
      //  Added BY Pir Ubaid For empty over payment notes
      //this.overPaymentNotes = "";
      this.claimModalRef.hide();
      this.cdr.detectChanges();
      this.claimViewModel.claimPayments = [];
      this.getPostedClaims();
      this.processedPaymentList = []
      //this.checkClaimDueAmount(null);
      // this.checkClaimDueAmount(null);
      this.fetchBatchDataAndUpdateRemainingAmount(batchID);
      this.UpdateCliamOverPayment();


      if(this.overPaymentNotes != ""){
        this.AddNotesForOverPayment(this.overPaymentNotes);
      }
      this.isSkipConfirmationDisabled = false;
      this.isSavePaymentButtonDisabled = false;
            if (this.PaymentClaimNo !== 0) {
    const payload = {
      claimNo: this.PaymentClaimNo,
      Patient_Account:this.patAccount,
      disableForm: false,
      PatientFirstName: this.patName,
    };
     if (this.billNextModalRef) {
  this.billNextModalRef.hide();
}

if (this.claimModalRef) {
  this.claimModalRef.hide();
}

    const encoded = Common.encodeBase64(JSON.stringify(payload));

    // ✅ Correct navigation (same page)
    this.router.navigate([
      '/Patient/Demographics',
      'ClaimDetail',
      encoded
    ]);
  }
    } else {
      this.toaster.error(res.Status || 'Failed to post payments.', 'Error');
      this.isSavePaymentButtonDisabled = false;
      this.AddOverPaymentModelHidden();
    }
  });
 
}
showOverPaymentModel(template: TemplateRef<any>) 
    {
         this.isGoButtonDisabled = false;
         this.addOverPaymentModel = this.modalService.show(template, {
         class: 'modal-xlg',
         backdrop: 'static',
          keyboard: false
        });
         this.modalController.register(this.addOverPaymentModel);
        return;
}
// CalculateNegativeBalance()
//     {
//          
//           this.TotalCharges = 0;
//           this.TotalPaidAmt = 0;
//           this.TotalAdjamt = 0;
//           this.Totalamtadj = 0;
//           this.ClaimDueAmt = 0;
//           this.dueAmtForOverPayment=0
//           this.TotalPaidAmt = 0;
//           this.TotalAdjamt = 0;
//          this.allPayments.forEach(payment => {
//               
//             const paidAmount =
//               payment.Amount_Paid != null &&
//               (payment.Amount_Paid) &&
//               (payment.Deleted == null || payment.Deleted === false)
//                 ? (payment.Amount_Paid)
//                 : 0;
          
//             this.TotalPaidAmt += paidAmount;
          
//             const adjustedAmount =
//               payment.Amount_Adjusted != null &&
//               !isNaN(parseFloat(payment.Amount_Adjusted)) &&
//               (payment.Deleted == null || payment.Deleted === false)
//                 ? parseFloat(payment.Amount_Adjusted)
//                 : 0;
          
//             this.TotalAdjamt += adjustedAmount;
//           });
          
//                   this.Totalamtadj = this.TotalPaidAmt + this.TotalAdjamt + this.amt_paid + this.Adjustment ;
//                   if (this.Totalamtadj > this.claim_total) {
//                       let calculatedAmount = this.claim_total - this.Totalamtadj;
//                       this.dueAmtForOverPayment = calculatedAmount < 0 ? calculatedAmount : -calculatedAmount;
//                       this.dueAmtForOverPayment = parseFloat(this.dueAmtForOverPayment.toFixed(2));
//                      
//                   }
//                   this.ClaimDueAmt = this.claim_total - (this.TotalPaidAmt + this.TotalAdjamt)
          
// }
SaveResponsbility()
  {
        this.paymentresponsbility.Claim_No = this.claimsNo;
        this.paymentresponsbility.Insurance_over_paid = this.paymentResponsibilityForm.get('overpaid').value;
        this.paymentresponsbility.Patient_credit_balance = this.paymentResponsibilityForm.get('creditbalance').value;
        this.paymentresponsbility.Total_Responsibility =   this.ClaimDueAmt;
        this.API.PostData('/Demographic/AddClaimOverPayment', this.paymentresponsbility, (d) => {
            if (d.Status == "Success") {
                this.AddOverPaymentModelHidden();
                //UnCommented By Pir ubaid 
                //..
                 this.AddNotesForOverPayment( this.overPaymentNotes );
                //..
                // this.checkClaimDueAmount(this.billNextModalTemplate);
                //swal('Payment', 'Overpayment Updated Successfully.', 'success');
                //this.onClaimSelectionChange(this.claimsNo);
                this.ClaimDueAmt = ''
            }
            else {
              this.isSavePaymentButtonDisabled = false;
                swal({
                    title: 'Error',
                    text: "Failed to update payment.",
                    icon: 'error',
                    button: 'OK'
                });
                
                this.refresh();
            }
        });

  }
  HandleSkipResponsbility() {
    this.paymentresponsbility.Claim_No = this.claimsNo;
    this.paymentresponsbility.Insurance_over_paid = '';
    this.paymentresponsbility.Patient_credit_balance = '';
    this.paymentresponsbility.Total_Responsibility = '';
    this.API.PostData('/Demographic/AddClaimOverPayment', this.paymentresponsbility, (d) => {
      if (d.Status == "Success") {
        this.AddOverPaymentModelHidden();
      }
      else {
        this.isSavePaymentButtonDisabled = false;
        swal({
          title: 'Error',
          text: "Failed to update payment.",
          icon: 'error',
          button: 'OK'
        });

        this.refresh();
      }
    });

  }
  AddOverPaymentModelHidden() {
        this.isSavePaymentButtonDisabled = false;
    this.paymentResponsibilityForm.reset({ creditbalance: '-', overpaid: '-' });
    this.addOverPaymentModel.hide();
    //this.ClaimDueAmt = '';
    this.selectedResponsibleParty = 'Select Responsible'
     if (this.addOverPaymentModel) {
    this.addOverPaymentModel.hide();
  }
  }
  AddOverPaymentModelSkip() {
    // this.savePostPayments('overpaymentype');
  }
  AddNotesForOverPayment(value: string) {
     const note = value.trim();
  if (!note) {
    return; // 🚫 Prevent empty note insertion
  }
    this.claimNotesModel.Response.Note_Detail = value;
    this.claimNotesModel.Response.Claim_No = this.claimViewModel.ClaimModel.Claim_No;
    this.claimNotesModel.Response.IsAuto_Note = true;
    this.API.PostData('/Demographic/SaveClaimNotes/', this.claimNotesModel.Response, (d) => {
      if (d.Status == "Sucess") {
        this.claimNotesModel.Response.Note_Detail="";
        this.overPaymentNotes="";
      }
    })
  }
  UpdateCliamOverPayment() {
    this.paymentresponsbility.Claim_No = this.claimViewModel.ClaimModel.Claim_No;
    this.paymentresponsbility.Insurance_over_paid = '0';
    this.paymentresponsbility.Patient_credit_balance = '0';
    this.paymentresponsbility.Total_Responsibility = '0';
    this.API.PostData('/Demographic/AddClaimOverPayment', this.paymentresponsbility, (d) => {
      if (d.Status == "Success") {
        this.AddOverPaymentModelHidden();

        this.isButtonDisabled = false;
        // this.checkClaimDueAmount(this.billNextModalTemplate)
        return;
      } else {
      }
    });

  }

  // getProcessedPaymentList() {
  //     
  //   const paymentList = this.claimViewModel.claimPayments.map(p => p.claimPayments);
  //        this.allPayments = [
  //       ...paymentList
  //     ].filter(p => !p.Deleted);
  //         
  //         
  //         
  //   const batchID = this.batchID;
  //   const batchDate = this.batchDate;
  //   const claimNo = this.claimsNo;
  //   const Check_Number = this.Check_No;
  //   const Check_Date = this.Cheque_Date;
  //   const Deposit_Date = this.Deposit_Date;

  //   return paymentList
  //     .filter(payment => {
  //       if (payment.Deleted === true)
  //       {
  //         this.Adjustment=0
  //         this.amt_paid=0
  //         return true;
  //       } 
  //       if (payment.claim_payments_id === 0) return true;
  //       if (!payment.originalData) return true;
  //         
  //       const original = payment.originalData;
  //       return (
  //         original.Amount_Paid !== payment.Amount_Paid ||
  //         original.Payment_Type !== payment.Payment_Type ||
  //         original.ENTERED_FROM !== payment.ENTERED_FROM ||
  //         original.Amount_Adjusted !== payment.Amount_Adjusted ||
  //         original.Payment_Source !== payment.Payment_Source ||
  //         original.Details !== payment.Details ||
  //         original.Reject_Type !== payment.Reject_Type ||
  //         original.Reject_Amount !== payment.Reject_Amount ||
  //         original.Paid_Proc_Code !== payment.Paid_Proc_Code ||
  //         original.Charged_Proc_Code !== payment.Charged_Proc_Code ||
  //         original.Check_No !== payment.Check_No ||
  //         original.Cheque_Date !== payment.Cheque_Date ||
  //         original.Date_Adj_Payment !== payment.Date_Adj_Payment ||
  //         original.DEPOSITSLIP_ID !== payment.DEPOSITSLIP_ID ||
  //         original.Contractual_Amt !== payment.Contractual_Amt ||
  //         original.DepositDate !== payment.DepositDate ||
  //         original.ERA_Rejection_CATEGORY_CODE !== payment.ERA_Rejection_CATEGORY_CODE
  //       );
  //     })
  //     .map(payment => ({
  //       ...payment,
  //       Claim_No: claimNo,
  //       Check_No: Check_Number ? Check_Number : payment.Check_No,
  //       Cheque_Date: Check_Date ? Check_Date : payment.Cheque_Date,
  //       Charged_Proc_Code: payment.Charged_Proc_Code ? payment.Charged_Proc_Code.split(' ')[0] : '',
  //       DepositDate: Deposit_Date ? Deposit_Date : payment.DepositDate,
  //     }));
  // }
  onInputChange(controlName: string): void {
    const control = this.paymentResponsibilityForm.get(controlName);
    if (!control) return;
    let raw = control.value;
    // If empty or null, just show '-'
    if (!raw) {
      control.setValue('-', { emitEvent: false });
      return;
    }
    raw = String(raw);
    // Step 1: Check for leading '-'
    let negative = raw.startsWith('-');
    let rest = negative ? raw.slice(1) : raw;
    // Step 2: Remove all non-digit and non-dot characters
    rest = rest.replace(/[^0-9.]/g, '');
    // Step 3: Keep only the first dot
    const firstDotIndex = rest.indexOf('.');
    if (firstDotIndex !== -1) {
      rest = rest.slice(0, firstDotIndex + 1) + rest.slice(firstDotIndex + 1).replace(/\./g, '');
    }
    // Step 4: Combine negative sign and rest
    let finalValue = negative ? '-' + rest : rest;
    // Step 5: If empty after '-', show just '-'
    if (finalValue === '' || finalValue === '-') finalValue = '-';
    control.setValue(finalValue, { emitEvent: false });
  }
// #end
// #region Transfer Credit Balance Handle below
showtcbmodel(template: TemplateRef<any>) {
    
       this.tcbModel = this.modalService.show(template, {
         class: 'modal-xlg',
         backdrop: 'static',
          keyboard: false
        });
        return;
    }
  getClaimsWithPatientDue() {
  this.spinner.show();
  const practice = JSON.parse(localStorage.getItem('sp') || '{}');
  const practiceCode = practice.PracticeCode;
  this.API
    .getDataClaimModel(`/Demographic/GetClaimsWithPatientDue?practicecode=${practiceCode}&patientaccount=${this.tPatientAcc}`)
    .subscribe({
      next: (data: any) => {
        if (data.Status === "Success") {
          this.claimswithPatientDue = data.Response;
          this.claimswithPatientDue = this.claimswithPatientDue.map(c => {
            const dos = new Date(c.Dos);
            const formattedDos = `${(dos.getMonth() + 1).toString().padStart(2, '0')}/${dos.getDate().toString().padStart(2, '0')}/${dos.getFullYear()}`;
            return {
              ...c,
              displayText: `${c.Claim_No} | ${formattedDos} | PT Due $${c.Amt_Due}`
            };
          });
        }
      },
      error: () => {
        this.toaster.error('Failed to fetch claims with patient due', 'Error');
      },
      complete: () => {
        // Always hide spinner AFTER processing & UI render
        setTimeout(() => this.spinner.hide(), 0);
      }
    });
}




    ClosetcbModal()
    {
          this.isSavePaymentButtonDisabled = false;
      // this.isTCB=false
      //this.transfercrditbalPayment=[]
        this.tcbModel.hide()
    }
       validateAndPost(template: TemplateRef<any>) {
           
           
        this.isTCB=false
            const selectedClaims: number[] = [];
            let hasValidationError = false;
    
            for (let p of this.transfercrditbalPayment) {
                const selectedClaimNo = p.claimPayments.Claim_No;
                const amtPaid = Math.abs(p.claimPayments.Amount_Paid);
    
                //  1. No claim selected (355139 = unselected default)
                if (!selectedClaimNo || selectedClaimNo === 355139) {
                    this.toast.error(
                        'Please select a Claim number before posting.',
                        'Error'
                    );
                    hasValidationError = true;
                    return;
                }
    
                //  2. Duplicate claim selected (ignore default 355139)
                if (selectedClaimNo !== 355139 && selectedClaims.includes(selectedClaimNo)) {
                    this.toast.error(
                        'You cannot select the same claim number multiple times.',
                        'Error'
                    );
                    hasValidationError = true;
                    return;
                } else {
                    selectedClaims.push(selectedClaimNo);
                }
    
                //  3. Amount paid exceeds patient due
                const selectedClaim = this.claimswithPatientDue.find(c => c.Claim_No === selectedClaimNo);
                if (selectedClaim && amtPaid > selectedClaim.Amt_Due) {
                    this.toast.error(
                        'The credit amount you\'re trying to transfer (From Amt.paid) exceeds Patient Due of the selected claim. Please Adjust.',
                        'Error'
                    );
                    this.isSavePaymentButtonDisabled = false;
                    hasValidationError = true;
                    return;
                }
            }
            if (!hasValidationError) {
                   
                this.ClosetcbModal();
                this.tcbModalShow = true
                this.savePostPayments('',template);
                //this.saveClaim('Save')
            }
    
        }
         onClaimChange(payment: any, event: any) {
                   
                if (event.length == 0) {
                    // Cleared
                    if (payment.claimPayments) {
                        payment.claimPayments.Claim_No = 355139;
                    }
                } else {
                    // Selected
                    if (payment.claimPayments) {
                        payment.claimPayments.Claim_No = event[0].data.Claim_No;
        
        
                    }
                }
            }
             PostPayment() {
                       
                       
                    const paymentList = this.transfercrditbalPayment.map(p => p.claimPayments);
                      this.claimswithPatientDue
                            this.API.PostData('/Demographic/InsertOrUpdateClaimPayments', paymentList, (res) => {
                              if (res.Status === 'Success') {
                                this.refresh(); 
                                this.getSetStatus();// Optional: Refresh or close modal
                                this.getPostedClaims();
                              } else {
                              }
                            }); 
                      }

checkPaymentBeforeRemoveClaim(claimNo: string , Amtdue: string,overPaymentTemplate: TemplateRef<any>,billNextTemplate: TemplateRef<any>) {
    
  // Prevent double-click
  if (this.isRemoveButtonDisabled) return;
  this.isRemoveButtonDisabled = true;
  
  const claimId = Number(claimNo);

  if (claimId) {
     this.API.getData(`/Payments/GetBatchPayments?claimId=${claimId}`)
    .subscribe({
      next: (res) => {
        if (res.Status === 'Success') {
          this.batchRemovePayments = res.Response || [];
          this.TCBPayment = this.batchRemovePayments.filter((p: any) =>
            p.Payment_Source === "T"
          );
          this.TCBPaymentId = this.batchRemovePayments.filter((p: any) =>
            p.Payment_Source === "T" &&
            p.T_payment_id != null &&
            p.T_payment_id != 0
          );
          if (this.TCBPaymentId.length > 0) {
            this.toaster.error(
              "This claim contains Transfer Credit Balance Target Claim Entry. Please remove the entry from the source claim first.",
              "Error"
            );
            this.isRemoveButtonDisabled = false;
            return;
          }
          if(this.TCBPayment.length > 0){
            this._apiService.confirmFun(
              'Confirm',
              'This claim contains Transfer Credit Balance entries. Do you want to continue and remove the claim?',
              () => {
                if (this.isPreviousMonthBatch()) {
                  this.toaster.error(
                    "This Batch belongs to previous month. Claim entry cannot be removed",
                    "Error"
                  );
                  this.isRemoveButtonDisabled = false;
                  return;
                }
                this.removeTCBClaim(claimNo, Amtdue, overPaymentTemplate, billNextTemplate);
                this.isRemoveButtonDisabled = false;
              }
            );
          } else {
            this.removeClaim(claimNo, Amtdue, overPaymentTemplate, billNextTemplate);
            this.isRemoveButtonDisabled = false;
          }
        } else {
          this.isRemoveButtonDisabled = false;
        }
      },
      error: (err) => {
        console.error('Error fetching batch payments:', err);
        this.toaster.error('Error while checking claim payments', 'Error');
        this.isRemoveButtonDisabled = false;
      },
      complete: () => {
        // Complete is optional here since we handle it in next/error
      }
    });
  } else {
    this.isRemoveButtonDisabled = false;
  }
}
removeTCBClaim(claimNo: string, Amtdue: string, overPaymentTemplate: TemplateRef<any>, billNextTemplate: TemplateRef<any>)
{
    const batchID = this.batchId;
    this.removeBatchId = batchID;
    this.isRemovePayment = false;
    if (claimNo && batchID) {
     
          this.API.getData(`/Payments/DeleteClaimPayment?batchID=${batchID}&claimNo=${claimNo}&Amtdue=${Amtdue}`)
            .subscribe(res => {
              if (res.Status === 'Success') {
                //
      //this.API.getData(`/Payments/GetClaimDetails?batchID=${batchID}`)
      this.API.getData(`/Payments/GetPayments?claimId=${claimNo}`)
            .subscribe(res => {
              if (res.Status === 'Success') {
this.claimLevelPayments = res.Response
              }
              else {
              }
            },
              (error) => {
                console.error("Error", error);
                this.isSavePaymentButtonDisabled = false;
              });
        
                //

                this.removeClaimdue = parseFloat(res.Response);
                if (this.removeClaimdue < 0) {
                  this.isRemovePayment = true;
                  this.claimsNo = claimNo;
                  this.showOverPaymentUpdateModel(overPaymentTemplate);
                  return;
                }

                if (this.removeClaimdue >= 0) {
                  this.paymentresponsbility.Claim_No = this.claimsNo;
                  this.paymentresponsbility.Insurance_over_paid = "0";
                  this.paymentresponsbility.Patient_credit_balance = "0";
                  this.paymentresponsbility.Total_Responsibility = "0";

                  this.API.PostData('/Demographic/AddClaimOverPayment', this.paymentresponsbility, (d) => {
                    if (d.Status === "Success") {
                         
                         setTimeout(() => {
  this.getPostedClaims();
  if (!this.claimList || this.claimList.length === 0) {
    this.totalBatchAmtPaid = 0; // reset total posted amount
         this.remainingAmount = this.batchAmount - this.totalBatchAmtPaid - this.unappliedAmount;

  }
  this.cdr.detectChanges();
}, 300);
                      this.isRemovePayment = true;
                      this.getPostedClaims();
                      // this.removeBatchPaymentwithBillNext(billNextTemplate);
                      setTimeout(() => {
  this.removeBatchPaymentwithBillNext(billNextTemplate);
}, 300);

                    } else {
                    }
                  });
                }
              }
              else {
                swal('Claim Removal', res.Response, 'error');
              }
            },
              (error) => {
                this.isSavePaymentButtonDisabled = false;
                console.error("Error while deleting claim:", error);
                this.toaster.error("Failed to remove claim. Please try again.", "Error");
              });
        }
}
  
// #end

    //#region  Auto Notes For Payment
    paymentMap: { [key: string]: string } = {
        "1": "Pri Pay",
        "2": "Sec Pay",
        "3": "Ter Pay",
        "P": "Patient Pay",
        "I": "Inbox Patient Pay",
        "L": "Coll Adj",
        "K": "Collection Pay",
        "A": "Insurance Adj.",
        "W": "Write Off/Adj.",
        "C": "Copay",
        "Z": "Other Adjustment",
        "D": "Dormant Adj.",
        "Q": "Patient Refund",
        "O": "Refund Requested From Office",
        "T": "Transfer Credit Balance"
    };
    paymentTypeMap: { [key: string]: string } = {
        "": "",
        "C": "Cash",
        "K": "Check",
        "R": "Credit",
        "O": "Other"
    }
    rejectionTypeMap: { [key: string]: string } = {
        "": "",
        "1": "Deductible",
        "2": "Coinsurance Amount",
        "3": "Copay",
        "8": "CPT Inconsistent with ICD",
        "9": "Invalid Modifier",
        "6": "Hospice admit same day",
        "A": "Deductible",
        "B": "Bank Charges",
        "C": "Copay",
        "D": "Duplicate",
        "E": "Ins need info from Patient",
        "F": "Finance Charges",
        "L": "Late Filing Adj",
        "M": "Pt responsibility has not been met",
        "O": "Other Charges",
        "P": "Insurance paid benefits to patient",
        "R": "Refund",
        "T": "Transferred From Other Claim",
        "V": "VFC Programme MCD",
        "01": "Benefits Exhausted",
        "02": "Non covered Benefits",
        "03": "Insurance Coverage lapsed/did not exist",
        "04": "Disallowed Cost Containment",
        "06": "Coinsurance Amount",
        "07": "Disallowed Other Amount",
        "10": "Invalid POS",
        "11": "Inconsistent with Patient Age",
        "12": "Inclusive in other procedure",
        "13": "Required Medical Notes",
        "14": "Inconsistent with Patient Gender",
        "15": "Pre-existing Condition",
        "16": "Covered by another payer",
        "17": "Duplicate/previously paid",
        "18": "Adjustment",
        "19": "Insurance needs COB information from patient",
        "20": "Lack of info",
        "21": "Not eligible charges",
        "22": "Services not authorized by Medipass PCP",
        "23": "Referring provider number not on file",
        "24": "NDC missing or invalid",
        "25": "Invalid/Missing Referral No.",
        "26": "Psychiatric Reduction",
        "27": "Patient Deceased",
        "28": "CPT Coding error",
        "29": "DX Coding Error",
        "30": "Bad Debt",
        "60": "SERVICE PERFORMED BY ANOTHER PCP WITHIN 60 DAYS",
        "AR": "Account Receivable",
        "B9": "Patient enrolled in a Hospice",
        "BC": "Bounce Check fee",
        "CA": "Patient responsibility towards collection agency",
        "CO": "Copay due",
        "GF": "Global Fee",
        "IA": "Invalid/Missing Authorization No",
        "IR": "Insurance reversal",
        "LF": "Late Filing",
        "NP": "Non-participating provider",
        "OA": "Other Amount Paid",
        "OP": "Out of network provider",
        "PE": "Provider was not eligible on DOS",
        "PP": "Provider is not patient's PCP",
        "PR": "Patient responsibility after insurance payment",
        "RI": "Refund to insurance",
        "RP": "Refund to the Patient",
        "120": "Missing/incomplete/invalid CLIA certification number",
        "145": "Premium Payment withholding",
        "160": "Injury/illness was the result of an activity that is benefit exclusion",
        "177": "Patient has not met the required eligibility requirements",
        "ARA": "Account Receivable applied to",
        "CAP": "Covered under Capitation",
        "NOF": "NOT ON FILE",
        "RSS": "Rectification for Secondary Submission",
        "N362": "The number of units exceeds the maximum allowed limit",
        "SBA": "Small Balance Adjustments",
        "D21": "NOHCARD21"
    };
    enteredFromMap: { [key: string]: string } = {
        "1": "IOU CASH REGISTER",
        "2": "SUPER BILL",
        "ERA": "ERA  PAYMENT",
        "4": "EOB",
        "5": "ERA  PAYMENT",
        "6": "ERA - REJECTED",
        "7": "ERA - UNMATCHED",
        "9": "ALL RESULT",
        "13": "NCO",
        "14": "PTL FEEDBACK",
        "15": "SPECIAL INSTRUCTION",
        "16": "REAL TIME CLAIM STATUS",
        "17": "PATIENT CALL",
        "18": "PATIENT PAYMENT",
        "40": "PATIENT PAID IN OFFICE",
        "43": "PATIENT PAID AT THE TIME OF VISIT",
        "44": "PATIENT PAID AFTER GETTING STATEMENT",
        "50": "Patient Refund",
        "60": "CareVoyant"
    };

// generatePaymentNotes(claimPaymentsArray: claimPayments[], type: string): string {

//   const start = performance.now();
//   let result = "";

//   if (type === 'newclaim') {

//     result = claimPaymentsArray.map(payment => {
//       const source = this.paymentMap[payment.claimPayments.Payment_Source] || "Unknown";
//       return `Payment: [Batch ID ${payment.claimPayments.BATCH_NO},Source ${source}, Amt. Paid $${payment.claimPayments.Amount_Paid}]`;
//     }).join("|");

//     this.autonotemodelskip = true;
//   }

//   else if (type === 'oldclaim') {

//     result = claimPaymentsArray
//       .filter(p => p.claimPayments.claim_payments_id === 0 || p.claimPayments.Deleted)
//       .map(payment => {

//         const source = this.paymentMap[payment.claimPayments.Payment_Source];
//         const batch = payment.claimPayments.BATCH_NO || "N/A";
//         let cpt = payment.claimPayments.Charged_Proc_Code.substring(0, 5) || "";

//         const cptNote = cpt ? `, CPT [${cpt}]` : "";

//         return payment.claimPayments.claim_payments_id === 0
//           ? `Payment Added from Batch ID [${batch}] : Source [${source}]${cptNote}`
//           : `Payment Deleted from Batch ID [${batch}] : Source [${source}]${cptNote}`;
//       })
//       .join("|");
//   }

//   const updatedArray = claimPaymentsArray.filter(p => p.claimPayments.claim_payments_id > 0);
//   let paymentupdatenotes = "";

//   if (type === 'oldclaim') {
//     const changeNotes = this.compareSpecificFields(this.oldclaimpayments, updatedArray);
//     changeNotes.push(result);
//     paymentupdatenotes = changeNotes.join("|");
//   }

//   if (!this.updatedNotes) {
//     this.updatedNotes = [];
//   }

//   // Clean previous payment messages
//   this.updatedNotes = this.updatedNotes
//     .map(n => n.replace(/Payment (Added|Deleted).*?(?=\||$)/g, "").trim())
//     .filter(n => n !== "");

//   const finalNote = paymentupdatenotes || result;

//   if (finalNote) {
//     this.updatedNotes.push(finalNote);
//   }

//   console.log(this.updatedNotes);
//   return result;
// }
generatePaymentNotes(claimPaymentsArray: claimPayments[], type: string): string {
    const start = performance.now();
    let result = "";
  //    if (type === "removeClaim") {
  //    const batch = this.batchId;
  // if (batch) {
  //   result = `Claim Payments Removed from Batch ID [${batch}]`;
  // }   
  //   } 
  if (type === "removeClaim") {
  const parts = claimPaymentsArray.map(payment => {
    const src =
      this.paymentMap[payment.claimPayments.Payment_Source] || "Unknown";
    const batch = this.batchId;
    const cptRaw = payment.claimPayments.Charged_Proc_Code;
    const cpt = cptRaw ? cptRaw.substring(0, 5) : "";
    const cptNote = cpt ? `, CPT [${cpt}]` : "";

    return `Payment Deleted from Batch ID [${batch}] : Source [${src}]${cptNote}`;
  });

  result = parts.join("|");
}

    else if (type === "newclaim") {
      result = claimPaymentsArray
        .map(payment => {
          const src = this.paymentMap[payment.claimPayments.Payment_Source] || "Unknown";
          const batch = payment.claimPayments.BATCH_NO;
          const amt = payment.claimPayments.Amount_Paid;
          return `Payment: [Batch ID ${batch}, Source ${src}, Amt. Paid $${amt}]`;
        })
        .join("|");
      
      this.autonotemodelskip = true;
    } else if (type === "oldclaim") {
      const parts = claimPaymentsArray
        .filter(p => p.claimPayments.claim_payments_id === 0 || p.claimPayments.Deleted)
        .map(payment => {
          const src = this.paymentMap[payment.claimPayments.Payment_Source] || "Unknown";
          const batch = payment.claimPayments.BATCH_NO;

          const cptRaw = payment.claimPayments.Charged_Proc_Code;
          const cpt = cptRaw ? cptRaw.substring(0, 5) : "";
          const cptNote = cpt ? `, CPT [${cpt}]` : "";

          if (payment.claimPayments.claim_payments_id === 0) {
            return `Payment Added from Batch ID [${batch}] : Source [${src}]${cptNote}`;
          } else {
            return `Payment Deleted from Batch ID [${batch}] : Source [${src}]${cptNote}`;
          }
        });

      result = parts.join("|");
    }

    // Now handle update notes / compare logic
    const updatedArray = claimPaymentsArray.filter(p => p.claimPayments.claim_payments_id > 0);
    let paymentUpdateNotes = "";

    if (type === "oldclaim") {
      const changeNotes = this.compareSpecificFields(this.oldclaimpayments, updatedArray);
      if(result != "" && result != null && result != undefined ){
        changeNotes.push(result);
      }
      // changeNotes.push(result);
      paymentUpdateNotes = changeNotes.join("|");
    }

    // Clean previous payment messages in this.updatedNotes
    this.updatedNotes = this.updatedNotes
      .map(n => (n || '')
        .replace(/Payment (Added|Deleted).*?(?=\||$)/g, "")
        .replace(/^\|+/g, "")    // <-- remove leading pipes
        .trim()
      )
      .filter(n => n && n.length > 0);

    // Decide final note
    const finalNote = paymentUpdateNotes || result;

    // Only add non-empty notes
    if (finalNote && finalNote.trim().length > 0) {
      
      const cleanedNote = finalNote.replace(/^[\|,\s]+/, "").trim();
      if (cleanedNote && cleanedNote.length > 0) {
        this.updatedNotes.push(cleanedNote);
      }
    }

return result.replace(/^[\|,\s]+/, "");
  }

    compareSpecificFields(payments1: any[], payments2: any[]): string[] {
        const fieldsToCompare = ["Payment_Source", "Payment_Type", "Date_Entry", "ENTERED_FROM",
            "Charged_Proc_Code", "Paid_Proc_Code", "Units", "Amount_Approved", "Amount_Paid", "Amount_Adjusted",
            "Contractual_Amt", "DEPOSITSLIP_ID", "BATCH_NO", "BATCH_DATE", "Check_No", "Date_Filing", "DepositDate",
            "Reject_Type", "Reject_Amount", "ERA_ADJUSTMENT_CODE", "ERA_Rejection_CATEGORY_CODE", "Details"];
        const numberfields = ["Units", "Amount_Approved", "Amount_Paid", "Amount_Adjusted", "Contractual_Amt"];
        let notes: string[] = [];
        if (Array.isArray(this.updatedNotes) && this.updatedNotes.length > 0) {
            this.updatedNotes[0] = this.updatedNotes[0]
                .split("|") // Split the string at index 0
                .filter(part =>
                    !part.trim().startsWith("Payment [Line") // Remove parts containing fieldsToCompare
                )
                .join("|") // Join back to a string
                .trim(); // Remove extra spaces
        }

        // Iterate through payments and compare only the specified fields
        for (let i = 0; i < Math.min(payments1.length, payments2.length); i++) {
            const p1 = payments1[i];
            const p2 = payments2[i];
            let charge_proc = p2.claimPayments.Charged_Proc_Code;
            let batchId=p2.claimPayments.BATCH_NO
            let changes: string[] = []; // Store changes for this line

            for (let field of fieldsToCompare) {
                let value1 = p1.claimPayments[field];
                let value2 = p2.claimPayments[field];

                if (numberfields.includes(field)) {
                    value1 = Number(value1);
                    value2 = Number(value2);
                }
                if (field === "BATCH_DATE" || field === "Date_Filing" || field === "DepositDate" || field === "Date_Entry"|| field === "BATCH_DATE") {

                    if (value1 !== null && value1 !== undefined) {
                        value1 = new Date(value1);
                        if (!isNaN(value1.getTime())) { // Ensure it's a valid date
                            value1 = new Intl.DateTimeFormat("en-US", {
                                year: "numeric",
                                month: "2-digit",
                                day: "2-digit"
                            }).format(value1);
                        }
                    }
                    if (value2 !== null && value2 !== undefined && field === "Date_Entry") {
                        value2 = new Date(value2);
                        if (!isNaN(value2.getTime())) { // Ensure it's a valid date
                            value2 = new Intl.DateTimeFormat("en-US", {
                                year: "numeric",
                                month: "2-digit",
                                day: "2-digit"
                            }).format(value2);
                        }
                    }
                              if (value2 !== null && value2 !== undefined && field === "BATCH_DATE") {
                        value2 = new Date(value2);
                        if (!isNaN(value2.getTime())) { // Ensure it's a valid date
                            value2 = new Intl.DateTimeFormat("en-US", {
                                year: "numeric",
                                month: "2-digit",
                                day: "2-digit"
                            }).format(value2);
                        }
                    }

                }

                if (value1 !== value2) {
                    if (field === "Payment_Source") {
                        value1 = this.paymentMap[value1];
                        value2 = this.paymentMap[value2];
                    }
                    if (field === "Payment_Type") {
                        value1 = this.paymentTypeMap[value1];
                        value2 = this.paymentTypeMap[value2];
                    }
                    if (field === "Reject_Type") {
                        value1 = this.rejectionTypeMap[value1];
                        value2 = this.rejectionTypeMap[value2];
                    }
                    if (field === "ENTERED_FROM") {
                        value1 = this.enteredFromMap[value1];
                        value2 = this.enteredFromMap[value2];
                    }
                    if (field === "ERA_ADJUSTMENT_CODE") {
                        field = "Adjustment_Code"
                    }
                    if (field === "ERA_Rejection_CATEGORY_CODE") {
                        field = "Rejection_Code"
                    }
                    if (field === "Date_Filing") {
                        field = "Check Date"
                    }
                       if (field === "DepositDate") {
                        field = "Deposit Date"
                    }
                       
                           if (field === "DEPOSITSLIP_ID") {
                        field = "DEPOSITSLIP ID"
                    }
                    // Check for null, undefined, or 0 and replace with empty brackets []
                    const formattedValue1 = (value1 === null || value1 === undefined || value1 === 0) ? "[ ]" : `[${value1}]`;
                    const formattedValue2 = (value2 === null || value2 === undefined || value2 === 0) ? "[ ]" : `[${value2}]`;

                    // Format field name: Remove underscores and capitalize each word
                    const formattedField = field
                        .split("_") // Split by underscore
                        .map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()) // Capitalize each word
                        .join(" "); // Join words with space
                    // Store changes
                    changes.push(`[${formattedField} ${formattedValue1} to ${formattedValue2}]`);
                }
            }
            // Add the note only if there are changes
            if (changes.length > 0) {
                let note;
                if (charge_proc) {
                    note = ` Payment [Line ${i + 1}][${charge_proc}][${batchId}]: ${changes.join(" , ")}`
                } else {
                    note = ` Payment [Line ${i + 1}]: ${changes.join(" , ")}`
                }
                notes.push(note);
            }
        }

        return notes;
    }

        AddPaymentNotesInDB() {
  //  Clean and validate notes
  const cleanedNotes = (this.updatedNotes || [])
    .map(n => (n || '').trim())
    .filter(n => n && n.length > 0); // Only keep non-empty notes

  const paymentNotes = cleanedNotes.join(", ");
  //below lines are commented by ubaid..
  //const overpaymentNote = (this.overPaymentNotes || '').trim();
  //const finalNote = paymentNotes || overpaymentNote;
  const finalNote = paymentNotes;
  
  //  DO NOT save empty notes
  if (!finalNote || finalNote.length === 0) {
    console.warn('No valid notes to save - skipping AddPaymentNotesInDB');
    return;
  }
  
  this.claimNotesModel.Response.Claim_Notes_Id = 0;
  this.claimNotesModel.Response.Note_Detail = finalNote;
  this.claimNotesModel.Response.Claim_No = this.claimViewModel.ClaimModel.Claim_No;
  this.claimNotesModel.Response.IsAuto_Note = true;
  this.API.PostData('/Demographic/SaveClaimNotes/', this.claimNotesModel.Response, (d) => {
    if (d.Status == "Sucess") {
      this.claimNotesModel.Response.Note_Detail = ""
      this.updatedNotes = [];
    }
  })
}
    //#endregion

  // AddNotesForCareVoyant() {
  //          
  //       const userid = this.Gv.currentUser.RolesAndRights[0].UserId;
  //       const username = this.Gv.currentUser.RolesAndRights[0].UserName;
  //       const entrydate = this.claimPaymentModel[ndx].claimPayments.Date_Entry;
      
  //       if(this.isBatchAdvisory){
            
  //         const currentDateStr = this.previousPaymentModel[ndx].claimPayments.Date_Entry; 
  //         const currentDate = new Date(currentDateStr);
  //       this.formattedDate = `${(currentDate.getMonth() + 1).toString().padStart(2, '0')}/${currentDate.getDate().toString().padStart(2, '0')}/${currentDate.getFullYear()}`;
  //       }
  //       else{
  //       const currentDate = new Date();
  //        this.formattedDate = `${(currentDate.getMonth() + 1).toString().padStart(2, '0')}/${currentDate.getDate().toString().padStart(2, '0')}/${currentDate.getFullYear()}`;

  //       }
       
  //       let value = `Entry date in Payment section has been modified from Current Date ${this.formattedDate} to ${entrydate} BY User ${username}`;
  //       this.claimNotesModel.Response.Note_Detail = value
  //       this.claimNotesModel.Response.IsAuto_Note= true
  //       this.claimNotesModel.Response.Claim_No = this.claimCharges[0].claimCharges.Claim_No;
  //       this.API.PostData('/Demographic/SaveClaimNotes/', this.claimNotesModel.Response, (d) => {
  //           if (d.Status == "Sucess") {
  //               return;
  //           }
  //       })

  //   }
  // #end
  

hasPaymentBySource(sources: string[]): boolean {
  const source = this.isRemovePayment
    ? this.claimLevelPayments    
    : this.allPayments;       
  const activePayments = source.filter(
    (p: any) =>
      sources.includes(p.Payment_Source) &&
       (p.Deleted === false  || p.Deleted === 0 || p.Deleted == null )
  );

  return activePayments.length > 0;
}


onBillNextChange() {
  this.showBillNextStatusDDL = true;
  this.selectedBillNextStatus = '';
  this.billNextStatusOptions = [];

  let hasPayment = false;

  if (this.selectedBillNext === 'Primary') {
    hasPayment = this.hasPaymentBySource(['1']);
  }
  else if (this.selectedBillNext === 'Secondary') {
    hasPayment = this.hasPaymentBySource(['2']);
  }
  else if (this.selectedBillNext === 'Tertiary') {
    hasPayment = this.hasPaymentBySource(['3']);
  }
  else if (this.selectedBillNext === 'Patient') {
    hasPayment = this.hasPaymentBySource(['P', 'I', 'C', 'T']);
  }

  if (hasPayment) {
    this.billNextStatusOptions = ['Billed', 'Rebilled'];
  } else {
    this.billNextStatusOptions = ['New', 'Billed', 'Rebilled'];
  }
  this.selectedBillNextStatus = '';
}
 applySelectedStatusNonBreaking() {
  if (!this.selectedBillNextStatus) return;

  const statusMap: any = {
    'New': 'N',
    'Billed': 'B',
    'Rebilled': 'R'
  };

  const mappedStatus = statusMap[this.selectedBillNextStatus];

  if (this.selectedBillNext === 'Primary') {
    this.claimViewModel.ClaimModel.Pri_Status = mappedStatus;
  }
  else if (this.selectedBillNext === 'Secondary') {
    this.claimViewModel.ClaimModel.Sec_Status = mappedStatus;
  }
  else if (this.selectedBillNext === 'Tertiary') {
    this.claimViewModel.ClaimModel.Oth_Status = mappedStatus;
  }
  else if (this.selectedBillNext === 'Patient') {
    this.claimViewModel.ClaimModel.Pat_Status = mappedStatus;
  }
}

 resetBillNextModalState() {
  this.selectedBillNext = '';
  this.selectedBillNextStatus = '';
  this.billNextStatusOptions = [];
  this.showBillNextStatusDDL = false;
}

reApplyRemoveSelectedStatus() {
  if (!this.isRemovePayment || !this.removeSelectedStatusMap) return;

  const statusMap: any = {
    'New': 'N',
    'Billed': 'B',
    'Rebilled': 'R'
  };

  const mappedStatus = statusMap[this.removeSelectedStatusMap.status];

  switch (this.removeSelectedStatusMap.responsible) {
    case 'Primary':
      this.claimViewModel.ClaimModel.Pri_Status = mappedStatus;
      break;
    case 'Secondary':
      this.claimViewModel.ClaimModel.Sec_Status = mappedStatus;
      break;
    case 'Tertiary':
      this.claimViewModel.ClaimModel.Oth_Status = mappedStatus;
      break;
    case 'Patient':
      this.claimViewModel.ClaimModel.Pat_Status = mappedStatus;
      break;
  }

  this.removeSelectedStatusMap = null;
}

forceApplySelectedStatus() {

  if (!this.selectedBillNextStatus) return;

  const statusMap: any = {
    'New': 'N',
    'Billed': 'B',
    'Rebilled': 'R'
  };

  const mappedStatus = statusMap[this.selectedBillNextStatus];

  switch (this.selectedBillNext) {
    case 'Primary':
      this.claimViewModel.ClaimModel.Pri_Status = mappedStatus;
      break;

    case 'Secondary':
      this.claimViewModel.ClaimModel.Sec_Status = mappedStatus;
      break;

    case 'Tertiary':
      this.claimViewModel.ClaimModel.Oth_Status = mappedStatus;
      break;

    case 'Patient':
      this.claimViewModel.ClaimModel.Pat_Status = mappedStatus;
      break;
  }

}

getClaimInsuranceOnly(claimNo: number) {
  this.removedClaimNo = claimNo;

  this.API.getData(
    `/Demographic/GetClaimInsurance?claimNo=${claimNo}`
  ).subscribe(res => {
    if (res.Status === 'Success') {

      this.claimViewModel = this.claimViewModel || new ClaimViewModel();
      this.claimViewModel.ClaimModel = res.Response.ClaimModel;
      this.claimViewModel.claimInusrance = res.Response.ClaimInsuranceList || [];
        this.claimViewModel.claimPayments = res.Response.ClaimPaymentsList || [];
      this.populateBillNextOptions();
    }
  });
}

preserveClaimStatuses() {
  const claim = this.claimViewModel.ClaimModel;

  this._preservedStatuses = {
    Pri: claim.Pri_Status,
    Sec: claim.Sec_Status,
    Oth: claim.Oth_Status,
    Pat: claim.Pat_Status
  };
}
restoreUnchangedStatuses() {
  const claim = this.claimViewModel.ClaimModel;

  if (!this._preservedStatuses) return;

  if (this.selectedBillNext !== 'Primary') {
    claim.Pri_Status = this._preservedStatuses.Pri;
  }
  if (this.selectedBillNext !== 'Secondary') {
    claim.Sec_Status = this._preservedStatuses.Sec;
  }
  if (this.selectedBillNext !== 'Tertiary') {
    claim.Oth_Status = this._preservedStatuses.Oth;
  }
  if (this.selectedBillNext !== 'Patient') {
    claim.Pat_Status = this._preservedStatuses.Pat;
  }
}



}
