export const NO_DATA_AGAINST_FILTER = "No data found against given criteria";
export const NO_SEARCH_CRITRIA = "Please Enter Any Search Criteria";