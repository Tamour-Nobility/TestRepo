import { Component, OnInit,ChangeDetectorRef } from '@angular/core';
import {DataService} from '.././data.service'
import { APIService } from '../components/services/api.service';
import { TooltipModule } from 'ngx-bootstrap/tooltip';
declare var $: any

@Component({
  selector: 'app-eligblity',
  templateUrl: './eligblity.component.html',
  styleUrls: ['./eligblity.component.css']
})
export class EligblityComponent implements OnInit {
  
 
  constructor( private dataService: DataService,private chRef: ChangeDetectorRef,private API: APIService,) { }
  pracTable: any;
  eligbilityDetails:any=[];
  benefitData:any=[];
  activeCoverage:any=[];
  coInsurance:any=[];
  coPayment:any=[];
  deductible:any=[];
  limitations:any=[];
  outOfPocket:any=[];
  nonCovered:any=[];
  primaryCareProvider:any=[];
  other:any=[];
  patientFirstName:any="";
  patientMiddleName:any="";
  patientLastName:any="";
  patientSex:any="";
  patientDateofBirth:any="";
  patientAddress:any="";
  patientCity:any="";
  patientState:any="";
  patientZip:any="";
  providerFirstName:any="";
  providerLastName:any="";
  eligibilityDate:any="";
  planBegin:any="";
  relationship:any="";
  date:any=[];
  benefitentity:any=[];
  allMedicalName:any=[];
  serviceTypeCode:any=[];
  patientPlan:any="";
  patientGroup:any="";
  patientPlanSponsor="";
  patientSubscriberName="";
  patientSubscriberRelationshiptoinsured ="";
  patientSubscriberInsuredID="";
  patientSubscriberNamelast="";
  tempVariable:any

  ngOnInit() {
    // $(function () {
    //   $('[data-toggle="tooltip"]').tooltip()
    // })

    this.API.getData(`/Demographic/GetServiceTypeCodesDescription`).subscribe(response => {
      console.log("My first api response",response);
      if(response.Status=="Success"){
        this.serviceTypeCode=response.Response;
        this.dividedJsonData();
      }
    });

   debugger
    var eligibilityData= localStorage.getItem("mydata")
    console.log("my localStorage Data",eligibilityData)
   var obj= JSON.parse(eligibilityData);
    this.eligbilityDetails=[]
                this.eligbilityDetails.push(obj) ;
                console.log("my data response",this.eligbilityDetails)

    if(obj.eligibilityresponse.hasOwnProperty('dependent')){
          this.patientFirstName=this.eligbilityDetails[0].eligibilityresponse.dependent.patientname.first;
          this.patientMiddleName=this.eligbilityDetails[0].eligibilityresponse.dependent.patientname.middle;
          this.patientLastName=this.eligbilityDetails[0].eligibilityresponse.dependent.patientname.last;
          this.patientSex=this.eligbilityDetails[0].eligibilityresponse.dependent.sex;
          this.patientDateofBirth=this.eligbilityDetails[0].eligibilityresponse.dependent["date-of-birth"];
          this.patientDateofBirth=this.patientDateofBirth.slice(4, 6)+'-'+this.patientDateofBirth.slice(6, 8)+'-'+this.patientDateofBirth.slice(0, 4);
          this.patientAddress=this.eligbilityDetails[0].eligibilityresponse.dependent.patientname.patientaddress;
          this.patientPlan=this.eligbilityDetails[0].eligibilityresponse.dependent.subscriberaddinfo[0].grouppolicynum;
          this.patientGroup=this.eligbilityDetails[0].eligibilityresponse.dependent.subscriberaddinfo[1].grouppolicynum;
          this.patientPlanSponsor=this.eligbilityDetails[0].eligibilityresponse.dependent.subscriberaddinfo[1].plansponsorname; 
          this.patientSubscriberName=this.eligbilityDetails[0].eligibilityresponse.subscriber.subscribername.first;
          this.patientSubscriberNamelast=this.eligbilityDetails[0].eligibilityresponse.subscriber.subscribername.last;
           this.patientSubscriberRelationshiptoinsured=this.eligbilityDetails[0].eligibilityresponse.subscriber.relationship.relationshipcode;
          this.patientSubscriberInsuredID=this.eligbilityDetails[0].eligibilityresponse.subscriber.subscriberid; 
          this.patientCity=this.eligbilityDetails[0].eligibilityresponse.dependent.patientname.patientcity;
          this.patientState=this.eligbilityDetails[0].eligibilityresponse.dependent.patientname.patientstate;
          this.patientZip=this.eligbilityDetails[0].eligibilityresponse.dependent.patientname.patientzip;
          this.benefitData=this.eligbilityDetails[0].eligibilityresponse.dependent.benefit;
          if(this.eligbilityDetails[0].eligibilityresponse.dependent.hasOwnProperty('date')){
            
            if(this.eligbilityDetails[0].eligibilityresponse.dependent.date.length>0){
             for(let i=0;i<this.eligbilityDetails[0].eligibilityresponse.dependent.date.length;i++){
               let dateofservice =this.eligbilityDetails[0].eligibilityresponse.dependent.date[i]["date-of-service"]
               this.eligbilityDetails[0].eligibilityresponse.dependent.date[i]["date-of-service"]=dateofservice.slice(4, 6)+'-'+dateofservice.slice(6, 8)+'-'+dateofservice.slice(0, 4);
               this.date.push(this.eligbilityDetails[0].eligibilityresponse.dependent.date[i]);
             }
            }else{
             let dateofservice=this.eligbilityDetails[0].eligibilityresponse.dependent.date["date-of-service"];
               this.eligbilityDetails[0].eligibilityresponse.dependent.date["date-of-service"]=dateofservice.slice(4, 6)+'-'+dateofservice.slice(6, 8)+'-'+dateofservice.slice(0, 4);
               this.date.push(this.eligbilityDetails[0].eligibilityresponse.dependent.date)
            }
         }
          if(obj.eligibilityresponse.inforeceiver.hasOwnProperty('providername')){
            this.providerFirstName=this.eligbilityDetails[0].eligibilityresponse.inforeceiver.providername.first;
            this.providerLastName=this.eligbilityDetails[0].eligibilityresponse.inforeceiver.providername.last;
        }
  }
  if(obj.eligibilityresponse.subscriber.hasOwnProperty('benefit')){
          this.patientFirstName=this.eligbilityDetails[0].eligibilityresponse.subscriber.patientname.first;
          this.patientMiddleName=this.eligbilityDetails[0].eligibilityresponse.subscriber.patientname.middle;
          this.patientLastName=this.eligbilityDetails[0].eligibilityresponse.subscriber.patientname.last;
          this.patientSex=this.eligbilityDetails[0].eligibilityresponse.subscriber.sex;
          this.patientDateofBirth=this.eligbilityDetails[0].eligibilityresponse.subscriber["date-of-birth"];
          this.patientDateofBirth=this.patientDateofBirth.slice(4, 6)+'-'+this.patientDateofBirth.slice(6, 8)+'-'+this.patientDateofBirth.slice(0, 4);
          this.patientAddress=this.eligbilityDetails[0].eligibilityresponse.subscriber.patientname.patientaddress;
          // this.patientSubscriberName=this.eligbilityDetails[0].eligibilityresponse.subscriber.subscribername.first;
          // this.patientSubscriberNamelast=this.eligbilityDetails[0].eligibilityresponse.subscriber.subscribername.last;
          this.patientSubscriberRelationshiptoinsured=this.eligbilityDetails[0].eligibilityresponse.subscriber.relationship.relationshipcode;
          this.patientSubscriberInsuredID=this.eligbilityDetails[0].eligibilityresponse.subscriber.subscriberid; 
          this.patientCity=this.eligbilityDetails[0].eligibilityresponse.subscriber.patientname.patientcity;
          this.patientState=this.eligbilityDetails[0].eligibilityresponse.subscriber.patientname.patientstate;
          this.patientZip=this.eligbilityDetails[0].eligibilityresponse.subscriber.patientname.patientzip;
          if(this.eligbilityDetails[0].eligibilityresponse.subscriber.hasOwnProperty('date')){
            
             if(this.eligbilityDetails[0].eligibilityresponse.subscriber.date.length>0){
              for(let i=0;i<this.eligbilityDetails[0].eligibilityresponse.subscriber.date.length;i++){
                let dateofservice =this.eligbilityDetails[0].eligibilityresponse.subscriber.date[i]["date-of-service"]
                this.eligbilityDetails[0].eligibilityresponse.subscriber.date[i]["date-of-service"]=dateofservice.slice(4, 6)+'-'+dateofservice.slice(6, 8)+'-'+dateofservice.slice(0, 4);
                this.date.push(this.eligbilityDetails[0].eligibilityresponse.subscriber.date[i]);
              }
             }else{
              let dateofservice=this.eligbilityDetails[0].eligibilityresponse.subscriber.date["date-of-service"];
                this.eligbilityDetails[0].eligibilityresponse.subscriber.date["date-of-service"]=dateofservice.slice(4, 6)+'-'+dateofservice.slice(6, 8)+'-'+dateofservice.slice(0, 4);
                this.date.push(this.eligbilityDetails[0].eligibilityresponse.subscriber.date)
             }
          }
          
          
          this.benefitData=this.eligbilityDetails[0].eligibilityresponse.subscriber.benefit;
          if(obj.eligibilityresponse.subscriber.hasOwnProperty('relationship')){
            this.relationship=this.eligbilityDetails[0].eligibilityresponse.subscriber.relationship.relationshipcode;
          }
          if(obj.eligibilityresponse.inforeceiver.hasOwnProperty('providername')){
            this.providerFirstName=this.eligbilityDetails[0].eligibilityresponse.inforeceiver.providername.first;
            this.providerLastName=this.eligbilityDetails[0].eligibilityresponse.inforeceiver.providername.last;
        }
  }
  
    
  }
//   get data() :any{
//     return this.dataService.sharedData
// }


Tooltip() {
  this.tempVariable = $.trim($($("selectfgfgdfgdfgdfgdf")));
}

dividedJsonData(){
  console.log("benefit all data",this.benefitData)
  const keys = ['info', 'coveragelevel','servicetype','servicetypecode','time_period_qualifier','plancoveragedescription','quantity','quantityqualifier','percent','benefitamount'],
  filtered = this.benefitData.filter(
      (s => (o: { [x: string]: any; }) => 
          (k => !s.has(k) && s.add(k))
          (keys.map(k => o[k]).join('|'))
      )
      (new Set)
  );

console.log("new data",filtered);
this.benefitData=filtered;
  for(var i=0;i<this.benefitData.length;i++){
    // console.log("for loof data",this.benefitData[i])
    var coveragelevel=this.benefitData[i].hasOwnProperty('coveragelevel');
    var info=this.benefitData[i].hasOwnProperty('info');
    var servicetype=this.benefitData[i].hasOwnProperty('servicetype');
    var servicetypecode=this.benefitData[i].hasOwnProperty('servicetypecode');
    var time_period_qualifier=this.benefitData[i].hasOwnProperty('time_period_qualifier');
    var benefitamount=this.benefitData[i].hasOwnProperty('benefitamount');
    var yes_no_response_code=this.benefitData[i].hasOwnProperty('yes_no_response_code');
    var plannetworkindicator=this.benefitData[i].hasOwnProperty('plannetworkindicator');
    var quantity=this.benefitData[i].hasOwnProperty('quantity');
    var quantityqualifier=this.benefitData[i].hasOwnProperty('quantityqualifier');
    var message=this.benefitData[i].hasOwnProperty('message');
      if(info || coveragelevel || servicetype || servicetypecode || time_period_qualifier || benefitamount || yes_no_response_code || plannetworkindicator || quantity || message || quantityqualifier){
          
          // if(this.benefitData[i].hasOwnProperty('servicetypecode')){
          //   this.benefitData[i].servicetypecode=this.benefitData[i].servicetypecode.replace(/[`~!@#$%^&*()_|+\-=?;:'",.<>\{\}\[\]\\\/]/gi, ',');
          //   var nameArr = this.benefitData[i].servicetypecode.split(',');
          //   var allMedicalValue=""
          //   for(var j=0;j<this.serviceTypeCode.length;j++){
              
          //     var serviceTypeCodeValue=this.serviceTypeCode[j]
          //     nameArr.forEach(myFunction);
          //     function myFunction(item) {
          //       var searchValue= item
          //      if(serviceTypeCodeValue.CODE==searchValue){
          //       // console.log("item",searchValue)
          //       allMedicalValue +=  serviceTypeCodeValue.DESCRIPTION+ ",";
          //         // console.log("allMedicalName",allMedicalValue)
          //      }
          //    }
         
          //  }
          //  this.benefitData[i].servicetypecode= allMedicalValue.slice(0, -1);
           
          // }
     for (let i = 0; i < this.benefitData.length; i++) {
    if (this.benefitData[i].hasOwnProperty('servicetypecode') && this.benefitData[i].servicetypecode) {
    let rawCodes = this.benefitData[i].servicetypecode.replace(/[^a-zA-Z0-9]/g, ',');
    let codeArray = rawCodes
      .split(',')
      .map(code => code.trim())
      .filter(code => code !== '');
    let descriptionArray = codeArray.map(code => {
      let match = this.serviceTypeCode.find(item => item.CODE === code);
      if (match) return match.DESCRIPTION;
    const hardcodedDescriptions: { [key: string]: string } = {
  '1': "Medical Care",
  '2': "Surgical",
  '3': "Consultation",
  '4': "Diagnostic X-Ray",
  '5': "Diagnostic Lab",
  '6': "Radiation Therapy",
  '7': "Anesthesia",
  '8': "Surgical Assistance",
  '9': "Other Medical",
  '10': "Blood Charges",
  '11': "Used Durable Medical Equipment",
  '12': "Durable Medical Equipment Purchase",
  '13': "Ambulatory Service Center Facility",
  '14': "Renal Supplies in the Home",
  '15': "Alternate Method Dialysis",
  '16': "Chronic Renal Disease (CRD) Equipment",
  '17': "Pre-Admission Testing",
  '18': "Durable Medical Equipment Rental",
  '19': "Pneumonia Vaccine",
  '20': "Second Surgical Opinion",
  '21': "Third Surgical Opinion",
  '22': "Social Work",
  '23': "Diagnostic Dental",
  '24': "Periodontics",
  '25': "Restorative",
  '26': "Endodontics",
  '27': "Maxillofacial Prosthetics",
  '28': "Adjunctive Dental Services",
  '30': "Health Benefit Plan Coverage",
  '32': "Plan Waiting Period",
  '33': "Chiropractic",
  '34': "Chiropractic Office Visits",
  '35': "Dental Care",
  '36': "Dental Crowns",
  '37': "Dental Accident",
  '38': "Orthodontics",
  '39': "Prosthodontics",
  '40': "Oral Surgery",
  '41': "Routine (Preventive) Dental",
  '42': "Home Health Care",
  '43': "Home Health Prescriptions",
  '44': "Home Health Visits",
  '45': "Hospice",
  '46': "Respite Care",
  '47': "Hospital",
  '48': "Hospital - Inpatient",
  '49': "Hospital - Room and Board",
  '50': "Hospital - Outpatient",
  '51': "Hospital - Emergency Accident",
  '52': "Hospital - Emergency Medical",
  '53': "Hospital - Ambulatory Surgical",
  '54': "Long Term Care",
  '55': "Major Medical",
  '56': "Medically Related Transportation",
  '57': "Air Transportation",
  '58': "Cabulance",
  '59': "Licensed Ambulance",
  '60': "General Benefits",
  '61': "In-vitro Fertilization",
  '62': "MRI/CAT Scan",
  '63': "Donor Procedures",
  '64': "Acupuncture",
  '65': "Newborn Care",
  '66': "Pathology",
  '67': "Smoking Cessation",
  '68': "Well Baby Care",
  '69': "Maternity",
  '70': "Transplants",
  '71': "Audiology Exam",
  '72': "Inhalation Therapy",
  '73': "Diagnostic Medical",
  '74': "Private Duty Nursing",
  '75': "Prosthetic Device",
  '76': "Dialysis",
  '77': "Otological Exam",
  '78': "Chemotherapy",
  '79': "Allergy Testing",
  '80': "Immunizations",
  '81': "Routine Physical",
  '82': "Family Planning",
  '83': "Infertility",
  '84': "Abortion",
  '85': "AIDS",
  '86': "Emergency Services",
  '87': "Cancer",
  '88': "Pharmacy",
  '89': "Free Standing Prescription Drug",
  '90': "Mail Order Prescription Drug",
  '91': "Brand Name Prescription Drug",
  '92': "Generic Prescription Drug",
  '93': "Podiatry",
  '94': "Podiatry - Office Visits",
  '95': "Podiatry - Nursing Home Visits",
  '96': "Professional (Physician)",
  '97': "Anesthesiologist",
  '98': "Professional (Physician) Visit - Office",
  '99': "Professional (Physician) Visit - Inpatient",
  'A0': "Professional (Physician) Visit - Outpatient",
  'A1': "Professional (Physician) Visit - Nursing Home",
  'A2': "Professional (Physician) Visit - Skilled Nursing Facility",
  'A3': "Professional (Physician) Visit - Home",
  'A4': "Psychiatric",
  'A5': "Psychiatric - Room and Board",
  'A6': "Psychotherapy",
  'A7': "Psychiatric - Inpatient",
  'A8': "Psychiatric - Outpatient",
  'A9': "Rehabilitation",
  'AA': "Rehabilitation - Room and Board",
  'AB': "Rehabilitation - Inpatient",
  'AC': "Rehabilitation - Outpatient",
  'AD': "Occupational Therapy",
  'AE': "Physical Medicine",
  'AF': "Speech Therapy",
  'AG': "Skilled Nursing Care",
  'AH': "Skilled Nursing Care - Room and Board",
  'AI': "Substance Abuse",
  'AJ': "Alcoholism",
  'AK': "Drug Addiction",
  'AL': "Vision (Optometry)",
  'AM': "Frames",
  'AN': "Routine Exam",
  'AO': "Lenses",
  'AQ': "Nonmedically Necessary Physical",
  'AR': "Experimental Drug Therapy",
  'B1': "Burn Care",
  'B2': "Brand Name Prescription Drug - Formulary",
  'B3': "Brand Name Prescription Drug - Non-Formulary",
  'BA': "Independent Medical Evaluation",
  'BB': "Partial Hospitalization (Psychiatric)",
  'BC': "Day Care (Psychiatric)",
  'BD': "Cognitive Therapy",
  'BE': "Massage Therapy",
  'BF': "Pulmonary Rehabilitation",
  'BG': "Cardiac Rehabilitation",
  'BH': "Pediatric",
  'BI': "Nursery",
  'BJ': "Skin",
  'BK': "Orthopedic",
  'BL': "Cardiac",
  'BM': "Lymphatic",
  'BN': "Gastrointestinal",
  'BP': "Endocrine",
  'BQ': "Neurology",
  'BR': "Eye",
  'BS': "Invasive Procedures",
  'BT': "Gynecological",
  'BU': "Obstetrical",
  'BV': "Obstetrical/Gynecological",
  'BW': "Mail Order Prescription Drug: Brand Name",
  'BX': "Mail Order Prescription Drug: Generic",
  'BY': "Physician Visit - Office: Sick",
  'BZ': "Physician Visit - Office: Well",
  'C1': "Coronary Care",
  'CA': "Private Duty Nursing - Inpatient",
  'CB': "Private Duty Nursing - Home",
  'CC': "Surgical Benefits - Professional (Physician)",
  'CD': "Surgical Benefits - Facility",
  'CE': "Mental Health Provider - Inpatient",
  'CF': "Mental Health Provider - Outpatient",
  'CG': "Mental Health Facility - Inpatient",
  'CH': "Mental Health Facility - Outpatient",
  'CI': "Substance Abuse Facility - Inpatient",
  'CJ': "Substance Abuse Facility - Outpatient",
  'CK': "Screening X-ray",
  'CL': "Screening laboratory",
  'CM': "Mammogram, High Risk Patient",
  'CN': "Mammogram, Low Risk Patient",
  'CO': "Flu Vaccination",
  'CP': "Eyewear and Eyewear Accessories",
  'CQ': "Case Management",
  'DG': "Dermatology",
  'DM': "Durable Medical Equipment",
  'DS': "Diabetic Supplies",
  'GF': "",
  'GN': "",
  'GY': "",
  'IC': "",
  'MH': "Mental Health",
  'NI': "",
  'ON': "",
  'PT': "",
  'PU': "",
  'RN': "",
  'RT': "",
  'TC': "",
  'TN': "",
  'UC': "Urgent Care"
};
      return hardcodedDescriptions[code] || code; 
    });

    this.benefitData[i].servicetypecode = descriptionArray.join(', ');
  }
}


          if(!time_period_qualifier){
            this.benefitData[i].time_period_qualifier="";
          }
          if(!quantityqualifier){
            this.benefitData[i].quantityqualifier="";
          }

          if(!message){
            this.benefitData[i].message="No Info";
          }

          if(!this.benefitData[i].hasOwnProperty('quantity')){
            this.benefitData[i].quantity="";
          }
          if(this.benefitData[i].hasOwnProperty('benefitamount')){
            this.benefitData[i].benefitamount="$"+parseInt(this.benefitData[i].benefitamount).toLocaleString('en-US');
          }
          else{
            this.benefitData[i].benefitamount=""
          }
          if(this.benefitData[i].hasOwnProperty('percent')){
            this.benefitData[i].percent=parseFloat(this.benefitData[i].percent)*100 +" %";
          }
          else{
            this.benefitData[i].percent="";
          }
          
          if(this.benefitData[i].hasOwnProperty('plannetworkindicator')){
            switch(this.benefitData[i].plannetworkindicator) {
              case 'In Plan-Network':
                this.benefitData[i].plannetworkindicator="In-Network";
                break;
              case 'Out of Plan-Network':
                this.benefitData[i].plannetworkindicator="Out-Network";
                break;
            }
            
          }
        switch (this.benefitData[i].info) {
          case 'Active Coverage':
            this.activeCoverage.push(this.benefitData[i]);
            break;
          case 'Co-Insurance':
              this.coInsurance.push(this.benefitData[i]);
            break;
          case 'Co-Payment':
            this.coPayment.push(this.benefitData[i]);
            break;
          case 'Deductible':
            this.deductible.push(this.benefitData[i]);
            break;
          case 'Limitations':
            this.limitations.push(this.benefitData[i]);
            break;
          case 'Out of Pocket (Stop Loss)':
            this.outOfPocket.push(this.benefitData[i]);
            break;
          case 'Non-Covered':
            this.nonCovered.push(this.benefitData[i]);
            break;
          case 'Primary Care Provider':
            if(!this.benefitData[i].hasOwnProperty('benefitentity')){
              this.benefitentity=[]
            }else{
              if(this.benefitData[i].benefitentity.length>0){
                
                for(let b=0;b<this.benefitData[i].benefitentity.length;b++){

                  this.benefitentity.push(this.benefitData[i].benefitentity[b]);
                }
              }
              else{
                this.benefitentity.push(this.benefitData[i].benefitentity);
              }
            }
            
            
            
            if(this.benefitData[i].hasOwnProperty('coveragelevel')){
              this.primaryCareProvider.push(this.benefitData[i]);
            }
            break;
            default:
            this.other.push(this.benefitData[i]);
            break;
        }
      }
 
  }
  
  console.log("All Active Coverage Data",this.activeCoverage);
  console.log("All coInsurance Data",this.coInsurance);
  console.log("All deductible Data",this.deductible);
  console.log("All limitations Data",this.limitations);
  console.log("All Out of Pocket (Stop Loss) Data",this.outOfPocket);
  console.log("Primary Care Provider",this.primaryCareProvider);
  console.log("coPayment",this.coPayment);
  console.log("benefitentity",this.benefitentity);
  console.log("date dfgkhsdfjkghsdfjkgh",this.date);


// Code of Pagenation
  if (this.pracTable)
        this.pracTable.destroy();
   
    this.chRef.detectChanges();
    this.pracTable = $('.pracTable').DataTable({
        columnDefs: [
            { orderable: false, targets: -1 }
        ],
        language: {
            emptyTable: "No data available"
        }
    });
  //End Code of Pagenation  
  }
 
}
