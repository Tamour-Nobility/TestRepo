export class PaymentResponsbility {
    Claim_No: number;
    Insurance_over_paid: string;  // Change to string
    Patient_credit_balance: string; // Change to string
    Total_Responsibility: string;
    Deleted:boolean

}
