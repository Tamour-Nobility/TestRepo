export class ResponseModel {
    Status: any;
    Response: any;
}