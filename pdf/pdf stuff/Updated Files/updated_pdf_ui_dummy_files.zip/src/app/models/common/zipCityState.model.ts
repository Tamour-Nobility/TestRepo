export class ZipCityStateViewModel {
    ZIP_Code: string;
    CityName: string;
    State: string;
}