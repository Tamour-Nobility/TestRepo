export class Ticketsearch {
    ticketId : number=0;
    ticketType : string;
    ticketReason : string;
    ticketPriority : string;
    practice : any;
    claimNumber : string;
    status : string;
    assignedDept : string;
    caseCreatedBy : string;
    assignedUser : string;
    byPayer : string;
    createdDateFrom : string;
    createdDateTo : string;
}
