import { PaymentResponsbility } from './payment-responsbility.model';

describe('PaymentResponsbility', () => {
  it('should create an instance', () => {
    expect(new PaymentResponsbility()).toBeTruthy();
  });
});
