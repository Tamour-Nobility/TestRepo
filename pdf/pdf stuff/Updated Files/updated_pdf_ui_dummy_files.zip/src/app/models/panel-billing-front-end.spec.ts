import { PanelBillingFrontEnd } from './panel-billing-front-end';

describe('PanelBillingFrontEnd', () => {
  it('should create an instance', () => {
    expect(new PanelBillingFrontEnd()).toBeTruthy();
  });
});
