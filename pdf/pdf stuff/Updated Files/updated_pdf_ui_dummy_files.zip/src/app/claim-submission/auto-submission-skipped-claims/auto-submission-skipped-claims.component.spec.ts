import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AutoSubmissionSkippedClaimsComponent } from './auto-submission-skipped-claims.component';

describe('AutoSubmissionSkippedClaimsComponent', () => {
  let component: AutoSubmissionSkippedClaimsComponent;
  let fixture: ComponentFixture<AutoSubmissionSkippedClaimsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AutoSubmissionSkippedClaimsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AutoSubmissionSkippedClaimsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
