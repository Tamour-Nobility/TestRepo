import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { APIService } from '../../../../src/app/components/services/api.service';
import { DatePipe } from '@angular/common';
import { Common } from '../../../app/services/common/common';
import { Router } from '@angular/router';
// import { APIService } from 'src/app/components/services/api.service';

@Component({
  selector: 'app-auto-submission-skipped-claims',
  templateUrl: './auto-submission-skipped-claims.component.html',
  styleUrls: ['./auto-submission-skipped-claims.component.css']
})
export class AutoSubmissionSkippedClaimsComponent implements OnInit {
  prac:any;
  errorTable:any;
   scrubberAllErrorClaims:any=[];
  constructor(public API: APIService,private chRef: ChangeDetectorRef,private datePipe: DatePipe,private router: Router) { }

  ngOnInit() {
    debugger
    //this.CustomEditHide();
    //update
      this.scrubberGetAllViolation();
      //this.showscrubbertable('Custom Edits');
    
    
  } 

  formatDate(dateString: string): string {
    debugger
    
    const date = new Date(dateString);
    return this.datePipe.transform(date, 'MM-dd-yyyy');
  }
  
    scrubberGetAllViolation(){
  
      var aaa=[]
        
      this.prac=JSON.parse(localStorage.getItem('sp'));
  
      if( localStorage.getItem('sp') === null){
        this.prac = {PracticeCode: '1010999'}
        this.prac = Number(this.prac['PracticeCode']);
      }else{
        this.prac=JSON.parse(localStorage.getItem('sp'));
        this.prac= this.prac['PracticeCode'];
        this.prac= Number(this.prac); 
      }
  
  
      
  
        this.API.PostData('/Scrubber/getSkippedClaims?practiceCode='+ this.prac, this.prac,  data => {
          debugger
            if (data.Status.toUpperCase() === 'SUCCESS') {
                if (this.errorTable)
                    this.errorTable.destroy();
                this.scrubberAllErrorClaims =[]
                
                var a=[]
                
  
                for(var res=0;res<data.Response.length;res++){
                  console.log("this.scrubberAllErrorClaims",data.Response[res].Error_Details.split(','))
                a=data.Response[res].Error_Details.split(',')
                var b=''
                for(var i=0;i<a.length;i++){
                  var z=a[i].trim()
                  if(!b.includes(z) && z!=''){
                    b+= z+ ', '
                  }
                }
                data.Response[res].Error_Details=b.replace(/,(?=\s*$)/, '')
                console.log("b",b.replace(/,(?=\s*$)/, ''))
                
                this.scrubberAllErrorClaims.push(data.Response[res])
                }
  
  
                console.log("claims",  aaa);
                this.chRef.detectChanges();
                this.errorTable = $('.errorTable').DataTable({
                    columnDefs: [
                        { orderable: false, targets: -1 }
                    ],
                    language: {
                        emptyTable: "No data available"
                    }
                });
            } else {
                swal('Failed', data.Status, 'error');
                this.errorTable = $('.errorTable').DataTable({
                  columnDefs: [
                      { orderable: false, targets: -1 }
                  ],
                  language: {
                      emptyTable: "No data available"
                  }
              });
            }
        }
    );
    }
    editClaim(claimNo, patientAccount, firstName, lastName) {
        this.router.navigate(['/Patient/Demographics/ClaimDetail/',
          Common.encodeBase64(JSON.stringify({
            Patient_Account: patientAccount,
            claimNo: claimNo,
            disableForm: false,
            PatientLastName: lastName,
            PatientFirstName: firstName
          }))]);
      }

}
