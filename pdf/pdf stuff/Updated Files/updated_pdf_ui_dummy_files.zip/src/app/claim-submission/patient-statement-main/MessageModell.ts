export class MessageModeld{

    Message_ID  :number;

   Messages :string;

   PracticeCode:any; 

   Deleted :boolean;

   Created_By :number;

  Created_Date:Date;

    Modified_By :Number;

    Modified_Date :Date;


}