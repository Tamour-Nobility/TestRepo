export class Practice {
    Id: number;
    Name: string;
}


export class ClaimDetail {
    Claim_No: number;
    Details: string;
    ReadableDetails:any=[];
    ReadableDetailsError:string;

}