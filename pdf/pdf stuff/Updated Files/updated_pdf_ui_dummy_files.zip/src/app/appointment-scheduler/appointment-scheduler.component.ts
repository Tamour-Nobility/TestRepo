import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-appointment-scheduler',
  templateUrl: './appointment-scheduler.component.html',
  styleUrls: ['./appointment-scheduler.component.css']
})
export class AppointmentSchedulerComponent implements OnInit {

  constructor() {
  }

  ngOnInit() {
  }
}
