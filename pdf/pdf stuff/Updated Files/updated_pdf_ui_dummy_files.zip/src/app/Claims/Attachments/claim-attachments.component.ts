import { Component, OnInit } from '@angular/core';
import { Common } from '../../services/common/common';
import { APIService } from '../../components/services/api.service';
import { SelectListViewModel } from '../../models/common/selectList.model';
import { FileHandlerService } from '../../components/services/file-handler/filehandler.service';
import { ToastrService } from 'ngx-toastr';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ChangeDetectorRef, EventEmitter, Input, Output, ViewChild } from '@angular/core';
import { saveAs } from 'file-saver';
import { ClaimAttachmentModel,ClaimNote } from '../../shared/models/PatientAttachment.model';
import { GvarsService } from '../../services/G_vars/gvars.service';

const validMimeTypes = [
  "application/pdf",                             
  "image/jpeg", "image/png",                     
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document", // DOCX
  "text/plain"                                   
];



const maximumFileSize = 20000000;

@Component({
  selector: 'app-claim-attachments',
  templateUrl: './claim-attachments.component.html',
  styleUrls: ['./claim-attachments.component.css']
})
export class ClaimAttachmentsComponent implements OnInit {
  form: FormGroup;
  selectedFile: File | null = null;
   Doc_Type_Lookup = [
  { code: 1, value: "All" },
  { code: 10, value: "Lab Documents" },
  { code: 100, value: "Procedure Documents" },
  { code: 102, value: "Vaccine Consent" },
  { code: 103, value: "EOB Documents" },
  { code: 104, value: "AdvDirective Documents" },
  { code: 108, value: "Patient Information" },
  { code: 11, value: "Physical Exam Drawing" },
  { code: 110, value: "Radiology Documents" },
  { code: 111, value: "Prescriptions" },
  { code: 112, value: "Home Health Documents" },
  { code: 113, value: "Medical Records" },
  { code: 114, value: "Paper Document Folder" },
  { code: 115, value: "BioTe Paperwork" },
  { code: 116, value: "HIPPA Paperwork" },
  { code: 12, value: "Procedures Drawing" },
  { code: 122, value: "SPAC FORMS" },
  { code: 123, value: "PortalBox" },
  { code: 13, value: "Healow Chat Documents" },
  { code: 137, value: "WorkersComp" },
  { code: 14, value: "Healow Chat History" },
  { code: 143, value: "Vision Drawing" },
  { code: 144, value: "Vision Category Inking" },
  { code: 145, value: "Vascular Documents" },
  { code: 146, value: "Fax Inbox" },
  { code: 149, value: "Notifications" },
  { code: 150, value: "ICD Groups" },
  { code: 151, value: "Vision Documents" },
  { code: 152, value: "Homunculus Examination" },
  { code: 153, value: "ePA Documents" },
  { code: 154, value: "Healow Chatbot History" },
  { code: 2, value: "Chart Documents" },
  { code: 21, value: "Immunization Forms" },
  { code: 23, value: "Speciality Forms" },
  { code: 3, value: "X-Ray Documents" },
  { code: 4, value: "Patient Documents" },
  { code: 5, value: "Consult Notes" },
  { code: 7, value: "Referral Notes" },
  { code: 8, value: "Examination Drawing" },
  { code: 84, value: "Case Manager" },
  { code: 86, value: "Dermatology Drawing" }
];


  uploading = false;
  noteModel: ClaimNote;
  filename:any;
  filetype:any;
  datatableClaimAttachments: any;
  attachmentTypesList: SelectListViewModel[] = [];
  attachments: ClaimAttachmentModel[] = [];

  isDataTableInitialized = false;
attachmentTypesLis = [
  { IdStr: 'ALL', Name: 'All' },
  { IdStr: 'Worker Comp', Name: 'Worker Comp' },
  { IdStr: 'No Fault', Name: 'No Fault' },
  { IdStr: 'Health Insurance', Name: 'Health Insurance' }
];

  @Input() ExcludedClaimsIds: number[] = [];
  @Input('PatientAccount') PatientAccount: number;
  @Input('Claim_No') Claim_No: number;
  @Input('UserName') UserName: string;
  @Output() onHidden: EventEmitter<any> = new EventEmitter();
  @ViewChild(ModalDirective) claimAttachment: ModalDirective;
   @ViewChild('fileInput') fileInput: any;
  // constructor(
  //   private toastr: ToastrService,
  //   private _apiService: APIService,
  //   private _fileHandlerService: FileHandlerService,
  //   private _chRef: ChangeDetectorRef,
  //   private _gv: GvarsService,
  // ) {}
  constructor(
  private toastr: ToastrService,
  private _apiService: APIService,
  private _fileHandlerService: FileHandlerService,
  private _chRef: ChangeDetectorRef,
  private _gv: GvarsService,
 )  {
   this.noteModel = new ClaimNote(); // Defensive init
  }


  ngOnInit() {
    this.initForm();
    
  }

  ngAfterViewInit(){
    debugger
this.getClaimAttachments();
      this.getClaimAttachmentTypeCodes();
  }

  initForm() {
    this.form = new FormGroup({
      attachment: new FormControl(null),
      documentType: new FormControl(null, [Validators.required]),
      insuranceType: new FormControl(null),
      description: new FormControl(null)
    });
  }

  show() {
    this.claimAttachment.show();
  }

  hide() {
    this.claimAttachment.hide();
  }

  onClaimAttachmentsShown() {
    debugger
    
      // this.getClaimAttachments();
      // this.getClaimAttachmentTypeCodes();
   
  }
  //   onClaimAttachmentsShown() {
  //   if (!Common.isNullOrEmpty(this.Claim_No)) {
  //       this.getClaimAttachments();
  //     this.getClaimAttachmentTypeCodes();
  //   }
  // }



  // getClaimAttachmentTypeCodes() {
  //   debugger
  //   this._apiService.getData('/ClaimsAttachments/GetAttachmentCodeList')
  //     .subscribe({
  //       next: (res) => {
  //         this.attachmentTypesList = res.Response || [];
  //       },
  //       error: (err) => {
  //         console.error("Error fetching attachment types", err);
  //         this.toastr.error('Failed to load attachment types.');
  //       }
  //     });
  // }
  getClaimAttachmentTypeCodes() {
    debugger
    this._apiService.getData('/ClaimsAttachments/GetAttachmentCodeList')
      .subscribe((res) => {
        this.attachmentTypesList = res.Response;
      });
  }
  onClaimAttachmentsHidden() {
    this.selectedFile = null;
    this.form.reset();
    this.uploading = false;
  }
  onChangeFile(event: any) {
    this.selectedFile = null;
    const { files } = event.target;
    if (files.length === 0) {
      this.toastr.warning('Please choose file to upload.', 'File Missing');
      return;
    }
    const file = files[0];
    const { size, type } = file;
    if (!validMimeTypes.includes(type)) {   
      this.toastr.warning('Please choose file with type PDF, JPG, PNG, DOCX, TXT', 'File Type');
      return;
    }
    if (size > maximumFileSize) {
      this.toastr.warning('Maximum file size 20Mb.', 'File Size');
      return;
    }
    this.selectedFile = file;
  }

//correct code
onUpload() {
  debugger;
  if (!this.selectedFile) {
    this.toastr.warning('Please choose file.', 'File Missing');
    return;
  }
  if (!this.form.controls["documentType"].value) {
    this.toastr.warning('Please select Doc Type', 'Doc Type');
    return;
  }
  if (!this.form.controls["insuranceType"].value) {
    this.toastr.warning('Please select Insurance Type.', 'Insurance Type');
    return;
  }
  if (!this.form.controls["description"].value) {
    this.toastr.warning('Please enter description', 'Description Missing');
    return;
  }

  this.uploading = true;
  const formData = new FormData();
  const attachment = new ClaimAttachmentModel();

  this._apiService.UserName = JSON.parse(localStorage.getItem('rr'));
  attachment.Doc_Type = this.Doc_Type_Lookup.find(d => d.code === Number(this.form.controls["documentType"].value)).value;
  attachment.Doc_Value = this.form.controls["documentType"].value;
  attachment.Insurance_Type = this.form.controls["insuranceType"].value;
  attachment.Description = this.form.controls["description"].value;
  attachment.Claim_No = this._apiService.Claim_No;
  attachment.Attached_By = JSON.parse(localStorage.getItem('rr'))[0].UserName;
  attachment.Attached_ON = new Date();
  attachment.Document_Name = this.selectedFile.name;
  attachment.file = this.selectedFile;
  attachment.Document_ID = 0;
  this._gv.setSelectedAttachment(attachment);
  this.attachments.push(attachment);
  this._chRef.detectChanges();
  var addrecord=this.attachments
  this.attachments=[];


// changes by abbas 

if (this.datatableClaimAttachments) {
          this._chRef.detectChanges();
          this.datatableClaimAttachments.destroy();
          }
        this.attachments=addrecord;
         this._chRef.detectChanges();
        const table: any = $('.datatableClaimAttachments');
        this.datatableClaimAttachments = table.DataTable({
          columnDefs: [
            { orderable: false, targets: -1 },
          ],
          order: [3, 'desc'],
          language: {
            emptyTable: "No data available"
          }
        })








  // if (this.datatableClaimAttachments) {
  //   const table = this.datatableClaimAttachments;
  //   table.row.add([
  //     attachment.Document_Name,
  //     attachment.Doc_Type,
  //     attachment.Insurance_Type,
  //     attachment.Description,
  //     attachment.Attached_By,
  //     attachment.Attached_ON.toLocaleString(),
  //     `<button class="btn btn-sm btn-danger">Delete</button>`
  //   ]).draw(false);  
  // }

  this.uploading = false;
  this.form.reset();
  this.selectedFile = null;
  this.toastr.success('File uploaded successfully.');

  this.filename = attachment.Document_Name;
  this.filetype = attachment.Doc_Type;

  formData.append("TypeCode", attachment.Doc_Type);
  formData.append("InsuranceType", attachment.Insurance_Type);
  formData.append("Description", attachment.Description);
  formData.append("file", this.selectedFile);
  formData.append("PracticeCode", this._gv.currentUser.selectedPractice.PracticeCode.toString());
  formData.append("Claim_No", attachment.Claim_No.toString());
}











// onUpload() {
//   debugger
//     if (!this.selectedFile) {
//     this.toastr.warning('Please choose file.', 'File Missing');
//     return;
//   }
//   if (!this.form.controls["documentType"].value) {
//     this.toastr.warning('Please select Doc Type', 'Doc Type');
//     return;
//   }
//      if (!this.form.controls["insuranceType"].value) {
//     this.toastr.warning('Please select Insurance Type.', 'Insurance Type');
//     return;
//   }
//   if (!this.form.controls["description"].value) {
//     this.toastr.warning('Please enter description', 'Description Missing');
//     return;
//   }

//     this.uploading = true;
//     const formData = new FormData();
//     const attachment = new ClaimAttachmentModel();
//     this._apiService.UserName=JSON.parse(localStorage.getItem('rr'))
//     attachment.Doc_Type = this.Doc_Type_Lookup.find(d => d.code === Number(this.form.controls["documentType"].value)).value;
//     attachment.Doc_Value = this.form.controls["documentType"].value;
//     attachment.Insurance_Type = this.form.controls["insuranceType"].value;
//     attachment.Description = this.form.controls["description"].value;
//     attachment.Claim_No = this._apiService.Claim_No;
//     attachment.Attached_By = JSON.parse(localStorage.getItem('rr'))[0].UserName;
//     attachment.Attached_ON = new Date();
//     attachment.Document_Name = this.selectedFile.name;
//     attachment.file =this.selectedFile;
//     attachment.Document_ID = 0;
//     this._gv.setSelectedAttachment(attachment);
//     if (this.datatableClaimAttachments) {
//           this._chRef.detectChanges();
//           this.datatableClaimAttachments.destroy();
//         }
//     this.attachments.push(attachment);
//     this._chRef.detectChanges();
//         const table: any = $('.datatableClaimAttachments');
//         this.datatableClaimAttachments = table.DataTable({
//           columnDefs: [
//             { orderable: false, targets: -1 },
//           ],
//           order: [3, 'desc'],
//           language: {
//             emptyTable: "No data available"
//           }
//         })

//     this.uploading = false;
//     this.form.reset();
//     this.selectedFile = null;
//     this.toastr.success('File uploaded successfully.');
//     console.log("this.attachments",this.attachments)

    
//     this.filename = attachment.Document_Name;
//     this.filetype = attachment.Doc_Type;

//     formData.append("TypeCode", attachment.Doc_Type);
//     formData.append("InsuranceType", attachment.Insurance_Type);
//     formData.append("Description", attachment.Description);
//     formData.append("file", this.selectedFile);
//     formData.append("PracticeCode", this._gv.currentUser.selectedPractice.PracticeCode.toString());
//     formData.append("Claim_No", attachment.Claim_No.toString());
// }








getClaimAttachments() {
  debugger;
  if(this._apiService.Claim_No){
    this._apiService.getData(`/ClaimsAttachments/GetAll?Claim_No=${this._apiService.Claim_No}`)
      .subscribe(res => {
        const table: any = $('.datatableClaimAttachments');
        if ($.fn.dataTable.isDataTable('.datatableClaimAttachments')) {
          table.DataTable().clear().destroy();
        }
  
        this.attachments = res.Response;
        this._chRef.detectChanges();
        this.datatableClaimAttachments = table.DataTable({
          columnDefs: [
            { orderable: false, targets: -1 },
          ],
          order: [3, 'desc'],
          language: {
            emptyTable: "No data available"
          }
        });
      });
  }
  }




// getClaimAttachments() {
//   debugger
//   this._apiService.getData(`/ClaimsAttachments/GetAll?Claim_No=${this._apiService.Claim_No}`)
//      .subscribe(res => {
//         if (this.datatableClaimAttachments) {
//           this._chRef.detectChanges();
//           this.datatableClaimAttachments.destroy();
//         }
//         debugger;
//         this.attachments = res.Response;
//         debugger;
//         this._chRef.detectChanges();
//         const table: any = $('.datatableClaimAttachments');
//         this.datatableClaimAttachments = table.DataTable({
//           columnDefs: [
//             { orderable: false, targets: -1 },
//           ],
//           order: [3, 'desc'],
//           language: {
//             emptyTable: "No data available"
//           }
//         })
//       })
// }


onDelete(id: number,Document_ID:number,i:number,Document_Name:any) {
  debugger
  this._apiService.confirmFun('Confirmation','Do you want to delete this attachment?', () => {
    console.log("id",id)
    if(Document_ID !=0){
      this._apiService.getData(`/patientattachments/ClaimDelete?id=${id}&Document_ID=${Document_ID}`)
      .subscribe((res) => {
        if (res.Status === 'success') {
          this.toastr.success('Attachment has been deleted.', 'Deleted Attachment');
          //this.attachments.splice(i, 1)
          this.AddAutoNotesForDeleteAttachment(Document_Name);

          this.attachments.splice(i, 1)
          var abs=this.attachments;
           this.attachments=[];
          console.log("this.attachments delete ",this.attachments)
           if (this.datatableClaimAttachments) {
          this._chRef.detectChanges();
          this.datatableClaimAttachments.destroy();
          }
        this.attachments=abs;
         this._chRef.detectChanges();
        const table: any = $('.datatableClaimAttachments');
        this.datatableClaimAttachments = table.DataTable({
          columnDefs: [
            { orderable: false, targets: -1 },
          ],
          order: [3, 'desc'],
          language: {
            emptyTable: "No data available"
          }
        })
        } else {
          this.toastr.error('Failed to delete attachment.', 'Error');
        }
      });
    }
    else{
      
      this.attachments.splice(i, 1)
      var abs=this.attachments;
      this.attachments=[];
      console.log("this.attachments delete ",this.attachments)
      if (this.datatableClaimAttachments) {
          this._chRef.detectChanges();
          this.datatableClaimAttachments.destroy();
        }
        this.attachments=abs;
    this._chRef.detectChanges();
        const table: any = $('.datatableClaimAttachments');
        this.datatableClaimAttachments = table.DataTable({
          columnDefs: [
            { orderable: false, targets: -1 },
          ],
          order: [3, 'desc'],
          language: {
            emptyTable: "No data available"
          }
        })    
    }
  });
}




  onDownload(id:number, Document_Name: string) {
    debugger
    this._apiService.downloadFile(`/ClaimsAttachments/Download?id=${id}`)
      .subscribe({
        next: (response) => {
          debugger
          const blob = new Blob([response]);
          saveAs(blob, Document_Name);
        },
        error: (err) => {
          console.error('Download error:', err);
          this.toastr.error('Failed to download file.');
        },
        complete: () => {
          console.info('File downloaded successfully');
        }
      });
  }

  

  AddAutoNotesForDeleteAttachment(Document_Name) {
      debugger;
      if (!this.noteModel) {
        this.noteModel = new ClaimNote();
      }
    
      this.noteModel.Claim_No = this._apiService.Claim_No;
      this.noteModel.Note_Detail=Document_Name;
      //this.ClaimnoteModel.Notes_Description = `Attachment Added: File Name [${this.filename}] , Type [${this.Doc_Type}]`;
    
      this._apiService.PostData('/Demographic/DeleteClaimAttachmentNote/', this.noteModel, (d) => {
        if (d.Status === "Sucess") {
          debugger;
          this.filename = '';
          
        }
      });
    }




   getNameFromList<T>(
    list: T[],
    idValue: any,
    idKey: keyof T,
    nameKey: keyof T
  ): string {
    const item = list.find(entry => String(entry[idKey]) === String(idValue));
    return item ? String(item[nameKey]) : '';
  }
 trackById(index: number, item: ClaimAttachmentModel): number {
  return Number(item.Claim_No);
}
  getFileDisplayName() {
    if (this.selectedFile && this.selectedFile.name) {
      if (this.selectedFile.name.length > 25)
        return this.selectedFile.name.substr(0, 24);
      return this.selectedFile.name;
    }
  }

}
