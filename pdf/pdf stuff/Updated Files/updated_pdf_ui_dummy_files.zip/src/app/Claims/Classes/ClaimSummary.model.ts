export class ClaimSummaryVM {
    Claim_No: number;
    Patient_Account: number;
    DOS: Date;
    Amt_Due: number;
    Amt_Paid: number;
    Claim_Total: number;
}
