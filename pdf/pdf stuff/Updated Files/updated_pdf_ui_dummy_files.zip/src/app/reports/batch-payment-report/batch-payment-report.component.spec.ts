import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BatchPaymentReportComponent } from './batch-payment-report.component';

describe('BatchPaymentReportComponent', () => {
  let component: BatchPaymentReportComponent;
  let fixture: ComponentFixture<BatchPaymentReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BatchPaymentReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BatchPaymentReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
