import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import * as moment from 'moment';
import { IMyDpOptions } from 'mydatepicker';
import { ToastrService } from 'ngx-toastr';
import { APIService } from '../../components/services/api.service'
import { Common } from '../../services/common/common';
import * as xlsx from 'xlsx';
import * as FileSaver from 'file-saver';
import { IMyDateRangeModel, IMyDrpOptions } from 'mydaterangepicker';
import {User } from '../../user-management/classes/requestResponse';

@Component({
  selector: 'app-batch-payment-report',
  templateUrl: './batch-payment-report.component.html',
  styleUrls: ['./batch-payment-report.component.css']
})
export class BatchPaymentReportComponent implements OnInit {
BPRForm: FormGroup;
  listPracticesList: any[];
  myDateRangePickerOptions: IMyDpOptions= {
    dateFormat: 'mm/dd/yyyy', height: '25px', width: '100%'
  
};
batchPaymentReport: any[] = [];
listUser: User[];
ddlPracticeCode: number = 0;
//: boolean = false;
sortingColumn: string = '';
sortingDirection: number = 1;
count = 10;
searchTerm: string;
filteredData: any[];
fullData: any[];
searchText: string;
totalResults = 0;
totalPages = 0;
currentPage = 1;
isSearchInitiated:boolean;
filteredRecords: any;
exportdata:any;
checkPaginationCall:boolean = false;
dateRange:any
request:any;
lastReportRequest: any = null;
  constructor(public API: APIService,
      private chRef: ChangeDetectorRef,
      public toaster: ToastrService,
      private route: ActivatedRoute,) { 
         this.listUser = [];
         this.batchPaymentReport=[]
      }

async ngOnInit() {
   await this.InitializeForm();
  await this.getPractices();
  await this.getUsersList();
}
  

InitializeForm(): any {
  this.BPRForm = new FormGroup({
      practiceCode: new FormControl(null,Validators.required),
      batchStatus: new FormControl(''),   // no validator
      batchType: new FormControl(''),     // no validator
      batchCheckNO:new FormControl(''),
      dateFrom:new FormControl(null),
      dateTo:new FormControl(null),
    dateRange: new FormControl({ beginDate: null, endDate: null }),
      paymentPostedUser: new FormControl(null),
      dateCriteria : new FormControl (''),
  });
}
  onDateRangeChanged(event: IMyDateRangeModel) {
    this.BPRForm.get('dateFrom').setValue(Common.isNullOrEmpty(event.beginJsDate) ? null : moment(event.beginJsDate).format('MM/DD/YYYY'));
    this.BPRForm.get('dateTo').setValue(Common.isNullOrEmpty(event.endJsDate) ? null : moment(event.endJsDate).format('MM/DD/YYYY'));
}
  getPractices() {
    debugger;
    this.API.getData('/Setup/GetPracticeList').subscribe(
      d => {
        if (d.Status == "Sucess") {
          this.listPracticesList = d.Response;
          this.listPracticesList = this.listPracticesList.map(practice => {
            return {
                ...practice,  // Keep all existing properties
                PracticeLabel: `${practice.Id} | ${practice.Name}`  // Add new combined property
              };
             });
        }
        else {
          swal('Failed', d.Status, 'error');
        }
      })
  }
  getUsersList() 
  {
      this.API.getData('/UserManagementSetup/GetUsersList').subscribe(
      data => {
        if (data.Status === 'Success')
        {
           this.listUser = data.Response;
           let users = data.Response.map((user: any) => ({
        ...user,
        DisplayLabel: `${user.UserName} | ${user.FirstName} ${user.LastName}`
      }));
      this.listUser = [
          { UserId: null, DisplayLabel: 'Select User' }, 
          ...users
        ];
      
        }
      });
  }
  onsubmit(){

    debugger
  this.checkPaginationCall=false;
  this.batchPaymentReport=[];
  this.totalResults = 0;
  this.currentPage =1 ;
  this.totalPages=0
        this.filteredRecords = '';
    if(this.BPRForm.valid){
      this.ddlPracticeCode=this.BPRForm.value.practiceCode,
      this.getBatchPaymentReportPagination();
      this.getBatchPaymentReport();
    }
  }
  getBatchPaymentReport() {
  if(this.checkPaginationCall== true){
    debugger
//     this.BPRForm.value.batchStatus = this.lastReportRequest.Batch_Status ;
// this.BPRForm.value.batchType =  this.lastReportRequest.Batch_Type ;
// this.BPRForm.value.batchCheckNO =this.lastReportRequest.Check_No ;
// this.BPRForm.value.paymentPostedUser =this.lastReportRequest.PaymentPostedUser;
// this.BPRForm.value.dateCriteria = this.lastReportRequest.Date_Criteria  ;
// this.BPRForm.value.dateFrom = this.lastReportRequest.Date_From ;
// this.BPRForm.value.dateTo = this.lastReportRequest.Date_To ;
if ( this.lastReportRequest.Batch_Status == null) {
  this.BPRForm.patchValue({ batchStatus: "" });
}
  if(this.lastReportRequest.Batch_Type == null){
        this.BPRForm.patchValue({ batchType: "" });
  }
    if(this.lastReportRequest.Check_No == null){
      this.BPRForm.patchValue({ batchCheckNO: "" });
  }
  if(this.lastReportRequest.PaymentPostedUser == null){
       this.BPRForm.patchValue({ paymentPostedUser: "" });
  }
    if(this.lastReportRequest.Date_Criteria == null){
       this.BPRForm.patchValue({ dateCriteria: "" });
  }
  
      if(this.lastReportRequest.Date_From == null){
       this.BPRForm.patchValue({ dateRange: "" });
       this.BPRForm.patchValue({ dateFrom: null });
  }
        if(this.lastReportRequest.Date_To== null){
       this.BPRForm.patchValue({ dateRange: "" });
       this.BPRForm.patchValue({ dateTo:null });
  }
      this.request = {
  Practice_Code: this.lastReportRequest.Practice_Code ,
  Batch_Status: this.lastReportRequest.Batch_Status,
  Batch_Type:  this.lastReportRequest.Batch_Type ,
  Check_No: this.lastReportRequest.Check_No,
  PaymentPostedUser: this.lastReportRequest.PaymentPostedUser,
  Date_Criteria: this.lastReportRequest.Date_Criteria  ,
  Date_From: this.lastReportRequest.Date_From ,
  Date_To: this.lastReportRequest.Date_To,
  PageSize: this.count,
  PageNo: this.currentPage,
  IsExport: true
};
  }
  else{

    if(this.BPRForm.value.dateCriteria != null && this.BPRForm.value.dateCriteria != "" && this.BPRForm.value.dateCriteria != undefined){
           if(this.BPRForm.value.dateFrom == null){
               this.toaster.error('Please Select Date Range.')
               return;
           }
     }
          if(this.BPRForm.value.dateFrom != null && this.BPRForm.value.dateFrom != undefined){
           if(this.BPRForm.value.dateCriteria == null || this.BPRForm.value.dateCriteria == ""){
               this.toaster.error('Please select Date Criteria.')
                return;
           }
     }

  


  if (!this.BPRForm.valid) return;

  let practiceCode = this.BPRForm.value.practiceCode;
  if (typeof practiceCode === 'string' && practiceCode.includes(' | ')) {
    const practiceCodeString = practiceCode.split(' | ')[0];
    practiceCode = parseInt(practiceCodeString, 10);
  }
  if(this.BPRForm.value.batchStatus == 'ALL'){
      this.BPRForm.value.batchStatus="";
  }
this.BPRForm.value.batchStatus = this.BPRForm.value.batchStatus === "" ? null : this.BPRForm.value.batchStatus;
this.BPRForm.value.batchType = this.BPRForm.value.batchType === "" ? null : this.BPRForm.value.batchType;
this.BPRForm.value.batchCheckNO = this.BPRForm.value.batchCheckNO === "" ? null : this.BPRForm.value.batchCheckNO;
this.BPRForm.value.paymentPostedUser = this.BPRForm.value.paymentPostedUser === "" ? null : this.BPRForm.value.paymentPostedUser;
this.BPRForm.value.dateCriteria = this.BPRForm.value.dateCriteria === "" ? null : this.BPRForm.value.dateCriteria;

   this.request = {
    Practice_Code: practiceCode,
    Batch_Status: this.BPRForm.value.batchStatus,
    Batch_Type: this.BPRForm.value.batchType,
    Check_No: this.BPRForm.value.batchCheckNO,
    PaymentPostedUser: this.BPRForm.value.paymentPostedUser,
    Date_Criteria: this.BPRForm.value.dateCriteria,
    Date_From: this.BPRForm.value.dateFrom ? this.BPRForm.value.dateFrom : null,
    Date_To: this.BPRForm.value.dateTo ? this.BPRForm.value.dateTo : null,
    PageSize: this.count,
    PageNo: this.currentPage,
    IsExport: true
  };
   this.lastReportRequest = { ...this.request };


  }
       debugger

this.API.PostData('/Report/GetBatchPaymentReport', this.request, (data) => {
      if (data.Status == 'success') {
        debugger
        debugger
        debugger
          this.isSearchInitiated = true;
       
          this.exportdata = data.Response;
    console.log("Data",this.exportdata)
          // this.chRef.detectChanges();
          // const table: any = $('.dtuserReportdetials');
          // this.dtuserreportdetials = table.DataTable({
         
          //   language: {
          //     emptyTable: "No data available"
          //   },
          //   dom: this.datatableService.getDom(),
          //   buttons: this.datatableService.getExportButtons(["CPT Wise Charges Detail Report"])
          // })
        }
        
        else {
          this.toaster.warning(data.Response + ' Found Againts the Given Criteria', '');
        }
      }
    )
  }




getBatchPaymentReportPagination() {
  debugger;
  if(this.checkPaginationCall== true){
    debugger
//     this.BPRForm.value.batchStatus = this.lastReportRequest.Batch_Status ;
// this.BPRForm.value.batchType =  this.lastReportRequest.Batch_Type ;
// this.BPRForm.value.batchCheckNO =this.lastReportRequest.Check_No ;
// this.BPRForm.value.paymentPostedUser =this.lastReportRequest.PaymentPostedUser;
// this.BPRForm.value.dateCriteria = this.lastReportRequest.Date_Criteria  ;
// this.BPRForm.value.dateFrom = this.lastReportRequest.Date_From ;
// this.BPRForm.value.dateTo = this.lastReportRequest.Date_To ;
if ( this.lastReportRequest.Batch_Status == null) {
  this.BPRForm.patchValue({ batchStatus: "" });
}
  if(this.lastReportRequest.Batch_Type == null){
        this.BPRForm.patchValue({ batchType: "" });
  }
    if(this.lastReportRequest.Check_No == null){
      this.BPRForm.patchValue({ batchCheckNO: "" });
  }
  if(this.lastReportRequest.PaymentPostedUser == null){
       this.BPRForm.patchValue({ paymentPostedUser: "" });
  }
    if(this.lastReportRequest.Date_Criteria == null){
       this.BPRForm.patchValue({ dateCriteria: "" });
  }
  
      if(this.lastReportRequest.Date_From == null){
       this.BPRForm.patchValue({ dateRange: "" });
       this.BPRForm.patchValue({ dateFrom: null });
  }
        if(this.lastReportRequest.Date_To== null){
       this.BPRForm.patchValue({ dateRange: "" });
       this.BPRForm.patchValue({ dateTo:null });
  }
      this.request = {
  Practice_Code: this.lastReportRequest.Practice_Code ,
  Batch_Status: this.lastReportRequest.Batch_Status,
  Batch_Type:  this.lastReportRequest.Batch_Type ,
  Check_No: this.lastReportRequest.Check_No,
  PaymentPostedUser: this.lastReportRequest.PaymentPostedUser,
  Date_Criteria: this.lastReportRequest.Date_Criteria  ,
  Date_From: this.lastReportRequest.Date_From ,
  Date_To: this.lastReportRequest.Date_To,
  PageSize: this.count,
  PageNo: this.currentPage,
  IsExport: false
};
  }
   
  else{

    if(this.BPRForm.value.dateCriteria != null && this.BPRForm.value.dateCriteria != "" && this.BPRForm.value.dateCriteria != undefined){
           if(this.BPRForm.value.dateFrom == null){
               this.toaster.error('Please Select Date Range.')
               return;
           }
     }
          if(this.BPRForm.value.dateFrom != null && this.BPRForm.value.dateFrom != undefined){
           if(this.BPRForm.value.dateCriteria == null || this.BPRForm.value.dateCriteria == ""){
               this.toaster.error('Please select Date Criteria.')
                return;
           }
     }

  


  if (!this.BPRForm.valid) return;

  let practiceCode = this.BPRForm.value.practiceCode;
  if (typeof practiceCode === 'string' && practiceCode.includes(' | ')) {
    const practiceCodeString = practiceCode.split(' | ')[0];
    practiceCode = parseInt(practiceCodeString, 10);
  }
  if(this.BPRForm.value.batchStatus == 'ALL'){
      this.BPRForm.value.batchStatus="";
  }
this.BPRForm.value.batchStatus = this.BPRForm.value.batchStatus === "" ? null : this.BPRForm.value.batchStatus;
this.BPRForm.value.batchType = this.BPRForm.value.batchType === "" ? null : this.BPRForm.value.batchType;
this.BPRForm.value.batchCheckNO = this.BPRForm.value.batchCheckNO === "" ? null : this.BPRForm.value.batchCheckNO;
this.BPRForm.value.paymentPostedUser = this.BPRForm.value.paymentPostedUser === "" ? null : this.BPRForm.value.paymentPostedUser;
this.BPRForm.value.dateCriteria = this.BPRForm.value.dateCriteria === "" ? null : this.BPRForm.value.dateCriteria;

   this.request = {
    Practice_Code: practiceCode,
    Batch_Status: this.BPRForm.value.batchStatus,
    Batch_Type: this.BPRForm.value.batchType,
    Check_No: this.BPRForm.value.batchCheckNO,
    PaymentPostedUser: this.BPRForm.value.paymentPostedUser,
    Date_Criteria: this.BPRForm.value.dateCriteria,
    Date_From: this.BPRForm.value.dateFrom ? this.BPRForm.value.dateFrom : null,
    Date_To: this.BPRForm.value.dateTo ? this.BPRForm.value.dateTo : null,
    PageSize: this.count,
    PageNo: this.currentPage,
    IsExport: false
  };
   this.lastReportRequest = { ...this.request };


  }
       debugger
this.API.PostData('/Report/GetBatchPaymentReport', this.request, (data) => {
      if (data.Status == 'success') {
        debugger
        this.isSearchInitiated = true;
        this.batchPaymentReport = data.Response.data;
        this.totalResults = data.Response.TotalRecords;
        this.currentPage = data.Response.CurrentPage;
        this.filteredRecords = data.Response.FilteredRecords;
        this.totalPages = Math.ceil(this.totalResults / this.count);
      } else {
        this.toaster.warning(data.Response + ' Found Against the Given Criteria', '');
      }
    }
  );
}

  toggleSorting(column: string) {
    if (column === this.sortingColumn) {
      this.sortingDirection = -this.sortingDirection;
    } else {
      this.sortingColumn = column;
      this.sortingDirection = 1;
    }

    this.sortData();
  }
  
sortData() {
  this.batchPaymentReport.sort((a, b) => {
    const direction = this.sortingDirection;
    const column = this.sortingColumn;

    const valA = (a[column] === null || a[column] === undefined) ? '' : a[column];
    const valB = (b[column] === null || b[column] === undefined) ? '' : b[column];

    if (valA < valB) return -1 * direction;
    if (valA > valB) return 1 * direction;
    return 0;
  });
}

  getPages() {
    const pages = [];
    for (let i = 1; i <= this.totalPages; i++) {
      pages.push(i);
    }
    return pages;
  }

  loadPage(page: number) {
    if (page >= 1 && page <= this.totalPages) {
     
       this.checkPaginationCall=true;
      this.getBatchPaymentReportPagination();
    }
  }
  loadNextPage() {
    if (this.currentPage < this.totalPages) {

      this.currentPage= this.currentPage + 1
      this.loadPage(this.currentPage);
    }
  }

  loadPreviousPage() {
    if (this.currentPage > 1) {
      this.currentPage = this.currentPage - 1;
      this.loadPage(this.currentPage);
    }
  }
  countValueChanged(event) {
    const selectedCount = event.target.value;
    this.count = +selectedCount; // Convert the value to a number
    this.currentPage = 1; // Reset to the first page when count changes
    this.getBatchPaymentReportPagination();
  }
exportExcel() {
const modifiedData = this.exportdata.map(({ useridbycreated,useridbymodified,Modified_ByN,CreatedDate,ModifiedDate, ...rest }) => { return rest; });
    // Dynamically get all keys from the first row
    const headersKeys = Object.keys(modifiedData[0]);

    // Define which fields are currency (decimal/numeric fields)
    const currencyKeys = [
        'BatchAmt',
        'PostedAmt',
        'RemainingAmt',
        'Amt_Approved',
        'Amt_Paid',
        'Amount_Adjusted',
        'Amount_Rejected'
    ];

    // Define which fields are date fields
    const dateKeys = ['DOS', 'DOS_From', 'DOS_To', 'Batch_CheckDate', 'Date_Entry', 'Cheque_Date',];

    // Convert modified data to worksheet
    const worksheet = xlsx.utils.json_to_sheet(modifiedData);

const headerMap: { [key: string]: string } = {
  Batch_Status: 'Batch Status',
  Batch_CheckNo: 'Batch Check No',
  Batch_CheckDate: 'Batch Check Date',
  BatchAmt: 'Batch Amount',
  PostedAmt: 'Posted Amount',
  RemainingAmt: 'Remaining Amount',
  Batch_CreatedBy: 'Batch Created By',
  Batch_CreatedDate: 'Batch Created Date',
  BILLING_PHYSICIAN: 'Billing Provider',
  Amt_Approved: 'Amount Approved',
  Amt_Paid: 'Amount Paid',
  Amount_Adjusted: 'Amount Adjusted',
  Amount_Rejected: 'Amount Rejected',
  facility_name: 'Facility',
  Insurance: 'Insurance',
  Entry_PostedBy: 'Entry Posted By',

};

// Format headers: apply mapping if exists, otherwise default formatting
headersKeys.forEach((header, index) => {
  const cellRef = xlsx.utils.encode_cell({ c: index, r: 0 });
  const displayName = headerMap[header] || header.replace(/_/g, ' ').toUpperCase();
  
  worksheet[cellRef] = { 
    v: displayName, 
    t: 's', 
    s: { font: { bold: true } } 
  };
});


    // Specify column widths and format values
    worksheet['!cols'] = [];
    modifiedData.forEach((row, rowIndex) => {
        headersKeys.forEach((key, colIndex) => {
            const cellRef = xlsx.utils.encode_cell({ c: colIndex, r: rowIndex + 1 });
            const value = row[key];
            if (['Patient_Account'].includes(key)) {
            worksheet[cellRef] = { v: value ? value.toString() : '', t: 's' };
            worksheet['!cols'][colIndex] = { wch: value ? value.toString().length + 2 : 10 };
            return;
        }
            if (currencyKeys.includes(key) && typeof value === 'number') {
                // Format currency fields
                const currencyValue = `$ ${value.toFixed(2)}`;
                //worksheet[cellRef] = { v: currencyValue, t: 's' };
                worksheet[cellRef] = {
    v: value,
    t: 'n',
    z: '$#,##0.00;-$#,##0.00'   // negative format moves "-" to the front
};
                worksheet['!cols'][colIndex] = { wch: currencyValue.length + 2 };
            } else if (dateKeys.includes(key)) {
                // Format date fields as MM/DD/YYYY
                if (value) {
                    const date = new Date(value);
                    worksheet[cellRef] = {
                        v: `${('0' + (date.getMonth() + 1)).slice(-2)}/${('0' + date.getDate()).slice(-2)}/${date.getFullYear()}`,
                        t: 's'
                    };
                } else {
                    worksheet[cellRef] = { v: '', t: 's' };
                }
                worksheet['!cols'][colIndex] = { wch: 12 };
            } else if (typeof value === 'number') {
                // Other numeric fields
                worksheet[cellRef] = { v: value, t: 'n' };
                worksheet['!cols'][colIndex] = { wch: value.toString().length + 2 };
            } else {
    // Strings or text fields
    const cellValue = value !== null && value !== undefined ? value : '';
    worksheet[cellRef] = { v: cellValue, t: 's' };

    const cellWidth = cellValue ? cellValue.toString().length + 2 : 5;
    worksheet['!cols'][colIndex] = { wch: cellWidth };
}
        });
    });

    // Create workbook and write to buffer
    const workbook = { Sheets: { data: worksheet }, SheetNames: ['data'] };
    const excelBuffer: any = xlsx.write(workbook, { bookType: 'xlsx', type: 'array' });

    this.saveAsExcelFile(excelBuffer, 'Batch Payment Report');
}


saveAsExcelFile(buffer: any, fileName: string): void {
    let EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
    let EXCEL_EXTENSION = '.xlsx';
    const data: Blob = new Blob([buffer], {
        type: EXCEL_TYPE,
    });
    FileSaver.saveAs(
        data,
        fileName + EXCEL_EXTENSION
    );
}

onClear() {
  this.isSearchInitiated = false;
  this.chRef.detectChanges();
  this.ddlPracticeCode = 0;
  this.BPRForm.reset({
    practiceCode: null,
    batchStatus: '',   
    batchType: '',    
    batchCheckNO: '',
    dateFrom: null,
    dateTo: null,
    dateRange: null,
    paymentPostedUser: null,
    dateCriteria: ''
  });

  this.dateRange = { beginDate: null, endDate: null };
  this.batchPaymentReport = [];
}


}
