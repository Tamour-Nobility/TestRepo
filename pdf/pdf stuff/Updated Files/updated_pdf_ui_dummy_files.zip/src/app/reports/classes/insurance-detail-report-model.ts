export class insurancedDetailReport {
    practiceCode: number;
    practiceName:string;
}
