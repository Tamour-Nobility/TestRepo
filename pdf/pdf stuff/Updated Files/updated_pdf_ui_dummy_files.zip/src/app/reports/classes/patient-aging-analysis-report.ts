export class PatientAgingAnalysisReport{
                PATIENT_ACCOUNT:number;
                PATIENT_NAME:string;
                DATE_Of_BIRTH :string;
                ADDRESS:string;
                CITY:string;
                STATE:string;
                ZIP:number;
                PHONE:number;
                SSN:number;
                EMAIL:number;
                BALANCE:number;
                S_0_30:number;
                S_31_60:number;
                S_61_90:number;
                S_91_120:number;
                S_121_180:number;
                S_180_PLUS:number;
}
