﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NPMWorkers.Entities
{
    public class Practice
    {
        [Key]
        public long Practice_Code { get; set; }
        public string Prac_Name { get; set; }
        public string Prac_Type { get; set; }
        public string Prac_Address { get; set; }
        public string Prac_State { get; set; }
        public string PRAC_License_Number { get; set; }
        public string Prac_City { get; set; }
        public string Prac_Zip { get; set; }
        public string Prac_URL { get; set; }
        public string Prac_Phone { get; set; }
        public string Prac_Alternate_Phone { get; set; }
        public string Prac_Tax_Id { get; set; }
        public Nullable<bool> Patient_Billing { get; set; }
        public Nullable<System.DateTime> Agreement_Date { get; set; }
        public Nullable<double> Billing_Percentage { get; set; }
        public Nullable<double> Old_Billing_Percentage { get; set; }
        public Nullable<System.DateTime> Old_Billing_Percentage_From { get; set; }
        public Nullable<System.DateTime> Old_Billing_Percentage_To { get; set; }
        public Nullable<double> Client_Billing_Percentage { get; set; }
        public string Office_Manager { get; set; }
        public string Email_Address { get; set; }
        public string County { get; set; }
        public string Location_Number { get; set; }
        public Nullable<bool> Is_Active { get; set; }
        public string Mailing_Address { get; set; }
        public string Mailing_City { get; set; }
        public string Mailing_State { get; set; }
        public string Mailing_Zip { get; set; }
        public string EMR_Name { get; set; }
        public string Patient_billing_Note { get; set; }
        public Nullable<bool> Is_Patient_Billing_Authentication_Required { get; set; }
        public Nullable<bool> Noshow_Charges { get; set; }
        public string Phone_Type { get; set; }
        public Nullable<System.DateTime> Commencement_Date { get; set; }
        public Nullable<int> Company_Id { get; set; }
        public Nullable<int> Office_Id { get; set; }
        public Nullable<System.DateTime> Open_Date { get; set; }
        public string Email_Contact_Person { get; set; }
        public Nullable<long> Created_By { get; set; }
        public Nullable<System.DateTimeOffset> Created_Date { get; set; }
        public Nullable<long> Modified_By { get; set; }
        public Nullable<System.DateTimeOffset> Modified_Date { get; set; }
        public Nullable<bool> Deleted { get; set; }
        public Nullable<bool> Agreement_View { get; set; }
        public string NPI { get; set; }
        public string Invoice_Practice_Name { get; set; }
        public string Invoice_Email_Address1 { get; set; }
        public string Invoice_Email_Address2 { get; set; }
        public string Invoice_Email_Address3 { get; set; }
        public string Invoice_Prac_Address { get; set; }
        public string Invoice_Prac_State { get; set; }
        public string Invoice_Prac_City { get; set; }
        public string Invoice_Prac_Zip { get; set; }
        public string Invoice_Fax { get; set; }
        public Nullable<int> Invocie_Fax_Type { get; set; }
        public string Practice_Pat_Bill_Name { get; set; }
        public string Pat_Bill_Prac_Address { get; set; }
        public string Pat_Bill_Prac_State { get; set; }
        public string Pat_Bill_Prac_City { get; set; }
        public string Pat_Bill_Prac_Zip { get; set; }
        public string Practice_Aliases { get; set; }
        public string Prac_Phone_Ext { get; set; }
        public string Practice_Key { get; set; }
        public string Prac_Category { get; set; }
        public Nullable<decimal> Practice_Avg_Collection { get; set; }
        public Nullable<bool> Credentialing_Status { get; set; }
        public Nullable<bool> Signed_Addendum { get; set; }
        public Nullable<bool> Practice_Blocked { get; set; }
        public Nullable<System.DateTime> Block_Date { get; set; }
        public string Block_Reason { get; set; }
        public string TAXONOMY_CODE { get; set; }
        public Nullable<bool> Termination_Notice { get; set; }
        public Nullable<System.DateTime> Termination_Notice_Date { get; set; }
        public Nullable<System.DateTime> Termination_Date { get; set; }
        public Nullable<bool> Check_Bounce_Penalty { get; set; }
        public Nullable<bool> Is_Resource_Enabled { get; set; }
        public bool FTP_ENABLE { get; set; }
        public string Unblock_Reason { get; set; }
        public string practice_attention { get; set; }
        public string practice_invoicecode { get; set; }
        public byte[] FTP_Settings { get; set; }
        public Nullable<System.DateTime> Ioupolicy_Effective_Date { get; set; }
        public Nullable<bool> Iou_Policy { get; set; }
        public Nullable<System.DateTime> Upgraded_Commencement_Date { get; set; }
        public Nullable<bool> Prac_Address_Pt_Billing { get; set; }
        public string Prac_Address_Line2 { get; set; }
        public Nullable<bool> Send_Detailed_Statement { get; set; }
        public Nullable<bool> Is_Claim_Submission_Allowed { get; set; }
        public Nullable<bool> Stop_Late_Filing { get; set; }
        public Nullable<System.DateTime> Transition_Date { get; set; }
        public Nullable<decimal> Default_Provider_Rate { get; set; }
        public Nullable<bool> ICD_Status { get; set; }
        public Nullable<System.DateTime> Last_Known_Medicare_Revalidation_Date { get; set; }
        public Nullable<System.DateTime> Next_revalidation_date { get; set; }
        public Nullable<System.DateTime> Last_Known_Medicaid_Certification_Date { get; set; }
        public Nullable<System.DateTime> Next_Certification_Date { get; set; }
        public string Contact_Person_Phone { get; set; }
        public string FTP_Path { get; set; }
        public string Contact_Person_Ext { get; set; }
        public Nullable<bool> EFS { get; set; }
        public Nullable<System.DateTime> EFSDate { get; set; }
        public Nullable<bool> Is_Practice_Facility_Based { get; set; }
        public string prac_doing_business { get; set; }
        public string FTP_Path_Patient_Statements { get; set; }
        public string PAYTOADDRESS { get; set; }
        public string PAYTOCITY { get; set; }
        public string PAYTOSTATE { get; set; }
        public string PAYTOZIP { get; set; }
        public string BILLINGQUESTIONPHONE { get; set; }
    }
}
