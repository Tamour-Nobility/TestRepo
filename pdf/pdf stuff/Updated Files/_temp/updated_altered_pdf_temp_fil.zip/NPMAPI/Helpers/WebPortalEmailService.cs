﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;
using System.Web;

namespace NPMAPI.Helpers
{
    public class WebPortalEmailService
    {
        private readonly string _smtpHost;
        private readonly int _smtpPort;
        private readonly bool _enableSsl;
        private readonly string _username;
        private readonly string _password;
        private readonly string _ediAlias;
        private readonly string _crdAlias;

        public WebPortalEmailService()
        {
            _smtpHost = ConfigurationManager.AppSettings["smtp"];
            _smtpPort = Convert.ToInt32(ConfigurationManager.AppSettings["portnumber"]);
            _enableSsl = Convert.ToBoolean(ConfigurationManager.AppSettings["IsSSL"]);
            _username = ConfigurationManager.AppSettings["itnemail"];
            _password = ConfigurationManager.AppSettings["itnemailpass"];
            _ediAlias = ConfigurationManager.AppSettings["webPortalEdiAlias"];
            _crdAlias = ConfigurationManager.AppSettings["webPortalCrdAlias"];
        }

        private SmtpClient CreateSmtpClient()
        {
            return new SmtpClient
            {
                Host = _smtpHost,
                Port = _smtpPort,
                EnableSsl = _enableSsl,
                DeliveryMethod = SmtpDeliveryMethod.Network,
                UseDefaultCredentials = false,
                Credentials = new NetworkCredential(_username, _password)
            };
        }

        public void SendPortalEmailAsync(
     string emailType,
     long practiceCode,
     string insuranceName,
     string userName,
     string status,
     string practiceAliasEmail,
     string tableBody = null)
        {
            try
            {
                var fromAddress = new MailAddress(_username, "NOBILITY RCM");
                var recipients = new List<string>();

                switch (emailType.ToLower())
                {
                    case "statusupdate":
                        recipients.Add(_ediAlias);
                        recipients.Add(_crdAlias);
                        break;
                    case "passwordupdate":
                    case "reactivation":
                    case "alert":
                        if (!string.IsNullOrEmpty(practiceAliasEmail))
                            recipients.Add(practiceAliasEmail);
                        break;
                }

                if (!recipients.Any())
                    throw new Exception($"No recipients found for email type {emailType}");

                string subject = string.Empty;
                string body = string.Empty;

                switch (emailType.ToLower())
                {
                    case "statusupdate":
                        subject = $"{practiceCode} - {insuranceName} - Marked {status}";
                        body = $@"
                <html><body style='font-family:Arial,sans-serif;color:#333;'>
                <p>Hi,</p>
                <p>
                    Insurance portal of '<strong>{insuranceName}</strong>' with username '<strong>{userName}</strong>' 
                    is marked as '<strong>{status}</strong>'.
                </p>
                <p>Please take necessary action.</p>
                <p>Regards,<br/>NPM Support</p>
                </body></html>";
                        break;

                    case "passwordupdate":
                        subject = $"{practiceCode} - {insuranceName} - Password updated";
                        body = $@"
                <html><body style='font-family:Arial,sans-serif;color:#333;'>
                <p>Hi,</p>
                <p>Insurance web portal password for '<strong>{insuranceName}</strong>' (user: <strong>{userName}</strong>) 
                has been updated. Please update your saved password.</p>
                <p>Regards,<br/>NPM Support</p>
                </body></html>";
                        break;

                    case "reactivation":
                        subject = $"{practiceCode} - {insuranceName} - Marked as active";
                        body = $@"
                <html><body style='font-family:Arial,sans-serif;color:#333;'>
                <p>Hi,</p>
                <p>
                    Insurance web portal '<strong>{insuranceName}</strong>' with username '<strong>{userName}</strong>' 
                    has been reactivated and marked as <b>Active</b>.
                </p>
                <p>Regards,<br/>NPM Support</p>
                </body></html>";
                        break;

                    case "alert":
                        subject = "Web Portals Attention Required";
                        body = $@"
                <html><body style='font-family:Arial,sans-serif;'>
                <p>Hi,</p>
                <p>Mentioned web portals passwords require attention:</p>
                {tableBody}
                <br/><p>Regards,<br/><b>NPM Support</b></p>
                </body></html>";
                        break;
                }

                using (var smtp = CreateSmtpClient())
                using (var msg = new MailMessage()
                {
                    From = fromAddress,
                    IsBodyHtml = true,
                    Subject = subject,
                    Body = body
                })
                {
                    
                    foreach (var to in recipients.Distinct())
                        msg.To.Add(new MailAddress(to));

                     smtp.Send(msg);
                }

                
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Error sending {emailType} email: {ex.Message}");
               
            }
        }
    }
    }