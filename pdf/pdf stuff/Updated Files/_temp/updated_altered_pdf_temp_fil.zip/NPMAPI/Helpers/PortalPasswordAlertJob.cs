﻿using NPMAPI.Models;
using NPMAPI.Services;
using Quartz;
using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NPMAPI.Helpers
{
    public class WebPortalPasswordAlertJob : IJob
    {
        public async Task Execute(IJobExecutionContext context)
        {
            try
            {
                using (var ctx = new NPMDBEntities())
                {
                    var emailService = new WebPortalEmailService();
                    int expiryLimit = 30;
                    int alertStart = 25;
                    var today = DateTimeOffset.Now;

                    var portals = ctx.Provider_Resources
                        .Where(p => (p.Deleted == null || p.Deleted == false)
                                 && p.Status != "Locked" && p.Status != "Disabled"
                                 && p.Status != "Blocked" && p.Status != "Inactive")
                        .ToList();

                    var expiring = portals
                        .Select(p =>
                        {
                            var lastUpdateDate = p.Password_Updated_Date ?? p.Created_Date;
                            if (!lastUpdateDate.HasValue) return null;

                            var totalDays = (today - lastUpdateDate.Value).TotalDays;
                            int daysRemaining = expiryLimit - (int)totalDays;

                            return new
                            {
                                p.Practice_Code,
                                p.Insurance_Name,
                                p.URL,
                                p.User_Name,
                                DaysRemaining = daysRemaining
                            };
                        })
                        .Where(x => x != null && expiryLimit - x.DaysRemaining >= alertStart)
                        .OrderBy(x => x.DaysRemaining)
                        .ToList();

                    if (!expiring.Any()) return;

                    var groupedByPractice = expiring.GroupBy(x => x.Practice_Code);

                    foreach (var group in groupedByPractice)
                    {
                        var practiceCode = group.Key;
                        var reporting = ctx.Practice_Reporting
                            .FirstOrDefault(r => r.Practice_Code == practiceCode && (r.Deleted == null || r.Deleted == false));

                        var teamLead = ctx.Users
                                     .FirstOrDefault(u =>
                                         reporting.TeamLead_ID != null &&
                                         u.UserId != null &&
                                         u.UserId == reporting.TeamLead_ID &&
                                         (u.IsDeleted == null || u.IsDeleted == false));


                        string aliasEmail = teamLead?.Email;
                        if (string.IsNullOrEmpty(aliasEmail)) continue;

                        var rows = string.Join("", group.Select(x =>
                        {
        
                            string formattedInsurance = "";
                            if (!string.IsNullOrEmpty(x.Insurance_Name))
                            {
                                formattedInsurance = string.Join("<br/>", Enumerable
                                    .Range(0, ((x.Insurance_Name.Length + 49) / 50))
                                    .Select(i => x.Insurance_Name.Substring(i * 50, Math.Min(50, x.Insurance_Name.Length - i * 50))));
                            }

              
                            string formattedUrlText = "";
                            if (!string.IsNullOrEmpty(x.URL))
                            {
                                formattedUrlText = string.Join("<br/>", Enumerable
                                    .Range(0, ((x.URL.Length + 99) / 100))
                                    .Select(i => x.URL.Substring(i * 100, Math.Min(100, x.URL.Length - i * 100))));
                            }

                            return $@"
                            <tr style='background-color:{(x.DaysRemaining < 0 ? "#ffe5e5" : "white")};'>
                                <td style='border:1px solid #ccc;padding:2px;text-align:center;'>{x.Practice_Code}</td>
                                <td style='border:1px solid #ccc;padding:2px;text-align:center;'>{formattedInsurance}</td>
                                <td style='border:1px solid #ccc;padding:2px;text-align:center;word-break:break-all;'>
                                    <a href='{x.URL}' target='_blank'>{formattedUrlText}</a>
                                </td>
                                <td style='border:1px solid #ccc;padding:2px;text-align:center;'>{x.User_Name}</td>
                                <td style='border:1px solid #ccc;padding:2px;text-align:center;color:{(x.DaysRemaining < 0 ? "red" : "black")};'>
                                    {x.DaysRemaining}
                                </td>
                            </tr>";
                                            }));

                                            string tableBody = $@"
                        <table style='border-collapse:collapse;width:100%;font-family:Arial, sans-serif;font-size:12px;'>
                            <tr style='background-color:#f2f2f2;'>
                                <th style='border:1px solid #ccc;padding:2px;'>Practice Code</th>
                                <th style='border:1px solid #ccc;padding:2px;'>Insurance Name</th>
                                <th style='border:1px solid #ccc;padding:2px;'>Web Link</th>
                                <th style='border:1px solid #ccc;padding:2px;'>User Name</th>
                                <th style='border:1px solid #ccc;padding:2px;'>Days Remaining</th>
                            </tr>{rows}
                        </table>";




                        emailService.SendPortalEmailAsync(
                           "alert",
                           (long)practiceCode,
                           "",
                           "",
                           "",
                           aliasEmail,
                           tableBody);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error executing WebPortalPasswordAlertJob: {ex.Message}");
            }
        }
    }
}