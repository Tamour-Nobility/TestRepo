﻿using NPMAPI.App_Start;
using NPMAPI.Models;
using NPMAPI.Repositories;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web;
using System.Web.Http;

namespace NPMAPI.Controllers
{
    [RoutePrefix("ClaimsAttachments")]
    public class ClaimsAttachmentsController : BaseController
    {
        private readonly IFileHandler _fileHandler;
        private readonly IClaimsAttachments _claimsAttachments;
        //public ClaimsAttachmentsController()
        //{

        //}
        public ClaimsAttachmentsController(IFileHandler fileHandler, IClaimsAttachments iclaimsAttachments)
        {
            _fileHandler = fileHandler;
            _claimsAttachments = iclaimsAttachments;
        }


        [HttpPost]
        public IHttpActionResult Attach()
        {
            try
            {
                var request = HttpContext.Current.Request;

                // ✅ Check all expected form fields
                string typeCode = request.Form["TypeCode"];
                string insuranceType = request.Form["InsuranceType"];
                string description = request.Form["Description"];
                string Practice_Code = request.Form["PracticeCode"];
                string Claim_No = request.Form["Claim_No"];
                if (string.IsNullOrEmpty(typeCode))
                    return BadRequest("Please provide TypeCode field");

                if (request.Files.Count == 0)
                    return BadRequest("No file uploaded.");

                var file = request.Files["file"];
                if (file == null || file.ContentLength == 0)
                    return BadRequest("Uploaded file is empty.");

                string fileNewName = $"{(Int32)(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalSeconds}_{Guid.NewGuid()}";

                string savePath = HttpContext.Current.Server.MapPath($"~/{ConfigurationManager.AppSettings["ClaimAttachments"]}/{fileNewName}");

                var allowedExtensions = new[] {
                ".jpg",".png",".jpeg",
                ".docx",".pdf",".txt"
                };

                var fileUploadResponse = _fileHandler.UploadImage(
                    file,
                    savePath,
                    allowedExtensions,
                    fileNewName,
                    GlobalVariables.MaximumClaimsAttachmentsSize);

                if (fileUploadResponse.Status == "success")
                {
                    var attachmentResponse = _claimsAttachments.AttachemntSave(new ClaimAttachmentRequest
                    {
                        Doc_Type = typeCode,
                        Document_Name = file.FileName,
                        FilePath = fileUploadResponse.Response,
                        InsuranceType = insuranceType,
                        Description = description,
                        Practice_Code = Practice_Code,
                        Claim_No = Claim_No,
                    }, GetUserId());

                    return Ok(attachmentResponse);
                }
                else
                {
                    return Ok(fileUploadResponse);
                }
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }

        [HttpGet]
        public IHttpActionResult GetAll(long Claim_No)
        {
            return Ok(_claimsAttachments.GetAllClaimAttachemnt(Claim_No));
        }

        [HttpGet]
        public ResponseModel GetAttachmentCodeList()
        {
            return _claimsAttachments.GetAttachmentTypeCodesList();
        }

        [HttpGet]
        public HttpResponseMessage Download(long id)
        {
            HttpResponseMessage response = Request.CreateResponse(HttpStatusCode.OK);
            var fileInfo = _claimsAttachments.GetAttachemnt(id);
            string filePath;
            if (fileInfo.Status == "success" && fileInfo != null)
            {
                filePath = HttpContext.Current.Server.MapPath($"~/{ConfigurationManager.AppSettings["ClaimAttachments"] + "/" + fileInfo.Response.FilePath}");
                if (!File.Exists(filePath))
                {
                    response.StatusCode = HttpStatusCode.NotFound;
                    response.ReasonPhrase = string.Format("File not found: {0} .", fileInfo.Response.Document_Name);
                    return response;
                }
                byte[] bytes = File.ReadAllBytes(filePath);
                response.Content = new ByteArrayContent(bytes);
                response.Content.Headers.ContentLength = bytes.LongLength;
                response.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment");
                response.Content.Headers.ContentDisposition.FileName = fileInfo.Response.Document_Name;
                response.Content.Headers.ContentType = new MediaTypeHeaderValue(MimeMapping.GetMimeMapping(fileInfo.Response.Document_Name));
                return response;
            }
            else
            {
                response.StatusCode = HttpStatusCode.NotFound;
                response.ReasonPhrase = string.Format("File not found: {0} .", fileInfo.Response.Document_Name);
                return response;
            }
        }



    }
}
