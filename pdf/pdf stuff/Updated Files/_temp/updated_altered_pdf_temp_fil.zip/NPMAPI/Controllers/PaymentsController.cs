﻿using System;
using System.Collections.Generic;
using System.Web.Http;
using NPMAPI.Models;
using NPMAPI.Models.ViewModels;
using NPMAPI.Repositories;

namespace NPMAPI.Controllers
{
    public class PaymentsController : BaseController
    {
        private readonly IPaymentsRepository _paymentsService;

        public PaymentsController(IPaymentsRepository paymentsService)
        {
            _paymentsService = paymentsService;
        }


        [HttpPost]
        public ResponseModel SearchPayment(PaymentsSearchRequestModel request)
        {

            return _paymentsService.SearchPayment(request);

        }

        [HttpPost]
        public ResponseModel AddInsurancePayment([FromBody] InsurancePaymentViewModel request)
        {
            if (ModelState.IsValid)
                return _paymentsService.AddInsurancePayment(request);
            else
                return new ResponseModel
                {
                    Status = "Error",
                    Response = "Validation"
                };
        }

        [HttpPost]
        public ResponseModel AddPatientPayment([FromBody] PatientPayment request)
        {
            if (ModelState.IsValid)
                return _paymentsService.AddPatientPayment(request);
            else
                return new ResponseModel
                {
                    Status = "Error",
                    Response = "Validation"
                };
        }

        public List<SelectListViewModel> GetPaymentList()
        {
            return _paymentsService.GetPaymentList();
        }

        [HttpGet]
        public ResponseModel GetClaimsSummary(string ClaimId, string practiceCode)
        {

            return _paymentsService.GetClaimsSummary(ClaimId, practiceCode);

        }

        [HttpPost]
        public ResponseModel GetClaimBypatient(patientBasedClaimModel request)
        {

            return _paymentsService.GetClaimBypatientdetials(request);

        }

        [HttpPost]
        public ResponseModel GetClaimByins(insBasedClaimModel request)
        {

            return _paymentsService.GetClaimByinsdetials(request);

        }


        [HttpPost]
        public ResponseModel PostClaims(postClaim request)
        {

            return _paymentsService.PostClaims(request);

        }

        [HttpGet]
        public ResponseModel getClaimsDetails(long claimNo, long patientaccount)
        {

            return _paymentsService.getClaimsDetails(claimNo, patientaccount);

        }

        [HttpPost]
        public ResponseModel SaveClaimsDetails(ClaimsPaymentDetailModel[] cpd)
        {

            return _paymentsService.SaveClaimsDetails(cpd);

        }

        [HttpGet]
        public ResponseModel checkPostedClaims(long batchno, long practiceCode)
        {

            return _paymentsService.checkPostedClaims(batchno, practiceCode);

        }


        //payment posting batch wise - Pir Ubaid

        [HttpPost]
        public ResponseModel CreateUpdateBatch([FromBody] BatchCreateModel batchData)
        {
            return _paymentsService.CreateUpdateBatch(batchData, GetUserId());
        }


        [HttpPost]
        public ResponseModel SearchBatch(BatchsSearchRequestModel request)
       {

            return _paymentsService.SearchBatch(request);

        }

        //close batch
        [HttpPost]
        public ResponseModel CloseBatch([FromBody] BatchsSearchRequestModel request)
        {
 
            return _paymentsService.CloseBatch(request);


        }

        //get patients
        [HttpGet]
        public ResponseModel GetPatientsWithDue(bool isDueOnly, int practiceCode)
        {
            
            return _paymentsService.GetPatientsWithDue(isDueOnly, practiceCode);

        }
        [HttpGet]
        public ResponseModel GetPatientsClaims(long patient_account, bool due_only)
        {
           
            return _paymentsService.GetPatientsClaims(patient_account,due_only);

        }

        [HttpGet]
            public ResponseModel GetClaimDetails(long claimID)
        {
           
            return _paymentsService.GetClaimDetails(claimID);

        }
        [HttpGet]
        public ResponseModel GetClaimDetailsByClaimNumber(long claimID, int practiceCode)
        {
           
            return _paymentsService.GetClaimDetailsByClaimNumber(claimID, practiceCode);

        }

        [HttpGet]
        public ResponseModel GetPostedClaims(string batchID)
        {
           
            return _paymentsService.GetPostedClaims(batchID);

        }


        //post payment

        [HttpPost]
        public ResponseModel PostPayments(ClaimsViewModel ClaimModel,long batchID,string batchDate)
        {

            return _paymentsService.PostPayments(ClaimModel,batchID,batchDate);

        }

        [HttpGet]
        public ResponseModel GetBatchPaymentSummary(string batchID)
        {

            return _paymentsService.GetBatchPaymentSummary(batchID);

        }
        [HttpGet]
        public ResponseModel GetBatchType(long batchID)
        {

            return _paymentsService.GetBatchType(batchID);

        }
        [HttpGet]
        public ResponseModel GetBatchCheckDetail(long batchID)
        {

            return _paymentsService.GetBatchCheckDetail(batchID);

        }
        [HttpGet]
        public ResponseModel DeleteClaimPayment(string batchID, long claimNo, string Amtdue)
               {

            return _paymentsService.DeleteClaimPayment(batchID, claimNo, Amtdue, GetUserId());

        }


        [HttpPost]
        public ResponseModel AutoCloseEligibleBatches()
        {

            return _paymentsService.AutoCloseEligibleBatches();

        }

        [HttpPost]
        public ResponseModel ReopenBatch(long BatchId)
        {
            return _paymentsService.ReopenBatch(BatchId, GetUserId());
        }

        [HttpGet]
        public ResponseModel GetBatchDate(long batchID)
        {

            return _paymentsService.GetBatchDate(batchID);

        }
        [HttpGet]
        public ResponseModel ValidateCheckNo(string CheckNo, long Practice_Code, DateTime BatchOpenDate, string PaymentType, long? BatchID = null)
        {
            return _paymentsService.ValidateCheckNo( CheckNo,Practice_Code,BatchOpenDate, PaymentType,BatchID);
        }
        [HttpPost]
        public ResponseModel CheckIfBatchHasPayments(long batchID)
        {
            return _paymentsService.CheckIfBatchHasPayments(batchID);
        }

        [HttpGet]
        public ResponseModel GetCurrentResponsible(long claimId)
        {

            return _paymentsService.GetCurrentResponsible(claimId);

        }
        [HttpGet]
        public ResponseModel GetBatchPayments(long claimId)
        {
            return _paymentsService.GetBatchPayments(claimId);
        }

        [HttpGet]
        public ResponseModel GetPayments(long claimId)
        {
            return _paymentsService.GetPayments(claimId);
        }
        [HttpGet]
        public ResponseModel GetBatchChequeNoAndDate(long batchID)
        {
            return _paymentsService.GetBatchChequeNoAndDate(batchID);
        }



    }
}
