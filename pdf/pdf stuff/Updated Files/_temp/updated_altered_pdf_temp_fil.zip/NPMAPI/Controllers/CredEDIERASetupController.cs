﻿using NPMAPI.App_Start;
using NPMAPI.Models;
using NPMAPI.Models.ViewModels;
using NPMAPI.Repositories;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace NPMAPI.Controllers
{
    public class CredEDIERASetupController : BaseController
    {
        private readonly ICredEDIERASetupRepository _credEDIERASetupService;
        private readonly IFileHandler _fileHandler;
        public CredEDIERASetupController(ICredEDIERASetupRepository credEDIERASetupService, IFileHandler fileHandler)
        {
            _credEDIERASetupService = credEDIERASetupService;
            _fileHandler = fileHandler;
        }
        [HttpGet]
        public ResponseModel GetLookupLists()
        {
            return _credEDIERASetupService.GetLookupLists();
        }
        [HttpPost]
        public ResponseModel AddEditCredApp(EDI_ERA_Setup cred_App_ViewModel)
        {
            return _credEDIERASetupService.AddEditCredEDIERASetup(cred_App_ViewModel, GetUserId());
        }
        [HttpGet]
        public ResponseModel GetCredEDIERASetupById(long id)
        {
            return _credEDIERASetupService.GetCredEDIERASetupById(id);
        }
        [HttpPost]
        public ResponseModel AddEditCred_EDIERA_Note(EDI_ERA_Notes eDI_ERA_Notes)
        {
            return _credEDIERASetupService.AddEditCred_EDIERA_Notes(eDI_ERA_Notes, GetUserId());
        }
        [HttpPost]
        public ResponseModel SearchCredEDIERASetup(EdiEraSetupSearchViewModel searchViewModel)
        {
            return _credEDIERASetupService.SearchCredEDIERASetup(searchViewModel);
        }
        [HttpGet]
        public ResponseModel GetCred_EDIERA_Notes(long application_Id)
        {
            return _credEDIERASetupService.GetCred_EDIERA_Notes(application_Id);
        }
        #region  Upload Credentialing Document
        [HttpPost]
        public IHttpActionResult UploadCred_EDIERA_Document()
        {
            try
            {


                string appId = HttpContext.Current.Request.Form["ApplicationId"];
                string docTypeId = HttpContext.Current.Request.Form["DocTypeId"];
                if (string.IsNullOrEmpty(appId))
                    return BadRequest("Please provide ApplicationId field");
                if (string.IsNullOrEmpty(docTypeId))
                    return BadRequest("Please provide DocTypeId field");

                string fileNewName = $"{(Int32)(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalSeconds}{Guid.NewGuid().ToString()}";

                string savePath = System.Web.HttpContext.Current.Server.MapPath(
                    $"~/{ConfigurationManager.AppSettings["CredEdiEraAppDocumentsPath"]}/{fileNewName}"
                );

                var uploadResponse = _fileHandler.UploadImage(
                      HttpContext.Current.Request.Files[0],
                    savePath,
                    new string[] {
                        ".jpg",".jpeg",".png",".gif",".jfif",
                        ".doc",".docx",".csv",".pdf",".xls",".xlsx",".txt"
                    },
                    fileNewName,
                    GlobalVariables.MaximumCredentialingDocumentSize
                );

                if (uploadResponse.Status != "success")
                    return Ok(uploadResponse);

                // Save metadata in database
                var saveResponse = _credEDIERASetupService.SaveCred_EDIERA_Document(new CredAppDocumentRequest()
                {
                    Application_Id = Convert.ToInt64(appId),
                    DocumentType_Id = Convert.ToInt32(docTypeId),
                    FileName = HttpContext.Current.Request.Files[0].FileName,
                    FilePath = uploadResponse.Response,


                    UploadedBy = GetUserId()
                });

                return Ok(saveResponse);
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion


        #region  Get documents by application id
        [HttpGet]
        public ResponseModel GetCred_EDIERA_Documents(long applicationId)
        {
            return _credEDIERASetupService.GetCred_EDIERA_Documents(applicationId);
        }
        #endregion


        #region  Get file by filename
        [HttpGet]
        public IHttpActionResult GetCred_EDIERA_DocumentById(long docId)
        {
            try
            {
                if (docId <= 0)
                    return BadRequest("Invalid document ID");

                // Get file name from DB
                var doc = _credEDIERASetupService.GetCred_EDIERA_DocumentByDocId(docId);
                if (doc == null || string.IsNullOrEmpty(doc.Response.Attachment_Path))
                    return NotFound();

                string folder = ConfigurationManager.AppSettings["CredEdiEraAppDocumentsPath"];
                string filePath = System.Web.HttpContext.Current.Server.MapPath($"~/{folder}/{doc.Response.Attachment_Path}");


                if (!File.Exists(filePath))
                    return NotFound();

                byte[] fileBytes = File.ReadAllBytes(filePath);
                string mimeType = MimeMapping.GetMimeMapping(filePath);

                HttpResponseMessage response = new HttpResponseMessage(HttpStatusCode.OK)
                {
                    Content = new ByteArrayContent(fileBytes)
                };
                response.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue(mimeType);
                response.Content.Headers.ContentDisposition =
                    new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment")
                    {
                        FileName = doc.Response.Attachment_Name
                    };

                return ResponseMessage(response);
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }

        [HttpGet]
        public ResponseModel DeleteCred_EDIERA_Document(long documentId)
        {
            return _credEDIERASetupService.DeleteCred_EDIERA_Document(documentId);
        }

        #endregion

        [HttpPost]
        public ResponseModel AddTPAName(TPA_Name_List tPA_Name_List)
        {
            return _credEDIERASetupService.AddTPAName(tPA_Name_List);
        }

    }
}
