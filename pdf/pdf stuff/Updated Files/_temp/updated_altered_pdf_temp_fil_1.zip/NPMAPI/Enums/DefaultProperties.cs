﻿namespace NPMAPI.Enums
{
    public enum DefaultProperties
    {
        Add,
        Edit,
        Update,
        Delete
    }
}