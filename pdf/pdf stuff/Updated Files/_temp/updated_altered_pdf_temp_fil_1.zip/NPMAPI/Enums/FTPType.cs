﻿namespace NPMAPI.Enums
{
    public enum FTPType
    {
        EDI,
        PatientStatement
    }
}