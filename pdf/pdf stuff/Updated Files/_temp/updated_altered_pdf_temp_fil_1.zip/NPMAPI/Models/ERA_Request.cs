﻿
namespace NPMAPI.Models
{
    public class ERA_Request
    {
        public long UserID { get; set; }

        public string UserName { get; set; }

        public long PracticeCde { get; set; }
    }
}