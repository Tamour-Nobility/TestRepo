﻿namespace NPMAPI.Models
{
    public partial class Claim
    {
        public string Facility_Name { get; set; }
    }
}