﻿using System.Collections.Generic;

namespace NPMAPI.Models
{
    public partial class Claim_Charges
    {
        public List<SelectListViewModel> NDCCodeList { get; set; }
    }
}