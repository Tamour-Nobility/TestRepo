﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NPMAPI.Models
{
    public partial class Claim_Charges
    {
        //public List<SelectListViewModel> NDCCodeList { get; set; }
    }
}