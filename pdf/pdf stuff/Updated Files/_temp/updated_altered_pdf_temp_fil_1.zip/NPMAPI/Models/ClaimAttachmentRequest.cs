﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using System.Text;

namespace NPMAPI.Models
{
    public class ClaimAttachmentRequest
    {
        [Required]
        public string Doc_Type { get; set; }
        [Required]
        public string Claim_No { get; set; }

        [Required]
        public string Document_Name { get; set; }

        [Required]
        public string FilePath { get; set; }

        [Required]
        public int Document_ID { get; set; }

        [Required]
        public string InsuranceType { get; set; }

        [Required]
        public string Description { get; set; }

        [Required]
        public string Practice_Code { get; set; } // <-- Added
    }
}