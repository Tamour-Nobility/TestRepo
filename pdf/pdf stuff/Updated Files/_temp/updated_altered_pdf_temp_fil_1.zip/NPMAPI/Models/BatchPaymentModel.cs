﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NPMAPI.Models
{
    public class BatchPaymentModel
    {
        public int Practice_Code { get; set; }

        private string _batchStatus;
        public string Batch_Status
        {
            get => string.IsNullOrWhiteSpace(_batchStatus) ? null : _batchStatus;
            set => _batchStatus = string.IsNullOrWhiteSpace(value) ? null : value;
        }

        private string _batchType;
        public string Batch_Type
        {
            get => string.IsNullOrWhiteSpace(_batchType) ? null : _batchType;
            set => _batchType = string.IsNullOrWhiteSpace(value) ? null : value;
        }

        private string _checkNo;
        public string Check_No
        {
            get => string.IsNullOrWhiteSpace(_checkNo) ? null : _checkNo;
            set => _checkNo = string.IsNullOrWhiteSpace(value) ? null : value;
        }

        private string _paymentPostedUser;
        public string PaymentPostedUser
        {
            get => string.IsNullOrWhiteSpace(_paymentPostedUser) ? null : _paymentPostedUser;
            set => _paymentPostedUser = string.IsNullOrWhiteSpace(value) ? null : value;
        }

        private string _dateCriteria;
        public string Date_Criteria
        {
            get => string.IsNullOrWhiteSpace(_dateCriteria) ? null : _dateCriteria;
            set => _dateCriteria = string.IsNullOrWhiteSpace(value) ? null : value;
        }

        public DateTime? Date_From { get; set; }
        public DateTime? Date_To { get; set; }

        public int PageSize { get; set; }
        public int PageNo { get; set; }
        public Boolean IsExport { get; set; }

    }
}