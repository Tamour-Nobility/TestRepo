﻿namespace NPMAPI.Controllers
{
    public interface IActionResult<T>
    {
    }
}