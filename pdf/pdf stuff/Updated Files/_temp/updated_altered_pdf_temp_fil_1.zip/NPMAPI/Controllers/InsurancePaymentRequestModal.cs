﻿namespace NPMAPI.Controllers
{
    public class InsurancePaymentRequestModal
    {
    }
}