﻿
using NPMAPI.App_Start;
using NPMAPI.Models;
using NPMAPI.Models.ViewModels;
using NPMAPI.Repositories;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using HttpContext = System.Web.HttpContext;

namespace NPMAPI.Controllers
{
    public class CredentialingController : BaseController
    {
        private readonly ICredentialingRepository _credentialingService;
        private readonly IFileHandler _fileHandler;
        private readonly IPracticeRepository _practiceService;
        public CredentialingController(ICredentialingRepository credentialingService, IFileHandler fileHandler, IPracticeRepository practiceService)
        {
            _credentialingService = credentialingService;
            _fileHandler = fileHandler;
            _practiceService = practiceService;
        }

        [HttpGet]
        public ResponseModel GetLookupLists()
        {
            return _credentialingService.GetLookupLists();
        }
        [HttpPost]
        public ResponseModel AddEditCredApp(Cred_App_ViewModel cred_App_ViewModel)
        {
            return _credentialingService.AddEditCredApp(cred_App_ViewModel, GetUserId());
        }
        [HttpPost]
        public ResponseModel SearchCredApp(CredAppSearchViewModel searchViewModel)
        {
            return _credentialingService.SearchCredApp(searchViewModel);
        }
        [HttpGet]
        public ResponseModel GetCredAppById(long Id)
        {
            return _credentialingService.GetCredAppById(Id);

        }
        [HttpPost]
        public ResponseModel AddEditCredAppNote(Cred_App_Notes cred_App_Notes)
        {
            return _credentialingService.AddEditCredAppNote(cred_App_Notes, GetUserId());
        }
        [HttpGet]
        public ResponseModel GetCredAppNotes(long application_Id)
        {
            return _credentialingService.GetCredAppNotes(application_Id);
        }
        #region  Upload Credentialing Document
        [HttpPost]
        public IHttpActionResult UploadCredAppDocument()
        {
            try
            {


                string appId = HttpContext.Current.Request.Form["ApplicationId"];
                string docTypeId = HttpContext.Current.Request.Form["DocTypeId"];
                if (string.IsNullOrEmpty(appId))
                    return BadRequest("Please provide ApplicationId field");
                if (string.IsNullOrEmpty(docTypeId))
                    return BadRequest("Please provide DocTypeId field");

                string fileNewName = $"{(Int32)(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalSeconds}{Guid.NewGuid().ToString()}";

                string savePath = System.Web.HttpContext.Current.Server.MapPath(
                    $"~/{ConfigurationManager.AppSettings["CredAppDocumentsPath"]}/{fileNewName}"
                );

                var uploadResponse = _fileHandler.UploadImage(
                      HttpContext.Current.Request.Files[0],
                    savePath,
                    new string[] {
                        ".jpg",".jpeg",".png",".gif",".jfif",
                        ".doc",".docx",".csv",".pdf",".xls",".xlsx",".txt"
                    },
                    fileNewName,
                    GlobalVariables.MaximumCredentialingDocumentSize
                );

                if (uploadResponse.Status != "success")
                    return Ok(uploadResponse);

                // Save metadata in database
                var saveResponse = _credentialingService.SaveCredAppDocument(new CredAppDocumentRequest()
                {
                    Application_Id = Convert.ToInt64(appId),
                    DocumentType_Id = Convert.ToInt32(docTypeId),
                    FileName = HttpContext.Current.Request.Files[0].FileName,
                    FilePath = uploadResponse.Response,


                    UploadedBy = GetUserId()
                });

                return Ok(saveResponse);
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion


        #region  Get documents by application id
        [HttpGet]
        public ResponseModel GetCredAppDocuments(long applicationId)
        {
            return _credentialingService.GetCredAppDocuments(applicationId);
        }
        #endregion


        #region  Get file by filename
        [HttpGet]
        public IHttpActionResult GetCredAppDocumentById(long docId)
        {
            try
            {
                if (docId <= 0)
                    return BadRequest("Invalid document ID");

                // Get file name from DB
                var doc = _credentialingService.GetCredAppDocumentByDocId(docId);
                if (doc == null || string.IsNullOrEmpty(doc.Response.Attachment_Path))
                    return NotFound();

                string folder = ConfigurationManager.AppSettings["CredAppDocumentsPath"];
                string filePath = System.Web.HttpContext.Current.Server.MapPath($"~/{folder}/{doc.Response.Attachment_Path}");


                if (!File.Exists(filePath))
                    return NotFound();

                byte[] fileBytes = File.ReadAllBytes(filePath);
                string mimeType = MimeMapping.GetMimeMapping(filePath);

                HttpResponseMessage response = new HttpResponseMessage(HttpStatusCode.OK)
                {
                    Content = new ByteArrayContent(fileBytes)
                };
                response.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue(mimeType);
                response.Content.Headers.ContentDisposition =
                    new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment")
                    {
                        FileName = doc.Response.Attachment
                    };

                return ResponseMessage(response);
            }
            catch (Exception ex)
            {
                return InternalServerError(ex);
            }
        }

        [HttpGet]
        public ResponseModel DeleteCredAppDocument(long documentId)
        {
            return _credentialingService.DeleteCredAppDocument(documentId);
        }

        #endregion

        [HttpGet]
        public ResponseModel GetUsersByModuleName(string moduleName)
        {
            return _credentialingService.GetUsersByModuleName(moduleName);

        }

        [HttpGet]
        public ResponseModel GetActivePractices()
        {
            return _practiceService.GetActivePractices();
        }
        [HttpGet]
        public ResponseModel GetCredAppReport(long practiceCode, int? ObjTypeId)
        {
            return _credentialingService.CredAppReport(practiceCode, ObjTypeId);
        }
        [HttpGet]
        public ResponseModel GetCredTasks(long? PracticeCode, long? UserId, int? Obj_Type_Id)
        {
            return _credentialingService.GetCredTasks(PracticeCode, UserId, Obj_Type_Id);
        }
        [HttpGet]
        public ResponseModel GetCredUserByRole(string Role)
        {
            return _credentialingService.GetUserByRole(Role, GetUserId());
        }

        [HttpGet]
        public ResponseModel GetCredUserListByRole(string Role,long practiceId)
        {
            return _credentialingService.GetUserListByRole(Role, practiceId);
        }
    }
}
