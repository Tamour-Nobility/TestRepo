﻿using Quartz;
using Quartz.Impl;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace NPMAPI.Helpers
{


    public static class SchedulerHelper
    {
        public static async Task StartQuartzJobAsync()
        {
            try
            {
                int hour = int.Parse(ConfigurationManager.AppSettings["QuartzJobHour"] ?? "10");
                int minute = int.Parse(ConfigurationManager.AppSettings["QuartzJobMinute"] ?? "45");

                IScheduler scheduler = await StdSchedulerFactory.GetDefaultScheduler();
                await scheduler.Start();

                IJobDetail job = JobBuilder.Create<WebPortalPasswordAlertJob>()
                    .WithIdentity("WebPortalAlertJob", "Maintenance")
                    .Build();

                ITrigger trigger = TriggerBuilder.Create()
                    .WithIdentity("DailyWebPortalAlertTrigger", "Maintenance")
                    .WithSchedule(CronScheduleBuilder.DailyAtHourAndMinute(hour, minute))
                    .Build();

                await scheduler.ScheduleJob(job, trigger);
            }
            catch (Exception ex)
            {
                throw new Exception("Error starting Quartz Job Scheduler", ex);
            }
        }
    }
}