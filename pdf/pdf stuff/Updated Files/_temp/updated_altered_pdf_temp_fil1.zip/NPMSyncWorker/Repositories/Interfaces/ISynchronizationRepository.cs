﻿using NPMSyncWorker.Entities;

namespace NPMSyncWorker.Repositories.Interfaces
{
    internal interface ISynchronizationRepository : IRepositoryBase<PracticeSynchronization>
    {

    }
}
