﻿namespace NPMSyncWorker.Enums
{
    internal enum eGender : int
    {
        Male = 1,
        Female = 2,
        Other = 3
    }
}
