﻿namespace NPMSyncWorker.Entities
{
    internal class Provider
    {
        public string Provid_FName { get; set; }
        public string Provid_LName { get; set; }
        public string Provid_Middle_Name { get; set; }
        public string Email_Address { get; set; }
        public string NPI { get; set; }
        public string Provider_Code { get; set; }
    }
}
