﻿namespace NPMSyncWorker.Entities
{
    internal class PracticeLocations
    {

    }
}
