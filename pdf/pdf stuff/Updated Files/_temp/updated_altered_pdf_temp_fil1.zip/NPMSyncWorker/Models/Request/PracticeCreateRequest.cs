﻿namespace NPMSyncWorker.Models.Request
{
    internal class PracticeCreateRequest
    {
       public PracticesAttribute practicesAttribute { get; set; }
    }
}
