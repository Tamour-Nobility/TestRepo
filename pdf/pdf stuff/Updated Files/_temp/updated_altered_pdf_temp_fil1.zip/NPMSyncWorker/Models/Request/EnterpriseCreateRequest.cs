﻿namespace NPMSyncWorker.Models.Request
{
    internal class EnterpriseCreateRequest
    {
        public Enterprise enterprise { get; set; }
    }
}
