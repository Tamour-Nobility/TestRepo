﻿namespace NPMSyncWorker.Models.Request
{
    internal class ProviderCreateRequest
    {
        public Doctor doctor { get; set; }
    }
}
