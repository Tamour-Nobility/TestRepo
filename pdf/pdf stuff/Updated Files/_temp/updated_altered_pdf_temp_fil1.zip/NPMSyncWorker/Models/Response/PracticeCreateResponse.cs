﻿namespace NPMSyncWorker.Models.Response
{
    internal class PracticeCreateResponse : BaseResponse
    {
    }
}
