﻿namespace NPMSyncWorker.Models
{
    internal class ExternalId
    {
        public int id { get; set; }
        public string issuer { get; set; }
        public string external_id { get; set; }
    }
}
