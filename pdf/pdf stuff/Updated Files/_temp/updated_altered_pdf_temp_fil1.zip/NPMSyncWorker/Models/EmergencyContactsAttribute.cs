﻿namespace NPMSyncWorker.Models
{
    internal class EmergencyContactsAttribute
    {
        public string first_name { get; set; }
        public string last_name { get; set; }
        public string cell_phone { get; set; }
        public string secondary_phone { get; set; }
        public string relationship { get; set; }
    }
}
