﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NPMAPI.Models
{
    public class BatchPaymentResponse
    {
        public long Batch_ID { get; set; }
        public string Batch_Type { get; set; }
        public string BatchStatus { get; set; }
        public string File_Name { get; set; }
        public string Batch_Payment_Type { get; set; }
        public string Batch_CheckNo { get; set; }
        public Nullable<System.DateTimeOffset> Batch_CheckDate { get; set; }
        public decimal BatchAmt { get; set; }
        public Nullable<decimal> PostedAmt { get; set; }
        public Nullable<decimal> RemainingAmt { get; set; }
        public Nullable<long> Batch_CreatedBy { get; set; }
        public Nullable<System.DateTime> Batch_CreatedDate { get; set; }
        public Nullable<long> Claim_No { get; set; }
        public Nullable<System.DateTime> DOS { get; set; }
        public string PATIENT_NAME { get; set; }
        public Nullable<long> Patient_Account { get; set; }
        public string BILLING_PHYSICIAN { get; set; }
        public Nullable<System.DateTimeOffset> Date_Entry { get; set; }
        public Nullable<decimal> Amt_Approved { get; set; }
        public Nullable<decimal> Amt_Paid { get; set; }
        public Nullable<decimal> Amount_Adjusted { get; set; }
        public Nullable<decimal> Amount_Rejected { get; set; }
        public string Payment_Source { get; set; }
        public string Payment_Type { get; set; }
        public Nullable<System.DateTime> Cheque_Date { get; set; }
        public string Cheque_No { get; set; }
        public string CPT { get; set; }
        public Nullable<System.DateTime> DOS_From { get; set; }
        public Nullable<System.DateTime> DOS_To { get; set; }
        public string facility_name { get; set; }
        public string Location_Name { get; set; }
        public string Insurance_Name { get; set; }
        public string Entry_PostedBy { get; set; }
    }
}