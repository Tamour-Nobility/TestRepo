﻿namespace NPMAPI.Models
{
    public partial class PatientInsuranceViewModel
    {
        public string SubscriberName { get; set; }
        public System.Nullable<bool> IS_Active { get; set; }

    }
}