﻿using NPMAPI.Models.InboxHealth;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NPMAPI.Models
{
    public class DeleteInvoiceResponse:BaseResponse
    {
    }
}