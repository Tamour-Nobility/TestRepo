﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NPMAPI.Models
{
    public class PhysicianSearchModel
    {
        public long Referral_Code { get; set; }
        public string Referral_Lname { get; set; }

        public string Referral_Fname { get; set; }

        public string Referral_City { get; set; }

        public string Referral_State { get; set; }

        public string Referral_Zip { get; set; }

        public string NPI { get; set; }

    }
}