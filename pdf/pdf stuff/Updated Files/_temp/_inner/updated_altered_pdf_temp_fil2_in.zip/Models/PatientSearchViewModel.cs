﻿namespace NPMAPI.Models
{
    public class PatientSearchViewModel
    {
    }
}