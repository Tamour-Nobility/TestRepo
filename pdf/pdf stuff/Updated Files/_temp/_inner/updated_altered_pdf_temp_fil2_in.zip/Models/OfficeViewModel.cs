﻿namespace NPMAPI.Models
{
    public class OfficeViewModel
    {
        public long OfficeId { get; set; }
        public long CompanyId { get; set; }
        public string OfficeName { get; set; }
        public string Address { get; set; }
        public string PhoneNo { get; set; }
    }
}