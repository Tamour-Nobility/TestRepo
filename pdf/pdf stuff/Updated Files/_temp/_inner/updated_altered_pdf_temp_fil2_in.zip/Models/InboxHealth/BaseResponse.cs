﻿namespace NPMAPI.Models.InboxHealth
{
    public class BaseResponse
    {
        public bool IsSuccessful { get; set; }
        public string ErrorMessage { get; set; }
    }
}