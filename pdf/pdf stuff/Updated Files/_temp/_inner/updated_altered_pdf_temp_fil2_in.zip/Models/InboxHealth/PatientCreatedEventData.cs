﻿namespace NPMAPI.Models.InboxHealth
{
    public class PatientCreatedEventData
    {

    }
}