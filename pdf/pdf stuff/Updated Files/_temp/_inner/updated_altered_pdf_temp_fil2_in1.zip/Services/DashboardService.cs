﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Linq;
using EdiFabric.Core.Model.Edi.X12;
using iTextSharp.text;
using NPMAPI.Models;
using NPMAPI.Models.ViewModels;
using NPMAPI.Repositories;

namespace NPMAPI.Services
{

    public class DashboardService : IDashboardRepository
    {
        private readonly IReportRepository _reportService;
        public DashboardService(IReportRepository reportService)
        {
            _reportService = reportService;
        }

        public ResponseModel GetDashboardData(long practiceCode, string fromDate, string toDate, long userId)
        {
            ResponseModel res = new ResponseModel();
            try
            {
                var req = new ReportRequestModel();
                req.PracticeCode = practiceCode;
               // var recentAgingSummary = _reportService.AgingSummaryRecent(req, userId);
                var CPAAnalysis = _reportService.GetCPAAnalysis(practiceCode, fromDate, toDate, userId);
                var insuranceAging = _reportService.GetInsuranceAging(practiceCode,userId);
                var claimsAndERAs = _reportService.GetClaimsAndERAs(practiceCode, fromDate, toDate,userId);
                var patientAging = _reportService.GetPatientAging(practiceCode,userId);
                var pcRatio = _reportService.GetPCRatio(practiceCode, fromDate, toDate, userId);
                var ChargesANDPaymentsTrend = _reportService.GetChargesANDPaymentsTrend(practiceCode, fromDate, toDate,userId);
               // var recentChargesPayment = _reportService.ChargesPaymentsRecent(req, userId);
               // var agingDashboard = _reportService.GetAgingDashboard(req, userId);
                res.Response = new ExpandoObject();
                // res.Response.recentAgingSummary = recentAgingSummary.Response.Count == 0 ? null : recentAgingSummary.Response;
                // res.Response.CPAAnalysis = CPAAnalysis.Response.Count==0 ? null : CPAAnalysis.Response;
                // res.Response.insuranceAging = insuranceAging.Response.Count == 0 ? null : insuranceAging.Response;
                // res.Response.claimsAndERAs = claimsAndERAs.Response.Count == 0 ? null : claimsAndERAs.Response;
                // res.Response.recentAgingSummary = recentAgingSummary.Response.Count == 0 ? null : recentAgingSummary.Response;
                // res.Response.patientAging = patientAging.Response.Count == 0 ? null : patientAging.Response;
                // res.Response.pcRatio = pcRatio.Response.Count == 0 ? null : pcRatio.Response;
                //res.Response.agingDashboard = agingDashboard.Response.Count == 0 ? null : agingDashboard.Response;
               // res.Response.recentAgingSummary = recentAgingSummary.Response;
                res.Response.CPAAnalysis = CPAAnalysis.Response;
                res.Response.insuranceAging = insuranceAging.Response;
                res.Response.claimsAndERAs = claimsAndERAs.Response;
                res.Response.patientAging = patientAging.Response;
                res.Response.pcRatio = pcRatio.Response;
                res.Response.ChargesANDPaymentsTrend = ChargesANDPaymentsTrend.Response;
              //  res.Response.agingDashboard = agingDashboard.Response;

                res.Status = "success";
                return res;
            }
            catch (Exception ex)
            {
                throw ex;  
            }
        }

        public ResponseModel GetExternalPractices()
        {
            List<int?> practices = new List<int?>(); 
            
            ResponseModel res = new ResponseModel();
            try { 
            using (var ctx = new NPMDBEntities())
            {
                    //  practices = ctx.Practice_Reporting.Where(pr => (pr.Deleted ?? false) == false).Select(pr => pr.Practice_Code).ToList();
                    //res.Response = ctx.Practice_Reporting.Where(pr => (pr.Deleted ?? false) == false).Select(pr => pr.Practice_Code).ToList();
                    //..Above change is commented to resolve the COSS Practice issue occured due to Practice_Reporting table change
                    res.Response = ctx.ExternalPractices_Reporting.Where(pr => (pr.Deleted ?? false) == false).Select(pr => pr.Practice_Code).ToList();
                }
                res.Status = "success";
            }
            catch(Exception e) {
                res.Status="error";
                throw e;
            }

            return res;
        }

        public ResponseModel GetOpenPaymentBatches(long practiceCode)
        {
            ResponseModel response = new ResponseModel();
            try
            {
                using (var db = new NPMDBEntities())
                {
                    var today = DateTime.Now;
                    int currentMonth = today.Month;
                    int currentYear = today.Year;

                    // Calculate previous month and year
                    int previousMonth = currentMonth == 1 ? 12 : currentMonth - 1;
                    int previousYear = currentMonth == 1 ? currentYear - 1 : currentYear;

                    // Current month open/re-open batches
                    int currentMonthCount = db.Batch_WisePayments
                        .Count(b =>
                            b.Practice_Code == practiceCode &&
                            (b.Batch_Status == 1 || b.Batch_Status == 2) &&
                            b.BatchOpenDate.HasValue &&
                            b.BatchOpenDate.Value.Month == currentMonth &&
                            b.BatchOpenDate.Value.Year == currentYear &&
                    (b.Deleted == null || b.Deleted == false)
                        );

                    // Immediate previous month open/re-open batches
                    int previousMonthsCount = db.Batch_WisePayments
                        .Count(b =>
                            b.Practice_Code == practiceCode &&
                            (b.Batch_Status == 1 || b.Batch_Status == 2) &&
                            b.BatchOpenDate.HasValue &&
                            b.BatchOpenDate.Value.Month == previousMonth &&
                            b.BatchOpenDate.Value.Year == previousYear &&
                    (b.Deleted == null || b.Deleted == false)
                        );

                    response.Status = "Success";
                    response.Response = new
                    {
                        CurrentMonth = currentMonthCount,
                        PreviousMonths = previousMonthsCount 
                    };
                }
            }
            catch (Exception ex)
            {
                response.Status = "Error";
                response.Response = ex.Message;
            }

            return response;
        }


    }
}