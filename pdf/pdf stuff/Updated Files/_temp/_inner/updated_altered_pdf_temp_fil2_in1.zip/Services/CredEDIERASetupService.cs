﻿using NPMAPI.Models;
using NPMAPI.Models.ViewModels;
using NPMAPI.Repositories;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;

namespace NPMAPI.Services
{
    public class CredEDIERASetupService : ICredEDIERASetupRepository
    {
        #region  Lookup tables
        public ResponseModel GetLookupLists()
        {
            ResponseModel objResponse = new ResponseModel();
            CredEDIERALookupLists lookupLists = new CredEDIERALookupLists();
            try
            {

                using (var ctx = new NPMDBEntities())
                {
                    lookupLists.EDI_ERA_Doc_Types = ctx.EDI_ERA_Doc_Type.ToList();
                    lookupLists.EDI_ERA_Obj_Types = ctx.EDI_ERA_Obj_Types.ToList();
                    lookupLists.EDI_ERA_Statuses = ctx.EDI_ERA_Statuses.ToList();
                    lookupLists.TPA_Name_List = ctx.TPA_Name_List.ToList();
                    lookupLists.Practice_Software = ctx.Practice_Software.Where(ps => ps.Is_Active == false || (ps.Deleted == false || ps.Deleted == null)).ToList();
                    lookupLists.Clearing_Houses = ctx.Clearing_Houses.ToList();
                }

                objResponse.Status = "Success";
                objResponse.Response = lookupLists;
                return objResponse;
            }
            catch (Exception ex)
            {
                objResponse.Status = "Error";
                throw ex;
            }


        }
        #endregion

        #region Crud
        public ResponseModel AddEditCredEDIERASetup(EDI_ERA_Setup eDI_ERA_Setup, long userId)
        {
            ResponseModel response = new ResponseModel();
            try
            {
                using (var ctx = new NPMDBEntities())
                {
                    bool assignedToChanged = false;
                    string oldAssignedTo = "";
                    string newAssignedTo = "";

                    if (eDI_ERA_Setup.EDI_ERA_App_Id > 0)
                    {
                        var existingEDI_ERA_App = ctx.EDI_ERA_Setup
                            .Where(c => c.EDI_ERA_App_Id == eDI_ERA_Setup.EDI_ERA_App_Id)
                            .FirstOrDefault();

                        if (existingEDI_ERA_App != null)
                        {

                            if (existingEDI_ERA_App.Assigned_To != eDI_ERA_Setup.Assigned_To)
                            {
                                assignedToChanged = true;

                                long oldId = existingEDI_ERA_App.Assigned_To;
                                long newId = eDI_ERA_Setup.Assigned_To;

                                oldAssignedTo = ctx.Users.Where(u => u.UserId == oldId).Select(s => s.UserName).FirstOrDefault();
                                newAssignedTo = ctx.Users.Where(u => u.UserId == newId).Select(s => s.UserName).FirstOrDefault();
                            }

                            existingEDI_ERA_App.Practice_Code = eDI_ERA_Setup.Practice_Code;
                            existingEDI_ERA_App.Obj_Type_Id = eDI_ERA_Setup.Obj_Type_Id;
                            existingEDI_ERA_App.Payer_Name  = eDI_ERA_Setup.Payer_Name;
                            existingEDI_ERA_App.Clearing_House_Id = eDI_ERA_Setup.Clearing_House_Id;
                            existingEDI_ERA_App.Software_Id = eDI_ERA_Setup.Software_Id;
                            existingEDI_ERA_App.Obj_Type_Id = eDI_ERA_Setup.Obj_Type_Id;
                            existingEDI_ERA_App.Direct_TPA = eDI_ERA_Setup.Direct_TPA;
                            existingEDI_ERA_App.TPA_Name_Id = eDI_ERA_Setup.TPA_Name_Id;
                            existingEDI_ERA_App.TPA_user_Id = eDI_ERA_Setup.TPA_user_Id;
                            existingEDI_ERA_App.App_Status_Id = eDI_ERA_Setup.App_Status_Id;
                            existingEDI_ERA_App.Tracking_Id = eDI_ERA_Setup.Tracking_Id;
                            existingEDI_ERA_App.Applied_Date = eDI_ERA_Setup.Applied_Date;
                            existingEDI_ERA_App.Effectice_Date = eDI_ERA_Setup.Effectice_Date;
                            existingEDI_ERA_App.Last_FollowUp_Date = eDI_ERA_Setup.Last_FollowUp_Date;
                            existingEDI_ERA_App.Next_Followup_Date = eDI_ERA_Setup.Next_Followup_Date;
                            existingEDI_ERA_App.Assigned_To = eDI_ERA_Setup.Assigned_To;
                            existingEDI_ERA_App.Assigned_By = eDI_ERA_Setup.Assigned_By;
                            existingEDI_ERA_App.Assigned_Date = eDI_ERA_Setup.Assigned_Date;
                            existingEDI_ERA_App.Modified_By = userId;
                            existingEDI_ERA_App.Modfied_Date = DateTime.Now;
                            ctx.SaveChanges();

                            response.Response = existingEDI_ERA_App.EDI_ERA_App_Id;


                            if (assignedToChanged)
                            {
                                string createdByUser = ctx.Users.Where(u => u.UserId == userId)
                                    .Select(s => s.UserName)
                                    .FirstOrDefault() ?? "NA";

                                string autoNote =
                                    $"Application ID APP-{existingEDI_ERA_App.EDI_ERA_App_Id} Assigned To User updated from {oldAssignedTo} to {newAssignedTo} by {createdByUser}.";

                                EDI_ERA_Notes note = new EDI_ERA_Notes
                                {
                                    EDI_ERA_App_Id = existingEDI_ERA_App.EDI_ERA_App_Id,
                                    Note_Desc = autoNote,
                                    Is_Auto_Note = true
                                };

                                AddEditCred_EDIERA_Notes(note, userId);
                            }
                        }
                    }
                    else
                    {
                        eDI_ERA_Setup.EDI_ERA_App_Id = Convert.ToInt32(ctx.SP_TableIdGenerator("EDI_ERA_App_Id").FirstOrDefault().ToString());
                        eDI_ERA_Setup.Created_by = userId;
                        eDI_ERA_Setup.Created_Date = DateTime.Now;
                        eDI_ERA_Setup.Deleted = false;

                        ctx.EDI_ERA_Setup.Add(eDI_ERA_Setup);
                        ctx.SaveChanges();

                        response.Response = eDI_ERA_Setup.EDI_ERA_App_Id;
                    }

                    response.Status = "Success";
                }
            }
            catch (Exception ex)
            {
                response.Status = "Error";
                response.STCDescription = "Operation Failed";
                throw;
            }

            return response;
        }
        public ResponseModel GetCredEDIERASetupById(long id)
        {
            ResponseModel response = new ResponseModel();
            try
            {
                using (var ctx = new NPMDBEntities())
                {
             

                        var data =
                            (
                                from c in ctx.EDI_ERA_Setup
                                where c.EDI_ERA_App_Id == id
                                   && (c.Deleted == null || c.Deleted == false)

                                //join ins in ctx.Insurances.Where(x => x.Deleted == null || x.Deleted == false)
                                //    on (long?)c.Insurance_Id equals (long?)ins.Insurance_Id into insJoin
                                //from ins in insJoin.DefaultIfEmpty()

                                //join insp in ctx.Insurance_Payers.Where(x => x.Deleted == null || x.Deleted == false)
                                //    on (long?)ins.InsPayer_Id equals (long?)insp.Inspayer_Id into inspJoin
                                //from insp in inspJoin.DefaultIfEmpty()

                                //join insn in ctx.Insurance_Names.Where(x => x.Deleted == null || x.Deleted == false)
                                //    on (long?)insp.Insname_Id equals (long?)insn.Insname_Id into insnJoin
                                //from insn in insnJoin.DefaultIfEmpty()

                                select new
                                {
                                    App = c,
                                    PayerName = c.Payer_Name
                                }
                            ).FirstOrDefault();



                  

                    if (data == null)
                    {
                        response.Status = "No Data";
                        return response;
                    }

                    response.Status = "Success";
                    response.Response = data;
                }


            }
            catch (Exception ex)
            {
                response.Status = "Error";
                response.STCDescription = "Operation Failed";
                throw;
            }

            return response;

        }

        public ResponseModel SearchCredEDIERASetup(EdiEraSetupSearchViewModel searchViewModel)
        {
            ResponseModel response = new ResponseModel();

            try
            {
                using (var ctx = new NPMDBEntities())
                {
                    var results = ctx.Database.SqlQuery<SP_SearchCredEdiEraApp_Result>(
                        "EXEC SP_SearchCredEdiEraApp " +
                        "@Practice_Code, @Clearing_House_Id, @Payer_Name, @Prac_Soft_ID, @Obj_Type_Id, @Status_Id, " +
                        "@Tracking_Id, @Created_By, @Assigned_To, @DateCriteria, @DateFrom, @DateTo",

                        new System.Data.SqlClient.SqlParameter("@Practice_Code",
                            (object)searchViewModel.Practice_Code ?? DBNull.Value),

                        new System.Data.SqlClient.SqlParameter("@Clearing_House_Id",
                            (object)searchViewModel.Clearing_House_Id ?? DBNull.Value),

                        new System.Data.SqlClient.SqlParameter("@Payer_Name",
                            (object)searchViewModel.Payer_Name ?? DBNull.Value),

                        new System.Data.SqlClient.SqlParameter("@Prac_Soft_ID",
                            (object)searchViewModel.Prac_Soft_ID ?? DBNull.Value),

                        new System.Data.SqlClient.SqlParameter("@Obj_Type_Id",
                            (object)searchViewModel.Obj_Type_Id ?? DBNull.Value),

                        new System.Data.SqlClient.SqlParameter("@Status_Id",
                            (object)searchViewModel.Status_Id ?? DBNull.Value),

                        new System.Data.SqlClient.SqlParameter("@Tracking_Id",
                            (object)searchViewModel.Tracking_Id ?? DBNull.Value),

                        new System.Data.SqlClient.SqlParameter("@Created_By",
                            (object)searchViewModel.Created_By ?? DBNull.Value),

                        new System.Data.SqlClient.SqlParameter("@Assigned_To",
                            (object)searchViewModel.Assigned_To ?? DBNull.Value),

                        new System.Data.SqlClient.SqlParameter("@DateCriteria",
                            (object)searchViewModel.DateCriteria ?? DBNull.Value),

                        new System.Data.SqlClient.SqlParameter("@DateFrom",
                            (object)searchViewModel.DateFrom ?? DBNull.Value),

                        new System.Data.SqlClient.SqlParameter("@DateTo",
                            (object)searchViewModel.DateTo ?? DBNull.Value)
                    ).ToList();

                    response.Status = "Success";
                    response.Response = results;
                }
            }
            catch (Exception ex)
            {
                response.Status = "Failed";
                response.STCDescription = ex.Message;
            }

            return response;
        }

        #endregion

        #region Notes

        public ResponseModel AddEditCred_EDIERA_Notes(EDI_ERA_Notes eDI_ERA_Notes, long UserId)
        {
            ResponseModel response = new ResponseModel();

            try
            {
                using (var ctx = new NPMDBEntities())
                {
                    if (eDI_ERA_Notes.EDI_ERA_Note_Id > 0)
                    {
                        var existingNote = ctx.EDI_ERA_Notes
                                              .FirstOrDefault(n => n.EDI_ERA_Note_Id == eDI_ERA_Notes.EDI_ERA_Note_Id && (n.Deleted == false || n.Deleted != null));

                        if (existingNote == null)
                        {
                            response.Status = "NotFound";
                            response.STCDescription = "Note not found";
                            return response;
                        }

                        existingNote.Note_Desc = eDI_ERA_Notes.Note_Desc;
                        existingNote.Modified_By = UserId;
                        existingNote.Modfied_Date = DateTime.Now;

                        ctx.SaveChanges();

                        response.Status = "Success";
                        response.Response = eDI_ERA_Notes.EDI_ERA_Note_Id;
                        return response;
                    }


                    eDI_ERA_Notes.EDI_ERA_Note_Id = Convert.ToInt64(ctx.SP_TableIdGenerator("EDI_ERA_Note_Id").FirstOrDefault().ToString());

                    eDI_ERA_Notes.Created_by = UserId;
                    eDI_ERA_Notes.Created_Date = DateTime.Now;
                    eDI_ERA_Notes.Deleted = false;


                    ctx.EDI_ERA_Notes.Add(eDI_ERA_Notes);
                    ctx.SaveChanges();

                    response.Status = "Success";
                    response.Response = eDI_ERA_Notes.EDI_ERA_Note_Id;
                }
            }
            catch (Exception ex)
            {
                response.Status = "Error";
                response.STCDescription = ex.Message;
            }

            return response;
        }

        public ResponseModel GetCred_EDIERA_Notes(long applicationId)

        {
            ResponseModel response = new ResponseModel();

            try
            {
                using (var ctx = new NPMDBEntities())
                {
                    var notes = (from n in ctx.EDI_ERA_Notes
                                 join u in ctx.Users
                                 on n.Created_by equals u.UserId into userJoin
                                 from u in userJoin.DefaultIfEmpty()  // LEFT JOIN
                                 where n.EDI_ERA_App_Id == applicationId
                                    && n.Deleted == false
                                 orderby n.Created_Date descending
                                 select new EDIERANotesViewModel
                                 {
                                     EDI_ERA_App_Id = n.EDI_ERA_App_Id,
                                     EDI_ERA_Note_Id = n.EDI_ERA_Note_Id,
                                     Note_Desc = n.Note_Desc,
                                     Is_Auto_Note = n.Is_Auto_Note,
                                     Created_by = n.Created_by,
                                     Created_Date = n.Created_Date,
                                     Created_By_UserName = u.UserName
                                 }).ToList();

                    response.Status = "Success";
                    response.Response = notes;
                }
            }
            catch (Exception ex)
            {
                response.Status = "Error";
                response.STCDescription = ex.Message;
            }

            return response;
        }

        #endregion
        #region  Documents
        public ResponseModel SaveCred_EDIERA_Document(CredAppDocumentRequest request)
        {
            ResponseModel response = new ResponseModel();

            try
            {
                using (var ctx = new NPMDBEntities())
                {
                    EDI_ERA_Documents doc = new EDI_ERA_Documents
                    {
                        EDI_ERA_Doc_Id = Convert.ToInt64(ctx.SP_TableIdGenerator("EDI_ERA_Doc_Id")
                                                            .FirstOrDefault().ToString()),
                        EDI_ERA_App_Id = request.Application_Id,
                        Attachment_Name = request.FileName,
                        Doc_Type_Id = request.DocumentType_Id,
                        Attachment_Path = request.FilePath,
                        Attached_On = DateTime.Now,
                        Attached_By = request.UploadedBy,
                        Deleted = false
                    };

                    ctx.EDI_ERA_Documents.Add(doc);
                    ctx.SaveChanges();

                    response.Status = "Success";
                    response.Response = doc.EDI_ERA_Doc_Id;
                }
            }
            catch (Exception ex)
            {
                response.Status = "Error";
                response.STCDescription = ex.Message;
            }

            return response;
        }
        public ResponseModel GetCred_EDIERA_Documents(long applicationId)
        {
            ResponseModel response = new ResponseModel();

            try
            {
                using (var ctx = new NPMDBEntities())
                {
                    var documents = (from d in ctx.EDI_ERA_Documents
                                     join dt in ctx.Cred_Document_Type on d.Doc_Type_Id equals dt.Doc_Type_Id
                                     join u in ctx.Users on d.Attached_By equals u.UserId into userJoin
                                     from u in userJoin.DefaultIfEmpty()
                                     where d.EDI_ERA_App_Id == applicationId
                                           && d.Deleted == false
                                     orderby d.Attached_On descending
                                     select new CredAppDocumentViewModel
                                     {
                                         Cred_App_Doc_Id = d.EDI_ERA_Doc_Id,
                                         Application_Id = d.EDI_ERA_App_Id,
                                         Doc_Type_Id = d.Doc_Type_Id,
                                         Doc_Type_Desc = dt.Doc_Type_Desc,
                                         Attachment = d.Attachment_Name,
                                         Attached_On = d.Attached_On,
                                         Attached_By = d.Attached_By,
                                         Attached_By_UserName = u.UserName
                                     }).ToList();

                    response.Status = "Success";
                    response.Response = documents;
                }
            }
            catch (Exception ex)
            {
                response.Status = "Error";
                response.STCDescription = ex.Message;
            }

            return response;
        }
        public ResponseModel GetCred_EDIERA_DocumentByDocId(long documentId)
        {
            ResponseModel response = new ResponseModel();

            try
            {
                using (var ctx = new NPMDBEntities())
                {
                    var document = ctx.EDI_ERA_Documents.FirstOrDefault(d => d.EDI_ERA_Doc_Id == documentId && d.Deleted == false);



                    response.Status = "Success";
                    response.Response = document;
                }
            }
            catch (Exception ex)
            {
                response.Status = "Error";
                response.STCDescription = ex.Message;
            }

            return response;
        }
        public ResponseModel DeleteCred_EDIERA_Document(long documentId)
        {
            var response = new ResponseModel();

            try
            {
                using (var db = new NPMDBEntities())
                {
                    var doc = db.EDI_ERA_Documents
                                .FirstOrDefault(x => x.EDI_ERA_Doc_Id == documentId && (x.Deleted == false || x.Deleted == null));

                    if (doc == null)
                    {
                        response.Status = "error";
                        response.STCDescription = "Document not found.";
                        return response;
                    }

                    string fileName = doc.Attachment_Name;
                    string folder = ConfigurationManager.AppSettings["CredAppDocuments"];
                    string fullPath = HttpContext.Current.Server.MapPath($"~/{folder}/{fileName}");


                    if (System.IO.File.Exists(fullPath))
                    {
                        System.IO.File.Delete(fullPath);
                    }

                    doc.Deleted = true;


                    db.SaveChanges();

                    response.Status = "success";
                    response.STCDescription = "Document deleted successfully.";
                    response.Response = documentId;
                }
            }
            catch (Exception ex)
            {
                response.Status = "error";
                response.STCDescription = ex.Message;
            }

            return response;
        }


        #endregion
        public ResponseModel AddTPAName(TPA_Name_List tPA_Name_List)
        {
            ResponseModel response = new ResponseModel();

            try
            {
                using (var ctx = new NPMDBEntities())
                {
                    
                    bool exists = ctx.TPA_Name_List
                        .Any(x => x.TPA_Name_Desc.Trim().ToLower() ==
                                  tPA_Name_List.TPA_Name_Desc.Trim().ToLower());

                    if (exists)
                    {
                        response.Status = "Error";
                        response.STCDescription = "TPA Name already exists.";
                        return response;
                    }

                    ctx.TPA_Name_List.Add(tPA_Name_List);
                    ctx.SaveChanges();

                    response.Status = "Success";
                    response.STCDescription = "TPA Name added successfully.";
                }
            }
            catch (Exception ex)
            {
                response.Status = "Error";
                response.STCDescription = ex.Message;
            }

            return response;
        }

    }
}