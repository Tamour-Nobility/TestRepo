﻿using NPMAPI.Models;
using NPMAPI.Repositories;
using System;
using System.Collections.Generic;
using System.Data.Entity.Validation;
using System.IO;
using System.Linq;
using System.Text;

namespace NPMAPI.Services
{
    public class ClaimsAttachmentsService : IClaimsAttachments
    {

        private readonly NPMDBEntities _db;

        public ClaimsAttachmentsService(NPMDBEntities db)
        {
            _db = db;
        }

        public ResponseModel GetAllClaimAttachemnt(long Claim_No)
        {
            try
            {
                var results = _db.uspGetClaimAttachments(Claim_No).ToList();
                return new ResponseModel()
                {
                    Status = "success",
                    Response = results
                };
            }
            catch (Exception)
            {
                throw;
            }
        }

        public ResponseModel AttachemntSave(ClaimAttachmentRequest request, long userId)
        {
            try
            {
                var attachment = new Claim_Document()
                {
                    Doc_Type = request.Doc_Type,
                    Document_ID = Convert.ToInt64(_db.SP_TableIdGenerator("Document_ID").FirstOrDefault().ToString()),
                    //Document_ID= 1,
                    Document_Name = request.Document_Name,
                    FilePath = request.FilePath,
                    Claim_No = long.Parse(request.Claim_No),

                    //Claim_No = request.Claim_No,
                    Created_By = userId,
                    Created_Date = DateTime.Now,
                    Modified_By = null,
                    Modified_Date = null,
                    Practice_Code = request.Practice_Code,
                    Insurance_Type = request.InsuranceType,
                    Description = request.Description,
                    Uploaded = true,
                    Deleted = false
                };

                _db.Claim_Document.Add(attachment);

                if (_db.SaveChanges() > 0)
                {
                    return new ResponseModel()
                    {
                        Status = "success",
                        Response = attachment
                    };
                }
                else
                {
                    return new ResponseModel()
                    {
                        Status = "Failure",
                        Response = "Unable to save file"
                    };
                }
            }
            catch (DbEntityValidationException ex)
            {
                // Detailed validation error logging
                var errorMessages = ex.EntityValidationErrors
                    .SelectMany(e => e.ValidationErrors)
                    .Select(e => $"Property: {e.PropertyName}, Error: {e.ErrorMessage}");

                var fullErrorMessage = string.Join("; ", errorMessages);
                var exceptionMessage = $"Validation failed: {fullErrorMessage}";

                throw new DbEntityValidationException(exceptionMessage, ex.EntityValidationErrors);
            }
            catch (Exception ex)
            {
                throw new Exception("An error occurred while saving the claim attachment.", ex);
            }
        }
        public ResponseModel GetAttachmentTypeCodesList()
        {
            try
            {
                var codes = _db.Doc_Type_Lookup
                    .Where(a => a.Deleted == false || a.Deleted == null) // Only include non-deleted entries
                    .Select(a => new SelectListViewModel()
                    {
                        IdStr = a.Code,
                        Name = a.Value
                    })
                    .OrderBy(a => a.IdStr)
                    .ToList();

                return new ResponseModel()
                {
                    Status = "success",
                    Response = codes
                };
            }
            catch (Exception)
            {
                throw;
            }
        }

        public ResponseModel GetAttachemnt(long Id)
        {
            try
            {
                return new ResponseModel()
                {
                    Status = "success",
                    Response = _db.Claim_Document.Where(pt => pt.Document_ID == Id && !(pt.Deleted ?? false)).FirstOrDefault()
                };
            }
            catch (Exception)
            {
                throw;
            }
        }

    }
}