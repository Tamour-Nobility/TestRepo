﻿using NPMAPI.Models;
using NPMAPI.Models.ViewModels;
using NPMAPI.Repositories;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;

namespace NPMAPI.Services
{
    public class CredentialingService : ICredentialingRepository
    {
        #region  Lookup tables
        public ResponseModel GetLookupLists()
        {
            ResponseModel objResponse = new ResponseModel();
            CredentialingLookupLists lookupLists = new CredentialingLookupLists();
            try
            {

                using (var ctx = new NPMDBEntities())
                {
                    lookupLists.cred_Application_Statuses = ctx.Cred_Application_Status.ToList();
                    lookupLists.cred_Application_Types = ctx.Cred_Application_Type.ToList();
                    lookupLists.cred_Contract_Types = ctx.Cred_Contract_Type.ToList();
                    lookupLists.cred_Document_Types = ctx.Cred_Document_Type.ToList();
                    lookupLists.cred_Objective_Types = ctx.Cred_Objective_Type.ToList();
                }

                objResponse.Status = "Success";
                objResponse.Response = lookupLists;
                return objResponse;
            }
            catch (Exception ex)
            {
                objResponse.Status = "Error";
                throw ex;
            }


        }
        #endregion
       #region Add/Edit 
        public ResponseModel AddEditCredApp(Cred_App_ViewModel cred_App_ViewModel, long userId)
        {
            ResponseModel response = new ResponseModel();
            Credentialing_Application credentialing_Application = new Credentialing_Application();

            try
            {
                using (var ctx = new NPMDBEntities())
                {
                    bool assignedToChanged = false;
                    string oldAssignedTo = "";
                    string newAssignedTo = "";

                    if (cred_App_ViewModel.Application_Id > 0)
                    {
                        var existingCredApp = ctx.Credentialing_Application
                            .Where(c => c.Application_Id == cred_App_ViewModel.Application_Id)
                            .FirstOrDefault();

                        if (existingCredApp != null)
                        {

                            if (existingCredApp.Assigned_To != cred_App_ViewModel.Assigned_To)
                            {
                                assignedToChanged = true;

                                long oldId = existingCredApp.Assigned_To;
                                long newId = cred_App_ViewModel.Assigned_To;

                                oldAssignedTo = ctx.Users.Where(u => u.UserId == oldId).Select(s => s.UserName).FirstOrDefault();
                                newAssignedTo = ctx.Users.Where(u => u.UserId == newId).Select(s => s.UserName).FirstOrDefault();
                            }

                            existingCredApp.Practice_Code = cred_App_ViewModel.Practice_Code;
                            existingCredApp.Provider_Id = cred_App_ViewModel.Provider_Id;
                            existingCredApp.Payer_Name = cred_App_ViewModel.Payer_Name;
                            existingCredApp.Ind_Provider_Id = cred_App_ViewModel.Ind_Provider_Id;
                            existingCredApp.IPA_Name = cred_App_ViewModel.IPA_Name;
                            existingCredApp.Obj_Type_Id = cred_App_ViewModel.Obj_Type_Id;
                            existingCredApp.Contract_Type_Id = cred_App_ViewModel.Contract_Type_Id;
                            existingCredApp.Plan_Name = cred_App_ViewModel.Plan_Name;
                            existingCredApp.Application_Type_Id = cred_App_ViewModel.Application_Type_Id;
                            existingCredApp.Application_Status_Id = cred_App_ViewModel.Application_Status_Id;
                            existingCredApp.Tracking_Id = cred_App_ViewModel.Tracking_Id;
                            existingCredApp.Applied_Date = cred_App_ViewModel.Applied_Date;
                            existingCredApp.Effective_Date = cred_App_ViewModel.Effective_Date;
                            existingCredApp.Recredentialing_Date = cred_App_ViewModel.Recredentialing_Date;
                            existingCredApp.Last_Followup_Date = cred_App_ViewModel.Last_Followup_Date;
                            existingCredApp.Next_Followup_Date = cred_App_ViewModel.Next_Followup_Date;
                            existingCredApp.Assigned_To = cred_App_ViewModel.Assigned_To;
                            existingCredApp.Assigned_By = cred_App_ViewModel.Assigned_By;
                            existingCredApp.Assigned_Date = cred_App_ViewModel.Assigned_Date;
                            existingCredApp.Modified_By = userId;
                            existingCredApp.Modified_Date = DateTime.Now;
                            ctx.SaveChanges();

                            response.Response = existingCredApp.Application_Id;


                            if (assignedToChanged)
                            {
                                string createdByUser = ctx.Users.Where(u => u.UserId == userId)
                                    .Select(s => s.UserName)
                                    .FirstOrDefault() ?? "NA";

                                string autoNote =
                                    $"Application ID APP-{existingCredApp.Application_Id} Assigned To User updated from {oldAssignedTo} to {newAssignedTo} by {createdByUser}.";

                                Cred_App_Notes note = new Cred_App_Notes
                                {
                                    Application_Id = existingCredApp.Application_Id,
                                    Note_Description = autoNote,
                                    Is_Auto_Note = true
                                };

                                AddEditCredAppNote(note, userId);
                            }
                        }
                    }
                    else
                    {
                        credentialing_Application.Application_Id = Convert.ToInt32(ctx.SP_TableIdGenerator("Application_Id").FirstOrDefault().ToString());
                        credentialing_Application.Practice_Code = cred_App_ViewModel.Practice_Code;
                        credentialing_Application.Provider_Id = cred_App_ViewModel.Provider_Id;
                        credentialing_Application.Payer_Name = cred_App_ViewModel.Payer_Name;
                        credentialing_Application.Ind_Provider_Id = cred_App_ViewModel.Ind_Provider_Id;
                        credentialing_Application.IPA_Name = cred_App_ViewModel.IPA_Name;
                        credentialing_Application.Obj_Type_Id = cred_App_ViewModel.Obj_Type_Id;
                        credentialing_Application.Contract_Type_Id = cred_App_ViewModel.Contract_Type_Id;
                        credentialing_Application.Plan_Name = cred_App_ViewModel.Plan_Name;
                        credentialing_Application.Application_Type_Id = cred_App_ViewModel.Application_Type_Id;
                        credentialing_Application.Application_Status_Id = cred_App_ViewModel.Application_Status_Id;
                        credentialing_Application.Tracking_Id = cred_App_ViewModel.Tracking_Id;
                        credentialing_Application.Applied_Date = cred_App_ViewModel.Applied_Date;
                        credentialing_Application.Effective_Date = cred_App_ViewModel.Effective_Date;
                        credentialing_Application.Recredentialing_Date = cred_App_ViewModel.Recredentialing_Date;
                        credentialing_Application.Last_Followup_Date = cred_App_ViewModel.Last_Followup_Date;
                        credentialing_Application.Next_Followup_Date = cred_App_ViewModel.Next_Followup_Date;
                        credentialing_Application.Assigned_To = cred_App_ViewModel.Assigned_To;
                        credentialing_Application.Assigned_By = cred_App_ViewModel.Assigned_By;
                        credentialing_Application.Assigned_Date = cred_App_ViewModel.Assigned_Date;
                        credentialing_Application.Modified_By = userId;
                        credentialing_Application.Modified_Date = DateTime.Now;
                        credentialing_Application.Created_By = userId;
                        credentialing_Application.Created_Date = DateTime.Now;
                        credentialing_Application.Deleted = false;

                        ctx.Credentialing_Application.Add(credentialing_Application);
                        ctx.SaveChanges();

                        response.Response = credentialing_Application.Application_Id;
                    }

                    response.Status = "Success";
                }
            }
            catch (Exception ex)
            {
                response.Status = "Error";
                response.STCDescription = "Operation Failed";
                throw;
            }

            return response;
        }


        public ResponseModel SearchCredApp(CredAppSearchViewModel searchViewModel)
        {

            ResponseModel response = new ResponseModel();
            try
            {
                using (var ctx = new NPMDBEntities())
                {

                    var results = ctx.Database.SqlQuery<SP_SearchCredApp_Result>(
                            "EXEC SP_SearchCredApp " +
                            "@Practice_Code, @Provider_Id, @Payer_Name, @Contract_Type_Id, @Obj_Type_Id, @Application_Status_Id, " +
                            "@Tracking_Id, @Created_By, @Assigned_To, @DateCriteria, @DateFrom, @DateTo",

                            new System.Data.SqlClient.SqlParameter("@Practice_Code", (object)searchViewModel.Practice_Code ?? DBNull.Value),
                            new System.Data.SqlClient.SqlParameter("@Provider_Id", (object)searchViewModel.Provider_Id ?? DBNull.Value),
                            new System.Data.SqlClient.SqlParameter("@Payer_Name", (object)searchViewModel.Payer_Name ?? DBNull.Value),
                            new System.Data.SqlClient.SqlParameter("@Contract_Type_Id", (object)searchViewModel.Contract_Type_Id ?? DBNull.Value),
                            new System.Data.SqlClient.SqlParameter("@Obj_Type_Id", (object)searchViewModel.Obj_Type_Id ?? DBNull.Value),
                            new System.Data.SqlClient.SqlParameter("@Application_Status_Id", (object)searchViewModel.Application_Status_Id ?? DBNull.Value),
                            new System.Data.SqlClient.SqlParameter("@Tracking_Id", (object)searchViewModel.Tracking_Id ?? DBNull.Value),
                            new System.Data.SqlClient.SqlParameter("@Created_By", (object)searchViewModel.Created_By ?? DBNull.Value),
                            new System.Data.SqlClient.SqlParameter("@Assigned_To", (object)searchViewModel.Assigned_To ?? DBNull.Value),
                            new System.Data.SqlClient.SqlParameter("@DateCriteria", (object)searchViewModel.DateCriteria ?? DBNull.Value),
                            new System.Data.SqlClient.SqlParameter("@DateFrom", (object)searchViewModel.DateFrom ?? DBNull.Value),
                            new System.Data.SqlClient.SqlParameter("@DateTo", (object)searchViewModel.DateTo ?? DBNull.Value)
                        ).ToList();

                    response.Status = "Success";
                    response.Response = results;
                }
            }
            catch (Exception ex)
            {
                response.Status = "Failed";
                response.STCDescription = ex.Message;
            }

            return response;
        }

        public ResponseModel GetCredAppById(long Id)
        {
            ResponseModel response = new ResponseModel();
            Cred_App_ViewModel cred_App_ViewModel = new Cred_App_ViewModel();

            try
            {
                using (var ctx = new NPMDBEntities())
                {
                    var data =
                        (from c in ctx.Credentialing_Application
                         where c.Application_Id == Id && (c.Deleted == null || c.Deleted == false)
                         //join ins in ctx.Insurances.Where(x => x.Deleted == null || x.Deleted == false)
                         //on c.Insurance_Id equals ins.Insurance_Id into insJoin
                         //from ins in insJoin.DefaultIfEmpty()
                         //join insp in ctx.Insurance_Payers.Where(x => x.Deleted == null || x.Deleted == false)
                         //on ins.InsPayer_Id equals insp.Inspayer_Id into inspJoin
                         //from insp in inspJoin.DefaultIfEmpty()
                         //join insn in ctx.Insurance_Names.Where(x => x.Deleted == null || x.Deleted == false)
                         //on insp.Insname_Id equals insn.Insname_Id into insnJoin
                         //from insn in insnJoin.DefaultIfEmpty()
                         select new
                         {
                             App = c,
                             PayerName = c.Payer_Name
                         }).FirstOrDefault();

                    if (data == null)
                    {
                        response.Status = "No Data";
                        return response;
                    }

                    var app = data.App;
                    cred_App_ViewModel.Application_Id = app.Application_Id;
                    cred_App_ViewModel.Practice_Code = app.Practice_Code;
                    cred_App_ViewModel.Provider_Id = app.Provider_Id;
                    cred_App_ViewModel.Payer_Name = app.Payer_Name;
                    cred_App_ViewModel.Ind_Provider_Id = app.Ind_Provider_Id;
                    cred_App_ViewModel.IPA_Name = app.IPA_Name;
                    cred_App_ViewModel.Obj_Type_Id = app.Obj_Type_Id;
                    cred_App_ViewModel.Contract_Type_Id = app.Contract_Type_Id;
                    cred_App_ViewModel.Plan_Name = app.Plan_Name;
                    cred_App_ViewModel.Application_Type_Id = app.Application_Type_Id;
                    cred_App_ViewModel.Application_Status_Id = app.Application_Status_Id;
                    cred_App_ViewModel.Tracking_Id = app.Tracking_Id;
                    cred_App_ViewModel.Applied_Date = app.Applied_Date;
                    cred_App_ViewModel.Effective_Date = app.Effective_Date;
                    cred_App_ViewModel.Recredentialing_Date = app.Recredentialing_Date;
                    cred_App_ViewModel.Last_Followup_Date = app.Last_Followup_Date;
                    cred_App_ViewModel.Next_Followup_Date = app.Next_Followup_Date;
                    cred_App_ViewModel.Assigned_To = app.Assigned_To;
                    cred_App_ViewModel.Assigned_By = app.Assigned_By;
                    cred_App_ViewModel.Assigned_Date = app.Assigned_Date;

                    // ⭐ ADD payer name here
                    cred_App_ViewModel.Payer_Name = data.PayerName;

                    response.Status = "Success";
                    response.Response = cred_App_ViewModel;
                }
            }
            catch (Exception ex)
            {
                response.Status = "Failed";
                response.STCDescription = ex.Message;
            }

            return response;
        }

        #endregion
        #region Notes

        public ResponseModel AddEditCredAppNote(Cred_App_Notes cred_App_Notes, long UserId)
        {
            ResponseModel response = new ResponseModel();

            try
            {
                using (var ctx = new NPMDBEntities())
                {
                    if (cred_App_Notes.Cred_App_Note_Id > 0)
                    {
                        var existingNote = ctx.Cred_App_Notes
                                              .FirstOrDefault(n => n.Cred_App_Note_Id == cred_App_Notes.Cred_App_Note_Id && n.Deleted == false);

                        if (existingNote == null)
                        {
                            response.Status = "NotFound";
                            response.STCDescription = "Note not found";
                            return response;
                        }

                        existingNote.Note_Description = cred_App_Notes.Note_Description;
                        existingNote.Modified_By = UserId;
                        existingNote.Modified_Date = DateTime.Now;

                        ctx.SaveChanges();

                        response.Status = "Success";
                        response.Response = cred_App_Notes.Cred_App_Note_Id;
                        return response;
                    }


                    Cred_App_Notes newNote = new Cred_App_Notes
                    {
                        Cred_App_Note_Id = Convert.ToInt64(ctx.SP_TableIdGenerator("Cred_App_Note_Id").FirstOrDefault().ToString()),
                        Application_Id = cred_App_Notes.Application_Id,
                        Note_Description = cred_App_Notes.Note_Description,
                        Is_Auto_Note = cred_App_Notes.Is_Auto_Note,
                        Created_By = UserId,
                        Created_Date = DateTime.Now,
                        Deleted = false
                    };

                    ctx.Cred_App_Notes.Add(newNote);
                    ctx.SaveChanges();

                    response.Status = "Success";
                    response.Response = newNote.Cred_App_Note_Id;
                }
            }
            catch (Exception ex)
            {
                response.Status = "Error";
                response.STCDescription = ex.Message;
            }

            return response;
        }

        public ResponseModel GetCredAppNotes(long applicationId)

        {
            ResponseModel response = new ResponseModel();

            try
            {
                using (var ctx = new NPMDBEntities())
                {
                    var notes = (from n in ctx.Cred_App_Notes
                                 join u in ctx.Users
                                 on n.Created_By equals u.UserId into userJoin
                                 from u in userJoin.DefaultIfEmpty()  // LEFT JOIN
                                 where n.Application_Id == applicationId
                                    && n.Deleted == false
                                 orderby n.Created_Date descending
                                 select new CredAppNoteViewModel
                                 {
                                     Cred_App_Note_Id = n.Cred_App_Note_Id,
                                     Application_Id = n.Application_Id,
                                     Note_Description = n.Note_Description,
                                     Is_Auto_Note = n.Is_Auto_Note,
                                     Created_By = n.Created_By,
                                     Created_Date = n.Created_Date,
                                     Created_By_UserName = u.UserName      // <-- from JOIN
                                 }).ToList();

                    response.Status = "Success";
                    response.Response = notes;
                }
            }
            catch (Exception ex)
            {
                response.Status = "Error";
                response.STCDescription = ex.Message;
            }

            return response;
        }

        #endregion

        public ResponseModel SaveCredAppDocument(CredAppDocumentRequest request)
        {
            ResponseModel response = new ResponseModel();

            try
            {
                using (var ctx = new NPMDBEntities())
                {
                    Cred_App_Docs doc = new Cred_App_Docs
                    {
                        Cred_App_Doc_Id = Convert.ToInt64(ctx.SP_TableIdGenerator("Cred_App_Doc_Id")
                                                            .FirstOrDefault().ToString()),
                        Application_Id = request.Application_Id,
                        Attachment = request.FileName,
                        Doc_Type_Id = request.DocumentType_Id,
                        Attachment_Path = request.FilePath,
                        Attached_On = DateTime.Now,
                        Attached_By = request.UploadedBy,
                        Deleted = false
                    };

                    ctx.Cred_App_Docs.Add(doc);
                    ctx.SaveChanges();

                    response.Status = "Success";
                    response.Response = doc.Cred_App_Doc_Id;
                }
            }
            catch (Exception ex)
            {
                response.Status = "Error";
                response.STCDescription = ex.Message;
            }

            return response;
        }
        public ResponseModel GetCredAppDocuments(long applicationId)
        {
            ResponseModel response = new ResponseModel();

            try
            {
                using (var ctx = new NPMDBEntities())
                {
                    var documents = (from d in ctx.Cred_App_Docs
                                     join dt in ctx.Cred_Document_Type on d.Doc_Type_Id equals dt.Doc_Type_Id
                                     join u in ctx.Users on d.Attached_By equals u.UserId into userJoin
                                     from u in userJoin.DefaultIfEmpty()
                                     where d.Application_Id == applicationId
                                           && d.Deleted == false
                                     orderby d.Attached_On descending
                                     select new CredAppDocumentViewModel
                                     {
                                         Cred_App_Doc_Id = d.Cred_App_Doc_Id,
                                         Application_Id = d.Application_Id,
                                         Doc_Type_Id = d.Doc_Type_Id,
                                         Doc_Type_Desc = dt.Doc_Type_Desc,
                                         Attachment = d.Attachment,
                                         Attached_On = d.Attached_On,
                                         Attached_By = d.Attached_By,
                                         Attached_By_UserName = u.UserName
                                     }).ToList();

                    response.Status = "Success";
                    response.Response = documents;
                }
            }
            catch (Exception ex)
            {
                response.Status = "Error";
                response.STCDescription = ex.Message;
            }

            return response;
        }
        public ResponseModel GetCredAppDocumentByDocId(long documentId)
        {
            ResponseModel response = new ResponseModel();

            try
            {
                using (var ctx = new NPMDBEntities())
                {
                    var document = ctx.Cred_App_Docs.FirstOrDefault(d => d.Cred_App_Doc_Id == documentId && d.Deleted == false);



                    response.Status = "Success";
                    response.Response = document;
                }
            }
            catch (Exception ex)
            {
                response.Status = "Error";
                response.STCDescription = ex.Message;
            }

            return response;
        }
        public ResponseModel DeleteCredAppDocument(long documentId)
        {
            var response = new ResponseModel();

            try
            {
                using (var db = new NPMDBEntities())
                {
                    var doc = db.Cred_App_Docs
                                .FirstOrDefault(x => x.Cred_App_Doc_Id == documentId && (x.Deleted == false || x.Deleted == null));

                    if (doc == null)
                    {
                        response.Status = "error";
                        response.STCDescription = "Document not found.";
                        return response;
                    }

                    string fileName = doc.Attachment;
                    string folder = ConfigurationManager.AppSettings["CredAppDocuments"];
                    string fullPath = HttpContext.Current.Server.MapPath($"~/{folder}/{fileName}");


                    if (System.IO.File.Exists(fullPath))
                    {
                        System.IO.File.Delete(fullPath);
                    }

                    doc.Deleted = true;


                    db.SaveChanges();

                    response.Status = "success";
                    response.STCDescription = "Document deleted successfully.";
                    response.Response = documentId;
                }
            }
            catch (Exception ex)
            {
                response.Status = "error";
                response.STCDescription = ex.Message;
            }

            return response;
        }


        public ResponseModel GetUsersByModuleName(string moduleName)
        {
            ResponseModel response = new ResponseModel();

            using (var db = new NPMDBEntities())
            {
                var module = db.Modules
                               .FirstOrDefault(m => m.Module_Name.ToLower() == moduleName.ToLower());

                if (module == null)
                {
                    response.Status = "Module not found";
                    response.Response = new List<object>();
                    return response;
                }

                long moduleId = module.Module_Id;


                var activeUsers = db.Users
                    .Where(u => (u.IsDeleted == false || u.IsDeleted == null) && u.IsActive == true);


                var userModuleUsers =
                    activeUsers.Join(db.Users_Module_Properties,
                        u => u.UserId,
                        ump => ump.UserId,
                        (u, ump) => new { u.UserId, u.UserName, u.FirstName, u.LastName, ModuleId = ump.ModuleId })
                    .Where(x => x.ModuleId == moduleId)
                    .Select(x => new { x.UserId, x.UserName, x.FirstName, x.LastName });


                var roleModuleUsers =
                    activeUsers.Join(db.Roles_Module_Properties,
                        u => u.RoleId,
                        rmp => rmp.Role_Id,
                        (u, rmp) => new { u.UserId, u.UserName, u.FirstName, u.LastName, ModuleId = rmp.Module_Id })
                    .Where(x => x.ModuleId == moduleId)
                    .Select(x => new { x.UserId, x.UserName, x.FirstName, x.LastName });

                var users = userModuleUsers
                    .Union(roleModuleUsers)
                    .Distinct()
                    .ToList();

                response.Status = "Success";
                response.Response = users;
                return response;
            }
        }
        public ResponseModel GetUserListByRole(string Role, long practiceId)
        {
            ResponseModel responseModel = new ResponseModel();
            try
            {
                using (var ctx = new NPMDBEntities())
                {
                    var results = ctx.Database.SqlQuery<UserViewDto>(
                              "EXEC USP_GETUsersListByRole @RoleName, @PracticeCode",
                                new System.Data.SqlClient.SqlParameter("@RoleName", (object)Role ?? DBNull.Value),
                                 new System.Data.SqlClient.SqlParameter("@PracticeCode", (object)practiceId ?? DBNull.Value)
                                 ).ToList();
                    responseModel.Status = "Success";
                    //if (Role == "Credentialing")
                    //{
                    //    results = results.Where(r => r.UserId == userId).ToList();
                    //}
                    responseModel.Response = results;
                }

            }
            catch (Exception ex)
            {
                responseModel.Status = "Failed";
                responseModel.STCDescription = ex.Message;

            }
            return responseModel;
        }
        #region Reprts

        public ResponseModel CredAppReport(long practiceCode,int? objTypeId)
        {
            ResponseModel response = new ResponseModel();
            try
            {
                using (var ctx = new NPMDBEntities())
                {

                    var results = ctx.Database.SqlQuery<SP_Cred_App_Report_Result>(
                            "EXEC SP_Credentialing_Report " +
                            "@Practice_Code,@Obj_Type_Id",

                            new System.Data.SqlClient.SqlParameter("@Practice_Code", (object)practiceCode ?? DBNull.Value),
                            new System.Data.SqlClient.SqlParameter("@Obj_Type_Id", (object)objTypeId ?? DBNull.Value)
                     
                        ).ToList();
                   

                    response.Status = "Success";
                    response.Response = results;
                }
            }
            catch (Exception ex)
            {
                response.Status = "Failed";
                response.STCDescription = ex.Message;
            }

            return response;
        }
        #endregion




        public ResponseModel GetCredTasks(long? PracticeCode, long? UserId,int? Obj_Type_Id)
        {
            ResponseModel responseModel = new ResponseModel();
            try
            {
                using (var ctx = new NPMDBEntities())
                {
                    var results = ctx.Database.SqlQuery<CredentialingTasksViewModel>(
                          "EXEC USP_Credentialing_Tasks " +
                              "@PracticeCode,@AssignedUserId,@ObjTypeId ",
                              new System.Data.SqlClient.SqlParameter("@PracticeCode", (object)PracticeCode ?? DBNull.Value),
                              new System.Data.SqlClient.SqlParameter("@AssignedUserId", (object)UserId ?? DBNull.Value),
                              new System.Data.SqlClient.SqlParameter("@ObjTypeId", (object)Obj_Type_Id ?? DBNull.Value)).ToList();
                    responseModel.Status = "Success";
                    responseModel.Response = results;
                }


            }
            catch (Exception ex)
            {
                responseModel.Status = "Failed";
                responseModel.STCDescription = ex.Message;

            }
            return responseModel;
        }
        public ResponseModel GetUserByRole(string Role, long userId)
        {
            ResponseModel responseModel = new ResponseModel();
            try
            {
                using(var ctx = new NPMDBEntities())
                {
                  var  results = ctx.Database.SqlQuery<UserViewDto>(
                           "EXEC USP_GETCredUsersByRole " +
                              "@RoleName",
                              new System.Data.SqlClient.SqlParameter("@RoleName", (object)Role ?? DBNull.Value)).ToList();
                    responseModel.Status = "Success";
                    if(Role== "Credentialing")
                    {
                        results = results.Where(r => r.UserId == userId).ToList();
                    }
                    responseModel.Response = results;
                }

            }
            catch (Exception ex)
            {
                responseModel.Status = "Failed";
                responseModel.STCDescription = ex.Message;

            }
            return responseModel;
        }
    }

}