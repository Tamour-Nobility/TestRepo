﻿using EdiFabric.Core.Model.Edi.X12;
using Microsoft.AspNet.SignalR;
using Microsoft.AspNet.SignalR.Hosting;
using NPMAPI.Models;
using NPMAPI.Models.ViewModels;
using NPMAPI.Repositories;
using Org.BouncyCastle.Asn1.Ocsp;
using System.Globalization;
using NPMAPI.Models.InboxHealth;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Dynamic;
using System.Linq;

namespace NPMAPI.Services
{
    public class PaymentsService : IPaymentsRepository
    {

        private IDeltaSyncRepository _deltaSyncRepository;
        public PaymentsService(IDeltaSyncRepository deltaSyncRepository)
        {
            _deltaSyncRepository = deltaSyncRepository;
        }

        public ResponseModel AddInsurancePayment(InsurancePaymentViewModel request)
        {
            ResponseModel objResponse = new ResponseModel();
            BATCHPAYMENT objModel = null;
            try
            {

                using (var ctx = new NPMDBEntities())
                {
                    objModel = new BATCHPAYMENT();
                    long BatchNo = Convert.ToInt64(ctx.SP_TableIdGenerator("BatchNo").FirstOrDefault().ToString());
                    objModel.BatchNo = BatchNo;
                    objModel.InsuranceID = request.InsuranceID;
                    objModel.PaymentTypeID = request.PaymentTypeID;
                    objModel.FacilityID = request.FacilityID;
                    objModel.DepositDate = request.DepositDate;
                    objModel.Amount = request.Amount;
                    objModel.CheckDate = request.CheckDate;
                    objModel.CheckNo = request.CheckNo;
                    objModel.EOBDate = request.EOBDate;
                    objModel.ReceivedDate = request.ReceivedDate;
                    objModel.NOtes = request.NOtes;
                    objModel.practice_code = request.prac_code;
                    objModel.PostedAmount = 0;


                    ctx.BATCHPAYMENTS.Add(objModel);
                    ctx.SaveChanges();
                    objResponse.Response = request.BatchNo;
                    objResponse.Status = "Success";


                }
            }
            catch (Exception ex)
            {
                objResponse.Status = "Error";
            }
            return objResponse;
        }
        public ResponseModel AddPatientPayment(PatientPayment request)
        {
            ResponseModel objResponse = new ResponseModel();
            BATCHPAYMENT objModel = null;
            try
            {
                using (var ctx = new NPMDBEntities())
                {





                    objModel = new BATCHPAYMENT();
                    long BatchNo = Convert.ToInt64(ctx.SP_TableIdGenerator("BatchNo").FirstOrDefault().ToString());
                    objModel.BatchNo = BatchNo;
                    objModel.PatientName = request.PatientName;
                    objModel.PaymentTypeID = request.PaymentTypeID;
                    objModel.FacilityID = request.FacilityID;
                    objModel.DepositDate = request.DepositDate;
                    objModel.Amount = request.Amount;
                    objModel.PatientAccount = request.PatientAccount;
                    objModel.CheckDate = request.CheckDate;
                    objModel.CheckNo = request.CheckNo;
                    objModel.practice_code = request.prac_code;
                    objModel.PostedAmount = 0;
                    objModel.NOtes = null;
                    objModel.EOBDate = null;
                    objModel.ReceivedDate = null;
                    objModel.InsuranceID = null;

                    ctx.BATCHPAYMENTS.Add(objModel);
                    ctx.SaveChanges();
                    objResponse.Response = request.BatchNo;
                    objResponse.Status = "Success";


                }
            }
            catch (Exception ex)
            {
                objResponse.Status = "Error";
            }
            return objResponse;
        }

        public List<SelectListViewModel> GetPaymentList()
        {
            try
            {
                using (var ctx = new NPMDBEntities())
                {
                    return ctx.PaymentTypes.Select(paymenttype =>
                         new SelectListViewModel()
                         {
                             Id = paymenttype.PaymentTypeID,
                             Name = paymenttype.PaymentType1,
                             Meta = paymenttype.PaymentSource

                         }
                     ).ToList();
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public ResponseModel SearchPayment(PaymentsSearchRequestModel SearchModel)
        {
            ResponseModel objResponse = new ResponseModel();
            try
            {
                List<uspGetAllPaymentbySearch_Result> objpaymnetList = null;
                using (var ctx = new NPMDBEntities())
                {
                    objpaymnetList = ctx.uspGetAllPaymentbySearch((SearchModel.paymentFrom == null ? "" : SearchModel.paymentFrom), (SearchModel.CheckNo == null ? "" : SearchModel.CheckNo), (SearchModel.FacilityId == null ? "" : SearchModel.FacilityId), (SearchModel.postedBy == null ? "" : SearchModel.postedBy), (SearchModel.BatchNo == null ? "" : SearchModel.BatchNo), (SearchModel.paymentId == null ? "" : SearchModel.paymentId), (SearchModel.PatientName == null ? "" : SearchModel.PatientName), (SearchModel.InsuranceId == null ? "" : SearchModel.InsuranceId), (SearchModel.PaymentType == null ? "" : SearchModel.PaymentType), (SearchModel.PaymentStatus == null ? "" : SearchModel.PaymentStatus), (SearchModel.PaymentDateFrom == null ? "" : SearchModel.PaymentDateFrom), (SearchModel.PaymentDateTo == null ? "" : SearchModel.PaymentDateTo), (SearchModel.practice_code == null ? "" : SearchModel.practice_code)).ToList();
                }

                if (objpaymnetList != null)
                {
                    objResponse.Status = "Sucess";
                    objResponse.Response = objpaymnetList;
                }
                else
                {
                    objResponse.Status = "No Data Found";
                }
                return objResponse;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public ResponseModel GetClaimsSummary(string ClaimId, string practiceCode)
        {
            ResponseModel objResponse = new ResponseModel();
            try
            {
                List<SP_GetClaimById_Result> objclaimId = null;

                using (var ctx = new NPMDBEntities())
                {

                    var response = GetClaimsbyid(ClaimId, practiceCode);

                    if (response.Status == "success")
                    {
                        if (response.Response.Count > 0)
                        {
                            var statementsList = response.Response;
                            objclaimId = statementsList;
                        }

                    }
                    objResponse.Status = "Sucess";
                    objResponse.Response = objclaimId;


                }
            }
            catch (Exception)
            {
                objResponse.Status = "Error";
            }
            return objResponse;
        }
        public ResponseModel GetClaimBypatientdetials(patientBasedClaimModel request)
        {
            ResponseModel objResponse = new ResponseModel();
            try
            {
                List<SP_Claim_patientbysearch_Result> objPatientClaim = null;

                using (var ctx = new NPMDBEntities())
                {

                    objPatientClaim = ctx.SP_Claim_patientbysearch((request.practiceCode == null ? "" : request.practiceCode), (request.PatientAccount == null ? "" : request.PatientAccount), (request.FacilityCode == null ? "" : request.FacilityCode), (request.Balance == 0 ? "" : request.Balance.ToString())).ToList();
                    objResponse.Status = "Sucess";
                    objResponse.Response = objPatientClaim;


                }
            }
            catch (Exception)
            {
                objResponse.Status = "Error";
            }
            return objResponse;
        }

        public ResponseModel GetClaimByinsdetials(insBasedClaimModel request)
        {
            ResponseModel objResponse = new ResponseModel();
            try
            {
                List<SP_Claim_Insurancebysearch_Result> objinsClaim = null;

                using (var ctx = new NPMDBEntities())
                {

                    objinsClaim = ctx.SP_Claim_Insurancebysearch((request.practiceCode == null ? "" : request.practiceCode), (request.insId == null ? "" : request.insId), (request.FacilityCode == null ? "" : request.FacilityCode), (request.Balance == 0 ? "" : request.Balance.ToString()), (request.dateFrom == null ? "" : request.dateFrom), (request.dateTo == null ? "" : request.dateTo)).ToList();
                    objResponse.Status = "Sucess";
                    objResponse.Response = objinsClaim;
                }
            }
            catch (Exception)
            {
                objResponse.Status = "Error";
            }
            return objResponse;
        }

        public ResponseModel PostClaims(postClaim request)
        {

            ResponseModel objResponse = new ResponseModel();
            string[] claims = null;

            claims = request.claimNo.Split(',');

            try
            {
                using (var ctx = new NPMDBEntities())
                {
                    for (int i = 0; i < claims.Length; i++)
                    {
                        long BatchPatientClaimId = Convert.ToInt64(ctx.SP_TableIdGenerator("BatchPatientClaimId").FirstOrDefault().ToString());
                        ctx.BatchPatientClaims.Add(new BatchPatientClaim
                        {
                            BatchPatientClaimId = BatchPatientClaimId,
                            BatchNo = request.batchNo,
                            ClaimNo = Convert.ToInt64(claims[i])
                        });

                    }
                    ctx.SaveChanges();

                    var result = ctx.BATCHPAYMENTS.FirstOrDefault(p => p.BatchNo == request.batchNo);
                    if (result != null)
                    {
                        result.PostedAmount = request.postAmount;
                        ctx.SaveChanges();
                    }

                    objResponse.Status = "Sucess";
                }


            }
            catch (Exception)
            {
                objResponse.Status = "Error";
            }
            return objResponse;

        }

        public ResponseModel getClaimsDetails(long claimNo, long patientaccount)
        {


            ClaimsPaymentDetailModel claimsPaymentDetailModel = new ClaimsPaymentDetailModel();
            ResponseModel objResponse = new ResponseModel();
            try
            {

                using (var ctx = new NPMDBEntities())
                {
                    #region Claim Model
                    claimsPaymentDetailModel.ClaimModel = ctx.Claims.SingleOrDefault(c => c.Claim_No == claimNo && (c.Deleted == null || c.Deleted == false));
                    claimsPaymentDetailModel.ClaimModel.Facility_Name = (from c in ctx.Claims
                                                                         join f in ctx.Facilities on c.Facility_Code equals f.Facility_Code
                                                                         where c.Claim_No == claimNo
                                                                         select f.Facility_Name).FirstOrDefault();

                    #endregion


                    claimsPaymentDetailModel.claimPayments = (from ci in ctx.Claim_Payments
                                                              join ins in ctx.Insurances on ci.Insurance_Id equals ins.Insurance_Id into ps
                                                              from pp in ps.DefaultIfEmpty()
                                                              join inp in ctx.Insurance_Payers on pp.InsPayer_Id equals inp.Inspayer_Id into uc
                                                              from c in uc.DefaultIfEmpty()
                                                              where (ci.Deleted ?? false) == false && (ci.Claim_No == claimNo)
                                                              select new ClaimPaymentViewModel()
                                                              {
                                                                  claimPayments = ctx.Claim_Payments.Where(ici => ici.Claim_No == claimNo && ici.claim_payments_id == ci.claim_payments_id).FirstOrDefault(),
                                                                  InsurancePayerName = c.Inspayer_Description
                                                              }).OrderBy(p => p.claimPayments.Date_Entry).ToList();


                    claimsPaymentDetailModel.claimInusrance = (from ci in ctx.Claim_Insurance
                                                               join ins in ctx.Insurances on ci.Insurance_Id equals ins.Insurance_Id
                                                               join inp in ctx.Insurance_Payers on ins.InsPayer_Id equals inp.Inspayer_Id
                                                               join g in ctx.Guarantors on ci.Subscriber equals g.Guarantor_Code into uc
                                                               from c in uc.DefaultIfEmpty()
                                                               where (ci.Deleted ?? false) == false && (ci.Claim_No == claimNo)
                                                               select new ClaimInsuranceViewModel()
                                                               {
                                                                   claimInsurance = ctx.Claim_Insurance.Where(ici => ici.Claim_No == claimNo && ici.Claim_Insurance_Id == ci.Claim_Insurance_Id).FirstOrDefault(),
                                                                   InsurancePayerName = inp.Inspayer_Description,
                                                                   SubscriberName = c.Guarant_Fname + " " + c.Guarant_Lname
                                                               }).OrderBy(i => i.claimInsurance.Pri_Sec_Oth_Type.ToLower() == "o").ThenBy(i => i.claimInsurance.Pri_Sec_Oth_Type.ToLower() == "s").ThenBy(i => i.claimInsurance.Pri_Sec_Oth_Type.ToLower() == "p").ToList();


                    claimsPaymentDetailModel.claimCharges = ctx.Claim_Charges.Where(ci => ci.Claim_No == claimNo && (ci.Deleted == null || ci.Deleted == false)).Select(svm => new ClaimChargesViewModel { amt = "", Description = ctx.Procedures.FirstOrDefault(p => p.ProcedureCode == svm.Procedure_Code).ProcedureDescription, claimCharges = ctx.Claim_Charges.Where(ci => ci.Claim_No == claimNo && ci.claim_charges_id == svm.claim_charges_id).FirstOrDefault() }).OrderBy(c => c.claimCharges.Sequence_No).ToList();
                    for (int i = 0; i < claimsPaymentDetailModel.claimCharges.Count(); i++)
                    {
                        var dCode1 = claimsPaymentDetailModel.claimCharges[i].claimCharges.Drug_Code;
                        try
                        {
                            if (claimsPaymentDetailModel.claimCharges[i].claimCharges.Drug_Code != null && claimsPaymentDetailModel.claimCharges[i].claimCharges.Drug_Code.Length > 5)
                            {
                                var dCode = (claimsPaymentDetailModel.claimCharges[i].claimCharges.Drug_Code)?.Insert(5, "-");
                                if (dCode.Length >= 10)
                                    dCode1 = dCode?.Insert(10, "-");
                            }
                        }
                        catch (Exception ex)
                        {
                            NPMLogger.GetInstance().Error(ex.ToString());
                        }
                        claimsPaymentDetailModel.claimCharges[i].Drug_Code = dCode1;
                        claimsPaymentDetailModel.claimCharges[i].claimCharges.Drug_Code = claimsPaymentDetailModel.claimCharges[i].claimCharges.Drug_Code;
                    }

                    if (claimsPaymentDetailModel != null && claimsPaymentDetailModel.claimCharges != null)
                    {
                        foreach (var item in claimsPaymentDetailModel.claimCharges)
                        {
                            var maxDate = Convert.ToDateTime("10/01/2015");
                            var ndcModel = ctx.NDC_CrossWalk.Where(scf => scf.HCPCS_Code == item.claimCharges.Procedure_Code && scf.Effective_Date_To >= maxDate).ToList();
                            item.claimCharges.NDCCodeList = new List<SelectListViewModel>();
                            foreach (var nItem in ndcModel)
                            {
                                SelectListViewModel objmodel = new SelectListViewModel();
                                objmodel.Id = nItem.NDC_ID;
                                objmodel.Name = nItem.NDC2;
                                objmodel.Meta = new ExpandoObject();
                                objmodel.Meta.Qualifier = nItem.Qualifier;
                                item.claimCharges.NDCCodeList.Add(objmodel);
                            }
                        }
                    }


                }
                objResponse.Response = claimsPaymentDetailModel;
                objResponse.Status = "Sucess";

            }

            catch (Exception)
            {
                objResponse.Status = "Error";
            }
            return objResponse;

        }

        public ResponseModel SaveClaimsDetails(ClaimsPaymentDetailModel[] cpd)
        {

            ResponseModel objResponse = new ResponseModel();
            bool isInsuranceChanged = false;
            double postAmount = 0.00;
            long batch_no = 0;
            foreach (var c in cpd)
            {
                ClaimsPaymentDetailModel UpdateClaim = c;
                batch_no = c.batch_no;
                try
                {
                    using (var db = new NPMDBEntities())
                    {
                        using (db.Database.BeginTransaction())
                        {




                            var originalclaim = db.Claims.Where(x => x.Claim_No == UpdateClaim.claims_no).FirstOrDefault();


                            if (originalclaim != null)
                            {
                                if (UpdateClaim.claimPayments != null)
                                {
                                    originalclaim.Pri_Ins_Payment = 0;
                                    originalclaim.Sec_Ins_Payment = 0;
                                    originalclaim.Oth_Ins_Payment = 0;
                                    originalclaim.Patient_Payment = 0;
                                    originalclaim.Amt_Paid = 0;
                                    originalclaim.Adjustment = 0;
                                    for (int i = 0; i < UpdateClaim.claimPayments.Count(); i++)
                                    {
                                        if (!(UpdateClaim.claimPayments[i].claimPayments.Deleted ?? false))
                                        {
                                            if (UpdateClaim.claimPayments[i].claimPayments.Payment_Source == "1")
                                                originalclaim.Pri_Ins_Payment += UpdateClaim.claimPayments[i].claimPayments.Amount_Paid != null ? UpdateClaim.claimPayments[i].claimPayments.Amount_Paid : 0;
                                            if (UpdateClaim.claimPayments[i].claimPayments.Payment_Source == "2")
                                                originalclaim.Sec_Ins_Payment += UpdateClaim.claimPayments[i].claimPayments.Amount_Paid != null ? UpdateClaim.claimPayments[i].claimPayments.Amount_Paid : 0;
                                            if (UpdateClaim.claimPayments[i].claimPayments.Payment_Source == "3")
                                                originalclaim.Oth_Ins_Payment += UpdateClaim.claimPayments[i].claimPayments.Amount_Paid != null ? UpdateClaim.claimPayments[i].claimPayments.Amount_Paid : 0;
                                            if (UpdateClaim.claimPayments[i].claimPayments.Payment_Source == "P" || UpdateClaim.claimPayments[i].claimPayments.Payment_Source == "C" || UpdateClaim.claimPayments[i].claimPayments.Payment_Source == "I")
                                                originalclaim.Patient_Payment += UpdateClaim.claimPayments[i].claimPayments.Amount_Paid != null ? UpdateClaim.claimPayments[i].claimPayments.Amount_Paid : 0;
                                            originalclaim.Amt_Paid += UpdateClaim.claimPayments[i].claimPayments.Amount_Paid != null ? UpdateClaim.claimPayments[i].claimPayments.Amount_Paid : 0;
                                            if (UpdateClaim.claimPayments[i].claimPayments.Amount_Adjusted != null)
                                                originalclaim.Adjustment += UpdateClaim.claimPayments[i].claimPayments.Amount_Adjusted;// != null ? decimal.Parse(UpdateClaim.claimPayments[i].AmountAdjusted) : 0;
                                        }
                                    }
                                }

                                originalclaim.Amt_Due = Convert.ToDecimal(originalclaim.Claim_Total) - (Convert.ToDecimal(originalclaim.Amt_Paid) + Convert.ToDecimal(originalclaim.Adjustment));
                                if (originalclaim.Amt_Due <= 0 && originalclaim.PTL_Status != true)
                                {
                                    originalclaim.Pri_Status = "P";
                                    originalclaim.Sec_Status = "P";
                                    originalclaim.Oth_Status = "P";
                                    originalclaim.Pat_Status = "P";
                                }
                                else
                                {
                                    originalclaim.Pri_Status = "";
                                    originalclaim.Sec_Status = "";
                                    originalclaim.Oth_Status = "";
                                    originalclaim.Pat_Status = "";
                                }

                            }


                            #region claimPayments
                            if (UpdateClaim.claimPayments != null)
                            {
                                foreach (var cPaymentItem in UpdateClaim.claimPayments)
                                {
                                    var item = cPaymentItem.claimPayments;
                                    if (item.claim_payments_id == 0 && (item.Deleted != null && !(bool)item.Deleted))
                                    {
                                        Claim_Payments cp = new Claim_Payments();
                                        long iClaimPaymentsId = Convert.ToInt64(db.SP_TableIdGenerator("Claim_Payments_Id").FirstOrDefault().ToString());
                                        cp.claim_payments_id = iClaimPaymentsId;
                                        cp.Created_By = UpdateClaim.userID;
                                        cp.Created_Date = DateTime.Now;
                                        if (item.Insurance_Id != null)
                                            cp.Insurance_Id = item.Insurance_Id;
                                        cp.Payment_Source = item.Payment_Source;
                                        if (item.ENTERED_FROM != null)
                                            cp.ENTERED_FROM = item.ENTERED_FROM;
                                        else
                                            cp.ENTERED_FROM = "";
                                        cp.Date_Adj_Payment = DateTime.Now;
                                        if (item.Date_Entry != null)
                                            cp.Date_Entry = item.Date_Entry;
                                        if (item.Date_Filing != null)
                                            cp.Date_Filing = item.Date_Filing;
                                        if (item.Sequence_No != null)
                                            cp.Sequence_No = item.Sequence_No;
                                        cp.Charged_Proc_Code = item.Charged_Proc_Code;
                                        cp.Paid_Proc_Code = item.Paid_Proc_Code;
                                        if (item.Units != null)
                                            cp.Units = item.Units;
                                        cp.MODI_CODE1 = item.MODI_CODE1;
                                        cp.MODI_CODE2 = item.MODI_CODE2;
                                        if (item.Amount_Approved != null)
                                            cp.Amount_Approved = item.Amount_Approved;
                                        if (item.Amount_Adjusted != null)
                                        {
                                            cp.Amount_Adjusted = item.Amount_Adjusted;
                                        }
                                        else
                                        {
                                            cp.Amount_Adjusted = 0;
                                        }
                                        if (item.Payment_Type != null)
                                            cp.Payment_Type = item.Payment_Type;
                                        else
                                            cp.Payment_Type = "";
                                        if (item.Amount_Paid != null)
                                            cp.Amount_Paid = item.Amount_Paid;
                                        cp.Claim_No = UpdateClaim.claims_no;
                                        cp.ERA_ADJUSTMENT_CODE = item.ERA_ADJUSTMENT_CODE;
                                        cp.ERA_Rejection_CATEGORY_CODE = item.ERA_Rejection_CATEGORY_CODE;
                                        cp.Payment_No = 123;
                                        cp.BATCH_NO = item.BATCH_NO;
                                        if (item.DEPOSITSLIP_ID != null)
                                            cp.DEPOSITSLIP_ID = item.DEPOSITSLIP_ID;
                                        if (item.BATCH_DATE != null)
                                            cp.BATCH_DATE = item.BATCH_DATE;
                                        cp.Details = item.Details;
                                        cp.Check_No = item.Check_No;
                                        if (item.Reject_Amount != null)
                                            cp.Reject_Amount = item.Reject_Amount;
                                        cp.Reject_Type = item.Reject_Type;
                                        if (item.DepositDate != null)
                                            cp.DepositDate = item.DepositDate;



                                        db.Claim_Payments.Add(cp);
                                        if (!string.IsNullOrEmpty(cp.Insurance_Id.ToString()))
                                        {
                                            //////////var result = db.Database.SqlQuery<string>("select top 1 call_status from calls where call_claim_no='" + UpdateClaim.claimNo + "'   and Call_Insurance_Id='" + cp.Insurance_Id + "'   and Call_Status in('IP','WT')   and isnull(Call_Deleted,0)=0 ").FirstOrDefault();
                                            //////////if (!string.IsNullOrEmpty(result))
                                            //////////{
                                            //////////    if (result.Trim() == "IP" || result.Trim() == "WT")
                                            //////////    {
                                            //////////        db.Database.ExecuteSqlCommand("update calls set call_status='DP' where call_claim_no='" + UpdateClaim.claimNo + "'  and Call_Status in('IP','WT') ");
                                            //////////        res.callmsg = true;
                                            //////////    }
                                            //////////}
                                        }
                                        //string count = "select count(*) from calls where Call_Claim_No='" + UpdateClaim.claimNo + "' and Call_Status in('IP','WT')  and isnull(Call_Deleted,0)=0 ";
                                        //var k = db.Database.SqlQuery<int>(count).Single();
                                        //if (k > 0)
                                        //{
                                        //    string dropCall = "update calls set Call_Status='DP' where call_claim_no='" + UpdateClaim.claimNo + "' and call_status in ('IP','WT') and isnull(call_deleted,0)=0";
                                        //    db.Database.ExecuteSqlCommand(dropCall);
                                        //}
                                    }
                                    else
                                    {
                                        var cp = db.Claim_Payments.Find(item.claim_payments_id);
                                        if (cp != null)
                                        {
                                            if (item.Deleted != null && (bool)item.Deleted)
                                            {
                                                cp.Deleted = true;
                                            }
                                            if (item.IsRectify != null && (bool)item.IsRectify)
                                            {
                                                cp.IsRectify = true;
                                            }
                                            cp.Payment_Source = item.Payment_Source;
                                            if (item.Insurance_Id != null)
                                                cp.Insurance_Id = item.Insurance_Id;
                                            else
                                                cp.Insurance_Id = null;
                                            if (item.ENTERED_FROM != null)
                                                cp.ENTERED_FROM = item.ENTERED_FROM;
                                            else
                                                item.ENTERED_FROM = "";
                                            if (item.Date_Entry != null)
                                                cp.Date_Entry = item.Date_Entry;
                                            if (item.Date_Filing != null)
                                                cp.Date_Filing = item.Date_Filing;
                                            if (item.Sequence_No != null)
                                                cp.Sequence_No = item.Sequence_No;
                                            cp.Charged_Proc_Code = item.Charged_Proc_Code;
                                            cp.Paid_Proc_Code = item.Paid_Proc_Code;
                                            if (item.Payment_Type != null)
                                                cp.Payment_Type = item.Payment_Type;
                                            else
                                                item.Payment_Type = "";
                                            if (item.Units != null)
                                                cp.Units = item.Units;
                                            cp.MODI_CODE1 = item.MODI_CODE1;
                                            cp.MODI_CODE2 = item.MODI_CODE2;
                                            if (item.Amount_Approved != null)
                                            {
                                                cp.Amount_Approved = item.Amount_Approved;
                                            }
                                            else
                                            {
                                                cp.Amount_Approved = 0;
                                            }
                                            if (item.Amount_Adjusted != null)
                                            {
                                                cp.Amount_Adjusted = item.Amount_Adjusted;
                                            }
                                            else
                                            {
                                                cp.Amount_Adjusted = 0;
                                            }

                                            if (item.Amount_Paid != null)
                                            {
                                                cp.Amount_Paid = item.Amount_Paid;
                                            }
                                            else
                                            {
                                                cp.Amount_Paid = 0;
                                            }
                                            cp.ERA_ADJUSTMENT_CODE = item.ERA_ADJUSTMENT_CODE;
                                            cp.ERA_Rejection_CATEGORY_CODE = item.ERA_Rejection_CATEGORY_CODE;
                                            cp.Payment_No = 123;
                                            cp.Modified_By = UpdateClaim.userID;
                                            cp.Modified_Date = DateTime.Now;
                                            cp.BATCH_NO = item.BATCH_NO;
                                            if (item.DEPOSITSLIP_ID != null)
                                                cp.DEPOSITSLIP_ID = item.DEPOSITSLIP_ID;
                                            if (item.BATCH_DATE != null)
                                                cp.BATCH_DATE = item.BATCH_DATE;
                                            cp.Details = item.Details;
                                            cp.Check_No = item.Check_No;
                                            cp.Reject_Type = item.Reject_Type;
                                            if (item.Reject_Amount != null)
                                                cp.Reject_Amount = item.Reject_Amount;
                                            if (item.DepositDate != null)
                                                cp.DepositDate = item.DepositDate;
                                        }
                                    }

                                    db.SaveChanges();
                                }
                            }
                            #endregion claimPayments

                            postAmount = c.PostedAmount;
                            long BatchPatientClaimId = Convert.ToInt64(db.SP_TableIdGenerator("BatchPatientClaimId").FirstOrDefault().ToString());
                            db.BatchPatientClaims.Add(new BatchPatientClaim
                            {
                                BatchPatientClaimId = BatchPatientClaimId,
                                BatchNo = c.batch_no,
                                ClaimNo = Convert.ToInt64(c.claims_no)
                            });
                            db.SaveChanges();




                            db.Database.CurrentTransaction.Commit();
                            objResponse.Status = "Sucess";


                        }

                    }
                }
                catch (Exception)
                {
                    objResponse.Status = "Error";
                }

            }
            try
            {

                using (var db = new NPMDBEntities())
                {
                    var result = db.BATCHPAYMENTS.FirstOrDefault(p => p.BatchNo == batch_no);
                    if (result != null)
                    {
                        result.PostedAmount = Convert.ToDecimal(postAmount);
                        db.SaveChanges();
                    }
                }

            }
            catch (Exception)
            {
                objResponse.Status = "Error";
            }



            return objResponse;

        }


        public ResponseModel checkPostedClaims(long batchno, long practiceCode)
        {
            List<SP_GetClaimById_Result> objclaimId = null;
            ResponseModel objResponse = new ResponseModel();
            List<BatchPatientClaim> myClaims = new List<BatchPatientClaim>();

            string[] claims = { };

            try
            {
                using (var db = new NPMDBEntities())
                {
                    claims = db.BatchPatientClaims.Where(b => b.BatchNo == batchno).Select(b => b.ClaimNo.ToString()).ToArray();

                    if (claims.Length > 0)
                    {
                        string claimsNO = string.Join(",", claims);



                        var response = GetClaimsbyidforChecking(claimsNO, practiceCode.ToString());

                        if (response.Status == "success")
                        {
                            if (response.Response.Count > 0)
                            {
                                var statementsList = response.Response;
                                objclaimId = statementsList;
                                foreach (var c in objclaimId)
                                {
                                    c.isPosted = true;

                                }
                            }

                        }
                        objResponse.Status = "Sucess";
                        objResponse.Response = objclaimId;
                    }



                }


            }
            catch (Exception)
            {
                objResponse.Status = "Error";
            }
            return objResponse;

        }

        private string GetClaimPOS(List<Claim_Charges> claimCharges)
        {
            try
            {
                var charges = claimCharges?.Where(cc => (cc.Deleted ?? false) == false).OrderBy(c => c.Created_Date).FirstOrDefault();
                if (charges == null)
                {
                    return "";
                }
                else
                {
                    return (charges.POS != null && charges.POS != 0) ? charges.POS.ToString() : "";

                }
            }
            catch (Exception)
            {
                throw;
            }

        }

        private ResponseModel GetClaimsbyid(string claimsid, string prac_code)
        {
            List<SP_GetClaimById_Result> claimsList = new List<SP_GetClaimById_Result>();
            ResponseModel res = new ResponseModel();
            try
            {
                using (var db = new NPMDBEntities())
                {


                    claimsList.AddRange(
                            db.Database.SqlQuery<SP_GetClaimById_Result>("SP_GetclaimbymultiIDS @ClaimId,@practiceCode", parameters: new[] {
                                new SqlParameter("@ClaimId", claimsid),
                                new SqlParameter("@practiceCode", prac_code),

                            }).ToList());
                    res.Status = "success";
                    res.Response = claimsList;

                }
            }
            catch (Exception)
            {
                throw;
            }
            return res;
        }


        private ResponseModel GetClaimsbyidforChecking(string claimsid, string prac_code)
        {
            List<SP_GetClaimById_Result> claimsList = new List<SP_GetClaimById_Result>();
            ResponseModel res = new ResponseModel();
            try
            {
                using (var db = new NPMDBEntities())
                {


                    claimsList.AddRange(
                            db.Database.SqlQuery<SP_GetClaimById_Result>("SP_GetclaimbymultiIDSforchecking @ClaimId,@practiceCode", parameters: new[] {
                                new SqlParameter("@ClaimId", claimsid),
                                new SqlParameter("@practiceCode", prac_code),

                            }).ToList());
                    res.Status = "success";
                    res.Response = claimsList;

                }
            }
            catch (Exception)
            {
                throw;
            }
            return res;
        }

        //payment posting batch wise - Pir Ubaid

        public ResponseModel CreateUpdateBatch(BatchCreateModel batchData, long userId)
        {
            ResponseModel response = new ResponseModel();

            // Validate input
            if (batchData == null)
            {
                response.Status = "Error";
                response.Response = "Invalid batch data.";
                return response;
            }
            try
            {
                using (var db = new NPMDBEntities())
                {
                    using (var ctx = new NPMDBEntities())
                    {
                        using (var transaction = ctx.Database.BeginTransaction())
                        {
                            try
                            {
                                long batchId = 0;
                                // Check if the batch already exists in the BATCHWISEPAYMENTS table
                                var existingBatch = db.Batch_WisePayments.FirstOrDefault(x => x.BatchID == batchData.BatchID && (x.Deleted == null || x.Deleted == false));

                                if (existingBatch != null)
                                {
                                    batchId = existingBatch.BatchID;
                                    // Update existing batch
                                    existingBatch.BatchType = batchData.BatchType;
                                    existingBatch.Practice_Code = batchData.Practice_Code;
                                    existingBatch.PaymentType = batchData.PaymentType;
                                    existingBatch.CheckNo = batchData.CheckNo;
                                    existingBatch.CheckDate = batchData.CheckDate;
                                    existingBatch.FileName = batchData.FileName;
                                    existingBatch.BatchOpenDate = batchData.BatchOpenDate;
                                    existingBatch.DepositDate = batchData.DepositDate;
                                    existingBatch.ReceivedDate = batchData.ReceivedDate;
                                    existingBatch.NOtes = batchData.NOtes;
                                    existingBatch.BatchAmount = batchData.BatchAmount;
                                    existingBatch.modified_by = userId;
                                    existingBatch.date_modified = DateTime.Now;
                                    //existingBatch.Batch_Status = batchData.BatchStatus;
                                    existingBatch.Remaining_Amount = batchData.RemainingAmount;
                                    existingBatch.Posted_Amount = batchData.PostedAmount;
                                }
                                else
                                {
                                    // Create new batch
                                    var newBatch = new Batch_WisePayments
                                    {
                                        BatchID = Convert.ToInt64(ctx.SP_TableIdGenerator("BatchID").FirstOrDefault().ToString()),
                                        Practice_Code = batchData.Practice_Code,
                                        BatchType = batchData.BatchType,
                                        PaymentType = batchData.PaymentType,
                                        CheckNo = batchData.CheckNo,
                                        CheckDate = batchData.CheckDate,
                                        FileName = batchData.FileName,
                                        BatchOpenDate = batchData.BatchOpenDate,
                                        DepositDate = batchData.DepositDate,
                                        ReceivedDate = batchData.ReceivedDate,
                                        NOtes = batchData.NOtes,
                                        BatchAmount = batchData.BatchAmount,
                                        created_by = userId,
                                        date_created = DateTime.Now,
                                        Batch_Status = batchData.BatchStatus,
                                        Remaining_Amount = batchData.RemainingAmount,
                                        Posted_Amount = batchData.PostedAmount,
                                        Deleted = false
                                    };
                                    batchId = newBatch.BatchID;
                                    db.Batch_WisePayments.Add(newBatch);
                                }

                                // Save changes
                                db.SaveChanges();
                                transaction.Commit();
                                if(existingBatch != null)
                                {
                                    var batchNo = batchData.BatchID.ToString();

                                    if (!string.IsNullOrWhiteSpace(batchNo))
                        {
                            db.Database.ExecuteSqlCommand("EXEC USP_SUMPOSTEDAMOUNT @BatchNo = {0}", batchNo);
                        }
                                }
                                
                                //  Execute stored procedure with only BatchID
                                ctx.USP_GetBatchPayments(
                                    null,                                       // @PracticeCode
                                    batchData.BatchID.ToString(),               // @BatchID
                                    null, null, null, null, null, null, null,   // other params as NULL
                                    null, null, null
                                );
                                response.Status = "Success";
                                response.Response = new
                                {
                                    BatchID = batchId,
                                    Message = "Batch created/updated successfully."
                                }; 
                            }
                            catch (Exception ex)
                            {
                                // Rollback on error
                                transaction.Rollback();
                                response.Status = "Error";
                                response.Response = "Failed to process batch: " + ex.Message;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                response.Status = "Error";
                response.Response = "An unexpected error occurred: " + ex.Message;
            }

            return response;
        }

        public ResponseModel SearchBatch(BatchsSearchRequestModel SearchModel)
        {
            ResponseModel objResponse = new ResponseModel();
            try
            {
                List<USP_GetBatchPayments_Result> objPaymentList = null;

                using (var ctx = new NPMDBEntities())
                {
                    var batchstatus = "";
                    if (SearchModel.BatchStatus == "100")
                    {
                        batchstatus = "1,2";
                    }
                    else
                    {
                        batchstatus = SearchModel.BatchStatus;
                    }
                    objPaymentList = ctx.USP_GetBatchPayments(
                                string.IsNullOrWhiteSpace(SearchModel.Practice_Code) ? null : SearchModel.Practice_Code,
                                string.IsNullOrWhiteSpace(SearchModel.BatchID) ? null : SearchModel.BatchID,
                                string.IsNullOrWhiteSpace(SearchModel.FileName) ? null : SearchModel.FileName,
                                string.IsNullOrWhiteSpace(SearchModel.BatchStatus) ? null : batchstatus,
                                string.IsNullOrWhiteSpace(SearchModel.BatchType) ? null : SearchModel.BatchType,
                                string.IsNullOrWhiteSpace(SearchModel.PostedBy) ? null : SearchModel.PostedBy,
                                string.IsNullOrWhiteSpace(SearchModel.PaymentStatus) ? null : SearchModel.PaymentStatus,
                                string.IsNullOrWhiteSpace(SearchModel.BatchDateFrom) ? null : SearchModel.BatchDateFrom,
                                string.IsNullOrWhiteSpace(SearchModel.BatchDateTo) ? null : SearchModel.BatchDateTo,
                                string.IsNullOrWhiteSpace(SearchModel.PaymentType) ? null : SearchModel.PaymentType,
                                string.IsNullOrWhiteSpace(SearchModel.CheckNo) ? null : SearchModel.CheckNo,
                                 string.IsNullOrWhiteSpace(SearchModel.CheckDate) ? null : SearchModel.CheckDate
                            ).ToList();
                }

                if (objPaymentList != null && objPaymentList.Count > 0)
                {
                    objResponse.Status = "Success";
                    objResponse.Response = objPaymentList;
                }
                else
                {
                    objResponse.Status = "No Data Found";
                }
            }
            catch (Exception ex)
            {
                objResponse.Status = "Error";
                objResponse.Response = $"Exception: {ex.Message}";
            }

            return objResponse;
        }



        //
        //close batch
        public ResponseModel CloseBatch(BatchsSearchRequestModel SearchModel)
        {
            ResponseModel objResponse = new ResponseModel();
            try
            {
                using (var ctx = new NPMDBEntities())
                {
                    
                    if (long.TryParse(SearchModel.BatchID, out long batchId))
                    {
                        var batch = ctx.Batch_WisePayments.FirstOrDefault(b => b.BatchID == batchId && (b.Deleted == null || b.Deleted == false));

                        if (batch == null)
                        {
                            objResponse.Status = "Error";
                            objResponse.Response = "Batch not found.";
                            return objResponse;
                        }
                        if (batch.Batch_Status == 0)
                        {
                            objResponse.Status = "Error";
                            objResponse.Response = "Batch is already closed.";
                            return objResponse;
                        }
                        if (batch.Batch_Status == null)
                        {
                            objResponse.Status = "Error";
                            objResponse.Response = "Batch status is uninitialized.";
                            return objResponse;
                        }


                        batch.Batch_Status = 0;

                        ctx.SaveChanges();

                        objResponse.Status = "Success";
                        objResponse.Response = "Batch has been successfully closed.";
                    }
                    else
                    {
                        objResponse.Status = "Error";
                        objResponse.Response = "Invalid BatchID format.";
                    }
                }
            }
            catch (Exception ex)
            {
                objResponse.Status = "Error";
                objResponse.Response = $"Exception: {ex.Message}";
            }

            return objResponse;
        }
        //get patients
        public ResponseModel GetPatientsWithDue(bool isDueOnly, int practiceCode)
        {
            ResponseModel responseModel = new ResponseModel();
            List<PatientListViewModel> list = new List<PatientListViewModel>();
            try
            {
                using (var db = new NPMDBEntities())
                {
                    var parameters = new SqlParameter[]
                    {
                new SqlParameter("@IsDueOnly", isDueOnly),
                new SqlParameter("@PracticeCode", practiceCode)
                    };

                    var patientList = db.Database.SqlQuery<PatientResult>("exec USP_GetPatientsWithDue @IsDueOnly, @PracticeCode", parameters).ToList();
                    list = patientList.Select(p => new PatientListViewModel()
                    {
                        Id = p.Patient_Account,
                        Name = p.Last_Name + "," + p.First_Name + " | " + p.Date_Of_Birth?.ToString("MM-dd-yyyy") + " | " + p.Age + " | " + p.Gender,
                    }).ToList();

                    // Set status and response data
                    responseModel.Status = "Success";
                    responseModel.Response = list;
                    return responseModel;
                }
            }
            catch (Exception ex)
            {
                responseModel.Status = "Error";
                responseModel.Response = ex.Message;
            }

            return responseModel;
        }

        public ResponseModel GetPatientsClaims(long patient_account, bool due_only = true)
        {
            ResponseModel responseModel = new ResponseModel();
            try
            {
                using (var db = new NPMDBEntities())
                {
                    var query = db.Claims.Where(c => c.Patient_Account == patient_account);

                    if (due_only)
                    {
                        query = query.Where(c => c.Amt_Due > 0);
                    }
                    var rawClaims = query
             .Join(db.Patients,
                   c => c.Patient_Account,
                   p => p.Patient_Account,
                   (c, p) => new { c, p })
             .Select(cp => new ClaimDTO
             {
                 ClaimID = cp.c.Claim_No,
                 DOS = cp.c.DOS,
                 Adjustment = cp.c.Adjustment,
                 Amt_due = cp.c.Amt_Due,
                 Amt_Paid = cp.c.Amt_Paid,
                 Claim_Total = cp.c.Claim_Total,
                 Pri_Status = cp.c.Pri_Status,
                 Sec_Status = cp.c.Sec_Status,
                 Oth_Status = cp.c.Oth_Status,
                 Pat_Status = cp.c.Pat_Status,
                 Patient_Account = cp.p.Patient_Account,
                 PatientFirstName = cp.p.First_Name,
                 PatientLastName = cp.p.Last_Name
             })
                        .ToList();

                    List<ClaimDTO> filteredClaims = new List<ClaimDTO>();

                    // Custom US culture (negative format as $-120.00)
                    var usCulture = (CultureInfo)CultureInfo.CreateSpecificCulture("en-US").Clone();
                    usCulture.NumberFormat.CurrencyNegativePattern = 1;


                    foreach (var claim in rawClaims)
                    {
                        var amount = claim.Amt_due ?? 0;
                        string formattedAmt = string.Format(usCulture, "${0}", amount.ToString("N2", usCulture));
                        ////string formattedAmt = (claim.Amt_due ?? 0).ToString("C", usCulture);
                        // ✅ Check each status individually and build ClaimDetails
                        if ((claim.Pri_Status == "N" || claim.Pri_Status == "B" || claim.Pri_Status == "R") && claim.Amt_due > 0)
                        {
                            claim.ClaimDetails = $"{claim.ClaimID} | {claim.DOS?.ToString("MM-dd-yyyy")} | Pri Ins Due {formattedAmt}";
                            filteredClaims.Add(claim);
                            continue;
                        }

                        if ((claim.Sec_Status == "N" || claim.Sec_Status == "B" || claim.Sec_Status == "R") && claim.Amt_due > 0)
                        {
                            claim.ClaimDetails = $"{claim.ClaimID} | {claim.DOS?.ToString("MM-dd-yyyy")} | Sec Ins Due {formattedAmt}";
                            filteredClaims.Add(claim);
                            continue;
                        }

                        if ((claim.Oth_Status == "N" || claim.Oth_Status == "B" || claim.Oth_Status == "R") && claim.Amt_due > 0)
                        {
                            claim.ClaimDetails = $"{claim.ClaimID} | {claim.DOS?.ToString("MM-dd-yyyy")} | Oth Ins Due {formattedAmt}";
                            filteredClaims.Add(claim);
                            continue;
                        }

                        if ((claim.Pat_Status == "N" || claim.Pat_Status == "B" || claim.Pat_Status == "R") && claim.Amt_due > 0)
                        {
                            claim.ClaimDetails = $"{claim.ClaimID} | {claim.DOS?.ToString("MM-dd-yyyy")} | Pat Due {formattedAmt}";
                            filteredClaims.Add(claim);
                            continue;
                        }


                        else if (claim.Amt_due == 0 || claim.Amt_due < 0 || claim.Amt_due > 0)
                        {
                            claim.ClaimDetails = $" {claim.ClaimID} | {claim.DOS?.ToString("MM-dd-yyyy")} | Due Amt:{formattedAmt} ";
                            filteredClaims.Add(claim);
                        }
                    }

                    responseModel.Status = "Success";
                    responseModel.Response = filteredClaims;
                }
            }
            catch (Exception ex)
            {
                responseModel.Status = "Error";
                responseModel.Response = ex.Message;
            }

            return responseModel;
        }

        //get adjustments,calim_total,amt_paid,amt_due by claim number
        public ResponseModel GetClaimDetails(long claimID)
        {
            ResponseModel responseModel = new ResponseModel();
            try
            {
                using (var db = new NPMDBEntities())
                {
                    var claim = (from c in db.Claims
                                 join co in db.Claim_Overpayment
                                     on c.Claim_No equals co.Claim_No into coGroup
                                 from co in coGroup.DefaultIfEmpty()
                                 where c.Claim_No == claimID
                                 select new
                                 {
                                     Adjustment = c.Adjustment,
                                     Amt_paid = c.Amt_Paid,
                                     Amt_due = c.Amt_Due,
                                     Claim_total = c.Claim_Total,
                                     InsuranceOverpaid = co != null ? co.Insurance_over_paid : 0,
                                     PatientCreditBalance = co != null ? co.Patient_credit_balance : 0
                                 })
                                 .FirstOrDefault();

                    if (claim != null)
                    {
                        responseModel.Status = "Success";
                        responseModel.Response = claim;
                    }
                    else
                    {
                        responseModel.Status = "Error";
                        responseModel.Response = "Claim not found.";
                    }

                    return responseModel;
                }
            }

            catch (Exception ex)
            {
                responseModel.Status = "Error";
                responseModel.Response = ex.Message;
                return responseModel;
            }



        }

        public ResponseModel GetClaimDetailsByClaimNumber(long claimID, int practiceCode)
        {
            ResponseModel responseModel = new ResponseModel();
            try
            {
                using (var db = new NPMDBEntities())
                {
                    // Get the claim and patient details
                    var claimData = db.Claims
                        .Where(c => c.Claim_No == claimID && c.practice_code == practiceCode)
                        .Join(db.Patients,
                            c => c.Patient_Account,
                            p => p.Patient_Account,
                            (c, p) => new { Claim = c, Patient = p })
                        .FirstOrDefault();

                    if (claimData != null)
                    {
                        // Fetch payments related to the claim
                        var payments = db.Claim_Payments
                            .Where(cp => cp.Claim_No == claimID && (cp.Deleted == false || cp.Deleted == null))
                            .ToList();

                        decimal totalAdjustment = payments.Sum(p => p.Amount_Adjusted ?? 0);
                        decimal totalPaid = payments.Sum(p => p.Amount_Paid ?? 0);
                        decimal claimTotal = claimData.Claim.Claim_Total ?? 0;
                        decimal amtDue = claimTotal - (totalAdjustment + totalPaid);

                        // Fetch overpayment if exists
                        var overpayment = db.Claim_Overpayment
                            .Where(co => co.Claim_No == claimID)
                            .Select(co => new
                            {
                                co.Insurance_over_paid,    // replace with actual column name
                        co.Patient_credit_balance      // replace with actual column name
                            })
                            .FirstOrDefault();

                        var result = new
                        {
                            AccountNo = claimData.Claim.Patient_Account,
                            ClaimNo = claimData.Claim.Claim_No,
                            FirstName = claimData.Patient.First_Name,
                            LastName = claimData.Patient.Last_Name,
                            Adjustment = totalAdjustment,
                            amt_paid = totalPaid,
                            claim_Total = claimTotal,
                            amt_due = amtDue,
                            OverpaidAmount = overpayment?.Insurance_over_paid ?? 0,   // 0 if not exists
                            CreditBalance = overpayment?.Patient_credit_balance ?? 0      // 0 if not exists
                        };

                        responseModel.Status = "Success";
                        responseModel.Response = result;
                    }
                    else
                    {
                        responseModel.Status = "Error";
                        responseModel.Response = "Claim not found";
                    }
                }
            }
            catch (Exception ex)
            {
                responseModel.Status = "Error";
                responseModel.Response = ex.Message;
            }

            return responseModel;
        }
        public ResponseModel GetPostedClaims(string batchID)
        {
            ResponseModel responseModel = new ResponseModel();
            try
            {
                using (var db = new NPMDBEntities())
                {
                    var claims = (from cp in db.Claim_Payments
                                  join c in db.Claims on cp.Claim_No equals c.Claim_No
                                  join p in db.Patients on c.Patient_Account equals p.Patient_Account
                                  join bp in db.Batch_WisePayments on cp.BATCH_NO equals bp.BatchID.ToString()
                                  where cp.BATCH_NO == batchID
                                        && (cp.Deleted == null || cp.Deleted == false)
                                        && (c.Deleted == null || c.Deleted == false)
                                          && (bp.Deleted == null || bp.Deleted == false)
                                  group new { cp, c, p, bp } by new
                                  {
                                      cp.Claim_No,
                                      p.Last_Name,
                                      p.First_Name,
                                      c.DOS,
                                      bp.BatchOpenDate
                                  } into g
                                  select new
                                  {
                                      g.Key.Claim_No,
                                      PatientName = g.Key.Last_Name + ", " + g.Key.First_Name,
                                      DOS = g.Key.DOS,
                                      TotalCharge = g.Max(x => x.c.Claim_Total),
                                      Amt_Due = g.Max(x => x.c.Amt_Due),
                                      Amt_Paid = g.Sum(x => x.cp.Amount_Paid),
                                      Patient_Payment = g.Max(x => x.c.Patient_Payment),
                                      InsurancePayment = g.Max(x => (x.c.Pri_Ins_Payment ?? 0)) +
                                                         g.Max(x => (x.c.Sec_Ins_Payment ?? 0)) +
                                                         g.Max(x => (x.c.Oth_Ins_Payment ?? 0)),
                                      BatchOpenDate = g.Key.BatchOpenDate,

                                      TotalAmtPaidForBatchID = db.Claim_Payments
                                        .Where(cp2 => cp2.BATCH_NO == batchID && (cp2.Deleted == null || cp2.Deleted == false))
                                        .Sum(cp2 => (decimal?)cp2.Amount_Paid) ?? 0
                                  }).ToList();

                    if (claims.Any())
                    {
                        responseModel.Status = "Success";
                        responseModel.Response = claims;
                    }
                    else
                    {
                        responseModel.Status = "Error";
                        responseModel.Response = "No claims found for the given batch ID.";
                    }
                }
            }
            catch (Exception ex)
            {
                responseModel.Status = "Error";
                responseModel.Response = ex.Message;
            }

            return responseModel;
        }

        public ResponseModel GetBatchPaymentSummary(string batchID)
        {
            ResponseModel responseModel = new ResponseModel();
            try
            {
                using (var db = new NPMDBEntities())
                {
                    var summary = db.Claim_Payments
                        .Where(cp => cp.BATCH_NO == batchID)
                        .GroupBy(cp => cp.BATCH_NO)
                        .Select(g => new
                        {
                            BatchID = g.Key,
                            TotalAmountPaid = g.Sum(x => (decimal?)x.Amount_Paid) ?? 0,
                            TotalAdjusted = g.Sum(x => (decimal?)x.Amount_Adjusted) ?? 0,
                            TotalApproved = g.Sum(x => (decimal?)x.Amount_Approved) ?? 0,
                            TotalRejected = g.Sum(x => (decimal?)x.Reject_Amount) ?? 0,
                            Count = g.Count()
                        })
                        .FirstOrDefault();

                    if (summary != null)
                    {
                        responseModel.Status = "Success";
                        responseModel.Response = summary;
                    }
                    else
                    {
                        responseModel.Status = "Error";
                        responseModel.Response = "No payments found for this batch.";
                    }
                }
            }
            catch (Exception ex)
            {
                responseModel.Status = "Error";
                responseModel.Response = ex.Message;
            }

            return responseModel;
        }

        //post paymnets
        public ResponseModel PostPayments(ClaimsViewModel ClaimModel, long batchID, string batchDate)
        {
            ResponseModel response = new ResponseModel();

            // Validate input
            //if (batchData == null)
            {
                response.Status = "Error";
                response.Response = "Invalid batch data.";
                return response;
            }
            try
            {
                using (var db = new NPMDBEntities())
                {
                    using (var ctx = new NPMDBEntities())
                    {
                        using (var transaction = ctx.Database.BeginTransaction())
                        {
                            try
                            {
                                // Check if the batch already exists in the BATCHWISEPAYMENTS table
                                var existingBatch = db.Batch_WisePayments.FirstOrDefault(x => x.BatchID == 123);

                                if (existingBatch != null)
                                {
                                    // Update existing batch
                                    //existingBatch.BatchType = batchData.BatchType;
                                    //existingBatch.Practice_Code = batchData.Practice_Code;
                                    //existingBatch.PaymentType = batchData.PaymentType;
                                    //existingBatch.CheckNo = batchData.CheckNo;
                                    //existingBatch.CheckDate = batchData.CheckDate;
                                    //existingBatch.FileName = batchData.FileName;
                                    //existingBatch.BatchOpenDate = batchData.BatchOpenDate;
                                    //existingBatch.DepositDate = batchData.DepositDate;
                                    //existingBatch.ReceivedDate = batchData.ReceivedDate;
                                    //existingBatch.NOtes = batchData.NOtes;
                                    //existingBatch.BatchAmount = batchData.BatchAmount;
                                    //existingBatch.modified_by = userId;
                                    //existingBatch.date_modified = DateTime.Now;
                                    //existingBatch.Batch_Status = batchData.BatchStatus;
                                    //existingBatch.Remaining_Amount = batchData.RemainingAmount;
                                    //existingBatch.Posted_Amount = batchData.PostedAmount;
                                }
                                else
                                {
                                    // Create new batch
                                    var newBatch = new Batch_WisePayments
                                    {
                                        BatchID = Convert.ToInt64(ctx.SP_TableIdGenerator("BatchID").FirstOrDefault().ToString()),
                                        //Practice_Code = batchData.Practice_Code,
                                        //BatchType = batchData.BatchType,
                                        //PaymentType = batchData.PaymentType,
                                        //CheckNo = batchData.CheckNo,
                                        //CheckDate = batchData.CheckDate,
                                        //FileName = batchData.FileName,
                                        //BatchOpenDate = batchData.BatchOpenDate,
                                        //DepositDate = batchData.DepositDate,
                                        //ReceivedDate = batchData.ReceivedDate,
                                        //NOtes = batchData.NOtes,
                                        //BatchAmount = batchData.BatchAmount,
                                        //created_by = userId,
                                        //date_created = DateTime.Now,
                                        //Batch_Status = batchData.BatchStatus,
                                        //Remaining_Amount = batchData.RemainingAmount,
                                        //Posted_Amount = batchData.PostedAmount
                                    };
                                    db.Batch_WisePayments.Add(newBatch);
                                }

                                // Save changes
                                db.SaveChanges();
                                transaction.Commit();

                                response.Status = "Success";
                                response.Response = "Batch created/updated successfully.";
                            }
                            catch (Exception ex)
                            {
                                // Rollback on error
                                transaction.Rollback();
                                response.Status = "Error";
                                response.Response = "Failed to process batch: " + ex.Message;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                response.Status = "Error";
                response.Response = "An unexpected error occurred: " + ex.Message;
            }

            return response;
        }



        public ResponseModel GetBatchType(long batchID)
        {
            ResponseModel response = new ResponseModel();
            try
            {
                using (var db = new NPMDBEntities())
                {
                    var BatchStatus = db.Batch_WisePayments
                                      .Where(b => b.BatchID == batchID && (b.Deleted == null || b.Deleted == false))
                                      .Select(b => b.Batch_Status)
                                      .FirstOrDefault();

                    if (BatchStatus != null)
                    {
                        response.Status = "Success";
                        response.Response = BatchStatus;
                    }
                    else
                    {
                        response.Status = "Error";
                        response.Response = "Batch ID not found";
                    }
                }
            }
            catch (Exception ex)
            {
                response.Status = "Error";
                response.Response = ex.Message;
            }

            return response;
        }
        //
        public ResponseModel GetBatchCheckDetail(long batchID)
        {
            ResponseModel response = new ResponseModel();
            try
            {
                using (var db = new NPMDBEntities())
                {
                    var BatchStatus = db.Batch_WisePayments
                                      .Where(b => b.BatchID == batchID && (b.Deleted == null || b.Deleted ==false))
                                      .Select(b => new
                                      {
                                          b.CheckNo,
                                          b.CheckDate,
                                          b.BatchOpenDate,
                                          b.DepositDate
                                      }
                                      )
                                      .FirstOrDefault();

                    if (BatchStatus != null)
                    {
                        response.Status = "Success";
                        response.Response = BatchStatus;
                    }
                    else
                    {
                        response.Status = "Error";
                        response.Response = "Batch ID not found";
                    }
                }
            }
            catch (Exception ex)
            {
                response.Status = "Error";
                response.Response = ex.Message;
            }

            return response;
        }
        //public ResponseModel DeleteClaimPayment(string batchID, long claimNo)
        //{
        //    ResponseModel response = new ResponseModel();
        //    try
        //    {
        //        using (var db = new NPMDBEntities())
        //        {
        //            var paymentToDelete = db.Claim_Payments
        //                .FirstOrDefault(cp => cp.BATCH_NO == batchID && cp.Claim_No == claimNo);

        //            if (paymentToDelete != null)
        //            {
        //                paymentToDelete.Deleted = true; // or = 1 if it's an int column
        //                db.SaveChanges();

        //                response.Status = "Success";
        //                response.Response = "Claim payment deleted successfully.";
        //            }
        //            else
        //            {
        //                response.Status = "Error";
        //                response.Response = "No matching record found for the given Batch ID and Claim No.";
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        response.Status = "Error";
        //        response.Response = ex.Message;
        //    }

        //    return response;
        //}
        //public ResponseModel DeleteClaimPayment(string batchID, long claimNo)
        //{
        //    ResponseModel response = new ResponseModel();
        //    try
        //    {
        //        using (var db = new NPMDBEntities())
        //        {
        //            // Fetch all records matching the given batchID and claimNo
        //            var paymentsToDelete = db.Claim_Payments
        //                .Where(cp => cp.BATCH_NO == batchID && cp.Claim_No == claimNo)
        //                .ToList();

        //            if (paymentsToDelete.Any())
        //            {
        //                // Mark each record as Deleted
        //                foreach (var payment in paymentsToDelete)
        //                {
        //                    payment.Deleted = true; // Set to true for BIT column
        //                    db.Entry(payment).State = System.Data.Entity.EntityState.Modified;
        //                }

        //                db.SaveChanges(); // Save all changes in one go

        //                response.Status = "Success";
        //                response.Response = $"{paymentsToDelete.Count} claim payment(s) marked as deleted successfully.";
        //            }
        //            else
        //            {
        //                response.Status = "Error";
        //                response.Response = "No matching records found for the given Batch ID and Claim No.";
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        response.Status = "Error";
        //        response.Response = ex.Message;
        //    }

        //    return response;
        //}
        //public ResponseModel DeleteClaimPayment(string batchID, long claimNo,string Amtdue, long userId)
        // {
        //    ResponseModel response = new ResponseModel();
        //    try
        //    {
        //        using (var db = new NPMDBEntities())
        //        {
        //            var paymentsToDelete = db.Claim_Payments
        //                .Where(cp => cp.BATCH_NO == batchID && cp.Claim_No == claimNo && cp.Deleted == false)
        //                .ToList();
        //            var Claimspayments = db.Claim_Payments
        //                .Where(cp => cp.Claim_No == claimNo && (cp.Deleted == false || cp.Deleted == null) && cp.BATCH_NO == null)
        //                .ToList();
        //            if (paymentsToDelete.Any())
        //            {
        //                var claim = db.Claims.FirstOrDefault(c => c.Claim_No == claimNo && (c.Deleted == null || c.Deleted == false));
        //                if (claim == null)
        //                {
        //                    response.Status = "Error";
        //                    response.Response = "Associated claim not found.";
        //                    return response;
        //                }
        //                var invoiceId = db.SyncedClaims
        //            .Where(x => x.Claim_no == claimNo)
        //            .FirstOrDefault()?.GeneratedId;
        //                if (invoiceId != null)
        //                {
        //                    BaseResponse deleteResponse = DeleteInboxInvoice(invoiceId.Value);
        //                    if (deleteResponse.IsSuccessful)
        //                    {
        //                        var query = "DELETE FROM SyncedClaims WHERE Claim_no = @ClaimNumber";
        //                        var result = db.Database.ExecuteSqlCommand(query, new SqlParameter("@ClaimNumber", claimNo));
        //                        if (result >= 0)
        //                        {
        //                            // Deleting from syncedclaimcharges
        //                            var claimCharges = db.Claim_Charges.Where(x => x.Claim_No == claimNo).ToList();

        //                            if (claimCharges != null && claimCharges.Count > 0)
        //                            {
        //                                foreach (var charge in claimCharges)
        //                                {
        //                                    if (charge.claim_charges_id != null)
        //                                    {
        //                                        var q = "DELETE FROM syncedclaimcharges WHERE claim_charges_id = @id";
        //                                        db.Database.ExecuteSqlCommand(q, new SqlParameter("@id", charge.claim_charges_id));
        //                                    }
        //                                }
        //                            }
        //                            // Deleting from syncedclaimpayments
        //                            var claimPayments = db.Claim_Payments.Where(x => x.Claim_No == claimNo).ToList();
        //                            foreach (var payments in claimPayments)
        //                            {
        //                                if (payments.claim_payments_id != null)
        //                                {
        //                                    var queryPayments = "DELETE FROM syncedclaimpayments WHERE claim_payments_id = @Payment_id";
        //                                    db.Database.ExecuteSqlCommand(queryPayments, new SqlParameter("@Payment_id", payments.claim_payments_id));
        //                                }
        //                            }
        //                        }
        //                    }
        //                }
        //                decimal totalAdjustmentAndPaid = 0;

        //                foreach (var payment in Claimspayments)
        //                {
        //                    totalAdjustmentAndPaid += (payment.Amount_Paid ?? 0) + (payment.Amount_Adjusted ?? 0);
        //                }

        //                var amtdue = (claim.Claim_Total ?? 0) - totalAdjustmentAndPaid;

        //                foreach (var payment in paymentsToDelete)
        //                {

        //                    //Added By hamza Akhlaq For Credit balance
        //                    if (payment.claim_payments_id != 0)
        //                    {
        //                        var cp = db.Claim_Payments.Find(payment.claim_payments_id);
        //                        if (cp != null)
        //                        {

        //                                cp.Deleted = true;
        //                                if (payment.Payment_Source == "T")
        //                                {
        //                                    var transferpayment = db.Claim_Payments.FirstOrDefault(p => p.T_payment_id == cp.claim_payments_id);
        //                                    if (transferpayment != null)
        //                                    {
        //                                        transferpayment.Deleted = true;
        //                                        var targetclaim = db.Claims.FirstOrDefault(c => c.Claim_No == transferpayment.Claim_No);
        //                                        targetclaim.Amt_Due = targetclaim.Amt_Due + transferpayment.Amount_Paid;
        //                                        targetclaim.Amt_Paid = targetclaim.Amt_Paid - transferpayment.Amount_Paid;
        //                                    if (transferpayment.Payment_Source == "T" && transferpayment.Amount_Paid > 0)
        //                                    {
        //                                        if (targetclaim.Patient_Payment > 0)
        //                                        {
        //                                             targetclaim.Patient_Payment = targetclaim.Patient_Payment - transferpayment.Amount_Paid;
        //                                        }
        //                                    }
        //                                    // targetclaim.Patient_Payment = targetclaim.Patient_Payment - transferpayment.Amount_Paid;
        //                                    List<CLAIM_NOTES> cLAIM_NOTEs = new List<CLAIM_NOTES>();
        //                                        cLAIM_NOTEs.Add(new CLAIM_NOTES
        //                                        {
        //                                            Claim_Notes_Id = Convert.ToInt64(db.SP_TableIdGenerator("Claim_Notes_Id").FirstOrDefault().ToString()),
        //                                            Claim_No = cp.Claim_No,
        //                                            IsAuto_Note = true,
        //                                            Note_Detail = $"The Transfer Credit Balance entry has been removed from the claim associated with Batch ID [{cp.BATCH_NO}].",
        //                                            Created_By = userId,
        //                                            Created_Date = DateTime.Now
        //                                        });

        //                                        cLAIM_NOTEs.Add(new CLAIM_NOTES
        //                                        {
        //                                            Claim_Notes_Id = Convert.ToInt64(db.SP_TableIdGenerator("Claim_Notes_Id").FirstOrDefault().ToString()),
        //                                            Claim_No = transferpayment.Claim_No,
        //                                            IsAuto_Note = true,
        //                                            Note_Detail = $"Transfer Credit Balance entry removed from the claim due to deletion of same entry from the source claim [{cp.Claim_No}] associated with Batch ID [{transferpayment.BATCH_NO}]",
        //                                            Created_By = userId,
        //                                            Created_Date = DateTime.Now
        //                                        });
        //                                        db.CLAIM_NOTES.AddRange(cLAIM_NOTEs);


        //                                };


        //                            }

        //                        }


        //                    }

        //                        // Reverse payment impact
        //                        if (payment.Payment_Source == "1")
        //                            claim.Pri_Ins_Payment -= payment.Amount_Paid;
        //                        else if (payment.Payment_Source == "2")
        //                            claim.Sec_Ins_Payment -= payment.Amount_Paid;
        //                        else if (payment.Payment_Source == "3")
        //                            claim.Oth_Ins_Payment -= payment.Amount_Paid;
        //                        else if ((payment.Payment_Source == "P" || payment.Payment_Source == "I" || payment.Payment_Source == "C" || payment.Payment_Source == "T")&& claim.Patient_Payment != 0)
        //                            claim.Patient_Payment -= payment.Amount_Paid;
        //                  //  else if(payment.Payment_Source == "T"&& payment.Amount_Paid < 0)
        //                  //  {
        //                  //      if (claim.Patient_Payment > 0) {
        //                  //          decimal positiveAmount = Math.Abs(payment.Amount_Paid.Value); // convert negative to positive

        //                  //          claim.Patient_Payment = claim.Patient_Payment - positiveAmount; // subtract from patient payment
        //                  //      }

        //                  //  }
        //                  //else if (payment.Payment_Source == "T" && payment.Amount_Paid > 0)
        //                  //  {

        //                  //      if (claim.Patient_Payment>0)
        //                  //      {
        //                  //          claim.Patient_Payment -= payment.Amount_Paid;
        //                  //      }

        //                  //  }
        //                   claim.Adjustment -= (payment.Amount_Adjusted ?? 0);
        //                        claim.Amt_Paid -= payment.Amount_Paid;
        //                        //claim.Amt_Due = claim.Claim_Total;
        //                        claim.Amt_Due = amtdue;

        //                        // Mark deleted
        //                        payment.Deleted = true;
        //                        db.Entry(payment).State = System.Data.Entity.EntityState.Modified;
        //                    }

        //                    db.SaveChanges();
        //                    // Call the SP AFTER successful save
        //                    db.Database.ExecuteSqlCommand(
        //                        "EXEC USP_GetBatchPayments @PracticeCode, @BatchID, @FileName, @BatchStatus, @BatchType, @PostedBy, @PaymentStatus, @BatchDateFrom, @BatchDateTo, @PaymentType, @CheckNo",
        //                        new SqlParameter("@PracticeCode", DBNull.Value),
        //                        new SqlParameter("@BatchID", batchID),
        //                        new SqlParameter("@FileName", DBNull.Value),
        //                        new SqlParameter("@BatchStatus", DBNull.Value),
        //                        new SqlParameter("@BatchType", DBNull.Value),
        //                        new SqlParameter("@PostedBy", DBNull.Value),
        //                        new SqlParameter("@PaymentStatus", DBNull.Value),
        //                        new SqlParameter("@BatchDateFrom", DBNull.Value),
        //                        new SqlParameter("@BatchDateTo", DBNull.Value),
        //                        new SqlParameter("@PaymentType", DBNull.Value),
        //                        new SqlParameter("@CheckNo", DBNull.Value)
        //                    );
        //                    response.Status = "Success";
        //                    response.Response = amtdue;
        //                }

        //                var batchNo = batchID.ToString();

        //                if (!string.IsNullOrWhiteSpace(batchNo))
        //                {
        //                    db.Database.ExecuteSqlCommand("EXEC USP_SUMPOSTEDAMOUNT @BatchNo = {0}", batchNo);
        //                }


        //            else
        //            {
        //                    response.Status = "Error";
        //                    response.Response = "No matching records found for the given Batch ID and Claim No.";
        //                }
        //            }
        //        } 
        //    catch (Exception ex)
        //    {
        //        response.Status = "Error";
        //        response.Response = ex.Message;
        //    }

        //    return response;
        //}


        public ResponseModel DeleteClaimPayment(string batchID, long claimNo, string Amtdue, long userId)
        {
            ResponseModel response = new ResponseModel();
            try
            {
                using (var db = new NPMDBEntities())
                {
                    var paymentsToDelete = db.Claim_Payments
                        .Where(cp => cp.BATCH_NO == batchID && cp.Claim_No == claimNo && cp.Deleted == false)
                        .ToList();
                    var Claimspayments = db.Claim_Payments
                        .Where(cp => cp.Claim_No == claimNo && (cp.Deleted == false || cp.Deleted == null) && cp.BATCH_NO == null)
                        .ToList();
                    if (paymentsToDelete.Any())
                    {
                        var claim = db.Claims.FirstOrDefault(c => c.Claim_No == claimNo && (c.Deleted == null || c.Deleted == false));
                        if (claim == null)
                        {
                            response.Status = "Error";
                            response.Response = "Associated claim not found.";
                            return response;
                        }
                        var invoiceId = db.SyncedClaims
                    .Where(x => x.Claim_no == claimNo)
                    .FirstOrDefault()?.GeneratedId;
                        if (invoiceId != null)
                        {
                            BaseResponse deleteResponse = DeleteInboxInvoice(invoiceId.Value);
                            if (deleteResponse.IsSuccessful)
                            {
                                var query = "DELETE FROM SyncedClaims WHERE Claim_no = @ClaimNumber";
                                var result = db.Database.ExecuteSqlCommand(query, new SqlParameter("@ClaimNumber", claimNo));
                                if (result >= 0)
                                {
                                    // Deleting from syncedclaimcharges
                                    var claimCharges = db.Claim_Charges.Where(x => x.Claim_No == claimNo).ToList();

                                    if (claimCharges != null && claimCharges.Count > 0)
                                    {
                                        foreach (var charge in claimCharges)
                                        {
                                            if (charge.claim_charges_id != null)
                                            {
                                                var q = "DELETE FROM syncedclaimcharges WHERE claim_charges_id = @id";
                                                db.Database.ExecuteSqlCommand(q, new SqlParameter("@id", charge.claim_charges_id));
                                            }
                                        }
                                    }
                                    // Deleting from syncedclaimpayments
                                    var claimPayments = db.Claim_Payments.Where(x => x.Claim_No == claimNo).ToList();
                                    foreach (var payments in claimPayments)
                                    {
                                        if (payments.claim_payments_id != null)
                                        {
                                            var queryPayments = "DELETE FROM syncedclaimpayments WHERE claim_payments_id = @Payment_id";
                                            db.Database.ExecuteSqlCommand(queryPayments, new SqlParameter("@Payment_id", payments.claim_payments_id));
                                        }
                                    }
                                }
                            }
                        }
                        decimal totalAdjustmentAndPaid = 0;

                        foreach (var payment in Claimspayments)
                        {
                            totalAdjustmentAndPaid += (payment.Amount_Paid ?? 0) + (payment.Amount_Adjusted ?? 0);
                        }

                        var amtdue = (claim.Claim_Total ?? 0) - totalAdjustmentAndPaid;

                        foreach (var payment in paymentsToDelete)
                        {

                            //Added By hamza Akhlaq For Credit balance
                            if (payment.claim_payments_id != 0)
                            {
                                var cp = db.Claim_Payments.Find(payment.claim_payments_id);
                                if (cp != null)
                                {

                                    cp.Deleted = true;
                                    if (payment.Payment_Source == "T")
                                    {
                                        var transferpayment = db.Claim_Payments.FirstOrDefault(p => p.T_payment_id == cp.claim_payments_id);
                                        if (transferpayment != null)
                                        {
                                            transferpayment.Deleted = true;
                                            var targetclaim = db.Claims.FirstOrDefault(c => c.Claim_No == transferpayment.Claim_No);
                                            targetclaim.Amt_Due = targetclaim.Amt_Due + transferpayment.Amount_Paid;
                                            targetclaim.Amt_Paid = targetclaim.Amt_Paid - transferpayment.Amount_Paid;
                                            if (transferpayment.Payment_Source == "T" && transferpayment.Amount_Paid > 0)
                                            {
                                                if (targetclaim.Patient_Payment > 0)
                                                {
                                                    targetclaim.Patient_Payment = targetclaim.Patient_Payment - transferpayment.Amount_Paid;
                                                }
                                            }
                                            // targetclaim.Patient_Payment = targetclaim.Patient_Payment - transferpayment.Amount_Paid;
                                            List<CLAIM_NOTES> cLAIM_NOTEs = new List<CLAIM_NOTES>();
                                            cLAIM_NOTEs.Add(new CLAIM_NOTES
                                            {
                                                Claim_Notes_Id = Convert.ToInt64(db.SP_TableIdGenerator("Claim_Notes_Id").FirstOrDefault().ToString()),
                                                Claim_No = cp.Claim_No,
                                                IsAuto_Note = true,
                                                Note_Detail = $"The Transfer Credit Balance entry has been removed from the claim associated with Batch ID [{cp.BATCH_NO}].",
                                                Created_By = userId,
                                                Created_Date = DateTime.Now
                                            });

                                            cLAIM_NOTEs.Add(new CLAIM_NOTES
                                            {
                                                Claim_Notes_Id = Convert.ToInt64(db.SP_TableIdGenerator("Claim_Notes_Id").FirstOrDefault().ToString()),
                                                Claim_No = transferpayment.Claim_No,
                                                IsAuto_Note = true,
                                                Note_Detail = $"Transfer Credit Balance entry removed from the claim due to deletion of same entry from the source claim [{cp.Claim_No}] associated with Batch ID [{transferpayment.BATCH_NO}]",
                                                Created_By = userId,
                                                Created_Date = DateTime.Now
                                            });
                                            db.CLAIM_NOTES.AddRange(cLAIM_NOTEs);


                                        };


                                    }

                                }


                            }

                            // Reverse payment impact
                            if (payment.Payment_Source == "1")
                                claim.Pri_Ins_Payment -= payment.Amount_Paid;
                            else if (payment.Payment_Source == "2")
                                claim.Sec_Ins_Payment -= payment.Amount_Paid;
                            else if (payment.Payment_Source == "3")
                                claim.Oth_Ins_Payment -= payment.Amount_Paid;
                            else if ((payment.Payment_Source == "P" || payment.Payment_Source == "I" || payment.Payment_Source == "C" || payment.Payment_Source == "T") && claim.Patient_Payment != 0)
                                claim.Patient_Payment -= payment.Amount_Paid;
                            //  else if(payment.Payment_Source == "T"&& payment.Amount_Paid < 0)
                            //  {
                            //      if (claim.Patient_Payment > 0) {
                            //          decimal positiveAmount = Math.Abs(payment.Amount_Paid.Value); // convert negative to positive

                            //          claim.Patient_Payment = claim.Patient_Payment - positiveAmount; // subtract from patient payment
                            //      }

                            //  }
                            //else if (payment.Payment_Source == "T" && payment.Amount_Paid > 0)
                            //  {

                            //      if (claim.Patient_Payment>0)
                            //      {
                            //          claim.Patient_Payment -= payment.Amount_Paid;
                            //      }

                            //  }
                            claim.Adjustment -= (payment.Amount_Adjusted ?? 0);
                            claim.Amt_Paid -= payment.Amount_Paid;
                            //claim.Amt_Due = claim.Claim_Total;
                            claim.Amt_Due = amtdue;

                            // Mark deleted
                            payment.Deleted = true;
                            db.Entry(payment).State = System.Data.Entity.EntityState.Modified;
                        }

                        db.SaveChanges();
                        // Call the SP AFTER successful save
                        db.Database.ExecuteSqlCommand(
                            "EXEC USP_GetBatchPayments @PracticeCode, @BatchID, @FileName, @BatchStatus, @BatchType, @PostedBy, @PaymentStatus, @BatchDateFrom, @BatchDateTo, @PaymentType, @CheckNo",
                            new SqlParameter("@PracticeCode", DBNull.Value),
                            new SqlParameter("@BatchID", batchID),
                            new SqlParameter("@FileName", DBNull.Value),
                            new SqlParameter("@BatchStatus", DBNull.Value),
                            new SqlParameter("@BatchType", DBNull.Value),
                            new SqlParameter("@PostedBy", DBNull.Value),
                            new SqlParameter("@PaymentStatus", DBNull.Value),
                            new SqlParameter("@BatchDateFrom", DBNull.Value),
                            new SqlParameter("@BatchDateTo", DBNull.Value),
                            new SqlParameter("@PaymentType", DBNull.Value),
                            new SqlParameter("@CheckNo", DBNull.Value)
                        );
                        response.Status = "Success";
                        response.Response = amtdue;
                        // Sum of Amount_Paid + Amount_Adjusted across all non-deleted rows for a claim
                        decimal totalPaidAdjusted = 0;

                        var pay = db.Claim_Payments
                            .Where(p =>
                                p.Claim_No == claimNo &&
                                (p.Deleted == false || p.Deleted == null)
                            );

                        if (pay.Any())
                        {
                            totalPaidAdjusted = pay.Sum(p =>
                                (decimal?)p.Amount_Paid ?? 0 +
                                (decimal?)p.Amount_Adjusted ?? 0
                            );
                            // Step 2: Get total charges (example)
                            decimal totalCharges = db.Claims.Where(c => c.Claim_No == claimNo).Select(c => (decimal?)c.Claim_Total).FirstOrDefault() ?? 0;

                            // Step 3: Calculate amount due
                            decimal amtDue = totalCharges - totalPaidAdjusted;

                            // Step 4: Response
                            response.Status = "Success";
                            response.Response = amtDue;
                        }
               
                    }

                    var batchNo = batchID.ToString();

                    if (!string.IsNullOrWhiteSpace(batchNo))
                    {
                        db.Database.ExecuteSqlCommand("EXEC USP_SUMPOSTEDAMOUNT @BatchNo = {0}", batchNo);
                    }


                    else
                    {
                        response.Status = "Error";
                        response.Response = "No matching records found for the given Batch ID and Claim No.";
                    }
                }
            }
            catch (Exception ex)
            {
                response.Status = "Error";
                response.Response = ex.Message;
            }

            return response;
        }


        //auto closed batches-pir uabid

        public ResponseModel AutoCloseEligibleBatches()
        {
            ResponseModel response = new ResponseModel();
            try
            {
                using (var db = new NPMDBEntities())
                {
                    var today = DateTime.Now;
                    int currentMonth = today.Month;
                    int currentYear = today.Year;

                    // Step 1: Aggregate posted amounts
                    var postedAmounts = db.Claim_Payments
                        .Where(cp => cp.Deleted == null || cp.Deleted == false)
                        .GroupBy(cp => cp.BATCH_NO)
                        .Select(g => new
                        {
                            BatchNo = g.Key,
                            PostedAmount = g.Sum(x => (decimal?)x.Amount_Paid ?? 0)
                        })
                        .ToList();

                    // Step 2: Candidate batches
                    var candidateBatches = db.Batch_WisePayments
                        .Where(b =>
                            (b.Batch_Status == 1 || b.Batch_Status == 2) &&
                             (b.Deleted == null || b.Deleted == false) &&
                            b.BatchOpenDate.HasValue &&
                            (
                                b.BatchOpenDate.Value.Year < currentYear ||
                                (b.BatchOpenDate.Value.Year == currentYear &&
                                 b.BatchOpenDate.Value.Month < currentMonth)
                            )
                        )
                        .ToList();

                    // Step 3: Match posted amounts
                    var eligibleBatches = candidateBatches
                        .Where(b =>
                        b.Remaining_Amount != null && b.Remaining_Amount == 0)
                        .ToList();

                    // Step 4: Update
                    if (eligibleBatches.Any())
                    {
                        foreach (var batch in eligibleBatches)
                        {
                            batch.Batch_Status = 3; // AutoClosed
                            batch.date_modified = DateTime.Now;
                        }

                        db.SaveChanges();

                        response.Status = "Success";
                        response.Response = $"{eligibleBatches.Count} batch(es) auto-closed successfully.";
                    }
                    else
                    {
                        response.Status = "Success";
                        response.Response = "No eligible batches found to auto-close.";
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
                response.Status = "Error";
                response.Response = ex.Message;
            }

            return response;
        }


        //reopen the batch in existing month - pir ubaid

        public ResponseModel ReopenBatch(long BatchId, long userId)
        {
            var response = new ResponseModel();
            try
            {
                using (var db = new NPMDBEntities())
                {
                    var batch = db.Batch_WisePayments.FirstOrDefault(b => b.BatchID == BatchId && (b.Deleted == null || b.Deleted == false));

                    if (batch == null)
                    {
                        response.Status = "Error";
                        response.Response = "Batch not found.";
                        return response;
                    }

                    // Combine Closed Status + Same Month Check
                    if (batch.Batch_Status != 0 ||
                        (batch.BatchOpenDate.HasValue &&
                         (batch.BatchOpenDate.Value.Month != DateTime.Now.Month ||
                          batch.BatchOpenDate.Value.Year != DateTime.Now.Year)))
                    {
                        response.Status = "Error";
                        response.Response = (batch.Batch_Status != 0)
                            ? "Batch is not closed, cannot reopen."
                            : "Batch can only be reopened within the same month of closure.";
                        return response;
                    }

                    // Update status → Reopened (status 2)
                    batch.Batch_Status = 2;
                    batch.date_modified = DateTime.Now;
                    batch.modified_by = userId;

                    db.SaveChanges();

                    response.Status = "Success";
                    response.Response = "Batch reopened successfully.";
                }
            }
            catch (Exception ex)
            {
                response.Status = "Error";
                response.Response = ex.Message;
            }

            return response;
        }



        public ResponseModel GetCurrentResponsible(long claimId)
        {
            ResponseModel objResponse = new ResponseModel();
            try
            {

                using (var ctx = new NPMDBEntities())
                {
                    var claim = ctx.Claims.FirstOrDefault(c => c.Claim_No == claimId);

                    if (claim == null)
                    {
                        objResponse.Status = "Error";
                        objResponse.Response = "Claim not found";
                        return objResponse;
                    }

                    // Determine Current Responsible
                    string currentResponsible = "";
                    string status = "";

                    if (new[] { "N", "B", "R" }.Contains(claim.Pri_Status))
                    {
                        currentResponsible = "Primary Insurance";
                        status = claim.Pri_Status;
                    }
                    else if (new[] { "N", "B", "R" }.Contains(claim.Sec_Status))
                    {
                        currentResponsible = "Secondary Insurance";
                        status = claim.Sec_Status;
                    }
                    else if (new[] { "N", "B", "R" }.Contains(claim.Oth_Status))
                    {
                        currentResponsible = "Other Insurance";
                        status = claim.Oth_Status;
                    }
                    else if (new[] { "N", "B", "R", "D", "C" }.Contains(claim.Pat_Status))
                    {
                        currentResponsible = "Patient";
                        status = claim.Pat_Status;
                    }


                    objResponse.Status = "Success";
                    objResponse.Response = currentResponsible;
                }
            }
            catch (Exception ex)
            {
                objResponse.Status = "Error";
                objResponse.Response = ex;
            }
            return objResponse;


        }





        public BaseResponse DeleteInboxInvoice(long invoiceId)
        {
            BaseResponse res = new BaseResponse();
            if (invoiceId != null)
            {
                var invoicePayments = _deltaSyncRepository.GetPyments_Invoice(invoiceId);
                bool allPaymentsDeleted = true;

                for (int i = 0; i < (invoicePayments?.invoice_payments?.Count ?? 0); i++)
                {
                    if (invoicePayments.invoice_payments[i].payment_id != null)
                    {
                        var deleteInvoicepaymentsRequest = new DeleteInvoicepaymentsRequest();
                        var paymentId = invoicePayments.invoice_payments[i].payment_id;

                        deleteInvoicepaymentsRequest.id = invoicePayments.invoice_payments[i].id;
                        deleteInvoicepaymentsRequest.payment.voided = "true";

                        var deleteInvoicePaymentsResponse = _deltaSyncRepository.DeletePayments(deleteInvoicepaymentsRequest, paymentId);
                        if (!deleteInvoicePaymentsResponse.IsSuccessful)
                        {
                            allPaymentsDeleted = false;
                            break;
                        }
                    }
                }

                var deleteinvoice = _deltaSyncRepository.DeleteInvoice(invoiceId);
                res.IsSuccessful = deleteinvoice.IsSuccessful;
            }
            return res;
        }


        public ResponseModel GetBatchDate(long batchID)
        {
            ResponseModel response = new ResponseModel();
            try
            {
                using (var db = new NPMDBEntities())
                {
                    var BatchDate = db.Batch_WisePayments
                                      .Where(b => b.BatchID == batchID && (b.Deleted == null || b.Deleted == false))
                                      .Select(b => new
                                      {

                                          b.BatchOpenDate,
                                          b.CheckNo,
                                          b.CheckDate,
                                          b.DepositDate

                                      }
                                      )
                                      .FirstOrDefault();

                    if (BatchDate != null)
                    {
                        response.Status = "Success";
                        response.Response = BatchDate;
                    }
                    else
                    {
                        response.Status = "Error";
                        response.Response = "Batch ID not found";
                    }
                }
            }
            catch (Exception ex)
            {
                response.Status = "Error";
                response.Response = ex.Message;
            }

            return response;
        }

        public ResponseModel ValidateCheckNo(string CheckNo, long Practice_Code, DateTime BatchOpenDate, string PaymentType, long? BatchID = null)
        {
            ResponseModel response = new ResponseModel();

            try
            {
                using (var ctx = new NPMDBEntities())
                {
                    var month = BatchOpenDate.Month;
                    var year = BatchOpenDate.Year;

                    // Step 1: Find existing batch with same CheckNo, PaymentType, PracticeCode, same month/year
                    var existingBatch = ctx.Batch_WisePayments.FirstOrDefault(b =>
                        b.CheckNo == CheckNo &&
                        b.Practice_Code == Practice_Code &&
                        b.PaymentType == PaymentType &&
                        b.BatchOpenDate.Value.Month == month &&
                        b.BatchOpenDate.Value.Year == year &&
                        (b.Deleted ==null || b.Deleted == false)
                    );

                    // Step 2: Duplicate check for new batch
                    if (BatchID == null || BatchID == 0)
                    {
                        if (existingBatch != null)
                        {
                            response.Status = "Duplicate";
                            return response;
                        }
                    }
                    else
                    {
                        // Step 3: Updating existing batch
                        var currentBatch = ctx.Batch_WisePayments.FirstOrDefault(b => b.BatchID == BatchID && (b.Deleted == null || b.Deleted == false));

                        if (currentBatch != null)
                        {
                            // Only check duplicates if CheckNo was changed
                            if (existingBatch != null && existingBatch.BatchID != currentBatch.BatchID)
                            {
                                response.Status = "Duplicate";
                                return response;
                            }

                            //  Step 4: New condition — Prevent update if ERA already Posted or Applied
                            if (PaymentType == "E")
                            {
                                // Find ERA record with same CheckNo that’s already Posted (P) or Applied (A)
                                var eraRecord = ctx.ERASUMMARies
                                    .FirstOrDefault(e => e.CHECKNUMBER == currentBatch.CheckNo &&
                                                         (e.POSTED == "P" || e.POSTED == "A"));

                                if (eraRecord != null)
                                {
                                    response.Status = "Blocked";
                                    response.Response = "Cannot update this batch because ERA is already Posted or Applied.";
                                    return response;
                                }
                            }
                        }
                    }

                    response.Status = "OK";
                }
            }
            catch (Exception ex)
            {
                response.Status = "Error";
                response.Response = ex.Message;
            }

            return response;
        }

        public ResponseModel CheckIfBatchHasPayments(long batchID)
        {
            ResponseModel response = new ResponseModel();
            try
            {
                using (var db = new NPMDBEntities())
                {
                    // First, check if batch exists
                    var batch = db.Batch_WisePayments.FirstOrDefault(b => b.BatchID == batchID && (b.Deleted == null || b.Deleted == false));

                    if (batch != null)
                    {
                        // Check if any Claim_Payments or UnappliedPayments exist for this batch
                        bool hasPayments = db.Claim_Payments.Any(p => p.BATCH_NO == batchID.ToString() && (p.Deleted == null || p.Deleted == false))
                                        || db.Unapplied_Payments.Any(u => u.BATCH_NO == batchID.ToString() && !u.Deleted);

                        response.Status = "Success";
                        response.Response = hasPayments; // true or false
                    }
                    else
                    {
                        response.Status = "Error";
                        response.Response = "Batch ID not found";
                    }
                }
            }
            catch (Exception ex)
            {
                response.Status = "Error";
                response.Response = ex.Message;
            }

            return response;
        }

        public ResponseModel GetBatchChequeNoAndDate(long batchID)
        {
            ResponseModel response = new ResponseModel();
            try
            {
                using (var db = new NPMDBEntities())
                {
                    var BatchDate = db.Batch_WisePayments
                                      .Where(b => b.BatchID == batchID)
                                      .Select(b => new
                                      {

                                          b.CheckNo,
                                          b.CheckDate

                                      }
                                      )
                                      .FirstOrDefault();

                    if (BatchDate != null)
                    {
                        response.Status = "Success";
                        response.Response = BatchDate;
                    }
                    else
                    {
                        response.Status = "Error";
                        response.Response = "Batch ID not found";
                    }
                }
            }
            catch (Exception ex)
            {
                response.Status = "Error";
                response.Response = ex.Message;
            }

            return response;
        }


        public ResponseModel GetBatchPayments(long claimId)
        {
            ResponseModel response = new ResponseModel();

            try
            {
                using (var db = new NPMDBEntities())
                {
                    var claimPayments = db.Claim_Payments
                        .Where(c => c.Claim_No == claimId
                                 && c.BATCH_NO != null
                                 && c.Deleted != true)
                        .ToList();

                    response.Status = "Success";
                    response.Response = claimPayments;
                }
            }
            catch (Exception ex)
            {
                response.Status = "Error";
                response.Response = ex.Message;
            }
            return response; // <-- ALWAYS returns
        }
        //get payments detail after deleted
        public ResponseModel GetPayments(long claimId)
        {
            ResponseModel response = new ResponseModel();

            try
            {
                using (var db = new NPMDBEntities())
                {
                    var claimPayments = db.Claim_Payments
                        .Where(c => c.Claim_No == claimId
                         && c.Deleted != true)
                        .ToList();

                    response.Status = "Success";
                    response.Response = claimPayments;
                }
            }
            catch (Exception ex)
            {
                response.Status = "Error";
                response.Response = ex.Message;
            }
            return response; // <-- ALWAYS returns
        }
    }


}




