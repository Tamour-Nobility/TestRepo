﻿using System;
using System.Collections.Generic;

namespace NPMAPI.Repositories
{
    public class Repository : IRepository
    {
        public IEnumerable<string> GetAll()
        {
            throw new NotImplementedException();
        }
    }
}