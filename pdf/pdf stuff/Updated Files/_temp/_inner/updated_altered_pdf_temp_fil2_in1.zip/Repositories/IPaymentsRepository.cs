﻿using System;
using System.Collections.Generic;
using NPMAPI.Models;
using NPMAPI.Models.ViewModels;

namespace NPMAPI.Repositories
{
    public interface IPaymentsRepository
    {
        ResponseModel AddInsurancePayment(InsurancePaymentViewModel request);

        ResponseModel AddPatientPayment(PatientPayment request);

        List<SelectListViewModel> GetPaymentList();

        ResponseModel SearchPayment(PaymentsSearchRequestModel SearchModel);

        ResponseModel GetClaimsSummary(string ClaimId, string practiceCode);

        ResponseModel GetClaimBypatientdetials(patientBasedClaimModel request);

        ResponseModel GetClaimByinsdetials(insBasedClaimModel request);
        ResponseModel PostClaims(postClaim request);
        ResponseModel getClaimsDetails(long claimNo, long patientaccount);
        ResponseModel SaveClaimsDetails(ClaimsPaymentDetailModel[] cpd);
        ResponseModel checkPostedClaims(long batchno, long practiceCode);
         //payment posting batch wise - Pir Ubaid
        ResponseModel CreateUpdateBatch(BatchCreateModel batchData, long userId);
        ResponseModel SearchBatch(BatchsSearchRequestModel SearchModel);
        ResponseModel CloseBatch(BatchsSearchRequestModel SearchModel);
        ResponseModel GetPatientsWithDue(bool isDueOnly, int practiceCode);
        ResponseModel GetPatientsClaims(long patient_account, bool due_only);
        ResponseModel GetClaimDetails(long claimID);
        ResponseModel GetClaimDetailsByClaimNumber(long claimID, int practiceCode);
        ResponseModel GetPostedClaims(string batchID);
        ResponseModel PostPayments(ClaimsViewModel ClaimModel, long batchID, string batchDate);
        ResponseModel GetBatchPaymentSummary(string batchID);
        ResponseModel GetBatchType(long batchID);
        ResponseModel GetBatchCheckDetail(long batchID);
        ResponseModel GetBatchDate(long batchID);
        ResponseModel ValidateCheckNo(string CheckNo, long Practice_Code, DateTime BatchOpenDate, string PaymentType, long? BatchID = null);
        ResponseModel CheckIfBatchHasPayments(long batchID);
        ResponseModel DeleteClaimPayment(string batchID, long claimNo, string Amtdue, long userId);
        ResponseModel GetCurrentResponsible(long claimId);
        ResponseModel GetBatchPayments(long claimId);
        ResponseModel GetPayments(long claimId);
        ResponseModel AutoCloseEligibleBatches();
        ResponseModel ReopenBatch(long BatchId, long userId);

        ResponseModel GetBatchChequeNoAndDate(long batchID);




    }
}
