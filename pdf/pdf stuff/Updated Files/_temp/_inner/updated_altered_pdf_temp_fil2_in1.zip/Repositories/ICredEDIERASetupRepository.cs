﻿using NPMAPI.Models;
using NPMAPI.Models.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NPMAPI.Repositories
{
   public interface ICredEDIERASetupRepository
    {
        ResponseModel GetLookupLists();
        ResponseModel AddEditCredEDIERASetup(EDI_ERA_Setup eDI_ERA_Setup, long userId);
        ResponseModel GetCredEDIERASetupById(long id);
        ResponseModel AddEditCred_EDIERA_Notes(EDI_ERA_Notes eDI_ERA_Notes, long UserId);
        ResponseModel SearchCredEDIERASetup(EdiEraSetupSearchViewModel searchViewModel);
        ResponseModel GetCred_EDIERA_Notes(long applicationId);
        ResponseModel SaveCred_EDIERA_Document(CredAppDocumentRequest request);
        ResponseModel GetCred_EDIERA_Documents(long applicationId);
        ResponseModel GetCred_EDIERA_DocumentByDocId(long documentId);
        ResponseModel DeleteCred_EDIERA_Document(long documentId);
        ResponseModel AddTPAName(TPA_Name_List tPA_Name_List);
    }
}
