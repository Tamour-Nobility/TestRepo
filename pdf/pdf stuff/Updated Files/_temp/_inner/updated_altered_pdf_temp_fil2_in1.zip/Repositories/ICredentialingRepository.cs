﻿using NPMAPI.Models;
using NPMAPI.Models.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace NPMAPI.Repositories
{
    public interface ICredentialingRepository
    {
        ResponseModel GetLookupLists();
        ResponseModel AddEditCredApp(Cred_App_ViewModel cred_App_ViewModel, long userId);
        ResponseModel SearchCredApp(CredAppSearchViewModel searchViewModel);
        ResponseModel GetCredAppById(long Id);
        ResponseModel AddEditCredAppNote(Cred_App_Notes cred_App_Notes, long UserId);

        ResponseModel GetCredAppNotes(long applicationId);
        ResponseModel SaveCredAppDocument(CredAppDocumentRequest request);
        ResponseModel GetCredAppDocuments(long applicationId);
        ResponseModel GetCredAppDocumentByDocId(long documentId);
        ResponseModel DeleteCredAppDocument(long documentId);
        ResponseModel GetUsersByModuleName(string moduleName);
        ResponseModel CredAppReport(long practiceCode, int? objTypeId);
        ResponseModel GetUserListByRole(string Role, long practiceId);


        ResponseModel GetCredTasks(long? PracticeCode, long? UserId, int? Obj_Type_Id);
        ResponseModel GetUserByRole(string Role, long userId);
    }
}