﻿using NPMAPI.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace NPMAPI.Repositories
{
    public interface IClaimsAttachments
    {
        ResponseModel AttachemntSave(ClaimAttachmentRequest request, long userId);
        ResponseModel GetAllClaimAttachemnt(long patientAccount);
        ResponseModel GetAttachemnt(long Id);
        ResponseModel GetAttachmentTypeCodesList();
    }
}