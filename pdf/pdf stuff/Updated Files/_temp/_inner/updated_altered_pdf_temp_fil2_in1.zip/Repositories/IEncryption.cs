﻿using NPMAPI.Models;

namespace NPMAPI.Repositories
{
    public interface IEncryption
    {
        string HashPassword(string password);
        bool VerifyHashedPassword(string hashedPassword, string password);
        LoggedInUserbyCodeViewModel VerifyUser(string username, string password);
        LoggedInUserbyCodeViewModel VerifyUserResend(long userid);
        LoggedInUserViewModel VerifyUserCode(string code, long userid);
        ResponseModel VerifyPassword(long userId, string password);
        LoggedInUserbyCodeViewModel VerifyUserForResetPassword(string userEmail);

        ResponseModel GetPracticesClientBased(long ClientCode, long userId);
    }
}
